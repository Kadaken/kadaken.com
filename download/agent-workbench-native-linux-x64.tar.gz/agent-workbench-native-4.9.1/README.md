# Agent Workbench Native

**One desk for Claude, Codex, Gemini and your local models.**

AWBN is a Linux desktop app for people who work with AI coding agents. Instead of
juggling terminal windows, you get one window: your projects on the left, your
code in the middle, and the agent talking to you on the right — watching it edit
your files as it happens.

> **Public beta for modern Linux x86-64.** Automated tests and clean-package
> checks run before release, but this is still early software. Keep projects in
> version control, maintain backups, and report what breaks.
>
> Developer notes from the pre-beta era live in `docs/README-developer-notes.md`.

---

## What it does

**Watch the work happen.** When an agent writes a file, the tree lights up, the
file opens, and the text appears *as it is being written* — before it lands on
disk. Touching several files at once splits the viewer: two side by side, three
with one across the bottom, four in a grid.

**Run your installed clients from one place.** AWBN detects supported Claude
Code, Codex, Gemini, and Ollama installations. Other local command-line clients
can be added explicitly as custom adapters. Each chat keeps its own client,
model, and effort.

**Projects, not just chats.** Register a folder and it becomes a project: its own
chats, its own file tree, its own Run button. Loose chats stay in Conversations;
project chats live in their project. Nothing gets mixed up.

**See what it costs, live.** Tokens in, out, cache and tool spend tick upward
while the turn runs — with a click-through list of which tools were called.
Usage limits for each provider are one glance away.

**Edit alongside the agent.** Unlock a file in the viewer and type. Every save
keeps a restore point, and reverting shows you a before/after diff first. Keep
normal version-control history and backups as the durable source of recovery.

**Queue work.** Stack messages while a turn runs. Each queued message remembers
the model and effort you picked for it, and you can change them per message.

**Run your project.** One button launches the app, game or site you're building —
in its own window.

---

## Install

### AppImage (recommended)

```bash
chmod +x Agent_Workbench_Native-*.AppImage
./Agent_Workbench_Native-*.AppImage
```

### Debian / Ubuntu

```bash
sudo dpkg -i agent-workbench-native_*_amd64.deb
```

### Tarball (installs for your user only)

```bash
tar xzf agent-workbench-native-*-linux-x64.tar.gz
cd agent-workbench-native-*/
./install.sh
```

**Requirements:** modern Linux x86-64 (Ubuntu 22.04+, Debian 12+, or a current
Fedora-family release), Python 3.10+, `xdg-utils` (normally preinstalled by a
desktop environment), and at least one agent CLI
installed and signed in — [Claude Code](https://claude.com/claude-code),
[Codex](https://www.npmjs.com/package/@openai/codex), Gemini CLI, or
[Ollama](https://ollama.com) for local models. AWBN drives the CLIs you already
use and their normal sign-in flows. Optional saved-key and connector features
store only values the user deliberately enters.

---

## First run

1. Start it. The private local bridge and per-user token are created with it.
2. **Welcome to Agent Workbench** shows the supported clients found on your
   computer. Detection does not execute custom commands or verify sign-in.
3. Sign into a client in your normal terminal, then use **Rescan**. Add another
   compatible command under **Options → Clients**.
4. **Conversations → +** starts a free chat; **Projects → folder-plus** registers
   a project folder.
5. Inside a project: **+** starts a project chat, the **eye** follows the agent's
   file access, and the **lock** lets you edit by hand.

**Read next:** [the guide](docs/GUIDE.md) walks through the whole app in fifteen
minutes. [Everything it can do](docs/FEATURES.md) is the complete list.
[Privacy](docs/PRIVACY.md) and the [security model](docs/SECURITY_MODEL.md) state
the beta's data flows, boundaries, and limitations.

---

## Your data

**AWBN keeps its own state on your computer.**

Most state lives under `~/.config/agent-workbench-native/`: conversations,
attachments, registered project paths, notes, memory, artifacts, optional saved
keys, and token counts. Registered projects may also contain a gitignored
`.agent-workbench/` folder with mirrors or restore data.

AWBN has **no account, no sync, and no built-in telemetry**. Its bridge is local
to your machine. The app may still contact providers and sites you explicitly
use through their CLIs, custom clients, tools, connectors, and update checks.

The one thing that leaves your machine is **what you send to an agent**. That
goes to whichever CLI you signed into (Anthropic, OpenAI, Google) under that
provider's own terms, exactly as if you had typed it in a terminal. Ollama
inference is local, but an enabled model tool can access files or the network.

Delete a chat and AWBN removes its session, attachments, and artifacts. The
provider CLI may retain its own native transcript; manage that with the
provider's tools. To erase all AWBN data, close the app and bridge, remove the
app-data folder above, then remove `.agent-workbench/` from registered projects
where present. Options → **Your data** → **Open folder** opens app data.

Two honest caveats: conversations are stored **unencrypted**, like your source
code — use disk encryption if that matters. And a secret pasted into a chat is
now both on disk and at your agent provider, so don't paste secrets.

---

## Updates

Options → **Check for updates** opens the verified beta download page. In-place
installation is disabled until release manifests have an offline signature
whose public key is pinned in AWBN. Verify downloads with `SHA256SUMS`.

---

## Safety

- The bridge listens on **127.0.0.1 only**, behind a per-user token generated on
  first run.
- Claude uses approval prompts, Codex defaults to `workspace-write`, and Gemini
  uses its default approval mode. The unsafe override is an explicit choice.
- In default safe mode, local-model shell, app-launch, delegation, and connector
  actions are unavailable; protected credential paths remain denied.
- Credential paths — `~/.ssh`, `~/.aws`, `.env`, keyrings, agent auth files — are
  blocked from tool reads, writes and searches.
- The viewer can only write inside folders you registered as projects.
- Every manual viewer edit is snapshotted before it is overwritten.
- AI clients are never updated globally without the user's explicit action.

---

## Build from source

```bash
git clone https://github.com/LegendofZito/agent-workbench.git -b awbn-native
cd agent-workbench
./install-native.sh          # build + install for your user
./package-release.sh         # AppImage / tarball / .deb into dist/
```

Requires the Flutter SDK (defaults to `~/.local/share/flutter`, override with
`FLUTTER_BIN`). Tests: `python3 -m unittest discover tests`, and
`cd app && flutter test`.

---

## Reporting problems

Open an issue with: what you did, what happened, your distro, and which agent
CLI. Do not paste raw **Inspect**, diffs, logs, or configuration into a public
issue: they can contain code, paths, remotes, prompts, and secrets. Review and
redact any diagnostic excerpt before sharing it.

Free to use, but not open source. Agent Workbench Native is Kadaken's
software: install it and run it anywhere you like, at no charge, but do not
redistribute or modify it. **Want it to do something different? Write in.**
Bug reports and feature requests are the intended way to change it, and what
gets changed ships to everyone. See LICENSE for the exact terms.

Free while it is in beta. Later versions may be paid — see LICENSE.
