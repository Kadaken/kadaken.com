#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
target="$HOME/.local/share/agent-workbench-native"
mkdir -p "$target" "$HOME/.local/bin" "$HOME/.local/share/applications" \
    "$HOME/.local/share/icons/hicolor/256x256/apps"
cp -a "$here/." "$target/"
cat > "$HOME/.local/bin/agent-workbench-native" <<LAUNCH
#!/usr/bin/env bash
exec "$target/agent-workbench-native" "\$@"
LAUNCH
chmod 755 "$HOME/.local/bin/agent-workbench-native"
sed "s|^Exec=.*|Exec=$HOME/.local/bin/agent-workbench-native|" \
    "$here/agent-workbench-native.desktop" \
    > "$HOME/.local/share/applications/agent-workbench-native.desktop"
if [ -f "$here/awbn-icon.png" ]; then
    cp "$here/awbn-icon.png" \
        "$HOME/.local/share/icons/hicolor/256x256/apps/agent-workbench-native.png"
fi
echo "Installed. Run agent-workbench-native or open it from your app menu."
