# Public beta release checklist

## Automated gate

- Python tests, Flutter tests, Flutter analysis, and shell syntax pass.
- Release is built through `package-release.sh` from tracked files only.
- Package launchers, bridge runtime tools, version, and icon are present.
- Unpacked artifacts contain no maintainer home or checkout paths.
- `SHA256SUMS` matches every published artifact.

## Clean-machine gate

- Test AppImage on a clean supported Linux x86-64 account.
- Confirm the bridge token is created with mode `0600` before first UI request.
- Confirm “Welcome to Agent Workbench” appears and reports clients truthfully.
- Register a disposable project; chat, edit, restore, delete, and restart.
- Confirm drafts and the last active project/conversation survive restart.
- Confirm missing clients and failed provider sign-in produce useful errors.
- Confirm an unapproved Gemini or local-model shell action cannot run.
- Confirm deleting an active or dirty worker cannot erase uncommitted work.
- Confirm a viewer save detects a file changed after its preview was opened.
- Confirm a failed send restores the complete draft and attachments.
- Confirm a custom command containing a fake credential is redacted from logs.
- Confirm update checks and web tools reject loopback and private-network URLs.

## Publish gate

- Create a GitHub prerelease, not a stable release.
- Publish Linux x86-64 requirements and known limitations prominently.
- Publish Privacy, Security Model, license notices, and `SHA256SUMS`.
- Deploy the Cloudflare page and JSON manifest, then verify their content types,
  direct download URLs, sizes, and checksums from a second machine.
- Keep in-place updates disabled until offline manifest signing is implemented.
- Keep write-capable connectors experimental until per-call approval, audit,
  retry/idempotency, and cancellation behavior are covered by release tests.
