# Third-party notices

Flutter dependency notices are bundled in the application's generated
`NOTICES.Z` file.

Bundled fonts:

- JetBrains Mono — Copyright JetBrains; SIL Open Font License 1.1.
  Source: <https://github.com/JetBrains/JetBrainsMono>
- Source Code Pro — Copyright Adobe, with Reserved Font Name “Source”; SIL Open
  Font License 1.1. Source: <https://github.com/adobe-fonts/source-code-pro>
- VT323 — distributed by Google Fonts under the SIL Open Font License 1.1.
  Source: <https://fonts.google.com/specimen/VT323>

The complete SIL Open Font License 1.1 is included as `OFL-1.1.txt`.

Provider names and logos identify compatibility with independently installed
clients. Anthropic, OpenAI, Google, Ollama, Hermes, and their marks belong to
their respective owners. AWBN is not endorsed by those providers.
