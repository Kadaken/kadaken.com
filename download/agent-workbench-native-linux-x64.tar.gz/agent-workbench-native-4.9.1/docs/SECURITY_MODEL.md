# Security model

Agent Workbench Native (AWBN) is a local Linux desktop app that launches AI
client programs under the signed-in user's account. It is not a security
boundary around those programs: a client receives the permissions granted by
its own approval mode and operating-system sandbox.

## Trust boundary

- The Python bridge binds only to `127.0.0.1:8765`.
- Every control route except `/health` requires a random per-user token.
- The token and app data live under `~/.config/agent-workbench-native/` with
  directory mode `0700` and file mode `0600`.
- Requests carrying a foreign web Origin are rejected, even on localhost.
- AWBN has no account, built-in telemetry, or sync service. Its only inbound
  listener is the loopback bridge described above.

Remote providers, downloaded packages, Git remotes, MCP servers, custom client
commands, and agent-generated shell commands are outside this trust boundary.

## Client permissions

- Claude uses its structured permission requests in safe mode.
- Codex defaults to the `workspace-write` sandbox.
- Gemini uses its default approval mode. In headless mode, an action that cannot
  be approved fails rather than running with `--yolo`.
- In default safe mode, local models do not receive shell, app-launch,
  delegation, or connector tools. File tools stay inside the current workspace,
  and common credential and app-state paths remain blocked.
- The unsafe permission override is off by default and must be set explicitly.
- AWBN never silently updates a globally installed AI client.

Custom clients and MCP servers are executable code. Install only clients you
trust and review their own permission configuration. Never put an API key or
other secret directly in a custom command; use that client's credential store.
Write-capable connectors remain experimental during beta.

## Files and retention

AWBN stores chats, attachments, generated artifacts, registered project paths,
restore points, and settings locally. Data is not encrypted by AWBN; use full
disk encryption when needed. Saved keys are plaintext `0600` files inside the
private app-data directory. Prefer a provider CLI's own credential store.

Deleting an AWBN conversation removes its AWBN session file and AWBN-owned
attachments/artifacts. A provider's native transcript is controlled by that
provider's CLI and is not deleted automatically. Registered projects can
contain a gitignored `.agent-workbench/` directory; treat archives that include
ignored files as sensitive. Automatic `AGENT_STATE.md` memory is off on fresh
installs and must be enabled deliberately.

Attachment imports are bounded per file, request, and chat, preserve a free-disk
reserve, and land through an atomic private-file write. Clipboard capture is
also size-bounded so a hostile or accidental clipboard cannot consume unlimited
memory.

## Updates and releases

The beta checks a small HTTPS manifest for version information. In-place
updates are disabled until manifests have an offline signature with a public
key pinned in AWBN. Users download beta updates manually and verify the
published `SHA256SUMS`. A checksum detects corruption; it is not a substitute
for code signing.

Release builds are created from tracked files in a private neutral temporary
directory, scanned for the maintainer's filesystem path, and distributed with
checksums. The current beta target is modern Linux x86-64 only.

## Remaining risk

An AI client can make incorrect or destructive changes within permissions the
user grants. Keep work in version control, review diffs and the Work Log, avoid
running multiple writers against the same uncommitted file, and maintain
backups. Do not paste secrets into a provider-backed chat.

Report security issues privately to the contact listed on the release page.
