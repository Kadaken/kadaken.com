# Privacy

Agent Workbench Native has no AWBN account, telemetry, advertising, analytics,
or cloud sync.

## Data kept on this computer

AWBN stores conversations, attachments, generated artifacts, settings,
registered project paths, and optional saved keys under
`~/.config/agent-workbench-native/`. Registered projects may also contain a
gitignored `.agent-workbench/` folder with chat mirrors or restore data. These
files are private to the local user but are not encrypted by AWBN.

## Data that can leave this computer

- Prompts, attached content, and relevant context sent through Claude Code,
  Codex, Gemini, or another cloud-backed CLI go to that CLI's provider under
  the user's provider account and terms.
- A local Ollama model normally stays local, but tools it invokes can access the
  network when the user approves them.
- Checking for an AWBN update fetches a public JSON file and sends ordinary web
  request metadata such as an IP address to the hosting provider.
- Custom clients, MCP servers, connectors, and commands have their own data
  behavior. AWBN cannot make an untrusted extension private.

## Deletion

Deleting a conversation removes AWBN's session and AWBN-owned attachments and
artifacts. Native client history is imported only by explicit user action and
remains controlled by that client. To remove all AWBN data, close the app and
bridge, remove `~/.config/agent-workbench-native/`, and remove
`.agent-workbench/` directories from registered projects. Removing a project
from the list does not delete the project.

Do not paste credentials into chat. Prefer provider login flows and an
encrypted disk.
