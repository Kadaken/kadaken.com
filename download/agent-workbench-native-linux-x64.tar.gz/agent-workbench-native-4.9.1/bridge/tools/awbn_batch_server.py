#!/usr/bin/env python3
"""Batch tools for Agent Workbench — one call instead of thirty shell commands.

Why this exists
---------------
Asked to "run through all the images and make them smooth", a client shells out
once per file. A real run measured 30 shell commands in a single turn, each one
re-sending the whole conversation, and every command's output landing back in
the context window. The work was small; the cost was not.

These tools do the whole sweep in ONE call and return a short summary instead of
thirty transcripts. The saving is the returned text as much as the round trips.

Everything here is deliberately boring: no dependencies beyond ImageMagick
(already installed) and the standard library, so there is nothing to break.

Safety
------
- Every path is resolved and must sit under the `root` the caller names.
- Anything that changes files defaults to `dry_run: true` and reports what it
  WOULD do. The caller has to ask twice.
- Anything that changes files writes a backup folder first, and says where.
- A cap on how many files one call may touch, so a bad glob cannot run away.

Protocol: JSON-RPC 2.0 over stdio, newline-delimited (MCP stdio transport).
stdout is the JSON-RPC channel ONLY; logging goes to stderr.
"""
import fnmatch
import json
import os
import shutil
import subprocess
import sys
import time

PROTO_DEFAULT = "2024-11-05"
# One call must not be able to rewrite a whole disk. A sweep bigger than this is
# a sign the glob is wrong, and saying so beats doing it.
MAX_FILES = 500
# Folders that are never the user's own work.
SKIP_DIRS = {
    ".git", ".godot", "node_modules", "build", "dist", "target",
    "__pycache__", ".venv", "venv", ".dart_tool", ".svelte-kit", ".next",
}
IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".avif")


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def under_root(root, path):
    """Resolve `path` and refuse anything outside `root`."""
    root_real = os.path.realpath(os.path.abspath(os.path.expanduser(root)))
    if not os.path.isdir(root_real):
        raise ValueError(f"not a folder: {root}")
    candidate = os.path.abspath(os.path.expanduser(path))
    if not os.path.isabs(path):
        candidate = os.path.abspath(os.path.join(root_real, path))
    real = os.path.realpath(candidate)
    if os.path.commonpath([root_real, real]) != root_real:
        raise ValueError(f"outside the project: {path}")
    return real


def collect(root, pattern, only_images=False):
    """Files under `root` matching `pattern`, newest-safe and capped."""
    root_real = os.path.realpath(os.path.abspath(os.path.expanduser(root)))
    if not os.path.isdir(root_real):
        raise ValueError(f"not a folder: {root}")
    found = []
    for dirpath, dirnames, filenames in os.walk(root_real):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        # Never sweep our own backups back into a job.
        dirnames[:] = [d for d in dirnames if not d.startswith("_awbn-backup-")]
        for name in filenames:
            full = os.path.join(dirpath, name)
            rel = os.path.relpath(full, root_real)
            if only_images and not name.lower().endswith(IMAGE_SUFFIXES):
                continue
            if pattern and not (fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(name, pattern)):
                continue
            found.append(full)
    found.sort()
    return found


def backup_dir(root, label):
    stamp = time.strftime("%Y%m%d-%H%M%S")
    folder = os.path.join(root, f"_awbn-backup-{label}-{stamp}")
    os.makedirs(folder, exist_ok=True)
    return folder


def magick(args):
    """Run ImageMagick, returning (ok, message)."""
    exe = shutil.which("magick") or shutil.which("convert")
    if not exe:
        return False, "ImageMagick is not installed"
    try:
        done = subprocess.run(
            [exe, *args], capture_output=True, text=True, timeout=120
        )
    except subprocess.TimeoutExpired:
        return False, "timed out"
    if done.returncode != 0:
        return False, (done.stderr or done.stdout or "failed").strip()[:200]
    return True, (done.stdout or "").strip()


# --------------------------------------------------------------------------
# the tools


def tool_find_files(root, pattern="", only_images=False, limit=200):
    """What is there, before anything is changed."""
    files = collect(root, pattern, only_images)
    rows = []
    for path in files[:limit]:
        try:
            size = os.path.getsize(path)
        except OSError:
            continue
        rows.append({"path": os.path.relpath(path, root), "bytes": size})
    return {
        "root": root,
        "matched": len(files),
        "shown": len(rows),
        "truncated": len(files) > len(rows),
        "files": rows,
    }


def tool_image_info(root, pattern="", limit=200):
    """Size, format and transparency for many images in one call."""
    files = collect(root, pattern, only_images=True)[:limit]
    rows = []
    for path in files:
        ok, out = magick(["identify", "-format", "%w %h %m %A", path])
        if not ok:
            rows.append({"path": os.path.relpath(path, root), "error": out})
            continue
        bits = out.split()
        rows.append({
            "path": os.path.relpath(path, root),
            "width": int(bits[0]) if bits and bits[0].isdigit() else None,
            "height": int(bits[1]) if len(bits) > 1 and bits[1].isdigit() else None,
            "format": bits[2] if len(bits) > 2 else "",
            "alpha": bits[3] if len(bits) > 3 else "",
        })
    return {"root": root, "count": len(rows), "images": rows}


def tool_batch_resize(root, pattern, max_edge, dry_run=True):
    """Shrink every matching image so its longest side is `max_edge`."""
    files = collect(root, pattern, only_images=True)
    if len(files) > MAX_FILES:
        raise ValueError(f"{len(files)} files match — too many for one call")
    plan, done, failed = [], [], []
    folder = None if dry_run else backup_dir(root, "resize")
    for path in files:
        rel = os.path.relpath(path, root)
        ok, out = magick(["identify", "-format", "%w %h", path])
        if not ok:
            failed.append({"path": rel, "why": out})
            continue
        try:
            w, h = (int(x) for x in out.split()[:2])
        except (ValueError, IndexError):
            failed.append({"path": rel, "why": "unreadable size"})
            continue
        if max(w, h) <= max_edge:
            continue
        if dry_run:
            plan.append({"path": rel, "from": f"{w}x{h}", "to_max_edge": max_edge})
            continue
        shutil.copy2(path, os.path.join(folder, os.path.basename(path)))
        ok, out = magick([path, "-resize", f"{max_edge}x{max_edge}>", path])
        (done if ok else failed).append(
            {"path": rel, "from": f"{w}x{h}"} if ok else {"path": rel, "why": out}
        )
    return {
        "dry_run": dry_run,
        "matched": len(files),
        "would_change" if dry_run else "changed": plan if dry_run else done,
        "failed": failed,
        "backup": folder,
    }


def tool_strip_halo(root, pattern, dry_run=True):
    """Remove a pale drop shadow baked into an icon for a white background.

    The exact job that started this: fourteen sidebar icons each carrying a
    light-grey shelf drawn for a white page, which reads as a bright smear on a
    dark interface. Grey, desaturated, in the bottom fifth — the artwork itself
    is coloured, so hue is a safer test than position alone.
    """
    files = collect(root, pattern, only_images=True)
    if len(files) > MAX_FILES:
        raise ValueError(f"{len(files)} files match — too many for one call")
    halo = "a>0.02 && a<0.96 && (r+g+b)/3>0.78 ? 0 : a"
    shelf = "j > h*0.78 && (r+g+b)/3 > 0.62 && (max(max(r,g),b)-min(min(r,g),b)) < 0.14 ? 0 : a"
    rows, failed = [], []
    folder = None if dry_run else backup_dir(root, "halo")
    for path in files:
        rel = os.path.relpath(path, root)
        ok, out = magick([
            path, "-channel", "RGBA", "-fx",
            "a>0.05 && a<0.95 && (r+g+b)/3>0.80 ? 1 : 0",
            "-format", "%[fx:int(mean*w*h)]", "info:",
        ])
        before = int(out) if ok and out.strip().isdigit() else 0
        if dry_run:
            if before:
                rows.append({"path": rel, "halo_pixels": before})
            continue
        shutil.copy2(path, os.path.join(folder, os.path.basename(path)))
        good = True
        for expr in (halo, shelf):
            ok, out = magick([
                path, "-alpha", "on", "-channel", "RGBA", "-fx", expr,
                "-write", "mpr:k", "+delete",
                path, "mpr:k", "-alpha", "off",
                "-compose", "CopyOpacity", "-composite", path,
            ])
            if not ok:
                failed.append({"path": rel, "why": out})
                good = False
                break
        if good:
            rows.append({"path": rel, "halo_pixels_before": before})
    return {
        "dry_run": dry_run,
        "matched": len(files),
        "with_halo" if dry_run else "cleaned": rows,
        "failed": failed,
        "backup": folder,
    }


def tool_find_in_files(root, text, pattern="", limit=200):
    """Which files contain `text`, and how often — without reading them all."""
    files = collect(root, pattern)
    hits = []
    scanned = 0
    for path in files:
        if len(hits) >= limit:
            break
        try:
            if os.path.getsize(path) > 4_000_000:
                continue
            with open(path, encoding="utf-8", errors="ignore") as handle:
                body = handle.read()
        except OSError:
            continue
        scanned += 1
        count = body.count(text)
        if count:
            hits.append({"path": os.path.relpath(path, root), "matches": count})
    return {"root": root, "scanned": scanned, "files_with_matches": len(hits), "hits": hits}


def tool_batch_replace(root, pattern, find, replace, dry_run=True, limit=200):
    """Change the same text across many files at once.

    The document half of batch work: "several documents" changed in one call
    rather than one edit per file. Dry run reports every file and how many
    times the text appears, so the sweep can be checked BEFORE it happens —
    which is the whole difference between this and a find/replace you regret.
    """
    files = collect(root, pattern)
    if len(files) > MAX_FILES:
        raise ValueError(f"{len(files)} files match — too many for one call")
    if not find:
        raise ValueError("nothing to find")
    plan, done, failed = [], [], []
    folder = None if dry_run else backup_dir(root, "replace")
    for path in files:
        rel = os.path.relpath(path, root)
        try:
            if os.path.getsize(path) > 4_000_000:
                continue
            with open(path, encoding="utf-8", errors="strict") as handle:
                body = handle.read()
        except (OSError, UnicodeDecodeError):
            continue  # binary or unreadable — not a document
        count = body.count(find)
        if not count:
            continue
        if dry_run:
            if len(plan) < limit:
                plan.append({"path": rel, "matches": count})
            continue
        try:
            shutil.copy2(path, os.path.join(folder, rel.replace(os.sep, "__")))
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(body.replace(find, replace))
            done.append({"path": rel, "replaced": count})
        except OSError as error:
            failed.append({"path": rel, "why": str(error)})
    return {
        "dry_run": dry_run,
        "files_affected": len(plan if dry_run else done),
        "would_change" if dry_run else "changed": plan if dry_run else done,
        "failed": failed,
        "backup": folder,
    }


def tool_project_health(root):
    """A quick read on a project, in one call rather than a dozen.

    What is here, what is big, what is unfinished. The things a coder opens a
    project and asks straight away.
    """
    counts, biggest, todos = {}, [], 0
    total = 0
    for dirpath, dirnames, filenames in os.walk(
        os.path.realpath(os.path.abspath(os.path.expanduser(root)))
    ):
        dirnames[:] = [
            d for d in dirnames
            if d not in SKIP_DIRS
            and not d.startswith(".")
            and not d.startswith("_awbn-backup-")
        ]
        for name in filenames:
            full = os.path.join(dirpath, name)
            ext = os.path.splitext(name)[1].lower() or "(none)"
            counts[ext] = counts.get(ext, 0) + 1
            total += 1
            try:
                size = os.path.getsize(full)
            except OSError:
                continue
            biggest.append((size, os.path.relpath(full, root)))
            if size < 2_000_000 and ext in {
                ".py", ".dart", ".js", ".ts", ".gd", ".rs", ".go", ".md",
            }:
                try:
                    with open(full, encoding="utf-8", errors="ignore") as handle:
                        text = handle.read()
                    todos += text.count("TODO") + text.count("FIXME")
                except OSError:
                    pass
    biggest.sort(reverse=True)
    top = sorted(counts.items(), key=lambda kv: -kv[1])[:10]
    return {
        "root": root,
        "files": total,
        "by_type": [{"ext": e, "count": c} for e, c in top],
        "biggest": [
            {"path": p, "bytes": s} for s, p in biggest[:10]
        ],
        "todo_or_fixme": todos,
    }


# What each kind of project is checked with. First match wins, so a Flutter
# project is not mistaken for a plain Dart one.
TASK_RECIPES = [
    ("pubspec.yaml", {
        "test": ["flutter", "test", "--suppress-analytics"],
        "check": ["flutter", "analyze", "--no-fatal-infos"],
    }),
    ("Cargo.toml", {"test": ["cargo", "test"], "check": ["cargo", "clippy"],
                    "build": ["cargo", "build", "--release"]}),
    ("package.json", {"test": ["npm", "test", "--silent"],
                      "build": ["npm", "run", "build"],
                      "check": ["npm", "run", "lint"]}),
    ("pyproject.toml", {"test": ["python3", "-m", "pytest", "-q"]}),
    ("project.godot", {"build": ["godot", "--headless", "--path", ".", "--export-release", "Linux"]}),
]


# A tool the user installed outside the system path is still installed. Flutter
# lives under ~/.local/share/flutter/bin and Rust under ~/.cargo/bin on this
# machine, and neither is on a bare subprocess's PATH — reporting "flutter is
# not installed" when it plainly is would be a lie the caller cannot check.
EXTRA_BIN_DIRS = [
    os.path.expanduser("~/.local/share/flutter/bin"),
    os.path.expanduser("~/.cargo/bin"),
    os.path.expanduser("~/.local/bin"),
    os.path.expanduser("~/.npm-global/bin"),
    "/usr/local/bin",
]


def find_executable(name):
    found = shutil.which(name)
    if found:
        return found
    for folder in EXTRA_BIN_DIRS:
        candidate = os.path.join(folder, name)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return ""


def detect_tasks(root):
    for marker, recipe in TASK_RECIPES:
        if os.path.isfile(os.path.join(root, marker)):
            return marker, recipe
    if os.path.isdir(os.path.join(root, "tests")):
        return "tests/", {"test": ["python3", "-m", "unittest", "discover", "-s", "tests", "-q"]}
    return "", {}


def tool_run_task(root, task="test", timeout=900):
    """Run a project's own tests, build or checks — and summarise the result.

    The point is the SUMMARY. A client that shells out gets the entire log
    back in its context window; a full test run is thousands of tokens of
    output to learn one thing. This returns whether it passed, the counts, and
    only the lines that failed.
    """
    root_real = os.path.realpath(os.path.abspath(os.path.expanduser(root)))
    if not os.path.isdir(root_real):
        raise ValueError(f"not a folder: {root}")
    marker, recipe = detect_tasks(root_real)
    if not recipe:
        return {"root": root, "error": "no recognised project here", "looked_for":
                [m for m, _ in TASK_RECIPES]}
    command = recipe.get(task)
    if not command:
        return {"root": root, "kind": marker, "error": f"no '{task}' for this project",
                "available": sorted(recipe)}
    exe = find_executable(command[0])
    if not exe:
        return {"root": root, "error": f"{command[0]} is not installed"}
    try:
        done = subprocess.run(
            [exe, *command[1:]], cwd=root_real, capture_output=True,
            text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return {"root": root, "task": task, "passed": False,
                "error": f"still running after {timeout}s"}
    output = (done.stdout or "") + (done.stderr or "")
    lines = [l.rstrip() for l in output.splitlines() if l.strip()]
    bad = [
        l for l in lines
        if any(w in l.lower() for w in ("error", "failed", "failure", "assert"))
    ]
    return {
        "root": root,
        "kind": marker,
        "task": task,
        "ran": " ".join(command),
        "passed": done.returncode == 0,
        "exit_code": done.returncode,
        # The tail is where a runner puts its verdict; the failures are what
        # you actually need. The middle of a passing log helps nobody.
        "summary": lines[-8:],
        "problems": bad[:20],
        "output_lines": len(lines),
    }


def tool_batch_rename(root, pattern, find, replace, dry_run=True):
    """Rename many files by replacing part of their name."""
    files = collect(root, pattern)
    if len(files) > MAX_FILES:
        raise ValueError(f"{len(files)} files match — too many for one call")
    plan, done, failed = [], [], []
    for path in files:
        name = os.path.basename(path)
        if find not in name:
            continue
        target = os.path.join(os.path.dirname(path), name.replace(find, replace))
        row = {"from": os.path.relpath(path, root)}
        # A replacement containing ../ would walk the rename straight out of
        # the project. Caught by stress-testing this before it shipped: a
        # rename to "../../../../tmp/x" was planned without complaint.
        try:
            target = under_root(root, target)
        except ValueError as error:
            failed.append({**row, "to": target, "why": str(error)})
            continue
        row["to"] = os.path.relpath(target, root)
        if os.path.exists(target):
            failed.append({**row, "why": "a file is already called that"})
            continue
        if dry_run:
            plan.append(row)
            continue
        try:
            os.rename(path, target)
            done.append(row)
        except OSError as error:
            failed.append({**row, "why": str(error)})
    return {
        "dry_run": dry_run,
        "would_rename" if dry_run else "renamed": plan if dry_run else done,
        "failed": failed,
    }


TOOLS = [
    {
        "name": "find_files",
        "description": (
            "List files under a project folder, optionally filtered by a glob "
            "like '*.png' or 'src/**/*.dart'. Use this instead of several ls/find "
            "commands — it skips .git, node_modules and build folders and returns "
            "one short list."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Project folder."},
                "pattern": {"type": "string", "description": "Glob, e.g. '*.png'."},
                "only_images": {"type": "boolean"},
                "limit": {"type": "integer"},
            },
            "required": ["root"],
        },
    },
    {
        "name": "image_info",
        "description": (
            "Width, height, format and transparency for MANY images in one call. "
            "Replaces running `identify` once per file."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string"},
                "pattern": {"type": "string"},
                "limit": {"type": "integer"},
            },
            "required": ["root"],
        },
    },
    {
        "name": "batch_resize",
        "description": (
            "Shrink every matching image so its longest side is at most "
            "max_edge. Defaults to a dry run that reports what WOULD change; "
            "pass dry_run false to do it. Backs up every file it touches."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string"},
                "pattern": {"type": "string"},
                "max_edge": {"type": "integer"},
                "dry_run": {"type": "boolean"},
            },
            "required": ["root", "pattern", "max_edge"],
        },
    },
    {
        "name": "strip_halo",
        "description": (
            "Remove a pale drop shadow baked into icons for a white background "
            "— the light smear they show on a dark interface. Dry run by "
            "default, reporting which files have one and how bad. Backs up "
            "every file it changes."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string"},
                "pattern": {"type": "string"},
                "dry_run": {"type": "boolean"},
            },
            "required": ["root", "pattern"],
        },
    },
    {
        "name": "find_in_files",
        "description": (
            "Which files under a folder contain a piece of text, and how many "
            "times. Returns counts, not file contents, so a wide search costs "
            "almost nothing."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string"},
                "text": {"type": "string"},
                "pattern": {"type": "string"},
                "limit": {"type": "integer"},
            },
            "required": ["root", "text"],
        },
    },
    {
        "name": "run_task",
        "description": (
            "Run this project's own tests, build or checks and return a SHORT "
            "result — passed or not, the last few lines, and the failures. "
            "Detects Flutter, Rust, Node, Python and Godot projects. Use this "
            "instead of shelling out: a full test log is thousands of tokens "
            "of output to learn one thing. task is 'test', 'build' or 'check'."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string"},
                "task": {"type": "string", "description": "test | build | check"},
                "timeout": {"type": "integer"},
            },
            "required": ["root"],
        },
    },
    {
        "name": "batch_replace",
        "description": (
            "Change the same text across MANY documents in one call. Dry run "
            "by default, listing every file and how many times the text "
            "appears so the sweep can be checked before it happens. Backs up "
            "every file it changes. Skips binaries."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string"},
                "pattern": {"type": "string", "description": "Glob, e.g. '*.md'."},
                "find": {"type": "string"},
                "replace": {"type": "string"},
                "dry_run": {"type": "boolean"},
            },
            "required": ["root", "pattern", "find", "replace"],
        },
    },
    {
        "name": "project_health",
        "description": (
            "A quick read on a project in one call: how many files, what kinds, "
            "the biggest ones, and how many TODO/FIXME markers are left."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"root": {"type": "string"}},
            "required": ["root"],
        },
    },
    {
        "name": "batch_rename",
        "description": (
            "Rename many files at once by replacing part of their name. Dry run "
            "by default. Refuses any rename that would overwrite something."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string"},
                "pattern": {"type": "string"},
                "find": {"type": "string"},
                "replace": {"type": "string"},
                "dry_run": {"type": "boolean"},
            },
            "required": ["root", "pattern", "find", "replace"],
        },
    },
]

HANDLERS = {
    "find_files": tool_find_files,
    "image_info": tool_image_info,
    "batch_resize": tool_batch_resize,
    "strip_halo": tool_strip_halo,
    "find_in_files": tool_find_in_files,
    "run_task": tool_run_task,
    "batch_replace": tool_batch_replace,
    "project_health": tool_project_health,
    "batch_rename": tool_batch_rename,
}


def call_tool(name, args):
    handler = HANDLERS.get(name)
    if handler is None:
        raise ValueError(f"no such tool: {name}")
    args = dict(args or {})
    root = args.get("root") or ""
    # Confine the whole call to the named folder before anything runs.
    if root:
        under_root(root, root)
    return handler(**args)


def handle(req):
    method = req.get("method", "")
    if method == "initialize":
        return {
            "protocolVersion": (req.get("params") or {}).get(
                "protocolVersion", PROTO_DEFAULT
            ),
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "awbn-batch", "version": "1.0.0"},
        }
    if method == "tools/list":
        return {"tools": TOOLS}
    if method == "tools/call":
        params = req.get("params") or {}
        try:
            result = call_tool(params.get("name", ""), params.get("arguments"))
            text = json.dumps(result, indent=1)
        except Exception as error:  # noqa: BLE001
            return {
                "content": [{"type": "text", "text": f"error: {error}"}],
                "isError": True,
            }
        return {"content": [{"type": "text", "text": text}]}
    raise ValueError(f"unknown method: {method}")


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            continue
        method = req.get("method", "")
        if method.startswith("notifications/") or "id" not in req:
            continue
        rid = req.get("id")
        try:
            resp = {"jsonrpc": "2.0", "id": rid, "result": handle(req)}
        except Exception as exc:  # noqa: BLE001
            log("handler error:", exc)
            resp = {
                "jsonrpc": "2.0",
                "id": rid,
                "error": {"code": -32603, "message": str(exc)},
            }
        sys.stdout.write(json.dumps(resp) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
