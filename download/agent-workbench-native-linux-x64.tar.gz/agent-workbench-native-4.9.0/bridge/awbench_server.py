#!/usr/bin/env python3
"""Headless backend for Agent Workbench Native.

The Svelte/Tauri application owns presentation. This server owns long-running
client processes and writes the same durable session format as the legacy
Workbench while keeping Native data under its own config root. It intentionally
uses only the Python standard library.
"""

import ast
import atexit
import errno
import commands
import glob
import ipaddress
import json
import sys
import hashlib
import fcntl
import os
import pty
import re
import secrets
import select
import signal
import shlex
import shutil
import socket
import subprocess
import struct
import threading
import tempfile
import time
import termios
import urllib.parse
import urllib.request
import uuid
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# This file normally runs as __main__ (systemd unit / awbench-next.sh), while
# commands.py handlers do a lazy `import awbench_server` to reach live server
# state. Without this alias that import would EXECUTE A SECOND MODULE INSTANCE
# with its own (empty) globals — stateless helpers appear to work, but any
# handler touching live registries (permission prompts, resident sessions)
# silently reads the wrong dicts. Alias the running instance under its module
# name so both worlds share one set of globals.
sys.modules.setdefault("awbench_server", sys.modules[__name__])

HOST = "127.0.0.1"
PORT = int(os.environ.get("AWBENCH_PORT", "8765"))
APP_DIR_NAME = "agent-workbench-native"
LEGACY_APP_DIR_NAME = "agent-workbench"
CONFIG_DIR = os.path.expanduser(f"~/.config/{APP_DIR_NAME}")
LEGACY_CONFIG_DIR = os.path.expanduser(f"~/.config/{LEGACY_APP_DIR_NAME}")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
FREE_CHAT_WORKSPACE_DIR = os.path.join(CONFIG_DIR, "workspace")
DEBUG_LOG_FILE = os.path.join(CONFIG_DIR, "debug.jsonl")
# Rotate the debug log once it passes this size; one prior generation is kept.
DEBUG_LOG_MAX_BYTES = int(os.environ.get("AWBENCH_DEBUG_LOG_MAX_BYTES", "2000000"))
DEBUG_LOG_LOCK = threading.Lock()
ARTIFACT_MAX_FILES_PER_REQUEST = 32
ARTIFACT_MAX_FILE_BYTES = 128 * 1024 * 1024
ARTIFACT_MAX_REQUEST_BYTES = 512 * 1024 * 1024
ARTIFACT_MAX_SESSION_BYTES = 2 * 1024 * 1024 * 1024
ARTIFACT_MIN_FREE_BYTES = 256 * 1024 * 1024
CLIPBOARD_MAX_BYTES = 32 * 1024 * 1024
# Persisted work-log/system items larger than this are diverted to the session's
# Artifacts pane; only a head + pointer stays in turn history. Root cause of the
# 17 MB session file: individual >1 MB verbatim outputs saved into turns forever.
WORK_ITEM_PERSIST_MAX_CHARS = int(
    os.environ.get("AWBENCH_WORK_ITEM_MAX_CHARS", "16000")
)
WORK_ITEM_HEAD_CHARS = 8000
BRIDGE_TOKEN_FILE = os.path.join(CONFIG_DIR, "bridge-token")
BRIDGE_AUTH_HEADER = "X-Agent-Workbench-Token"
KEYS_STORE_FILE = os.path.join(CONFIG_DIR, "keys.json")
KEYS_EXPORT_FILE = os.path.join(CONFIG_DIR, "keys_list.md")
LEGACY_KEYS_EXPORT_FILE = os.path.expanduser("~/keys_list.md")
SESS_DIR = os.path.join(CONFIG_DIR, "sessions")
# Isolated git worktrees for spawned worker sessions (one per worker, removed on
# session delete). Kept outside the project tree so they never pollute it.
WORKTREES_DIR = os.path.join(CONFIG_DIR, "worktrees")
LOCAL_DELEGATE_SERVER = os.path.join(CONFIG_DIR, "local_delegate_server.py")
# Batch tools every client gets: one call to sweep a folder instead of a shell
# command per file. A measured turn spent 30 commands doing what one of these
# does, and paid for every command's output landing back in its context.
# Beside this file, which is where install-native.sh puts it — and where it
# also sits in a source checkout, so both layouts find it.
BATCH_TOOLS_SERVER = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "tools", "awbn_batch_server.py"
)
CLAUDE_MCP_CONFIG_FILE = os.path.join(CONFIG_DIR, "claude_mcp.json")
# MCP servers that hang Claude's startup handshake and aren't needed inside Claude
# (Codex is driven as its own agent here, not as an MCP). Excluded from every Claude
# launch via a curated --mcp-config + --strict-mcp-config.
CLAUDE_MCP_DENYLIST = {"codex"}
GEMINI_TITLE_CACHE_FILE = os.path.join(CONFIG_DIR, "gemini-titles.json")
CONFIG_BOOTSTRAP_FILE = os.path.join(CONFIG_DIR, ".legacy-bootstrap.json")
CUSTOM_PROJECTS_DIR = os.path.join(CONFIG_DIR, "client-workspaces")
OLLAMA_BASE = os.environ.get("OLLAMA_API_BASE", "http://localhost:11434").rstrip("/")
PROJECT_STATE_FILENAME = "AGENT_STATE.md"
PROJECT_REGISTRY_DIRNAME = ".agent-workbench"
PROJECT_REGISTRY_FILENAME = "project.json"
PROJECT_RECORD_CHATS_DIRNAME = "chats"
PROJECT_RECORD_HANDOFFS_DIRNAME = "handoffs"
PROJECT_RECORD_GITIGNORE = (
    "# AWBN chat transcripts, handoffs and viewer edit backups are private\n"
    "# local records - never part of the project's own history.\n"
    "/chats/\n"
    "/handoffs/\n"
    "/manual-edit-backups/\n"
)
PROJECT_STATE_MAX_CHARS = 24_000
LOCAL_PROJECT_STATE_MODEL = os.environ.get("AWBENCH_PROJECT_STATE_MODEL", "qwen3:8b")
# AGENT_STATE is maintained incrementally (append-only) by this fast, code-aware
# local model — NOT a cloud agent (saves tokens) and NOT a full rewrite each turn
# (avoids the "telephone game" drift). qwen2.5-coder:7b: ~11s, names files/functions
# accurately. The old qwen3:8b reasoning model took ~44s.
STATE_WRITER_MODEL = os.environ.get("AWBENCH_STATE_WRITER_MODEL", "qwen2.5-coder:7b")
# Roll AGENT_STATE.md into AGENT_STATE_2.md (etc.) once it passes this size, instead
# of truncating and dropping the oldest knowledge.
STATE_SPLIT_BYTES = int(os.environ.get("AWBENCH_STATE_SPLIT_BYTES", "120000"))
STATE_CORE_SECTIONS = (
    "## Current Status",
    "## Rules (do / don't)",
    "## Setbacks & Fixes",
    "## Progress",
)
STATE_TAG_TO_SECTION = {
    "RULE": "## Rules (do / don't)",
    "SETBACK": "## Setbacks & Fixes",
    "PROGRESS": "## Progress",
}
LOCAL_AGENT_MAX_STEPS = 24
LOCAL_TOOL_MAX_OUTPUT = 24_000
LOCAL_FILE_MAX_BYTES = 2_000_000
PRIVATE_DIR_MODE = 0o700
PRIVATE_FILE_MODE = 0o600
LOCAL_TOOL_CONFIRMATION_PHRASE = "CONFIRM LOCAL TOOL ACTION"
try:
    MAX_POST_BYTES = max(
        1024,
        int(os.environ.get("AWBENCH_MAX_POST_BYTES", str(5 * 1024 * 1024))),
    )
except (TypeError, ValueError):
    MAX_POST_BYTES = 5 * 1024 * 1024
_BRIDGE_AUTH_TOKEN = None
PROTECTED_BASENAMES = {
    ".env",
    ".aws",
    ".env.local",
    ".env.development",
    ".env.production",
    ".npmrc",
    ".pypirc",
    ".netrc",
    "id_rsa",
    "id_dsa",
    "id_ecdsa",
    "id_ed25519",
    "credentials",
    "credentials.json",
}
PROTECTED_SUFFIXES = (".key", ".pem", ".p12", ".pfx")
PROTECTED_COMMAND_PATTERNS = (
    "keys_list.md",
    "bridge-token",
    ".env",
    ".ssh/",
    ".ssh\\",
    ".qwen/",
    ".qwen\\",
    ".claude.json",
    ".claude/",
    ".claude\\",
    ".codex/",
    ".codex\\",
    ".gemini/",
    ".gemini\\",
    ".gnupg/",
    ".gnupg\\",
    ".aws/",
    ".aws\\",
    ".azure/",
    ".azure\\",
    ".kube/",
    ".kube\\",
    ".docker/",
    ".docker\\",
    "mcp-oauth-tokens.json",
    "oauth_creds.json",
)
CONNECTOR_WRITE_ACTION_RE = re.compile(
    r"\b("
    r"add|archive|buy|cancel|create|delete|deploy|deposit|destroy|edit|erase|"
    r"execute|forward|invite|label|merge|modify|order|publish|push|remove|reply|"
    r"restore|sell|send|set|share|submit|trade|transfer|trash|update|upload|withdraw"
    r")\b",
    re.IGNORECASE,
)
DANGEROUS_COMMAND_PATTERNS = (
    (r"(^|[;&|]\s*)(sudo|su|pkexec)\b", "privilege escalation"),
    (r"(^|[;&|]\s*)(rm|rmdir)\b", "file deletion"),
    (r"\b(chmod|chown|chgrp|setfacl)\b", "permission or ownership change"),
    (r"\b(systemctl|service|loginctl)\b", "service/session control"),
    (r"\b(reboot|shutdown|poweroff|halt)\b", "machine power control"),
    (r"(^|[;&|]\s*)(kill|killall|pkill)\b", "process termination"),
    (r"\b(dd|mkfs|fdisk|parted|cryptsetup|mount|umount)\b", "disk or mount operation"),
    (r"\b(make|ninja)\s+install\b", "install target"),
    (r"\bbash\s+install\.sh\b|\bsh\s+install\.sh\b|\./install\.sh\b", "installer script"),
    (
        r"\b(apt|apt-get|dnf|yum|pacman|zypper|flatpak|snap)\s+"
        r"(install|remove|erase|upgrade|update|dist-upgrade|autoremove)\b",
        "system package change",
    ),
    (
        r"\b(npm|pnpm|yarn|bun)\s+"
        r"(install|add|remove|update|upgrade|dlx|x)\b",
        "JavaScript package or executable change",
    ),
    (
        r"\b(pip|pip3|uv|poetry|pipenv)\s+"
        r"(install|add|remove|update|sync)\b",
        "Python package or executable change",
    ),
    (r"\bcargo\s+(install|publish|login|owner|yank)\b", "Rust package publication/install"),
    (
        r"\bgit\s+"
        r"(reset|clean|rebase|merge|checkout|switch|restore|commit|push|tag)\b",
        "git history or working-tree mutation",
    ),
    (
        r"\bgit\s+branch\s+(-d|-D|--delete|-m|-M|--move|--set-upstream-to)\b",
        "git branch mutation",
    ),
    (
        r"\b(curl|wget)\b.*\|\s*(sh|bash|zsh|fish|python|python3|node|ruby|perl)\b",
        "downloaded code execution",
    ),
    (
        r"\b(docker|podman|kubectl|helm|terraform|ansible)\s+"
        r"(apply|build|create|delete|destroy|exec|install|push|rollout|run|scale|set|upgrade)\b",
        "container or infrastructure change",
    ),
    (r"(^|[^&])&\s*(#.*)?$", "background command"),
    (r"\b(nohup|disown)\b", "detached background command"),
)
QWEN_MCP_BRIDGE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "tools",
    "qwen_mcp_bridge.mjs",
)
QWEN_SETTINGS_FILE = os.path.expanduser("~/.qwen/settings.json")
WORKER_JOBS_PATH = os.path.join(CONFIG_DIR, "worker-jobs.json")
WORKER_JOBS_MAX = 240
WORKER_JOBS_LOCK = threading.Lock()
CUSTOM_CLI_SESSIONS = {}
CUSTOM_CLI_SESSIONS_LOCK = threading.Lock()
SUPPORTED_CONNECTORS = {
    "threejs",
    "cloudflare",
    "google-drive",
    "supabase",
    "vercel",
    "gmail",
    "google-calendar",
    "canva",
    "hugging-face",
    "indeed",
    "cocounsel-legal",
    "robinhood",
}

ACTIVE_TURNS = {}
ACTIVE_LOCK = threading.Lock()
CONFIG_RMW_LOCK = threading.RLock()
CONFIG_RMW_LOCAL = threading.local()
# Session ids whose files were deleted while a turn was still finalizing — a
# late save_session for one of these must not recreate the file. See
# save_session / ui_delete_session.
DELETED_SESSION_IDS = set()
DELETED_SESSION_IDS_LOCK = threading.Lock()
SESSION_LOCKS = {}
SESSION_LOCKS_LOCK = threading.Lock()
SESSION_LOCKS_LOCAL = threading.local()
PROJECT_RECORD_LOCKS = {}
PROJECT_RECORD_LOCKS_LOCK = threading.Lock()
MANUAL_EDIT_LOCKS = {}
MANUAL_EDIT_LOCKS_LOCK = threading.Lock()
LIMIT_CACHE = {}
LIMIT_CACHE_SECONDS = 60
LIMIT_REFRESH_LOCK = threading.Lock()
LIMIT_REFRESHING = set()
# Last-known limits, so a restart draws the real figure instead of a blank chip
# while the background refresh runs.
USAGE_LIMIT_CACHE_FILE = os.path.join(CONFIG_DIR, "usage-limits.json")
CONNECTOR_CACHE = {"time": 0.0, "value": [], "refreshing": False}
CONNECTOR_CACHE_SECONDS = 15
CONNECTOR_REFRESH_LOCK = threading.Lock()
UPDATE_LOCK = threading.Lock()
# Codex is updated on-demand, immediately before a new AWBN Codex turn, rather
# than while a turn is running.  Keep the check infrequent enough that a busy
# session is not held up by an npm registry request on every message.
CODEX_AUTO_UPDATE_INTERVAL_SECONDS = 6 * 60 * 60
CODEX_AUTO_UPDATE_LOCK = threading.Lock()
CODEX_AUTO_UPDATE_STATE = {"checked_at": 0.0, "installed": "", "latest": ""}
HANDOFF_WARNING_PERCENT = 70
HANDOFF_MAX_CHARS = 60_000
# Stall watchdog for Claude turns. A healthy `claude` emits its system/init event
# within a few seconds; if none arrives within this window the turn is hung on an
# MCP server's startup handshake and is stopped instead of ticking "Working"
# forever. STALL_WARN only surfaces a notice (no kill) for slow mid-turn tool calls.
CLAUDE_INIT_TIMEOUT = 90
CLAUDE_STALL_WARN = 120
# Hard ceiling: if Claude goes this long with zero output AND no background job is
# pending, the turn is genuinely hung — kill it and end the turn instead of spinning
# "Working…" forever. Generous so a slow-but-alive tool call isn't cut off.
CLAUDE_STALL_HARD = 600
# How often to repeat a stall notice while a turn stays silent (v4.7.1).
CLAUDE_STALL_REWARN = 60
try:
    CLAUDE_BACKGROUND_IDLE_TIMEOUT = max(
        0,
        int(os.environ.get("AWBENCH_CLAUDE_BACKGROUND_IDLE_TIMEOUT", "1800")),
    )
except (TypeError, ValueError):
    CLAUDE_BACKGROUND_IDLE_TIMEOUT = 1800
_OLLAMA_INFERENCE_SEM = threading.Semaphore(1)
_OLLAMA_CTX_CACHE: "dict[str, int]" = {}
_OLLAMA_CTX_TS = 0.0
_OLLAMA_CTX_TTL = 30.0
GUI_CLI_PATHS = tuple(
    dict.fromkeys(
        [
            os.path.expanduser(f"~/.local/share/{APP_DIR_NAME}/cli"),
            os.path.expanduser("~/.local/bin"),
            os.path.expanduser("~/.npm-global/bin"),
            os.path.expanduser("~/.local/share/pnpm"),
            os.path.expanduser("~/.bun/bin"),
            os.path.expanduser("~/.volta/bin"),
            os.path.expanduser("~/.asdf/shims"),
            os.path.expanduser("~/.local/share/mise/shims"),
            os.path.expanduser("~/.cargo/bin"),
            os.path.expanduser("~/bin"),
            *sorted(glob.glob(os.path.expanduser("~/.nvm/versions/node/*/bin"))),
            "/usr/local/bin",
            "/usr/bin",
            "/usr/local/sbin",
            "/usr/sbin",
            "/snap/bin",
        ]
    )
)
# The legacy OG-workbench CLI shims silently rewrite every claude/codex/gemini
# launch with bypass/yolo flags (found 2026-07-03 — this was the real reason
# AWBN's safe-permission default never took effect). AWBN must always launch
# the real binaries and own its permission flags itself, so this dir is
# excluded from the subprocess PATH even when the user's shell PATH has it.
LEGACY_BYPASS_SHIM_DIR = os.path.expanduser(f"~/.local/share/{LEGACY_APP_DIR_NAME}/cli")

# ---------------------------------------------------------------------------
# Worker / sub-agent spawn support
# ---------------------------------------------------------------------------
# Ordered cheapest-first preferred models per backend for spawned workers.
# Kept as a preference, not a fixed list: coerce_model() checks these against
# the client's live catalog, so a name the vendor retires is caught there
# rather than launching a worker on a model that no longer exists.
PREFERRED_WORKER_MODELS = {
    "claude": ["sonnet", "haiku"],
    # gpt-5.4-mini and gpt-5.4 are marked "hide" in Codex's own catalog now,
    # so they are no longer the cheap tier — 5.2 is the cheapest still listed.
    "codex": ["gpt-5.2", "gpt-5.5"],
    "hermes": ["Default"],
}
# An empty model means "whatever the installed CLI puts at the top of its own
# catalog" — resolved by default_model_for(). Codex ranks its catalog by the
# vendor's `priority` field, so a new flagship becomes the default the day it
# ships. Claude names `opus` on purpose: fable is the top entry but the pricier
# one, so that default stays a deliberate choice rather than tracking releases.
DEFAULT_AGENT_SETTINGS = {
    "claude": {"model": "opus", "effort": "medium"},
    "codex": {"model": "", "effort": "high"},
    "gemini": {"model": "Auto", "effort": "Default"},
    "hermes": {"model": "Default", "effort": "Default"},
    "ollama": {"model": "", "effort": "Default"},
}
# BACKUP ONLY — never the source of truth (v4.3.3).
#
# The real model list lives inside each installed CLI and is read at runtime by
# the "Model/effort discovery" section below. These tables exist for one case:
# the CLI isn't installed, or its file can't be read. When they are in use the
# payload says so (model_source "static") and the app labels the dropdown, so a
# stale hand-kept list can never again pass itself off as the live one — which
# is exactly how gpt-5.6 went missing while looking perfectly normal.
#
# Do not "keep these current" by hand. If a list here is wrong, the discovery
# reader is what needs fixing.
UI_MODEL_OPTIONS = {
    "claude": ["fable", "opus", "sonnet", "haiku"],
    "codex": ["gpt-5.6-sol", "gpt-5.6-terra", "gpt-5.6-luna", "gpt-5.5"],
    "gemini": [
        "Auto",
        "gemini-3.1-pro-preview",
        "gemini-3-pro-preview",
        "gemini-3.5-flash",
        "gemini-3-flash-preview",
        "gemini-3.1-flash-lite",
        "gemini-2.5-pro",
        "gemini-2.5-flash",
    ],
    "hermes": ["Default"],
}
UI_EFFORT_OPTIONS = {
    "claude": ["Ultracode", "max", "xhigh", "high", "medium", "low"],
    "codex": ["ultra", "max", "xhigh", "high", "medium", "low"],
    "gemini": ["Default"],
    "hermes": ["Default"],
    "ollama": ["Default"],
}
# AWBN's own effort entry (not a CLI level) — kept in front of Claude's real
# levels wherever those are discovered. See the "ultracode" branch at launch.
CLAUDE_EXTRA_EFFORTS = ["Ultracode"]
# Clients that exist in this codebase but are no longer offered when starting
# work. Retiring one here keeps every read path intact — old sessions still
# open, render, and report their tokens — while removing it from the pickers,
# so nobody starts a chat that cannot run.
#
# Availability and account eligibility vary by user. A supported adapter is
# offered only when its executable is detected; provider sign-in errors remain
# explicit instead of globally retiring the client for everyone.
RETIRED_AGENTS = {}
# The clients a picker may offer, in display order.
SELECTABLE_FIXED_AGENTS = tuple(
    key for key in ("claude", "codex", "gemini", "hermes") if key not in RETIRED_AGENTS
)
CURRENT_ONBOARDING_VERSION = 1
# Setup re-asks on this many later opens before it stops offering itself.
ONBOARDING_MAX_DEFERRALS = 2


UI_AGENT_LABELS = {
    "claude": "Claude Code",
    "codex": "Codex",
    "gemini": "Gemini CLI",
    "hermes": "Hermes",
    "ollama": "Ollama",
}
UI_DEFAULT_AGENT_SETTINGS = {
    "claude": {"model": "opus", "effort": "high"},
    "codex": {"model": "", "effort": "high"},
    "gemini": {"model": "Auto", "effort": "Default"},
    "hermes": {"model": "Default", "effort": "Default"},
    "ollama": {"model": "", "effort": "Default"},
}
# Local model names to keep out of the picker, e.g. helpers a project pulls in.
# Set AWBN_HIDE_MODEL_PREFIXES="foo-,bar-" to hide your own. Empty by default.
HIDDEN_AWBN_OLLAMA_MODEL_PREFIXES = tuple(
    part.strip()
    for part in os.environ.get("AWBN_HIDE_MODEL_PREFIXES", "").split(",")
    if part.strip()
)
# Agents whose launch model is checked before a turn starts. The check exists to
# stop a stale model — carried across a handoff, left on an old workspace, or
# retired by the vendor — from hard-failing every turn. Ollama, custom clients
# and gemini pass through unchanged (their names are free-form or validated by
# the CLI itself).
COERCED_MODEL_AGENTS = ("claude", "codex")


def valid_models_for(agent_key):
    """The set of model names a turn may launch with, read from the installed
    CLI's own catalog (v4.3.3).

    This used to be a hand-typed set, and it is the reason "AWBN lost gpt-5.6":
    even once the dropdown offered gpt-5.6-sol, every turn was rewritten back to
    gpt-5.5 on the way out, because sol was not in a list somebody had to
    remember to edit. The live catalog is now the authority; the hardcoded
    baseline is unioned in only as a backstop so an unreadable CLI can't strand
    a session on a name we'd then refuse to launch."""
    agent_key = clean_text(agent_key)
    if agent_key not in COERCED_MODEL_AGENTS:
        return set()
    names = set(UI_MODEL_OPTIONS.get(agent_key) or [])
    try:
        for agent in get_model_discovery_agents():
            if clean_text(agent.get("key")) == agent_key:
                # all_models, not models: a model the vendor has delisted is
                # still launchable, it just isn't offered any more.
                names.update(
                    clean_text(item)
                    for item in (agent.get("all_models") or agent.get("models") or [])
                )
                break
    except Exception:  # noqa: BLE001 - a discovery failure must not block a turn
        pass
    return {name for name in names if name}


def default_model_for(agent_key):
    """The model a session starts on when nothing else has been chosen.

    A configured default is kept as long as the installed CLI still offers it;
    once it disappears — or when it's deliberately left blank - the catalog's
    own first entry wins. Vendors put their current flagship first, so the
    default follows releases instead of needing an edit here."""
    agent_key = clean_text(agent_key)
    configured = clean_text((DEFAULT_AGENT_SETTINGS.get(agent_key) or {}).get("model"))
    offered = []
    try:
        for agent in get_model_discovery_agents():
            if clean_text(agent.get("key")) == agent_key:
                offered = [
                    clean_text(item) for item in agent.get("models") or [] if clean_text(item)
                ]
                break
    except Exception:  # noqa: BLE001 - never let this block a launch
        offered = []
    if configured and (not offered or configured in offered):
        return configured
    if offered:
        return offered[0]
    baseline = UI_MODEL_OPTIONS.get(agent_key) or []
    return configured or (baseline[0] if baseline else "Default")


def coerce_model(agent_key, model, allow_unverified=False):
    """Return (model, was_coerced). If the model isn't in the agent's live
    catalog, swap it for that agent's default rather than letting the turn fail.
    `allow_unverified` is the user's explicit "use it anyway" from the Custom…
    box — a deliberate choice is never quietly overridden."""
    agent_key = clean_text(agent_key)
    model = clean_text(model)
    if allow_unverified:
        return model, False
    valid = valid_models_for(agent_key)
    if not valid or not model or model == "Default" or model in valid:
        return model, False
    return default_model_for(agent_key) or model, True
DEFAULT_MEMORY_PREFERENCES = {
    # Fresh installs keep conversation-derived state inside AWBN unless the
    # user deliberately enables project memory.  Project-local AGENT_STATE.md
    # files can otherwise be archived, synced, or committed by accident.
    "auto_update": "off",
    "note_taker": "ollama",
    "ollama_model": LOCAL_PROJECT_STATE_MODEL,
    "min_interval_seconds": 300,
    "min_prompt_chars": 240,
    "skip_duplicate_prompts": True,
    "update_on_handoff": True,
    "inject_shared_state": True,
    "inject_max_chars": 8000,
}
# Injected as --append-system-prompt on every Claude turn in smart mode.
#
# Retuned for the Claude 5 family (v4.3.3). The previous version was written
# against models that under-reached for subagents and needed encouragement.
# The current ones lean the other way: they delegate readily, verify their own
# work without being asked, and write longer than the task needs. Three of the
# rules below therefore push the opposite direction from before, and one line
# was removed outright — "verify the worker's result" now causes redundant
# verification passes rather than better ones.
#
# What did NOT change: the honesty requirement. Not claiming unverified work as
# done is a reporting rule, not a request for extra checking, and it stays.
CLAUDE_SMART_ORCHESTRATION_PROMPT = """
Agent Workbench orchestration policy:

# Routing
Before taking tools or modifying files on a substantial actionable request,
emit one short visible routing line:
Routing: <agent profile + model/effort> — <brief reason>.
Do not emit a routing line for conversation, clarification, status checks,
simple explanations, or tiny one-step actions.

Route by DIFFICULTY, not by category. Bounded read-only research goes to
Haiku. Work that is genuinely routine — mechanical edits, obvious fixes, a
change you could describe completely in two sentences — goes to Sonnet. Keep
anything subtle with Opus: architecture, ambiguous diagnosis, high-consequence
judgment, destructive operations, final review, and any task whose difficulty
you are unsure of. A task is not routine merely because it is "coding": input
handling, concurrency, protocol work, and anything with exact user-specified
behaviour are subtle even when small. When in doubt, keep it yourself.

When you do delegate, quote the user's own words for the requirement verbatim
in the brief. A paraphrase loses the exact rule ("hold right click + tap left
click") that the work depends on.

# Delegating
Subagents multiply cost and time: each one re-establishes context, re-explores,
and reports back, and you then read its report. Delegate rarely and only when
the payoff clearly exceeds that overhead. Do not ask the user whether to
delegate.

Use at most one worker by default. Fan out only when the work is genuinely
independent and parallel — unrelated modules, a wide multi-file investigation —
and say why. Do not split one modest job into pieces. If one worker can do it,
use one.

Do not delegate work you could finish yourself in a handful of tool calls: a
few file reads, a couple of edits, a simple search, a quick check.

Do not use a subagent to review, verify, or double-check your own work. That
belongs in your own loop.

Brief a worker precisely the first time rather than launching, waiting, and
re-briefing. Once you delegate, commit to it — do not redo the work or
re-derive its findings when it reports back. If you launch several workers for
independent tracks, send them in one message so they run concurrently.

If the MCP tool `mcp__local-delegate__delegate_local` is available, use it only
for cheap local mechanical subtasks. It is not shared memory and not a
Claude-to-Codex channel; cross-client continuity comes from the Workbench
handoff artifact and project AGENT_STATE.md.

Keep delegation inside the current Claude session and present one integrated
answer.

# Scope
Deliver what was asked, at the scope intended. Make routine judgment calls
yourself; check in only when different readings would lead to materially
different work. If you think the ask is mistaken, say so in a sentence and
carry on with it as asked. Do not add features, refactors, abstractions, or
error handling for cases that cannot happen. Finish the whole task rather than
the easy part of it, and if something genuinely cannot be finished, do the rest
and say plainly what is missing.

# Reporting
Report outcomes faithfully. If a check failed, say so with the output. If a
step was skipped, say that. State what you verified and what you did not, and
never present unverified work as done. When something is genuinely finished and
checked, say so plainly without hedging.

# Length
Lead with the outcome — the first sentence should answer what happened or what
you found. Supporting detail comes after. Keep it readable rather than clipped:
drop details that would not change what the reader does next, instead of
compressing sentences into fragments, arrow chains, or shorthand.
""".strip()
CLAUDE_SMART_AGENTS = {
    "workbench-researcher": {
        "description": "Bounded read-only research, repository discovery, inventories, and fact gathering.",
        "prompt": "Stay read-only, gather the minimum evidence needed, cite exact files or sources, and return a concise factual brief.",
        "tools": ["Read", "Grep", "Glob", "Bash", "WebFetch", "WebSearch"],
        "model": "haiku",
    },
    "workbench-builder": {
        "description": "Well-scoped coding, editing, tests, refactors, UI implementation, and routine debugging.",
        "prompt": "Implement the assigned change surgically, preserve existing behavior, run focused validation, and report changed files and unresolved risks.",
        "model": "sonnet",
        "effort": "high",
    },
    "workbench-complex-builder": {
        "description": "Difficult implementation with broad coupling or subtle failure modes after architecture is clear.",
        "prompt": "Implement the defined design carefully, preserve invariants, run focused and broader validation, and report remaining uncertainty.",
        "model": "sonnet",
        "effort": "high",
    },
    "workbench-reviewer": {
        "description": "Independent adversarial verification after substantial delegated implementation - tries to disprove the work.",
        "prompt": "Your only job is to disprove the delegated work, not to improve or extend it. Assume it is broken and try to prove it: check the actual implementation and validation evidence against the requirements, and hunt for the specific case where it fails, breaks existing behavior, or where the validation does not actually exercise the claim. Report each break with the concrete failing scenario (inputs, state, expected vs actual). If you cannot break it, say so plainly. Do not propose new features, refactors, or scope beyond confirming or breaking the delegated work.",
        "tools": ["Read", "Grep", "Glob", "Bash"],
        "model": "opus",
        "effort": "high",
    },
}
CLAUDE_SMART_AGENTS_JSON = json.dumps(CLAUDE_SMART_AGENTS, separators=(",", ":"))
def resolve_cli_binary(name, fallback=None):
    """Where this machine actually keeps `name`.

    Installs differ: claude may sit in ~/.local/bin, /usr/local/bin or a
    distro package dir; codex may come from npm-global, nvm, pnpm or apt.
    Search the same PATH a turn would launch with, and only then fall back to
    the most common location so the caller still has something to report."""
    search = os.pathsep.join(
        [*GUI_CLI_PATHS, *(os.environ.get("PATH", "").split(os.pathsep))]
    )
    found = shutil.which(name, path=search)
    if found:
        return found
    return fallback or os.path.expanduser(f"~/.local/bin/{name}")


def installed_cli_path(key):
    """Return a launchable path for a supported client, or an empty string.

    Detection is deliberately local and read-only: it resolves only known
    executable names and never starts a client, reads credentials, or stores
    the user's absolute install path.
    """
    binary = {
        "claude": "claude",
        "codex": "codex",
        "gemini": "gemini",
        "hermes": "hermes",
        "ollama": "ollama",
    }.get(clean_text(key).lower())
    if not binary:
        return ""
    candidate = resolve_cli_binary(binary, "")
    if not candidate:
        return ""
    candidate = os.path.abspath(os.path.expanduser(candidate))
    return candidate if os.path.isfile(candidate) and os.access(candidate, os.X_OK) else ""


def custom_client_command_available(command):
    """Check only the first executable in a saved custom-client command.

    Arbitrary clients need their existing adapter settings, so discovery must
    never execute an unknown command merely to identify it.
    """
    try:
        tokens = shlex.split(clean_text(command))
    except ValueError:
        return False
    if not tokens:
        return False
    executable = os.path.expanduser(tokens[0])
    if os.path.isabs(executable) or os.sep in executable:
        candidate = os.path.abspath(executable)
        return os.path.isfile(candidate) and os.access(candidate, os.X_OK)
    search = os.pathsep.join(
        [*GUI_CLI_PATHS, *(os.environ.get("PATH", "").split(os.pathsep))]
    )
    return bool(shutil.which(executable, path=search))


_CLIENT_UPDATE_SPEC_TEMPLATES = [
    {
        "key": "claude",
        "label": "Claude Code",
        "binary": "claude",
        "version_args": ["--version"],
        "latest_cmd": None,
        "update_args": ["update"],
        "note": "Native install - update checks and installs the latest.",
    },
    {
        "key": "codex",
        "label": "Codex",
        "binary": "codex",
        "fallback": os.path.expanduser("~/.npm-global/bin/codex"),
        "version_args": ["--version"],
        "latest_cmd": ["npm", "view", "@openai/codex", "version"],
        "update_cmd": ["npm", "install", "-g", "@openai/codex@latest"],
        "note": "",
    },
    {
        "key": "hermes",
        "label": "Hermes",
        "binary": "hermes",
        "version_args": ["--version"],
        "latest_cmd": None,
        "update_args": ["update"],
        "note": "Managed install - Update runs Hermes' native updater.",
    },
]


def client_update_specs():
    """The update specs with every binary resolved for THIS machine."""
    specs = []
    for template in _CLIENT_UPDATE_SPEC_TEMPLATES:
        binary = resolve_cli_binary(
            template["binary"], template.get("fallback")
        )
        spec = {
            "key": template["key"],
            "label": template["label"],
            "version_cmd": [binary, *template.get("version_args", [])],
            "latest_cmd": template.get("latest_cmd"),
            "update_cmd": template.get("update_cmd")
            or ([binary, *template["update_args"]] if template.get("update_args") else None),
            "note": template.get("note", ""),
        }
        specs.append(spec)
    return specs


# ---------------------------------------------------------------------------
# Model/effort discovery (self-updating dropdowns)
# ---------------------------------------------------------------------------
# Every agent's model list is read from the program the user actually has
# installed — the same data that CLI's own `/model` screen is built from.
#
# AWBN can't run `/model`: it's an interactive command inside each CLI's chat
# UI. So we read the registry those screens read. v4.3.3 made all three work
# the same way, after --help scraping was found to be guesswork:
#
#   claude  bundle carries `latest_per_family:{fable:"claude-fable-5",...}`
#           plus a {id, display_name, capabilities} table. The aliases, their
#           real names, and which effort levels each supports all come from
#           there. (Before: three example words scraped out of --help prose.)
#   codex   native binary embeds the model catalog as JSON — slug,
#           display_name, visibility, priority, supported_reasoning_levels.
#           `visibility: "hide"` is honoured, so retired models stop showing.
#   gemini  bundle carries `VALID_GEMINI_MODELS` plus the pro/flash aliases.
#   ollama  already asked the local daemon what's installed.
#
# Efforts are per model, not per agent: Haiku 4.5 supports none, GPT-5.6-Sol
# supports six including `ultra`. A single per-agent list was wrong for both.
#
# When a CLI can't be read the hardcoded baseline is used and the entry is
# marked "static" so the app can SAY the list is a backup. A stale list that
# looks live is the bug that started all this.
_MODEL_DISCOVERY_LOCK = threading.Lock()
_MODEL_DISCOVERY_STATE = {"agents": None, "versions": {}, "generated_at": "", "reason": ""}


def _client_update_spec(key):
    return next(
        (spec for spec in client_update_specs() if clean_text(spec.get("key")) == key),
        None,
    )


# CLI program files are big (the claude bundle is ~275MB, the codex native
# binary ~200MB). Scanning one is cheap; doing it on every request would not
# be. Parsed catalogs are cached against (path, size, mtime) so a CLI update
# invalidates the entry by itself, with no version bookkeeping.
_PROGRAM_CATALOG_CACHE = {}
_PROGRAM_CATALOG_CACHE_LOCK = threading.Lock()
_MAX_PROGRAM_SCAN_BYTES = 600 * 1024 * 1024


def _program_fingerprint(path):
    try:
        stat = os.stat(path)
    except OSError:
        return None
    if stat.st_size > _MAX_PROGRAM_SCAN_BYTES:
        return None
    return (os.path.realpath(path), stat.st_size, int(stat.st_mtime))


PROGRAM_CATALOG_CACHE_FILE = os.path.join(CONFIG_DIR, "client-catalogs.json")


def _load_persisted_catalogs():
    """Parsed catalogs saved from a previous run, keyed by file fingerprint.

    Scanning the client program files costs ~4.4 seconds — the Claude bundle
    alone is ~275MB — and the result only changes when the client is updated.
    Holding it in memory meant paying that on every bridge restart. On disk it
    survives, so a restart reads a few KB of JSON instead of 475MB, and an
    updated client still rescans because its fingerprint no longer matches."""
    raw = load_json(PROGRAM_CATALOG_CACHE_FILE, {}) or {}
    return raw if isinstance(raw, dict) else {}


def _persisted_catalog_key(name, fingerprint):
    path, size, mtime = fingerprint
    return f"{name}|{path}|{size}|{mtime}"


def _cached_program_catalog(name, path, parser):
    """Run `parser(text)` over a program file once per (file, version) and
    remember the result, in memory and on disk. Any read/parse failure caches
    as an empty catalog for that fingerprint so a broken install isn't
    re-scanned on every request."""
    fingerprint = _program_fingerprint(path)
    if not fingerprint:
        return []
    key = (name, fingerprint)
    with _PROGRAM_CATALOG_CACHE_LOCK:
        if key in _PROGRAM_CATALOG_CACHE:
            return _PROGRAM_CATALOG_CACHE[key]
    disk_key = _persisted_catalog_key(name, fingerprint)
    persisted = _load_persisted_catalogs()
    stored = persisted.get(disk_key)
    if isinstance(stored, list):
        with _PROGRAM_CATALOG_CACHE_LOCK:
            _PROGRAM_CATALOG_CACHE[key] = stored
        return stored
    try:
        with open(path, "rb") as handle:
            text = handle.read().decode("utf-8", errors="replace")
        catalog = parser(text) or []
    except (OSError, MemoryError, ValueError):
        catalog = []
    with _PROGRAM_CATALOG_CACHE_LOCK:
        _PROGRAM_CATALOG_CACHE[key] = catalog
        # Only ever a handful of installed CLIs; drop older fingerprints of
        # the same program so an update doesn't grow this forever.
        for stale in [k for k in _PROGRAM_CATALOG_CACHE if k[0] == name and k != key]:
            _PROGRAM_CATALOG_CACHE.pop(stale, None)
    try:
        # Same pruning on disk: keep only this program's current fingerprint.
        fresh = {
            stored_key: value
            for stored_key, value in persisted.items()
            if not stored_key.startswith(f"{name}|")
        }
        fresh[disk_key] = catalog
        save_json(PROGRAM_CATALOG_CACHE_FILE, fresh)
    except OSError:
        pass
    return catalog


# --- Claude ---------------------------------------------------------------

def claude_bundle_path():
    """The claude CLI's real program file. `~/.local/bin/claude` is usually a
    symlink into ~/.local/share/claude/versions/<version>; a package install
    puts it elsewhere on PATH. Anything too small to be the bundle (a shell
    shim) is rejected, and the versions directory is tried as a fallback."""
    spec = _client_update_spec("claude") or {}
    candidates = [
        (spec.get("version_cmd") or [None])[0],
        shutil.which("claude"),
        os.path.expanduser("~/.local/bin/claude"),
    ]
    for candidate in candidates:
        if not candidate:
            continue
        resolved = os.path.realpath(os.path.expanduser(candidate))
        try:
            if os.path.isfile(resolved) and os.path.getsize(resolved) > 10_000_000:
                return resolved
        except OSError:
            continue
    versions = sorted(
        glob.glob(os.path.expanduser("~/.local/share/claude/versions/*")),
        key=lambda item: os.path.getmtime(item) if os.path.exists(item) else 0,
    )
    for candidate in reversed(versions):
        try:
            if os.path.isfile(candidate) and os.path.getsize(candidate) > 10_000_000:
                return candidate
        except OSError:
            continue
    return ""


def _parse_claude_catalog(text):
    """Model aliases the claude CLI accepts for --model, with the real name and
    effort levels of whatever each alias currently points at.

    Two structures in the bundle, both authoritative:
      latest_per_family:{fable:"claude-fable-5",opus:"claude-opus-5",...}
      {id:"claude-opus-5",family:"opus",display_name:"Opus 5",...
       capabilities:["effort","max_effort","xhigh_effort",...]}

    Aliases are used rather than full ids on purpose: `--model opus` follows
    "the latest Opus" the way the CLI intends, and the family table is what
    tells us which id that is today. Families absent from the table (mythos)
    are absent from the dropdown, because the CLI doesn't take them either."""
    family_block = re.search(r"latest_per_family:\{([^}]*)\}", text)
    if not family_block:
        return []
    aliases = re.findall(r"([A-Za-z0-9_]+):\"(claude-[A-Za-z0-9.\-]+)\"", family_block.group(1))
    if not aliases:
        return []
    registry = {}
    for match in re.finditer(
        r"\{id:\"(claude-[A-Za-z0-9.\-]+)\",family:\"[A-Za-z0-9_]+\",display_name:\"([^\"]+)\"",
        text,
    ):
        model_id, display_name = match.group(1), match.group(2)
        if model_id in registry:
            continue
        tail = text[match.end() : match.end() + 1500]
        capability_block = re.search(r"capabilities:\[([^\]]*)\]", tail)
        capabilities = set()
        if capability_block:
            capabilities = {
                part.strip().strip('"')
                for part in capability_block.group(1).split(",")
                if part.strip()
            }
        default_effort = re.search(r"default_effort:\"([A-Za-z0-9_]+)\"", tail)
        registry[model_id] = (
            display_name,
            capabilities,
            default_effort.group(1) if default_effort else "",
        )
    catalog = []
    for alias, model_id in aliases:
        display_name, capabilities, default_effort = registry.get(model_id, ("", set(), ""))
        efforts = []
        if "effort" in capabilities:
            # --help enumerates the full ladder (low, medium, high, xhigh,
            # max); the per-model capabilities say how far up it may go.
            if "max_effort" in capabilities:
                efforts.append("max")
            if "xhigh_effort" in capabilities:
                efforts.append("xhigh")
            efforts.extend(["high", "medium", "low"])
        catalog.append(
            {
                "value": alias,
                "label": display_name or alias,
                "model_id": model_id,
                "efforts": efforts,
                "default_effort": default_effort,
                "listed": True,
            }
        )
    return catalog


def discover_claude_model_catalog(path=""):
    path = path or claude_bundle_path()
    if not path:
        return []
    return _cached_program_catalog("claude", path, _parse_claude_catalog)


# --- Codex ----------------------------------------------------------------

def codex_native_binary_path():
    """The real Codex ELF (the npm wrapper chain ends in a vendored native
    binary) — the model CATALOG lives inside it as embedded JSON."""
    patterns = [
        "~/.npm-global/lib/node_modules/@openai/codex/node_modules/@openai/*/vendor/*/bin/codex",
        "~/.local/lib/node_modules/@openai/codex/node_modules/@openai/*/vendor/*/bin/codex",
        "/usr/lib/node_modules/@openai/codex/node_modules/@openai/*/vendor/*/bin/codex",
    ]
    for pattern in patterns:
        for candidate in sorted(glob.glob(os.path.expanduser(pattern))):
            try:
                if os.path.isfile(candidate) and os.path.getsize(candidate) > 10_000_000:
                    return candidate
            except OSError:
                continue
    return ""


def _parse_codex_catalog(text):
    """Codex's embedded model catalog. Each entry looks like

        {"slug": "gpt-5.6-sol", ... "display_name": "GPT-5.6-Sol",
         "supported_reasoning_levels": [{"effort": "low", ...}, ...],
         "visibility": "list", "priority": 1, "model_messages": {...}}

    Every field we want appears before the enormous "model_messages" blob, so
    each entry is only scanned that far. `visibility` is honoured: Codex marks
    retired models "hide" and its own /model screen drops them — AWBN used to
    list gpt-5.4 and gpt-5.4-mini long after they left the picker. Hidden
    models stay usable (a session already on one still launches), they just
    aren't offered."""
    catalog = []
    seen = set()
    for match in re.finditer(r'"slug":\s*"(gpt-[A-Za-z0-9._\-]{1,64})"', text):
        slug = match.group(1)
        if slug in seen:
            continue
        seen.add(slug)
        tail = text[match.end() : match.end() + 12000]
        for terminator in ('"model_messages"', '"slug"'):
            cut = tail.find(terminator)
            if cut != -1:
                tail = tail[:cut]
        display_name = re.search(r'"display_name":\s*"([^"]+)"', tail)
        visibility = re.search(r'"visibility":\s*"([a-z_]+)"', tail)
        priority = re.search(r'"priority":\s*(-?\d+)', tail)
        default_effort = re.search(r'"default_reasoning_level":\s*"([a-z]+)"', tail)
        levels_block = re.search(
            r'"supported_reasoning_levels":\s*\[(.*?)\]', tail, re.S
        )
        efforts = []
        if levels_block:
            efforts = re.findall(r'"effort":\s*"([a-z]+)"', levels_block.group(1))
        # Highest first, matching how every other effort list in AWBN reads.
        ladder = ["ultra", "max", "xhigh", "high", "medium", "low"]
        efforts = [level for level in ladder if level in efforts] + [
            level for level in efforts if level not in ladder
        ]
        catalog.append(
            {
                "value": slug,
                "label": display_name.group(1) if display_name else slug,
                "efforts": efforts,
                "default_effort": default_effort.group(1) if default_effort else "",
                "listed": (visibility.group(1) if visibility else "list") == "list",
                "priority": int(priority.group(1)) if priority else 9999,
            }
        )
    catalog.sort(key=lambda item: item.get("priority", 9999))
    return catalog


def discover_codex_model_catalog(path=""):
    path = path or codex_native_binary_path()
    if not path:
        return []
    return _cached_program_catalog("codex", path, _parse_codex_catalog)


def discover_codex_models_from_binary(path=""):
    """Model slugs from Codex's embedded catalog, in the catalog's own order.
    Kept as the plain-list view over discover_codex_model_catalog()."""
    return [item["value"] for item in discover_codex_model_catalog(path)]


# --- Gemini ---------------------------------------------------------------

def gemini_bundle_paths():
    """Gemini CLI ships as a bundle of chunked JS. Only the chunk carrying
    packages/core/src/config/models.ts matters, but which chunk that is
    changes between releases, so candidates are returned newest-first."""
    patterns = [
        "~/.npm-global/lib/node_modules/@google/gemini-cli/bundle/*.js",
        "~/.local/lib/node_modules/@google/gemini-cli/bundle/*.js",
        "/usr/lib/node_modules/@google/gemini-cli/bundle/*.js",
        "/usr/local/lib/node_modules/@google/gemini-cli/bundle/*.js",
    ]
    found = []
    for pattern in patterns:
        found.extend(glob.glob(os.path.expanduser(pattern)))
    return sorted(set(found))


def _parse_gemini_catalog(text):
    """Gemini's model list, from the CLI's own `VALID_GEMINI_MODELS` set.

    The set is written as references to the model constants declared just
    above it, so both are read and resolved:

        var PREVIEW_GEMINI_3_1_MODEL = "gemini-3.1-pro-preview";
        var VALID_GEMINI_MODELS = new Set([ PREVIEW_GEMINI_3_1_MODEL, ... ]);

    "none" is a sentinel for "this slot has no preview build", not a model.
    Gemini exposes no friendly display names — its own picker shows the raw
    id — so the id is the label."""
    if "VALID_GEMINI_MODELS" not in text:
        return []
    constants = dict(
        re.findall(r"var ([A-Z0-9_]+) = \"([A-Za-z0-9.\-]+)\";", text)
    )
    members = re.search(
        r"var VALID_GEMINI_MODELS = /\* @__PURE__ \*/ new Set\(\[(.*?)\]\)", text, re.S
    ) or re.search(r"var VALID_GEMINI_MODELS = new Set\(\[(.*?)\]\)", text, re.S)
    if not members:
        return []
    catalog = []
    seen = set()
    # "Auto" is AWBN's own "let the CLI choose" entry: it means "don't pass
    # --model at all", and every launch path already treats it that way.
    for name in ["Auto"] + [
        part.strip() for part in members.group(1).split(",") if part.strip()
    ]:
        value = name if name == "Auto" else constants.get(name, "")
        if not value or value == "none" or value in seen:
            continue
        seen.add(value)
        catalog.append({"value": value, "label": value, "efforts": [], "listed": True})
    return catalog if len(catalog) > 1 else []


def discover_gemini_model_catalog():
    for path in gemini_bundle_paths():
        catalog = _cached_program_catalog("gemini", path, _parse_gemini_catalog)
        if catalog:
            return catalog
    return []


def _options_from_catalog(key, catalog, extra_efforts=()):
    """Turn a discovered catalog into the dropdown payload for one agent.

    `models` is what the picker offers (hidden entries dropped); `all_models`
    is everything the CLI still accepts, which is what a launch is validated
    against — a session sitting on a model the vendor has since delisted keeps
    working instead of being silently rewritten."""
    listed = [item for item in catalog if item.get("listed", True)]
    models = [item["value"] for item in listed]
    labels = {
        item["value"]: item.get("label") or item["value"]
        for item in listed
        if (item.get("label") or item["value"]) != item["value"]
    }
    # Every listed model gets an entry, including the ones that support no
    # effort at all — Haiku 4.5 is the live example. Leaving those out would
    # let the UI fall back to the per-agent union and offer Haiku a "max"
    # setting the model has no concept of.
    efforts_by_model = {
        item["value"]: (
            list(extra_efforts) + list(item.get("efforts") or [])
            if item.get("efforts")
            else ["Default"]
        )
        for item in listed
    }
    # The per-agent list stays in the payload for anything that hasn't been
    # told about per-model efforts yet: the union, in ladder order.
    ladder = ["Ultracode", "ultra", "max", "xhigh", "high", "medium", "low"]
    union = {
        level
        for levels in efforts_by_model.values()
        for level in levels
        if level != "Default"
    }
    efforts = [level for level in ladder if level in union] + sorted(
        level for level in union if level not in ladder
    )
    return {
        "models": models,
        "all_models": [item["value"] for item in catalog],
        "model_labels": labels,
        "efforts": efforts or list(UI_EFFORT_OPTIONS.get(key) or ["Default"]),
        "efforts_by_model": efforts_by_model,
        "models_dynamic": bool(models),
        "efforts_dynamic": bool(union),
    }


def _static_options(key):
    """The hardcoded backup, shaped like a discovery result and flagged as not
    live so the app can label it."""
    models = list(UI_MODEL_OPTIONS.get(key) or [])
    return {
        "models": models,
        "all_models": models,
        "model_labels": {},
        "efforts": list(UI_EFFORT_OPTIONS.get(key) or ["Default"]),
        "efforts_by_model": {},
        "models_dynamic": False,
        "efforts_dynamic": False,
    }


def discover_claude_model_options():
    """Claude's --model aliases, their real names, and the effort levels each
    one actually supports — read from the installed bundle's own model
    registry. Replaces (v4.3.3) scraping three example words out of --help
    prose, which was never the list and silently omitted haiku."""
    catalog = discover_claude_model_catalog()
    if not catalog:
        return _static_options("claude")
    return _options_from_catalog("claude", catalog, extra_efforts=CLAUDE_EXTRA_EFFORTS)


def discover_codex_model_options():
    """Codex's model catalog, straight out of the native binary: real names,
    per-model reasoning levels, and the vendor's own show/hide flag."""
    catalog = discover_codex_model_catalog()
    if not catalog:
        return _static_options("codex")
    return _options_from_catalog("codex", catalog)


def discover_gemini_model_options():
    """Gemini's own VALID_GEMINI_MODELS set, read from the installed bundle.
    Gemini has no effort flag, so efforts stay Default."""
    catalog = discover_gemini_model_catalog()
    if not catalog:
        return _static_options("gemini")
    options = _options_from_catalog("gemini", catalog)
    options["efforts"] = list(UI_EFFORT_OPTIONS.get("gemini") or ["Default"])
    options["efforts_dynamic"] = False
    return options


# Discovery attempted only for the CLIs with a readable model registry
# (claude, codex, gemini); hermes and ollama are handled directly in
# build_model_discovery_agents (hermes static passthrough, ollama already
# dynamic via visible_ollama_models()).
MODEL_DISCOVERERS = {
    "claude": discover_claude_model_options,
    "codex": discover_codex_model_options,
    "gemini": discover_gemini_model_options,
}


def build_model_discovery_agents():
    """Build the full /client/models payload: one entry per fixed-list agent
    (claude/codex/gemini interrogated live; hermes passed through static)
    plus Ollama's already-dynamic installed-model list."""
    agents = []
    for key in SELECTABLE_FIXED_AGENTS:
        discoverer = MODEL_DISCOVERERS.get(key)
        if discoverer:
            try:
                options = discoverer()
            except Exception:  # noqa: BLE001 - a bad read falls back, never fails
                options = _static_options(key)
        else:
            options = _static_options(key)
        models = options.get("models") or ["Default"]
        efforts = options.get("efforts") or ["Default"]
        settings = UI_DEFAULT_AGENT_SETTINGS.get(key) or {}
        # The configured default only survives if the live catalog still
        # offers it; otherwise the catalog's own first entry (the vendor's
        # top pick) wins. Resolved inline rather than via default_model_for()
        # because this function is what builds the cache that reads from.
        default_model = clean_text(settings.get("model"))
        if default_model not in models:
            default_model = models[0]
        agents.append(
            {
                "key": key,
                "label": UI_AGENT_LABELS.get(key, key.title()),
                "agent": key,
                "models": models,
                "all_models": options.get("all_models") or models,
                "model_labels": options.get("model_labels") or {},
                "efforts": efforts,
                "efforts_by_model": options.get("efforts_by_model") or {},
                "default_model": default_model,
                "default_effort": settings.get("effort") or "Default",
                "connected": bool(installed_cli_path(key)),
                "local": False,
                "model_source": "dynamic" if options.get("models_dynamic") else "static",
                "effort_source": "dynamic" if options.get("efforts_dynamic") else "static",
                "static": not (
                    options.get("models_dynamic") or options.get("efforts_dynamic")
                ),
            }
        )
    installed_ollama = visible_ollama_models()
    agents.append(
        {
            "key": "ollama",
            "label": "Ollama",
            "agent": "local",
            "models": installed_ollama or ["Default"],
            "all_models": installed_ollama or ["Default"],
            "model_labels": {},
            "efforts": ["Default"],
            "efforts_by_model": {},
            "default_model": installed_ollama[0] if installed_ollama else "Default",
            "default_effort": "Default",
            "connected": bool(installed_cli_path("ollama") or installed_ollama),
            "local": True,
            "model_source": "dynamic",
            "effort_source": "static",
            "static": False,
        }
    )
    return agents


def check_model_name(agent_key, model):
    """Check a typed model name against the installed CLI's own catalog.

    Returns `known` False for a name the CLI has never heard of, so the app can
    say so before storing it. Where there is nothing to check against — a
    custom client, an agent with no readable catalog — `checkable` is False and
    the name is accepted as-is, because refusing on no evidence would be its
    own kind of lie."""
    agent_key = clean_text(agent_key)
    if agent_key == "local":
        agent_key = "ollama"
    model = clean_text(model)
    result = {
        "ok": True,
        "agent": agent_key,
        "model": model,
        "known": False,
        "checkable": False,
        "label": "",
        "listed": False,
        "source": "static",
        "models": [],
    }
    if not model:
        return {**result, "ok": False, "error": "no model name given"}
    try:
        agents = get_model_discovery_agents()
    except Exception:  # noqa: BLE001 - fall through to "can't check"
        agents = []
    for agent in agents:
        if clean_text(agent.get("key")) != agent_key:
            continue
        listed = [clean_text(item) for item in agent.get("models") or []]
        every = [clean_text(item) for item in agent.get("all_models") or []] or listed
        source = clean_text(agent.get("model_source")) or "static"
        # A static baseline is a backup list, not evidence about what the CLI
        # accepts — don't reject a name on its say-so.
        checkable = source == "dynamic"
        return {
            **result,
            "known": (model in every) if checkable else True,
            "checkable": checkable,
            "label": clean_text((agent.get("model_labels") or {}).get(model)),
            "listed": model in listed,
            "source": source,
            "models": listed,
        }
    return {**result, "known": True}


def model_cache_versions_changed(previous_versions, current_versions):
    """Pure predicate: True when the set of tracked CLI versions differs
    from what the discovery cache was last built against — the 'new models
    arrived' moment the user wants dropdowns to notice on their own. An
    empty `previous` (first run) always counts as changed so the cache gets
    built at least once."""
    previous_versions = previous_versions or {}
    current_versions = current_versions or {}
    if not previous_versions:
        return True
    return set(previous_versions.items()) != set(current_versions.items())


def refresh_model_discovery_cache(versions=None, reason="manual"):
    with _MODEL_DISCOVERY_LOCK:
        agents = build_model_discovery_agents()
        _MODEL_DISCOVERY_STATE["agents"] = agents
        _MODEL_DISCOVERY_STATE["versions"] = dict(versions or {})
        _MODEL_DISCOVERY_STATE["generated_at"] = now_iso()
        _MODEL_DISCOVERY_STATE["reason"] = reason
        return agents


def peek_model_discovery_agents():
    """The discovered agents IF they are already cached, otherwise None.

    Never builds. Building means reading each installed CLI's program file —
    the Claude bundle alone is ~275MB — which measured 4.3 seconds cold. That
    is fine in the background thread that warms this cache at startup, and not
    fine on a request the app blocks its launch on. Callers that can live with
    the hardcoded baseline for one call should use this; /client/models still
    builds on demand for callers that genuinely need the live list."""
    with _MODEL_DISCOVERY_LOCK:
        return _MODEL_DISCOVERY_STATE["agents"]


def get_model_discovery_agents(force=False):
    with _MODEL_DISCOVERY_LOCK:
        cached = _MODEL_DISCOVERY_STATE["agents"]
        versions = dict(_MODEL_DISCOVERY_STATE.get("versions") or {})
    if force:
        return refresh_model_discovery_cache(versions=versions, reason="forced")
    if cached is None:
        return refresh_model_discovery_cache(versions=versions, reason="startup")
    return cached


def note_client_versions_for_model_cache(checks):
    """Called after every /client/updates scan with that scan's own results
    — no extra CLI invocations. If any tracked client's installed version
    differs from what the model-discovery cache was last built against,
    rebuild it: a version bump is exactly the 'a CLI shipped something new'
    moment the user wants dropdowns to notice without being asked. Returns
    True if a rebuild happened."""
    current_versions = {
        clean_text(item.get("key")): clean_text(item.get("installed"))
        for item in (checks or [])
        if clean_text(item.get("key"))
    }
    with _MODEL_DISCOVERY_LOCK:
        previous_versions = dict(_MODEL_DISCOVERY_STATE.get("versions") or {})
    if not model_cache_versions_changed(previous_versions, current_versions):
        return False
    refresh_model_discovery_cache(versions=current_versions, reason="version-change")
    return True


def normalized_filesystem_path(path):
    try:
        raw = os.fspath(path)
    except TypeError:
        raw = ""
    return os.path.realpath(os.path.abspath(os.path.expanduser(raw)))


def is_private_app_data_path(path):
    candidate = normalized_filesystem_path(path)
    root = normalized_filesystem_path(CONFIG_DIR)
    try:
        return os.path.commonpath([candidate, root]) == root
    except ValueError:
        return False


def chmod_best_effort(path, mode):
    try:
        if not os.path.islink(path) and os.path.exists(path):
            os.chmod(path, mode)
    except OSError:
        pass


def ensure_private_dir(path):
    os.makedirs(path, mode=PRIVATE_DIR_MODE, exist_ok=True)
    if is_private_app_data_path(path):
        chmod_best_effort(path, PRIVATE_DIR_MODE)


def ensure_private_parent(path):
    parent = os.path.dirname(os.path.abspath(os.path.expanduser(os.fspath(path))))
    if is_private_app_data_path(parent):
        ensure_private_dir(parent)
    else:
        os.makedirs(parent, exist_ok=True)


def ensure_private_file(path):
    if is_private_app_data_path(path):
        chmod_best_effort(path, PRIVATE_FILE_MODE)


def secure_existing_app_data():
    if not os.path.isdir(CONFIG_DIR):
        return {"dirs": 0, "files": 0}
    fixed_dirs = 0
    fixed_files = 0
    for current, directories, files in os.walk(CONFIG_DIR):
        if os.path.islink(current):
            directories[:] = []
            continue
        chmod_best_effort(current, PRIVATE_DIR_MODE)
        fixed_dirs += 1
        directories[:] = [
            directory
            for directory in directories
            if not os.path.islink(os.path.join(current, directory))
        ]
        for filename in files:
            path = os.path.join(current, filename)
            if os.path.islink(path):
                continue
            chmod_best_effort(path, PRIVATE_FILE_MODE)
            fixed_files += 1
    return {"dirs": fixed_dirs, "files": fixed_files}


def merge_missing_dict(target, source):
    changed = False
    for key, value in source.items():
        if key not in target:
            target[key] = value
            changed = True
            continue
        existing = target.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            if merge_missing_dict(existing, value):
                changed = True
    return changed


def copy_missing_tree(source, destination):
    if os.path.isdir(source):
        if os.path.exists(destination) and not os.path.isdir(destination):
            raise RuntimeError(
                f"bootstrap destination is not a directory: {destination}"
            )
        ensure_private_dir(destination)
        for name in os.listdir(source):
            copy_missing_tree(
                os.path.join(source, name),
                os.path.join(destination, name),
            )
        return
    if os.path.exists(destination):
        return
    ensure_private_parent(destination)
    shutil.copy2(source, destination)
    ensure_private_file(destination)


def merge_or_copy_bootstrap_file(source, destination):
    if os.path.exists(destination) and os.path.isdir(destination):
        raise RuntimeError(f"bootstrap destination is a directory: {destination}")
    if not os.path.exists(destination):
        ensure_private_parent(destination)
        shutil.copy2(source, destination)
        ensure_private_file(destination)
        return
    if not source.lower().endswith(".json"):
        return
    source_value = load_json(source, None)
    destination_value = load_json(destination, None)
    if not isinstance(source_value, dict) or not isinstance(destination_value, dict):
        return
    if merge_missing_dict(destination_value, source_value):
        save_json(destination, destination_value)


def bootstrap_next_config_dir():
    os.makedirs(os.path.dirname(CONFIG_DIR), exist_ok=True)
    ensure_private_dir(CONFIG_DIR)
    if os.path.isfile(CONFIG_BOOTSTRAP_FILE):
        secure_existing_app_data()
        return
    if not os.path.isdir(LEGACY_CONFIG_DIR):
        secure_existing_app_data()
        return
    for name in os.listdir(LEGACY_CONFIG_DIR):
        source = os.path.join(LEGACY_CONFIG_DIR, name)
        destination = os.path.join(CONFIG_DIR, name)
        if os.path.isdir(source):
            copy_missing_tree(source, destination)
        else:
            merge_or_copy_bootstrap_file(source, destination)
    save_json(
        CONFIG_BOOTSTRAP_FILE,
        {"bootstrapped_at": now_iso(), "source": LEGACY_CONFIG_DIR},
    )
    secure_existing_app_data()


def preferred_worker_model(agent):
    """Return the first (cheapest) model from PREFERRED_WORKER_MODELS for *agent*.

    Falls back to "Default" for unrecognised backends.
    """
    entries = PREFERRED_WORKER_MODELS.get(clean_text(agent) or "", [])
    return entries[0] if entries else "Default"


def now_iso():
    return datetime.now().astimezone().isoformat()


def authoritative_time_context():
    moment = datetime.now().astimezone()
    zone_name = getattr(moment.tzinfo, "key", None) or moment.tzname() or "local"
    offset = moment.strftime("%z")
    if len(offset) == 5:
        offset = offset[:3] + ":" + offset[3:]
    return (
        "<session_context>\n"
        "Authoritative local system time for this turn:\n"
        f"- Local date and time: {moment.strftime('%A, %B %-d, %Y at %-I:%M:%S %p %Z')}\n"
        f"- ISO 8601: {moment.isoformat()}\n"
        f"- Time zone: {zone_name} (UTC{offset})\n"
        "Use this as the source of truth for today, yesterday, tomorrow, elapsed "
        "dates, deadlines, and any other relative time reference. If conversation "
        "history conflicts with this clock, this clock wins.\n"
        "</session_context>"
    )


def load_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def _semver_tuple(value):
    """Extract the first x.y.z-like version from text."""
    match = re.search(r"(\d+)\.(\d+)\.(\d+)", value or "")
    return tuple(int(part) for part in match.groups()) if match else None


def _run_capture(cmd, timeout=25, env=None):
    """Run a command and return (ok, combined stdout/stderr). Never raises."""
    try:
        process = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            env=env,
        )
        return process.returncode == 0, (process.stdout or "") + (process.stderr or "")
    except Exception as exc:
        return False, str(exc)


def _first_command_line(output):
    return (clean_text(output).splitlines() or [""])[0]


def _version_text(output):
    parsed = _semver_tuple(clean_text(output))
    return ".".join(map(str, parsed)) if parsed else clean_text(output)


def other_awbn_codex_turn_is_active(session_id):
    """True when updating Codex would overlap another AWBN Codex turn.

    The current turn has already claimed its slot by the time stream_codex()
    calls this helper, so its own session id must be explicitly ignored.
    """
    with ACTIVE_LOCK:
        active_session_ids = [
            active_id
            for active_id in ACTIVE_TURNS
            if active_id != clean_text(session_id)
        ]
    for active_id in active_session_ids:
        try:
            active_session = load_session(active_id)
        except (OSError, ValueError, KeyError):
            continue
        if clean_text(active_session.get("agent")).lower() == "codex":
            return True
    return False


def auto_update_codex_before_turn(session_id):
    """Check and, when needed, update Codex before AWBN starts a turn.

    An update failure is advisory: an installed Codex may still be perfectly
    usable, so this returns the failure for the Work Log but never prevents the
    user's turn from launching.  A second active AWBN Codex turn defers the
    install entirely to avoid changing the global npm package mid-turn.
    """
    # A workbench must not silently mutate a globally installed client.  Users
    # can update from Options, or explicitly restore the legacy behavior for a
    # managed machine with this environment variable.
    enabled = clean_text(os.environ.get("AWBN_CODEX_AUTO_UPDATE")).lower()
    if enabled not in {"1", "true", "yes", "on"}:
        return {"checked": False, "reason": "disabled"}

    spec = _client_update_spec("codex") or {}
    version_cmd = spec.get("version_cmd")
    latest_cmd = spec.get("latest_cmd")
    update_cmd = spec.get("update_cmd")
    if not version_cmd or not latest_cmd or not update_cmd:
        return {"checked": False, "error": "Codex update commands are not configured."}

    # Never block a turn behind another turn's update check.
    if not CODEX_AUTO_UPDATE_LOCK.acquire(blocking=False):
        return {"checked": False, "reason": "check already running"}
    try:
        now = time.monotonic()
        if now - float(CODEX_AUTO_UPDATE_STATE.get("checked_at") or 0) < CODEX_AUTO_UPDATE_INTERVAL_SECONDS:
            return {"checked": False, "reason": "recent"}
        if other_awbn_codex_turn_is_active(session_id):
            return {"checked": False, "deferred": True}

        with UPDATE_LOCK:
            installed_ok, installed_output = _run_capture(version_cmd)
            latest_ok, latest_output = _run_capture(latest_cmd, timeout=40)

            installed_line = _first_command_line(installed_output) if installed_ok else ""
            latest_line = _first_command_line(latest_output) if latest_ok else ""
            installed_tuple = _semver_tuple(installed_line)
            latest_tuple = _semver_tuple(latest_line)
            installed = _version_text(installed_line or installed_output)
            latest = _version_text(latest_line or latest_output)

            CODEX_AUTO_UPDATE_STATE.update(
                {"checked_at": now, "installed": installed, "latest": latest}
            )
            if not installed_ok:
                return {
                    "checked": True,
                    "installed": installed,
                    "latest": latest,
                    "error": clean_text(installed_output) or "Could not run Codex --version.",
                }
            if not latest_ok or not latest_tuple:
                return {
                    "checked": True,
                    "installed": installed,
                    "latest": latest,
                    "error": clean_text(latest_output) or "Could not check the latest Codex version.",
                }
            if not installed_tuple:
                return {
                    "checked": True,
                    "installed": installed,
                    "latest": latest,
                    "error": "Could not read the installed Codex version.",
                }
            if installed_tuple >= latest_tuple:
                return {"checked": True, "installed": installed, "latest": latest, "updated": False}

            update_ok, update_output = _run_capture(update_cmd, timeout=300)
            if not update_ok:
                return {
                    "checked": True,
                    "installed": installed,
                    "latest": latest,
                    "error": clean_text(update_output) or "The Codex update command failed.",
                }

            verified_ok, verified_output = _run_capture(version_cmd)
            verified_line = _first_command_line(verified_output) if verified_ok else ""
            verified_tuple = _semver_tuple(verified_line)
            verified = _version_text(verified_line or verified_output)
            CODEX_AUTO_UPDATE_STATE["installed"] = verified or installed
            if not verified_ok or not verified_tuple or verified_tuple < latest_tuple:
                return {
                    "checked": True,
                    "installed": verified or installed,
                    "latest": latest,
                    "error": "Codex update finished but the installed version could not be verified.",
                }

            try:
                with _MODEL_DISCOVERY_LOCK:
                    versions = dict(_MODEL_DISCOVERY_STATE.get("versions") or {})
                versions["codex"] = verified
                refresh_model_discovery_cache(versions=versions, reason="codex-auto-update")
            except Exception:
                pass
            return {"checked": True, "installed": verified, "latest": latest, "updated": True}
    finally:
        CODEX_AUTO_UPDATE_LOCK.release()


def bridge_auth_token():
    global _BRIDGE_AUTH_TOKEN
    ensure_private_dir(CONFIG_DIR)
    if _BRIDGE_AUTH_TOKEN:
        return _BRIDGE_AUTH_TOKEN
    try:
        with open(BRIDGE_TOKEN_FILE, encoding="utf-8") as handle:
            token = clean_text(handle.read())
        if len(token) >= 32:
            try:
                os.chmod(BRIDGE_TOKEN_FILE, 0o600)
            except OSError:
                pass
            _BRIDGE_AUTH_TOKEN = token
            return token
    except OSError:
        pass

    token = "awbn_" + secrets.token_urlsafe(48)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    try:
        fd = os.open(BRIDGE_TOKEN_FILE, flags, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(token + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        _BRIDGE_AUTH_TOKEN = token
        return token
    except FileExistsError:
        with open(BRIDGE_TOKEN_FILE, encoding="utf-8") as handle:
            token = clean_text(handle.read())
        if len(token) < 32:
            raise RuntimeError("bridge auth token file is invalid")
        try:
            os.chmod(BRIDGE_TOKEN_FILE, 0o600)
        except OSError:
            pass
        _BRIDGE_AUTH_TOKEN = token
        return token


def save_json(path, value):
    ensure_private_parent(path)
    temporary = f"{path}.tmp-{os.getpid()}-{threading.get_ident()}-{uuid.uuid4()}"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    ensure_private_file(temporary)
    os.replace(temporary, path)
    ensure_private_file(path)


def claude_mcp_scope_for_cwd(cwd):
    """Which MCP toolkits a session actually needs, by its working folder
    (v4.1.0, requested: "we need AWBN to be as token sparing as possible").
    Every loaded MCP server's tool schemas live in the session's context and
    are re-read each step — the godot server alone ships 200+ tools — so a
    trading chat must not carry the game toolkit and vice versa.

    Scopes: 'game' (project.godot present) → godot + blender;
    'trading' (declares a broker library) → robinhood; 'home' (loose chats
    (terminal parity); anything else → lean (no heavy toolkits)."""
    home = os.path.expanduser("~")
    real = os.path.realpath(clean_text(cwd) or home)
    if os.path.isfile(os.path.join(real, "project.godot")):
        return "game"
    # v4.3.0 (beta prep): scope by what the project USES, not by its name.
    # Matching on folder names only worked on the machine those names came
    # from; a declared trading dependency means the same thing everywhere.
    if _project_declares_trading(real):
        return "trading"
    if real == home:
        return "home"
    return "lean"


_TRADING_MARKERS = (
    "robin_stocks",
    "robin-stocks",
    "alpaca",
    "ib_insync",
    "ib-insync",
    "ccxt",
)


def _project_declares_trading(root):
    """True when the project's own dependency files name a broker/trading
    library — the signal that its chats need the trading toolkit."""
    for name in ("requirements.txt", "pyproject.toml", "package.json"):
        path = os.path.join(root, name)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as handle:
                text = handle.read(200_000).lower()
        except OSError:
            continue
        if any(marker in text for marker in _TRADING_MARKERS):
            return True
    for sub in ("backend", "app", "src"):
        path = os.path.join(root, sub, "requirements.txt")
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as handle:
                text = handle.read(200_000).lower()
        except OSError:
            continue
        if any(marker in text for marker in _TRADING_MARKERS):
            return True
    return False


# v4.1.3 (reported: chats felt expensive): loose home chats run
# lean too — the heavy toolkits load ONLY in the project types that use
# them. Need the trading toolkit? Open the project that declares it.
_MCP_SCOPE_HEAVY_SERVERS = {
    "godot": {"game"},
    "blender": {"game"},
    "robinhood-trading": {"trading"},
}


def mcp_server_allowed_for_scope(name, scope):
    allowed = _MCP_SCOPE_HEAVY_SERVERS.get(clean_text(name).lower())
    if allowed is None:
        return True  # lightweight/unknown servers pass through everywhere
    return scope in allowed


def disabled_mcp_servers(config=None):
    """Server names the user has switched off, per client: {agent: {names}}.

    Measured before building this (2026-07-28): connecting all three of this
    machine's MCP servers - including Godot's ~200 tools — costs 105 prompt
    tokens per Claude turn, reproducible to the token across runs. The CLIs
    defer tool schemas rather than loading them eagerly, so a connected server
    is nearly free. These switches are therefore about noise, safety and
    startup hangs, NOT about saving tokens, and one global setting is enough —
    no need to make the user manage it per project."""
    config = config if isinstance(config, dict) else (load_json(CONFIG_FILE, {}) or {})
    raw = config.get("disabled_mcp_servers")
    disabled = {}
    if isinstance(raw, dict):
        for agent, names in raw.items():
            if isinstance(names, list):
                disabled[clean_text(agent)] = {
                    clean_text(name) for name in names if clean_text(name)
                }
    return disabled


def claude_mcp_servers_available():
    """Every MCP server Claude could load, from the user's own config."""
    servers = {}
    user_config = load_json(os.path.expanduser("~/.claude.json"), {}) or {}
    groups = [user_config.get("mcpServers")]
    projects = user_config.get("projects")
    if isinstance(projects, dict):
        for project_cfg in projects.values():
            if isinstance(project_cfg, dict):
                groups.append(project_cfg.get("mcpServers"))
    for group in groups:
        if isinstance(group, dict):
            for name, spec in group.items():
                if isinstance(spec, dict):
                    servers.setdefault(clean_text(name), spec)
    return servers


def codex_mcp_servers_available():
    """Every MCP server Codex could load, from ~/.codex/config.toml."""
    path = os.path.expanduser("~/.codex/config.toml")
    try:
        with open(path, encoding="utf-8") as handle:
            text = handle.read()
    except OSError:
        return {}
    return {
        name: {"source": "config.toml"}
        for name in re.findall(r"\[mcp_servers\.([A-Za-z0-9_\-]+)\]", text)
    }


def client_tools_payload(config=None):
    """What each client offers and whether it's switched on — the data behind
    the Tools panel. Read from each client's own config, never a hand-kept
    list, so a server the user adds or removes shows up by itself."""
    config = config if isinstance(config, dict) else (load_json(CONFIG_FILE, {}) or {})
    disabled = disabled_mcp_servers(config)
    clients = []
    for key, available, note in (
        ("claude", claude_mcp_servers_available(), ""),
        (
            "codex",
            codex_mcp_servers_available(),
            "Codex loads these from its own config.toml.",
        ),
    ):
        off = disabled.get(key) or set()
        clients.append(
            {
                "key": key,
                "label": UI_AGENT_LABELS.get(key, key.title()),
                "note": note,
                "servers": [
                    {
                        "name": name,
                        "enabled": name not in off,
                        # A server AWBN refuses regardless of the switch,
                        # because it hangs the client's startup handshake.
                        "blocked": key == "claude"
                        and name.lower() in CLAUDE_MCP_DENYLIST,
                    }
                    for name in sorted(available)
                ],
            }
        )
    return {
        "ok": True,
        "clients": clients,
        # Stated in the UI so nobody switches things off hoping to save money.
        "token_cost_note": (
            "Connected servers cost about 105 tokens a turn in total - the "
            "clients load tool details only when used. Measured, not estimated."
        ),
    }


def set_mcp_server_enabled(agent, name, enabled):
    """Switch one client's MCP server on or off. Global by design."""
    agent = clean_text(agent)
    name = clean_text(name)
    if not agent or not name:
        raise RuntimeError("agent and server name are required")
    config = load_json(CONFIG_FILE, {}) or {}
    raw = config.get("disabled_mcp_servers")
    store = raw if isinstance(raw, dict) else {}
    current = [clean_text(item) for item in (store.get(agent) or []) if clean_text(item)]
    if enabled:
        current = [item for item in current if item != name]
    elif name not in current:
        current.append(name)
    store[agent] = sorted(set(current))
    config["disabled_mcp_servers"] = store
    save_json(CONFIG_FILE, config)
    return client_tools_payload(config)


def build_claude_mcp_config(include_delegate, cwd=None):
    """Curated MCP set passed to every Claude launch with --strict-mcp-config.

    Collects the user's configured MCP servers (global `mcpServers` plus any
    project-scoped ones, e.g. robinhood-trading under the $HOME project) and
    drops the denylisted ones that hang Claude's startup handshake (codex). Adds the
    local delegate when smart orchestration is on. Because it is passed with
    --strict-mcp-config, ONLY these load — so the hanging codex MCP can never
    initialize, AND the useful servers are available in EVERY Claude session
    regardless of its working directory (important now that project-linked sessions
    launch in their own folder). Always returns a path (an empty server set is still
    written, so strict mode reliably excludes the denylisted globals)."""
    servers = {}
    switched_off = disabled_mcp_servers().get("claude") or set()
    user_config = load_json(os.path.expanduser("~/.claude.json"), {}) or {}
    groups = [user_config.get("mcpServers")]
    projects = user_config.get("projects")
    if isinstance(projects, dict):
        for project_cfg in projects.values():
            if isinstance(project_cfg, dict):
                groups.append(project_cfg.get("mcpServers"))
    for group in groups:
        if isinstance(group, dict):
            for name, spec in group.items():
                if clean_text(name).lower() in CLAUDE_MCP_DENYLIST:
                    continue
                # Honour the user's own switch from the Tools panel.
                if clean_text(name) in switched_off:
                    continue
                if isinstance(spec, dict):
                    servers.setdefault(name, spec)
    if os.path.isfile(BATCH_TOOLS_SERVER) and "awbn-batch" not in switched_off:
        servers["awbn-batch"] = {
            "command": "python3",
            "args": [BATCH_TOOLS_SERVER],
        }
    if include_delegate and os.path.isfile(LOCAL_DELEGATE_SERVER):
        servers["local-delegate"] = {
            "command": "python3",
            "args": [LOCAL_DELEGATE_SERVER],
            "env": {"DELEGATE_MODEL": "qwen3:8b"},
        }
    # v4.1.0: scope the heavy toolkits to the sessions that need them.
    scope = claude_mcp_scope_for_cwd(cwd)
    servers = {
        name: spec
        for name, spec in servers.items()
        if mcp_server_allowed_for_scope(name, scope)
    }
    config = {"mcpServers": servers}
    # One config file per scope — the resident process' launch signature
    # includes this path, so a session relaunches iff its scope changed.
    scoped_path = CLAUDE_MCP_CONFIG_FILE.replace(".json", f".{scope}.json")
    existing = load_json(scoped_path, None)
    if existing != config:
        save_json(scoped_path, config)
    return scoped_path


def clamp_int(value, default, minimum, maximum):
    try:
        number = int(value)
    except (TypeError, ValueError):
        number = default
    return max(minimum, min(maximum, number))


def memory_preferences():
    config = load_json(CONFIG_FILE, {}) or {}
    raw = config.get("memory_preferences") or {}
    if not isinstance(raw, dict):
        raw = {}
    prefs = dict(DEFAULT_MEMORY_PREFERENCES)
    prefs.update(raw)
    auto_update = clean_text(prefs.get("auto_update")).lower() or "off"
    if auto_update not in {"off", "manual", "smart", "every_turn"}:
        auto_update = "off"
    note_taker = clean_text(prefs.get("note_taker")).lower() or "ollama"
    if note_taker not in {"fallback", "ollama"}:
        note_taker = "fallback"
    prefs["auto_update"] = auto_update
    prefs["note_taker"] = note_taker
    prefs["ollama_model"] = clean_text(prefs.get("ollama_model")) or LOCAL_PROJECT_STATE_MODEL
    prefs["min_interval_seconds"] = clamp_int(
        prefs.get("min_interval_seconds"),
        DEFAULT_MEMORY_PREFERENCES["min_interval_seconds"],
        0,
        86_400,
    )
    prefs["min_prompt_chars"] = clamp_int(
        prefs.get("min_prompt_chars"),
        DEFAULT_MEMORY_PREFERENCES["min_prompt_chars"],
        0,
        20_000,
    )
    prefs["inject_max_chars"] = clamp_int(
        prefs.get("inject_max_chars"),
        DEFAULT_MEMORY_PREFERENCES["inject_max_chars"],
        500,
        PROJECT_STATE_MAX_CHARS,
    )
    prefs["skip_duplicate_prompts"] = prefs.get("skip_duplicate_prompts") is not False
    prefs["update_on_handoff"] = prefs.get("update_on_handoff") is not False
    prefs["inject_shared_state"] = prefs.get("inject_shared_state") is not False
    return prefs


def parse_iso_timestamp(value):
    try:
        timestamp = datetime.fromisoformat(clean_text(value))
        return timestamp.astimezone() if timestamp.tzinfo is None else timestamp
    except (TypeError, ValueError):
        return None


def latest_completed_prompt_before_current(session):
    turns = session.get("turns") or []
    if len(turns) < 2:
        return ""
    for turn in reversed(turns[:-1]):
        prompt = clean_text(turn.get("prompt"))
        if prompt:
            return prompt
    return ""


def should_refresh_project_state_after_turn(session, turn, prefs):
    mode = clean_text(prefs.get("auto_update")).lower()
    if mode in {"off", "manual"}:
        return False, f"auto_update={mode}"
    if clean_text(turn.get("status")) != "completed":
        return False, "turn not completed"
    if mode == "every_turn":
        return True, "every_turn"

    state_path = project_state_path(infer_project_root(session, session.get("cwd")))
    if state_path and not os.path.isfile(state_path):
        return True, "state file missing"

    prompt = clean_text(turn.get("prompt"))
    if prefs.get("skip_duplicate_prompts") and prompt:
        previous_prompt = latest_completed_prompt_before_current(session)
        if previous_prompt and previous_prompt == prompt:
            return False, "duplicate prompt"

    prompt_chars = len(prompt)
    output_chars = 0
    for item in turn.get("items") or []:
        if not isinstance(item, dict):
            continue
        if item.get("type") == "agentMessage":
            output_chars += len(clean_text(item.get("text") or item.get("content")))
    if prompt_chars < int(prefs.get("min_prompt_chars") or 0) and output_chars < 600:
        return False, "turn too small"

    updated_at = parse_iso_timestamp(session.get("project_state_updated_at"))
    if updated_at:
        elapsed = (datetime.now().astimezone() - updated_at).total_seconds()
        minimum = int(prefs.get("min_interval_seconds") or 0)
        if minimum > 0 and elapsed < minimum:
            return False, f"throttled {int(elapsed)}s/{minimum}s"
    return True, "smart threshold"


def session_path(session_id):
    if not re.fullmatch(r"[A-Za-z0-9:_-]+", session_id or ""):
        raise ValueError("invalid session id")
    return os.path.join(SESS_DIR, f"{session_id}.json")


def session_lock_path(session_id):
    return session_path(session_id) + ".lock"


def _session_thread_lock(session_id):
    with SESSION_LOCKS_LOCK:
        lock = SESSION_LOCKS.get(session_id)
        if lock is None:
            lock = threading.RLock()
            SESSION_LOCKS[session_id] = lock
        return lock


@contextmanager
def locked_config():
    """Serialize config.json read-modify-write operations across processes.

    Atomic replacement prevents torn JSON, but it does not prevent two bridge
    threads from both reading the same old value and silently overwriting one
    another's unrelated settings.  Keep the lock on a stable sidecar inode so
    it remains valid while config.json itself is atomically replaced.
    """
    depth = getattr(CONFIG_RMW_LOCAL, "depth", 0)
    with CONFIG_RMW_LOCK:
        if depth:
            CONFIG_RMW_LOCAL.depth = depth + 1
            try:
                yield
            finally:
                CONFIG_RMW_LOCAL.depth = depth
            return
        lock_path = f"{CONFIG_FILE}.lock"
        ensure_private_parent(lock_path)
        lock_fd = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o600)
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
            chmod_best_effort(lock_path, PRIVATE_FILE_MODE)
            CONFIG_RMW_LOCAL.depth = 1
            yield
        finally:
            CONFIG_RMW_LOCAL.depth = 0
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)
            finally:
                os.close(lock_fd)


@contextmanager
def locked_sessions(*session_ids):
    """Hold per-session locks across a full read-modify-write operation.

    `save_json` is atomic, but atomic replace alone still allows lost updates:
    two threads/processes can both read an old session, make different changes,
    then the later save overwrites the earlier one. These locks are both
    in-process (`RLock`) and cross-process (`flock` on `<session>.json.lock`) so
    the Python bridge and Tauri commands coordinate on the same session file.
    """
    unique_ids = sorted(
        {
            clean_text(session_id)
            for session_id in session_ids
            if clean_text(session_id)
        }
    )
    held = getattr(SESSION_LOCKS_LOCAL, "held", None)
    if held is None:
        held = set()
        SESSION_LOCKS_LOCAL.held = held
    acquired = []
    try:
        for session_id in unique_ids:
            if session_id in held:
                continue
            thread_lock = _session_thread_lock(session_id)
            thread_lock.acquire()
            lock_fd = None
            try:
                ensure_private_parent(session_lock_path(session_id))
                lock_fd = os.open(
                    session_lock_path(session_id),
                    os.O_RDWR | os.O_CREAT,
                    0o600,
                )
                fcntl.flock(lock_fd, fcntl.LOCK_EX)
                try:
                    os.chmod(session_lock_path(session_id), 0o600)
                except OSError:
                    pass
                held.add(session_id)
                acquired.append((session_id, thread_lock, lock_fd))
            except Exception:
                if lock_fd is not None:
                    try:
                        os.close(lock_fd)
                    except OSError:
                        pass
                thread_lock.release()
                raise
        yield
    finally:
        for session_id, thread_lock, lock_fd in reversed(acquired):
            held.discard(session_id)
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)
            except OSError:
                pass
            try:
                os.close(lock_fd)
            except OSError:
                pass
            thread_lock.release()


def load_session(session_id):
    with locked_sessions(session_id):
        with open(session_path(session_id), encoding="utf-8") as handle:
            return json.load(handle)


def preserve_concurrent_session_fields(session):
    """Preserve narrow UI edits made after this in-memory copy was loaded."""
    session_id = clean_text(session.get("id"))
    try:
        current = load_json(session_path(session_id), {}) or {}
    except ValueError:
        return session
    if not isinstance(current, dict) or current.get("id") != session_id:
        return session
    merged = None

    def _merged():
        nonlocal merged
        if merged is None:
            merged = deepcopy(session)
        return merged

    # kanban_phase is only ever written by the /session/kanban-phase endpoint
    # (a deliberate fresh load+lock+save). A long-running turn holds a stale
    # session copy and its periodic save_session() would otherwise clobber a
    # board move on its next checkpoint — so always take the on-disk value.
    # (The turn path never sets kanban_phase, so disk is authoritative.)
    current_phase = clean_text(current.get("kanban_phase"))
    if current_phase and current_phase != clean_text(session.get("kanban_phase")):
        _merged()["kanban_phase"] = current_phase

    # Title rescue: keep a concurrent user rename from being clobbered.
    current_title = clean_text(current.get("title"))
    if current_title and current.get("user_renamed") is True:
        incoming_updated = parse_iso_timestamp(session.get("updated_at"))
        current_updated = parse_iso_timestamp(current.get("updated_at"))
        should_preserve_title = session.get("user_renamed") is not True
        if current_updated and incoming_updated:
            should_preserve_title = (
                should_preserve_title or current_updated >= incoming_updated
            )
        if should_preserve_title:
            m = _merged()
            m["title"] = current_title
            m["user_renamed"] = True
            if clean_text(current.get("preview")):
                m["preview"] = clean_text(current.get("preview"))

    return merged if merged is not None else session


def project_record_session_key(session_id):
    """Return a bounded filename-safe key without changing the session id itself."""
    value = clean_text(session_id)
    label = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip(".-")[:64] or "session"
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]
    return f"{label}-{digest}"


def _project_record_thread_lock(root):
    key = os.path.realpath(root)
    with PROJECT_RECORD_LOCKS_LOCK:
        lock = PROJECT_RECORD_LOCKS.get(key)
        if lock is None:
            lock = threading.RLock()
            PROJECT_RECORD_LOCKS[key] = lock
        return lock


def filesystem_project_root_for_session(session=None, fallback_cwd=""):
    """Resolve project identity only from explicit state and the filesystem.

    Imported terminal history can have a generated title that happens to match
    a different registered project.  Project-local records and terminal
    summaries must never use those title/alias heuristics: a valid explicit
    project root wins, otherwise the session cwd and its nearest marker decide.
    """
    session = session or {}
    stored = clean_text(session.get("project_root"))
    if stored:
        stored = os.path.realpath(os.path.abspath(os.path.expanduser(stored)))
        if os.path.isdir(stored):
            return stored

    cwd = clean_text(session.get("cwd")) or clean_text(fallback_cwd)
    if not cwd:
        return ""
    cwd = os.path.realpath(os.path.abspath(os.path.expanduser(cwd)))
    if not os.path.isdir(cwd):
        return ""
    root = find_project_root(cwd)
    if not root:
        return ""
    root = os.path.realpath(os.path.abspath(os.path.expanduser(root)))
    return root if os.path.isdir(root) else ""


def _project_record_root(session, allow_existing=False):
    """Resolve a deliberately registered project eligible for local records.

    Native history discovery touches many unrelated working directories. Merely
    inferring a project-like cwd must therefore never create metadata there. A
    project is eligible only after it has an AWBN marker, or while saving an
    explicit project chat whose stored root agrees with the filesystem-derived
    root. Deletion may also clean up an existing mirror after its marker was
    removed.
    """
    home = os.path.realpath(os.path.abspath(os.path.expanduser("~")))
    stored = clean_text((session or {}).get("project_root"))
    try:
        root = filesystem_project_root_for_session(
            session,
            (session or {}).get("cwd"),
        )
    except Exception:
        return ""
    if (
        not root
        or root in {home, os.path.realpath(os.path.abspath(os.sep))}
        or not os.path.isdir(root)
    ):
        return ""

    metadata_dir = os.path.join(root, PROJECT_REGISTRY_DIRNAME)
    if os.path.lexists(metadata_dir) and os.path.islink(metadata_dir):
        return ""
    registry = os.path.join(metadata_dir, PROJECT_REGISTRY_FILENAME)
    registered = os.path.isfile(registry) and not os.path.islink(registry)

    explicit_project_chat = bool((session or {}).get("project_chat") is True)
    explicit_project_chat = bool(
        explicit_project_chat
        and stored
        and os.path.realpath(os.path.abspath(os.path.expanduser(stored))) == root
    )
    if registered or explicit_project_chat:
        return root

    if allow_existing and os.path.isdir(metadata_dir):
        key = project_record_session_key((session or {}).get("id"))
        chat_path = os.path.join(
            metadata_dir,
            PROJECT_RECORD_CHATS_DIRNAME,
            f"{key}.json",
        )
        handoff_path = os.path.join(
            metadata_dir,
            PROJECT_RECORD_HANDOFFS_DIRNAME,
            key,
        )
        if os.path.isfile(chat_path) or os.path.isdir(handoff_path):
            return root
    return ""


def _ensure_private_project_record_dir(path):
    """Create a project-record directory without following a symlink parent."""
    parent = os.path.dirname(path)
    if os.path.islink(parent):
        raise RuntimeError(f"refusing symlinked project record parent: {parent}")
    if os.path.lexists(path):
        if os.path.islink(path) or not os.path.isdir(path):
            raise RuntimeError(f"refusing unsafe project record directory: {path}")
    else:
        os.mkdir(path, PRIVATE_DIR_MODE)
    chmod_best_effort(path, PRIVATE_DIR_MODE)


def _save_private_project_text(path, content):
    parent = os.path.dirname(path)
    if os.path.islink(parent):
        raise RuntimeError(f"refusing symlinked project record parent: {parent}")
    if os.path.lexists(path) and os.path.islink(path):
        raise RuntimeError(f"refusing symlinked project record file: {path}")
    save_text_atomic(path, content)
    chmod_best_effort(path, PRIVATE_FILE_MODE)


def _ensure_project_record_gitignore(metadata_dir):
    path = os.path.join(metadata_dir, ".gitignore")
    if os.path.lexists(path) and os.path.islink(path):
        raise RuntimeError(f"refusing symlinked project record file: {path}")
    existing = ""
    if os.path.isfile(path):
        with open(path, encoding="utf-8") as handle:
            existing = handle.read()
    lines = {line.strip() for line in existing.splitlines()}
    additions = []
    if "/chats/" not in lines:
        additions.append("/chats/")
    if "/handoffs/" not in lines:
        additions.append("/handoffs/")
    if additions:
        if existing.strip():
            content = existing.rstrip() + "\n" + "\n".join(additions)
        else:
            content = PROJECT_RECORD_GITIGNORE
        _save_private_project_text(path, content)
    elif os.path.isfile(path):
        chmod_best_effort(path, PRIVATE_FILE_MODE)
    return path


def _same_file_or_path(source, destination):
    try:
        if os.path.exists(destination) and os.path.samefile(source, destination):
            return True
    except OSError:
        pass
    return os.path.realpath(source) == os.path.realpath(destination)


def _copy_private_file_atomic(source, destination):
    """Atomically copy a record, skipping an unchanged mtime/size snapshot."""
    source = os.path.abspath(os.path.expanduser(source))
    destination = os.path.abspath(os.path.expanduser(destination))
    if not os.path.isfile(source) or _same_file_or_path(source, destination):
        return False
    parent = os.path.dirname(destination)
    if os.path.islink(parent):
        raise RuntimeError(f"refusing symlinked project record parent: {parent}")
    if os.path.lexists(destination) and os.path.islink(destination):
        raise RuntimeError(f"refusing symlinked project record file: {destination}")

    source_stat = os.stat(source)
    try:
        destination_stat = os.stat(destination)
    except OSError:
        destination_stat = None
    if (
        destination_stat is not None
        and destination_stat.st_size == source_stat.st_size
        and destination_stat.st_mtime_ns == source_stat.st_mtime_ns
    ):
        chmod_best_effort(destination, PRIVATE_FILE_MODE)
        return False

    temporary = (
        f"{destination}.tmp-{os.getpid()}-{threading.get_ident()}-{uuid.uuid4()}"
    )
    try:
        with open(source, "rb") as source_handle, open(
            temporary, "xb"
        ) as destination_handle:
            shutil.copyfileobj(source_handle, destination_handle, length=1024 * 1024)
            destination_handle.flush()
            os.fsync(destination_handle.fileno())
        chmod_best_effort(temporary, PRIVATE_FILE_MODE)
        os.utime(
            temporary,
            ns=(source_stat.st_atime_ns, source_stat.st_mtime_ns),
            follow_symlinks=False,
        )
        os.replace(temporary, destination)
        chmod_best_effort(destination, PRIVATE_FILE_MODE)
        return True
    finally:
        try:
            os.remove(temporary)
        except OSError:
            pass


def _native_transcript_mirror_path(chats_dir, session):
    source = clean_text((session or {}).get("source_path"))
    if not source:
        return ""
    suffix = os.path.splitext(os.path.basename(source))[1]
    if not re.fullmatch(r"\.[A-Za-z0-9]{1,12}", suffix or ""):
        suffix = ".jsonl"
    key = project_record_session_key((session or {}).get("id"))
    return os.path.join(chats_dir, f"{key}.source{suffix.lower()}")


def mirror_project_session_records(session):
    """Mirror one complete session plus related records into its project."""
    root = _project_record_root(session)
    if not root:
        return {}
    key = project_record_session_key(session.get("id"))
    metadata_dir = os.path.join(root, PROJECT_REGISTRY_DIRNAME)
    chats_dir = os.path.join(metadata_dir, PROJECT_RECORD_CHATS_DIRNAME)
    handoffs_dir = os.path.join(metadata_dir, PROJECT_RECORD_HANDOFFS_DIRNAME)
    result = {"root": root, "session": "", "handoff": "", "source": ""}
    optional_errors = []

    with _project_record_thread_lock(root):
        _ensure_private_project_record_dir(metadata_dir)
        _ensure_project_record_gitignore(metadata_dir)
        _ensure_private_project_record_dir(chats_dir)

        session_mirror = os.path.join(chats_dir, f"{key}.json")
        if os.path.lexists(session_mirror) and os.path.islink(session_mirror):
            raise RuntimeError(
                f"refusing symlinked project record file: {session_mirror}"
            )
        save_json(session_mirror, session)
        chmod_best_effort(session_mirror, PRIVATE_FILE_MODE)
        result["session"] = session_mirror

        handoff_source = ""
        for field in ("handoff_stage_artifact", "handoff_artifact"):
            candidate = os.path.abspath(
                os.path.expanduser(clean_text(session.get(field)))
            )
            if candidate and os.path.isfile(candidate):
                handoff_source = candidate
                break
        if handoff_source:
            try:
                _ensure_private_project_record_dir(handoffs_dir)
                handoff_session_dir = os.path.join(handoffs_dir, key)
                _ensure_private_project_record_dir(handoff_session_dir)
                handoff_mirror = os.path.join(handoff_session_dir, "HANDOFF.md")
                _copy_private_file_atomic(handoff_source, handoff_mirror)
                result["handoff"] = handoff_mirror
            except Exception as error:
                optional_errors.append(f"handoff: {clean_text(error)}")

        source_path = os.path.abspath(
            os.path.expanduser(clean_text(session.get("source_path")))
        )
        if source_path and os.path.isfile(source_path):
            try:
                transcript_mirror = _native_transcript_mirror_path(chats_dir, session)
                _copy_private_file_atomic(source_path, transcript_mirror)
                result["source"] = transcript_mirror
            except Exception as error:
                optional_errors.append(f"source transcript: {clean_text(error)}")

    if optional_errors:
        raise RuntimeError("; ".join(optional_errors))
    return result


def remove_project_session_records(session):
    """Remove only this session's private mirror; never project source/metadata."""
    root = _project_record_root(session, allow_existing=True)
    if not root:
        return False
    key = project_record_session_key(session.get("id"))
    metadata_dir = os.path.join(root, PROJECT_REGISTRY_DIRNAME)
    chats_dir = os.path.join(metadata_dir, PROJECT_RECORD_CHATS_DIRNAME)
    handoffs_dir = os.path.join(metadata_dir, PROJECT_RECORD_HANDOFFS_DIRNAME)

    with _project_record_thread_lock(root):
        for directory in (metadata_dir, chats_dir, handoffs_dir):
            if os.path.lexists(directory) and os.path.islink(directory):
                raise RuntimeError(
                    f"refusing symlinked project record parent: {directory}"
                )
        if os.path.isdir(chats_dir):
            for name in os.listdir(chats_dir):
                if name == f"{key}.json" or name.startswith(f"{key}.source."):
                    path = os.path.join(chats_dir, name)
                    if os.path.isfile(path) or os.path.islink(path):
                        os.remove(path)
        handoff_session_dir = os.path.join(handoffs_dir, key)
        if os.path.islink(handoff_session_dir):
            raise RuntimeError(
                f"refusing symlinked project record directory: {handoff_session_dir}"
            )
        if os.path.isdir(handoff_session_dir):
            shutil.rmtree(handoff_session_dir)
    return True


def save_session(session):
    session_id = clean_text(session.get("id"))
    with locked_sessions(session_id):
        # Guard against a deleted session being resurrected: a turn thread that
        # was force-stopped during delete still runs its `finally: save_session`,
        # which would recreate the just-removed file. The flag is set + the file
        # removed under this same per-session lock, so the two are serialized —
        # a save that loses the race sees the flag and no-ops.
        with DELETED_SESSION_IDS_LOCK:
            if session_id in DELETED_SESSION_IDS:
                return
        persisted = preserve_concurrent_session_fields(session)
        save_json(session_path(session_id), persisted)
        try:
            mirror_project_session_records(persisted)
        except Exception as error:
            append_debug_event(
                "project_record_mirror_failed",
                session=session_id,
                error=clean_text(error)[:500],
            )


def clean_text(value):
    return str(value or "").replace("\x00", "").strip()


def claude_usage_limit_error(value):
    text = clean_text(value)
    if not text:
        return ""
    normalized = re.sub(r"\s+", " ", text.lower())
    limit_markers = (
        "claude.ai/settings/usage",
        "hit your monthly spend limit",
        "usage limit",
        "rate limit",
        "too many requests",
    )
    if not any(marker in normalized for marker in limit_markers):
        return ""
    return (
        "Claude usage limit reached. Check Claude Settings > Usage for the "
        "specific exhausted bucket and reset time. Claude CLI reported: "
        f"{text}"
    )


def claude_background_idle_timed_out(pending_bg, idle_seconds, timeout_seconds=None):
    """Return true only when pending Claude background work has gone silent too long.

    Foreground tool stalls use CLAUDE_STALL_HARD. This guard is separate because a
    `result` with pending background work intentionally keeps the turn open, but a
    missing task notification should not leave the UI "Working" forever.
    """
    try:
        pending = int(pending_bg)
        idle = float(idle_seconds)
        timeout = (
            CLAUDE_BACKGROUND_IDLE_TIMEOUT
            if timeout_seconds is None
            else float(timeout_seconds)
        )
    except (TypeError, ValueError):
        return False
    return pending > 0 and timeout > 0 and idle >= timeout


def safe_permissions_enabled():
    """Default to native client safety prompts/sandboxes.

    Historical AWBN behavior launched Claude/Codex/Gemini with bypass/yolo flags
    unless AGENT_WORKBENCH_SAFE_PERMISSIONS=1 was set. For a security-sensitive
    workbench, the default must be the safe path. The old variable still works,
    and an explicit unsafe escape hatch exists for local users who intentionally
    want the previous behavior.
    """
    unsafe = clean_text(os.environ.get("AGENT_WORKBENCH_UNSAFE_PERMISSIONS")).lower()
    legacy_safe = clean_text(os.environ.get("AGENT_WORKBENCH_SAFE_PERMISSIONS")).lower()
    if unsafe in {"1", "true", "yes", "on"}:
        return False
    if legacy_safe in {"0", "false", "no", "off"}:
        return False
    return True


def gemini_permission_args(*, skip_trust_on_unsafe=False):
    if safe_permissions_enabled():
        return ["--approval-mode", "default"]
    if skip_trust_on_unsafe:
        return ["--yolo", "--skip-trust"]
    return ["--approval-mode", "yolo"]


def maybe_emit_unsafe_permissions_notice(emit):
    if safe_permissions_enabled():
        return
    emit(
        {
            "type": "work",
            "kind": "system",
            "content": (
                "UNSAFE agent permissions override is enabled. AWBN will pass native "
                "bypass/yolo flags to agent CLIs for this turn."
            ),
        }
    )


def claude_config_path():
    return os.path.expanduser("~/.claude.json")


def patch_claude_project_trust(cwd):
    """Mark the current cwd trusted for Claude Code, matching the user's local schema.

    This is intentionally narrow: only the project entry for the launch cwd is
    touched, and the write goes through save_json's fsync + replace path.
    """
    if safe_permissions_enabled():
        return False
    path = claude_config_path()
    data = load_json(path, {}) or {}
    if not isinstance(data, dict):
        data = {}
    projects = data.setdefault("projects", {})
    if not isinstance(projects, dict):
        projects = {}
        data["projects"] = projects
    project_path = os.path.abspath(os.path.expanduser(clean_text(cwd) or "~"))
    project = projects.setdefault(project_path, {})
    if not isinstance(project, dict):
        project = {}
        projects[project_path] = project

    changed = False
    if project.get("hasTrustDialogAccepted") is not True:
        project["hasTrustDialogAccepted"] = True
        changed = True
    try:
        seen_count = int(project.get("projectOnboardingSeenCount") or 0)
    except (TypeError, ValueError):
        seen_count = 0
    if seen_count < 1:
        project["projectOnboardingSeenCount"] = 1
        changed = True
    if project.get("hasCompletedProjectOnboarding") is not True:
        project["hasCompletedProjectOnboarding"] = True
        changed = True
    if changed:
        save_json(path, data)
    return changed


def maybe_emit_claude_trust_preflight(cwd, emit):
    if safe_permissions_enabled():
        return
    try:
        changed = patch_claude_project_trust(cwd)
        if changed:
            emit(
                {
                    "type": "work",
                    "kind": "system",
                    "content": f"Claude trust preflight updated {claude_config_path()} for {os.path.abspath(os.path.expanduser(cwd or '~'))}",
                }
            )
    except Exception as error:
        emit(
            {
                "type": "work",
                "kind": "system",
                "content": f"Claude trust preflight failed: {clean_text(error)}",
            }
        )


BUILTIN_SKILLS = [
    ("deep-research", "Deep, multi-source research that returns a cited report."),
    ("code-review", "Reviews your current code changes for bugs and cleanups."),
    ("ultrareview", "Claude's ultra code review for a branch or pull request."),
    ("security-review", "Security review of pending code changes."),
    ("simplify", "Tidies and simplifies the code you just changed."),
    ("verify", "Runs the app and confirms a change actually works."),
    ("run", "Launches the app so you can see a change in action."),
    ("init", "Writes a CLAUDE.md describing this codebase."),
    ("review", "Reviews a GitHub pull request."),
    ("claude-api", "Reference for the Claude API and Anthropic SDK."),
    ("update-config", "Changes Claude Code settings, hooks, and permissions."),
    ("keybindings-help", "Helps you customize keyboard shortcuts."),
    ("fewer-permission-prompts", "Cuts down repetitive permission pop-ups."),
    ("loop", "Runs a prompt or command on a repeating schedule."),
    ("schedule", "Schedules recurring or one-time automated agent runs."),
]

SKILL_BLURBS = {
    "deep-research": "Deep, multi-source research that returns a cited report.",
    "code-review": "Reviews your current code changes for bugs and cleanups.",
    "ultrareview": "Claude's ultra code review for a branch or pull request.",
    "security-review": "Security review of pending code changes.",
    "simplify": "Tidies and simplifies the code you just changed.",
    "verify": "Runs the app and confirms a change actually works.",
    "run": "Launches the app so you can see a change in action.",
    "init": "Writes a CLAUDE.md describing this codebase.",
    "review": "Reviews a GitHub pull request.",
    "claude-api": "Reference for the Claude API and Anthropic SDK.",
    "update-config": "Changes Claude Code settings, hooks, and permissions.",
    "keybindings-help": "Helps you customize keyboard shortcuts.",
    "fewer-permission-prompts": "Cuts down repetitive permission pop-ups.",
    "loop": "Runs a prompt or command on a repeating schedule.",
    "schedule": "Schedules recurring or one-time automated agent runs.",
    "frontend-design": "Designs polished, production-quality web UI.",
    "skill-creator": "Helps you create a brand-new skill.",
    "session-report": "Summarizes what happened during a coding session.",
}


def humanize_skill_desc(raw):
    text = clean_text(raw)
    if not text:
        return ""
    lowered = text.lower()
    for prefix in (
        "this skill should be used when the user asks to",
        "this skill should be used when the user",
        "this skill should be used when",
        "this skill should be used to",
        "use this skill when the user",
        "use this skill to",
        "use this skill when",
        "use when the user asks",
        "use when the user",
        "use when",
        "use this when",
    ):
        if lowered.startswith(prefix):
            text = text[len(prefix):].lstrip(" ,:-")
            break
    for sep in (". ", ".\n", "; "):
        index = text.find(sep)
        if index != -1:
            text = text[: index + 1]
            break
    text = text.strip().strip('"')
    if text and text[0].islower():
        text = text[0].upper() + text[1:]
    return text[:140]


def parse_skill_md_frontmatter(path, fallback_name):
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            lines = handle.readlines()
        name = ""
        desc = ""
        in_frontmatter = False
        dash_count = 0
        for raw_line in lines:
            stripped = raw_line.strip()
            if stripped == "---":
                dash_count += 1
                if dash_count == 1:
                    in_frontmatter = True
                    continue
                if dash_count == 2:
                    break
            if not in_frontmatter:
                continue
            if stripped.startswith("name:"):
                name = stripped[5:].strip().strip('"').strip("'")
            elif stripped.startswith("description:"):
                desc = stripped[12:].strip().strip('"').strip("'")
        return clean_text(name) or fallback_name, clean_text(desc)
    except Exception:
        return fallback_name, ""


def discover_skills(cwd, agent_key="claude"):
    home = os.path.expanduser("~")
    agent_key = clean_text(agent_key)
    if agent_key == "codex":
        seen = {}
        root = os.path.join(home, ".codex", "skills")
        if os.path.isdir(root):
            for dirpath, _dirnames, filenames in os.walk(root):
                if "SKILL.md" not in filenames:
                    continue
                name, desc = parse_skill_md_frontmatter(
                    os.path.join(dirpath, "SKILL.md"),
                    os.path.basename(dirpath),
                )
                if name and name not in seen:
                    seen[name] = {
                        "name": name,
                        "description": humanize_skill_desc(desc),
                        "source": "codex",
                    }
        return sorted(seen.values(), key=lambda item: item["name"].casefold())
    if agent_key == "gemini":
        seen = {}
        root = os.path.join(home, ".gemini", "commands")
        if os.path.isdir(root):
            for dirpath, _dirnames, filenames in os.walk(root):
                for filename in filenames:
                    if not filename.endswith(".toml"):
                        continue
                    stem = filename[:-5]
                    rel = os.path.relpath(dirpath, root)
                    name = stem if rel == "." else rel.replace(os.sep, ":") + ":" + stem
                    if name in seen:
                        continue
                    desc = ""
                    try:
                        with open(os.path.join(dirpath, filename), encoding="utf-8", errors="replace") as handle:
                            for line in handle:
                                match = re.match(r"""^\s*description\s*=\s*["'](.+?)["']\s*$""", line)
                                if match:
                                    desc = match.group(1)
                                    break
                    except Exception:
                        pass
                    seen[name] = {
                        "name": name,
                        "description": humanize_skill_desc(desc),
                        "source": "gemini",
                    }
        return sorted(seen.values(), key=lambda item: item["name"].casefold())
    if agent_key != "claude":
        return []

    seen = {}
    for name, desc in BUILTIN_SKILLS:
        seen[name] = {"name": name, "description": desc, "source": "built-in"}
    scan_dirs = [
        (os.path.join(home, ".claude", "skills"), "personal"),
    ]
    if cwd:
        scan_dirs.append((os.path.join(cwd, ".claude", "skills"), "project"))
    plugins_root = os.path.join(home, ".claude", "plugins", "marketplaces")
    if os.path.isdir(plugins_root):
        for marketplace in os.listdir(plugins_root):
            for subdir in ("plugins", "external_plugins"):
                root = os.path.join(plugins_root, marketplace, subdir)
                if not os.path.isdir(root):
                    continue
                for plugin in os.listdir(root):
                    scan_dirs.append((os.path.join(root, plugin, "skills"), "plugin"))
    for root, source in scan_dirs:
        if not os.path.isdir(root):
            continue
        for skill_dir in os.listdir(root):
            skill_md = os.path.join(root, skill_dir, "SKILL.md")
            if not os.path.isfile(skill_md):
                continue
            name, desc = parse_skill_md_frontmatter(skill_md, skill_dir)
            if name and name not in seen:
                seen[name] = {
                    "name": name,
                    "description": desc,
                    "source": source,
                }
    for entry in seen.values():
        entry["description"] = SKILL_BLURBS.get(entry["name"]) or humanize_skill_desc(
            entry.get("description"),
        )
    return sorted(seen.values(), key=lambda item: item["name"].casefold())


def skill_favorites(agent_key):
    config = load_json(CONFIG_FILE, {}) or {}
    favorites = config.get("skill_favorites_by_agent")
    if not isinstance(favorites, dict):
        favorites = {}
    values = favorites.get(clean_text(agent_key))
    if not isinstance(values, list):
        values = []
    return [clean_text(value) for value in values if clean_text(value)]


def set_skill_favorite(agent_key, name, favorite):
    agent_key = clean_text(agent_key)
    name = clean_text(name)
    config = load_json(CONFIG_FILE, {}) or {}
    if not isinstance(config, dict):
        config = {}
    favorites = config.get("skill_favorites_by_agent")
    if not isinstance(favorites, dict):
        favorites = {}
    values = skill_favorites(agent_key)
    if favorite and name and name not in values:
        values.append(name)
    if not favorite:
        values = [value for value in values if value != name]
    favorites[agent_key] = values
    config["skill_favorites_by_agent"] = favorites
    save_json(CONFIG_FILE, config)
    return values


def skills_payload(agent_key, cwd):
    favorites = skill_favorites(agent_key)
    favorite_set = set(favorites)
    skills = []
    for skill in discover_skills(cwd, agent_key):
        name = clean_text(skill.get("name"))
        if not name:
            continue
        skills.append({**skill, "favorite": name in favorite_set})
    skills.sort(key=lambda item: (not item.get("favorite"), item["name"].casefold()))
    return {"ok": True, "agent": clean_text(agent_key), "favorites": favorites, "skills": skills}


def normalize_worker_job(raw):
    if not isinstance(raw, dict):
        return None
    kind = clean_text(raw.get("kind")) or "session"
    if kind not in {"session", "background"}:
        kind = "session"
    record = {
        "id": clean_text(raw.get("id")),
        "kind": kind,
        "source_session_id": clean_text(raw.get("source_session_id")),
        "source_title": clean_text(raw.get("source_title")),
        "session_id": clean_text(raw.get("session_id")),
        "title": clean_text(raw.get("title")),
        "prompt": clean_text(raw.get("prompt")),
        "command": clean_text(raw.get("command")),
        "note": clean_text(raw.get("note")),
        "agent": clean_text(raw.get("agent")),
        "model": clean_text(raw.get("model")),
        "effort": clean_text(raw.get("effort")),
        "status": clean_text(raw.get("status")) or "queued",
        "created_at": clean_text(raw.get("created_at")),
        "updated_at": clean_text(raw.get("updated_at")),
        "completed_at": clean_text(raw.get("completed_at")),
        "request_signature": clean_text(raw.get("request_signature")),
        "worktree_path": clean_text(raw.get("worktree_path")),
        "worktree_branch": clean_text(raw.get("worktree_branch")),
        "error": clean_text(raw.get("error")),
    }
    if not record["id"] or not record["source_session_id"]:
        return None
    if record["kind"] == "session" and not record["session_id"]:
        return None
    if record["kind"] == "background":
        record["session_id"] = ""
        record["agent"] = record["agent"] or "background"
        record["model"] = record["model"] or "manual"
        record["effort"] = record["effort"] or "Default"
        if not record["title"]:
            record["title"] = shorten(record["command"] or record["note"] or "Background job", 80)
    if record["status"] not in {
        "queued",
        "starting",
        "running",
        "completed",
        "cancelled",
        "error",
        "interrupted",
    }:
        record["status"] = "queued"
    return record


def load_worker_jobs():
    jobs = []
    for raw in load_json(WORKER_JOBS_PATH, []) or []:
        normalized = normalize_worker_job(raw)
        if normalized is not None:
            jobs.append(normalized)
    return jobs


def save_worker_jobs(jobs):
    clean = [normalize_worker_job(job) for job in (jobs or [])]
    clean = [job for job in clean if job is not None]
    clean.sort(
        key=lambda job: (job["updated_at"] or job["created_at"] or "", job["id"]),
        reverse=True,
    )
    # Never evict a live worker merely because the bounded history filled up.
    # Losing its metadata makes the hidden child session unreachable from its
    # parent even though it may still be changing files.
    active = [job for job in clean if _is_worker_job_active(job.get("status"))]
    history = [job for job in clean if not _is_worker_job_active(job.get("status"))]
    history_limit = max(0, WORKER_JOBS_MAX - len(active))
    clean = [*active, *history[:history_limit]]
    ensure_private_parent(WORKER_JOBS_PATH)
    save_json(WORKER_JOBS_PATH, clean)
    return clean


def _match_worker_status(status):
    status = clean_text(status).lower()
    if status in {"queued", "starting", "running", "completed", "cancelled", "error", "interrupted"}:
        return status
    if status == "canceled":
        return "cancelled"
    if status == "done":
        return "completed"
    return "queued" if status else "queued"


def _is_worker_job_active(status):
    return clean_text(status).lower() in {"queued", "starting", "running"}


def list_worker_jobs(source_id, include_history=False):
    source_id = clean_text(source_id)
    if not source_id:
        return []
    jobs = [job for job in load_worker_jobs() if job.get("source_session_id") == source_id]
    if not include_history:
        jobs = [job for job in jobs if _is_worker_job_active(job.get("status") or "")]
    jobs.sort(
        key=lambda job: (job.get("updated_at") or job.get("created_at") or "", job["id"]),
        reverse=True,
    )
    return jobs


def upsert_worker_job(job):
    normalized = normalize_worker_job(job)
    if normalized is None:
        return None
    with WORKER_JOBS_LOCK:
        jobs = load_worker_jobs()
        for index, existing in enumerate(jobs):
            if existing["id"] == normalized["id"]:
                jobs[index] = normalized
                return save_worker_jobs(jobs)
        jobs.append(normalized)
        return save_worker_jobs(jobs)


def find_worker_job_by_signature(source_id, signature):
    source_id = clean_text(source_id)
    signature = clean_text(signature)
    for job in load_worker_jobs():
        if (
            clean_text(job.get("source_session_id")) == source_id
            and clean_text(job.get("request_signature")) == signature
        ):
            return job
    return None


def create_background_worker_job(source_id, title="", command="", note="", status="running"):
    source_id = clean_text(source_id)
    with locked_sessions(source_id):
        return _create_background_worker_job_locked(
            source_id,
            title=title,
            command=command,
            note=note,
            status=status,
        )


def _create_background_worker_job_locked(
    source_id, title="", command="", note="", status="running"
):
    source_id = clean_text(source_id)
    if not source_id:
        raise ValueError("background worker job requires a source session")
    session = load_session(source_id)
    now = now_iso()
    job = {
        "id": str(uuid.uuid4()),
        "kind": "background",
        "source_session_id": source_id,
        "source_title": clean_text(session.get("title")) or "Source session",
        "session_id": "",
        "title": clean_text(title) or shorten(command or note or "Background job", 80),
        "prompt": clean_text(note),
        "command": clean_text(command),
        "note": clean_text(note),
        "agent": "background",
        "model": "manual",
        "effort": "Default",
        "status": _match_worker_status(status) or "running",
        "created_at": now,
        "updated_at": now,
        "completed_at": now if _match_worker_status(status) in {"completed", "cancelled", "error", "interrupted"} else "",
        "request_signature": "",
        "error": "",
    }
    upsert_worker_job(job)
    return normalize_worker_job(job)


def update_background_worker_job(source_id, job_id, status="", note="", title="", command=""):
    source_id = clean_text(source_id)
    job_id = clean_text(job_id)
    if not source_id or not job_id:
        raise ValueError("background worker update requires source_id and job_id")
    matched = None
    now = now_iso()
    with WORKER_JOBS_LOCK:
        jobs = load_worker_jobs()
        for job in jobs:
            if (
                job.get("id") != job_id
                or job.get("source_session_id") != source_id
                or job.get("kind") != "background"
            ):
                continue
            if status:
                job["status"] = _match_worker_status(status)
            if note:
                job["note"] = clean_text(note)
                job["prompt"] = clean_text(note)
            if title:
                job["title"] = clean_text(title)
            if command:
                job["command"] = clean_text(command)
            job["updated_at"] = now
            if job["status"] in {"completed", "cancelled", "error", "interrupted"}:
                job["completed_at"] = now
            else:
                job["completed_at"] = ""
            matched = normalize_worker_job(job)
            break
        if not matched:
            raise ValueError("background worker job not found")
        save_worker_jobs(jobs)
    return matched


def remove_worker_jobs_for_source(source_id):
    source_id = clean_text(source_id)
    if not source_id:
        return []
    with WORKER_JOBS_LOCK:
        jobs = load_worker_jobs()
        remaining = []
        removed = []
        for job in jobs:
            keep = (
                job.get("source_session_id") != source_id
                or _is_worker_job_active(job.get("status") or "")
            )
            if not keep and job.get("kind") == "session":
                child_id = clean_text(job.get("session_id"))
                try:
                    keep = bool(child_id) and os.path.isfile(session_path(child_id))
                except ValueError:
                    keep = False
            if keep:
                remaining.append(job)
            else:
                removed.append(job)
        if remaining != jobs:
            save_worker_jobs(remaining)
        return removed


def _worker_child_session_ids(source_id):
    source_id = clean_text(source_id)
    children = set()
    try:
        names = os.listdir(SESS_DIR)
    except OSError:
        return children
    for name in names:
        if not name.endswith(".json"):
            continue
        path = os.path.join(SESS_DIR, name)
        child = load_json(path, {}) or {}
        if (
            isinstance(child, dict)
            and clean_text(child.get("worker_parent_session_id")) == source_id
            and clean_text(child.get("id"))
        ):
            children.add(clean_text(child.get("id")))
    return children


def worker_session_delete_blocker(session):
    """Explain why deleting this source session would orphan live worker state."""
    session = session if isinstance(session, dict) else {}
    source_id = clean_text(session.get("id"))
    if not source_id:
        return ""
    child_ids = _worker_child_session_ids(source_id)
    active_background = 0
    changed = False
    now = now_iso()
    with WORKER_JOBS_LOCK:
        jobs = load_worker_jobs()
        for job in jobs:
            if clean_text(job.get("source_session_id")) != source_id:
                continue
            if job.get("kind") == "background":
                if _is_worker_job_active(job.get("status")):
                    active_background += 1
                continue
            child_id = clean_text(job.get("session_id"))
            try:
                child_exists = bool(child_id) and os.path.isfile(session_path(child_id))
            except ValueError:
                child_exists = False
            if child_exists:
                child_ids.add(child_id)
            elif _is_worker_job_active(job.get("status")):
                # A crash between job creation and session persistence used to
                # leave an immortal queued job. Reconcile it instead of blocking
                # its parent forever.
                job["status"] = "interrupted"
                job["updated_at"] = now
                job["completed_at"] = now
                job["error"] = job.get("error") or "worker session record is missing"
                changed = True
        if changed:
            save_worker_jobs(jobs)
    if child_ids:
        return (
            f"cannot delete a conversation that still owns {len(child_ids)} worker "
            "conversation(s); delete those workers first"
        )
    if active_background:
        return (
            "cannot delete a conversation while its background worker metadata "
            "is active; finish or cancel those jobs first"
        )
    return ""


def remove_worker_metadata_for_deleted_session(session):
    """Remove only metadata whose owning session was successfully deleted."""
    session = session if isinstance(session, dict) else {}
    session_id = clean_text(session.get("id"))
    parent_id = clean_text(session.get("worker_parent_session_id"))
    if not session_id:
        return 0
    with WORKER_JOBS_LOCK:
        jobs = load_worker_jobs()
        if parent_id:
            remaining = [
                job
                for job in jobs
                if (
                    clean_text(job.get("session_id")) != session_id
                    and clean_text(job.get("id")) != session_id
                    and clean_text(job.get("source_session_id")) != session_id
                )
            ]
        else:
            remaining = [
                job
                for job in jobs
                if clean_text(job.get("source_session_id")) != session_id
            ]
        removed = len(jobs) - len(remaining)
        if removed:
            save_worker_jobs(remaining)
        return removed


def mark_worker_job_status(session_id, status, error=""):
    status = _match_worker_status(status)
    normalized_error = clean_text(error)
    now = now_iso()
    with WORKER_JOBS_LOCK:
        jobs = load_worker_jobs()
        changed = False
        for job in jobs:
            if job.get("session_id") != session_id:
                continue
            if job["status"] != status:
                job["status"] = status
                changed = True
            if normalized_error:
                job["error"] = normalized_error
                changed = True
            if changed:
                job["updated_at"] = now
            if status in {"completed", "cancelled", "error", "interrupted"}:
                job["completed_at"] = now
        if changed:
            return save_worker_jobs(jobs)
        return jobs


def shorten(value, limit=80):
    text = re.sub(r"\s+", " ", clean_text(value))
    return text if len(text) <= limit else text[: max(1, limit - 1)].rstrip() + "…"


def iso_from_unix(timestamp):
    try:
        return datetime.fromtimestamp(float(timestamp)).astimezone().isoformat()
    except (TypeError, ValueError, OSError):
        return now_iso()


def strip_session_context(text):
    value = clean_text(text)
    match = re.match(
        r"^\s*(<session_context>.*?</session_context>)\s*(.*)$",
        value,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if not match:
        return "", value
    return clean_text(match.group(1)), clean_text(match.group(2))


HARNESS_INJECTION_BLOCK = re.compile(
    r"<task-notification>.*?</task-notification>"
    r"|<system-reminder>.*?</system-reminder>"
    r"|<local-command-stdout>.*?</local-command-stdout>"
    r"|<local-command-stderr>.*?</local-command-stderr>",
    re.IGNORECASE | re.DOTALL,
)
SESSION_CONTEXT_BLOCK = re.compile(
    r"<session_context>.*?</session_context>",
    re.IGNORECASE | re.DOTALL,
)


def clean_native_title(*candidates):
    """First non-empty candidate with the injected <session_context> blob stripped —
    so imported session titles never render as a raw XML dump."""
    for candidate in candidates:
        text = SESSION_CONTEXT_BLOCK.sub("", clean_text(candidate)).strip()
        if text:
            return text[:120]
    return ""


def strip_attachment_injection(text):
    raw = clean_text(text)
    if not raw:
        return ""
    if not raw.lstrip().lower().startswith("the user attached the following local files"):
        return raw
    marker = "\n\nuser request:\n"
    index = raw.lower().find(marker)
    return clean_text(raw[index + len(marker):]) if index != -1 else ""


def visible_user_prompt_text(text):
    raw = clean_text(text)
    if not raw:
        return ""
    lowered = raw.lstrip().lower()
    has_hidden_prefix = lowered.startswith(
        (
            "project shared state",
            "read the authoritative continuation handoff",
            "also read the shared project state",
            "also read the project registry before acting",
        )
    )
    if has_hidden_prefix:
        if "</session_context>" in raw:
            suffix = raw.rsplit("</session_context>", 1)[1]
            _hidden, visible = strip_session_context(suffix)
            result = clean_text(visible or suffix)
        else:
            fallback = SESSION_CONTEXT_BLOCK.sub("", raw)
            for pattern in (
                r"^Read the authoritative continuation handoff before acting:\s*\S+\s*",
                r"^Also read the shared project state before acting:\s*\S+\s*",
                r"^Also read the project registry before acting:\s*\S+\s*",
                r"^This handoff is being injected into an existing session\..*",
            ):
                fallback = re.sub(pattern, "", fallback, flags=re.IGNORECASE | re.MULTILINE)
            result = clean_text(fallback)
    else:
        _hidden, visible = strip_session_context(raw)
        result = visible or raw
    return strip_attachment_injection(result)


def strip_harness_injections(text):
    raw = clean_text(text)
    if not raw:
        return ""
    cleaned = SESSION_CONTEXT_BLOCK.sub("", raw)
    cleaned = HARNESS_INJECTION_BLOCK.sub("", cleaned)
    cleaned = clean_text(cleaned)
    if not cleaned:
        return ""
    if cleaned.lstrip().lower().startswith(
        "this session is being continued from a previous conversation"
    ):
        return ""
    if cleaned.lstrip().lower().startswith(
        "please inspect and respond to the attached file"
    ):
        return ""
    cleaned = clean_text(visible_user_prompt_text(cleaned))
    if not cleaned:
        return ""
    without_image_markers = clean_text(re.sub(r"\[Image[^\]]*\]", "", cleaned))
    if not without_image_markers:
        return ""
    return without_image_markers


def project_label(cwd):
    cwd = clean_text(cwd).rstrip(os.sep)
    base = os.path.basename(cwd)
    return base or cwd or "~"


def normalized_project_key(value):
    text = clean_text(value)
    _context, visible = strip_session_context(text)
    text = visible or text
    text = re.sub(
        r"^(?:codex|claude|gemini|ollama|openai|anthropic|google)\s*:\s*",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()
    text = re.sub(
        r"\s+(?:session|day|week|part|chapter|round|run|iteration|episode)\s+\d+\s*$",
        "",
        text,
        flags=re.IGNORECASE,
    ).strip()
    text = re.sub(r"\b\d+$", "", text).strip()
    words = [
        word
        for word in re.findall(r"[a-z0-9]+", text.lower())
        if word and word != "the"
    ]
    if not words:
        return ""
    return " ".join(sorted(words))


def project_title_keys(session):
    keys = set()
    for value in (
        (session or {}).get("title"),
        (session or {}).get("preview"),
        (session or {}).get("handoff_base_title"),
    ):
        key = normalized_project_key(value)
        if key:
            keys.add(key)
    return keys


def session_title_matches_root(session, root):
    title_keys = project_title_keys(session)
    if not title_keys:
        return False
    candidates = [project_label(root)]
    try:
        _registry_path, registry = read_project_registry(root)
    except Exception:
        registry = {}
    if isinstance(registry, dict):
        candidates.extend(
            [
                registry.get("display_name"),
                registry.get("root"),
                registry.get("state_file"),
            ]
        )
        candidates.extend(registry.get("aliases") or [])
    for candidate in candidates:
        key = normalized_project_key(candidate)
        if key and key in title_keys:
            return True
    return False


def roots_related(a, b):
    a = os.path.abspath(os.path.expanduser(clean_text(a)))
    b = os.path.abspath(os.path.expanduser(clean_text(b)))
    if not a or not b:
        return False
    try:
        return os.path.commonpath([a, b]) in {a, b}
    except ValueError:
        return False


def project_related_roots(root):
    root = os.path.abspath(os.path.expanduser(clean_text(root)))
    if not root:
        return []
    roots = [root] if os.path.isdir(root) else []
    try:
        _path, registry = read_project_registry(root)
    except Exception:
        registry = {}
    for field in ("related_roots", "related_projects", "allowed_roots"):
        values = registry.get(field) if isinstance(registry, dict) else []
        if isinstance(values, str):
            values = [values]
        elif isinstance(values, dict):
            values = list(values.values())
        if not isinstance(values, list):
            continue
        for value in values:
            if isinstance(value, dict):
                value = value.get("root") or value.get("path")
            path = os.path.abspath(os.path.expanduser(clean_text(value)))
            if path and os.path.isdir(path):
                roots.append(path)
    return list(dict.fromkeys(roots))


def project_roots_related(a, b):
    a = os.path.abspath(os.path.expanduser(clean_text(a)))
    b = os.path.abspath(os.path.expanduser(clean_text(b)))
    if not a or not b:
        return False
    if roots_related(a, b):
        return True
    for base, other in ((a, b), (b, a)):
        for related in project_related_roots(base):
            if roots_related(related, other):
                return True
    return False


def path_has_project_marker(path):
    if not path or not os.path.isdir(path):
        return False
    for marker in (
        PROJECT_REGISTRY_DIRNAME,
        ".git",
        "project.godot",
        "package.json",
        "pyproject.toml",
        "Cargo.toml",
    ):
        if os.path.exists(os.path.join(path, marker)):
            return True
    return False


def find_project_root(path):
    raw = clean_text(path)
    if not raw:
        return ""
    candidate = os.path.abspath(os.path.expanduser(raw))
    if os.path.isfile(candidate):
        candidate = os.path.dirname(candidate)
    if not os.path.isdir(candidate):
        return ""
    home = os.path.abspath(os.path.expanduser("~"))
    current = candidate
    while True:
        if path_has_project_marker(current):
            return current
        parent = os.path.dirname(current)
        if parent == current or current == home:
            break
        current = parent
    if candidate != home:
        return candidate
    return ""


def project_title_slugs(session):
    raw = clean_text(
        (session or {}).get("title")
        or (session or {}).get("preview")
        or (session or {}).get("handoff_base_title")
    )
    _context, visible = strip_session_context(raw)
    raw = visible or raw
    raw = re.sub(
        r"^(?:codex|claude|gemini|ollama|openai|anthropic|google)\s*:\s*",
        "",
        raw,
        flags=re.IGNORECASE,
    )
    raw = re.sub(
        r"\s+(?:session|day|week|part|chapter|round|run|iteration|episode)\s+\d+\s*$",
        "",
        raw,
        flags=re.IGNORECASE,
    ).strip()
    raw = re.sub(r"\b\d+$", "", raw).strip()
    if not raw:
        return []
    slug = re.sub(r"[^a-z0-9]+", "-", raw.lower()).strip("-")
    if not slug:
        return []
    candidates = [slug]
    if not slug.startswith("the-"):
        candidates.append("the-" + slug)
    words = raw.lower().split()
    if len(words) > 1:
        rotated = " ".join(words[1:] + [words[0]])
        rotated_slug = re.sub(r"[^a-z0-9]+", "-", rotated).strip("-")
        if rotated_slug and rotated_slug not in candidates:
            candidates.append(rotated_slug)
            if not rotated_slug.startswith("the-"):
                candidates.append("the-" + rotated_slug)
    return candidates


def project_root_from_registry_aliases(session):
    raw = clean_text(
        (session or {}).get("title")
        or (session or {}).get("preview")
        or (session or {}).get("handoff_base_title")
    )
    if not raw:
        return ""
    raw = re.sub(
        r"^(?:codex|claude|gemini|ollama|openai|anthropic|google)\s*:\s*",
        "",
        raw,
        flags=re.IGNORECASE,
    ).strip()
    raw = re.sub(
        r"\s+(?:session|day|week|part|chapter|round|run|iteration|episode)\s+\d+\s*$",
        "",
        raw,
        flags=re.IGNORECASE,
    ).strip()
    raw = re.sub(r"\b\d+$", "", raw).strip()
    if not raw:
        return ""
    raw_lower = raw.lower()
    home = os.path.abspath(os.path.expanduser("~"))
    search_roots = [
        home,
        os.path.join(home, "Projects"),
    ]
    seen = set()
    for base in search_roots:
        if not os.path.isdir(base) or base in seen:
            continue
        seen.add(base)
        try:
            for entry in os.scandir(base):
                if not entry.is_dir():
                    continue
                registry_file = os.path.join(
                    entry.path, PROJECT_REGISTRY_DIRNAME, PROJECT_REGISTRY_FILENAME
                )
                if not os.path.isfile(registry_file):
                    continue
                data = load_json(registry_file, {})
                if not isinstance(data, dict):
                    continue
                for alias in data.get("aliases") or []:
                    if clean_text(alias).lower() == raw_lower:
                        root = clean_text(data.get("root")) or entry.path
                        if root and os.path.isdir(root):
                            return os.path.abspath(root)
        except OSError:
            continue
    return ""


def project_root_from_title(session, cwd):
    slugs = project_title_slugs(session)
    if not slugs:
        return ""
    title_keys = project_title_keys(session)
    home = os.path.abspath(os.path.expanduser("~"))
    search_roots = [
        cwd,
        home,
        os.path.join(home, "Projects"),
    ]
    seen = set()
    for base in search_roots:
        base = os.path.abspath(os.path.expanduser(clean_text(base)))
        if not base or base in seen or not os.path.isdir(base):
            continue
        seen.add(base)
        for slug in slugs:
            path = os.path.join(base, slug)
            if os.path.isdir(path):
                root = find_project_root(path)
                if root and os.path.abspath(root) != home:
                    return root
        if title_keys:
            try:
                for entry in os.scandir(base):
                    if not entry.is_dir():
                        continue
                    if normalized_project_key(entry.name) not in title_keys:
                        continue
                    root = find_project_root(entry.path)
                    if root and os.path.abspath(root) != home:
                        return root
            except OSError:
                continue
    return ""


def infer_project_root(session=None, fallback_cwd=""):
    session = session or {}
    # An isolated worker worktree IS the session's project root for as long as
    # it exists — title/registry inference below must not redirect the session
    # back to the shared source tree (that would defeat the isolation).
    worktree = clean_text(session.get("worktree_path"))
    if worktree:
        worktree = os.path.abspath(os.path.expanduser(worktree))
        if os.path.isdir(worktree):
            return worktree
    stored_root = clean_text(session.get("project_root"))
    stored_root = (
        os.path.abspath(os.path.expanduser(stored_root))
        if stored_root and os.path.isdir(os.path.expanduser(stored_root))
        else ""
    )
    cwd = os.path.abspath(
        os.path.expanduser(
            clean_text(session.get("cwd")) or clean_text(fallback_cwd) or os.path.expanduser("~")
        )
    )
    home = os.path.abspath(os.path.expanduser("~"))
    title_root = project_root_from_title(session, cwd)
    if title_root:
        if (
            stored_root
            and stored_root != title_root
            and session_title_matches_root(session, title_root)
        ):
            return title_root
        if (
            not stored_root
            or stored_root == home
            or not project_roots_related(title_root, stored_root)
        ):
            return title_root
        try:
            if (
                stored_root != title_root
                and os.path.commonpath([stored_root, title_root]) == stored_root
            ):
                return title_root
        except ValueError:
            return title_root
    if stored_root:
        return stored_root
    if title_root:
        return title_root
    alias_root = project_root_from_registry_aliases(session)
    if alias_root:
        return alias_root
    root = find_project_root(cwd)
    if root:
        return root
    return cwd if os.path.isdir(cwd) and cwd != home else ""


# Agents whose transport retains prior-turn context (so the full AGENT_STATE body
# does not need re-sending every turn): Claude's persistent stream session and
# Codex's resumed thread both carry it forward, and Gemini has file-read tools.
CONTEXT_RETAINING_AGENTS = {"claude", "codex", "gemini"}


def smart_state_context(cwd, prompt=""):
    """Lean, prompt-aware shared-state view (saves tokens vs. pasting the whole file).

    Always injects a cheap table of contents + Current Status, then adds ONLY the
    section(s) whose text overlaps this turn's prompt (relevance match). The full
    file is named so the agent can read any section on demand. Per-turn cost stays
    roughly flat regardless of how large AGENT_STATE grows."""
    path = project_state_path(cwd)
    if not path or not os.path.isfile(path):
        return ""
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            content = handle.read(PROJECT_STATE_MAX_CHARS)
    except OSError:
        return ""
    _preamble, sections = split_state_sections(content)
    if not sections:
        return project_state_pointer_context(cwd)

    toc, current_status = [], ""
    for heading, body in sections:
        title = heading.lstrip("#").strip()
        toc.append(f"  - {title}")
        if title.lower().startswith("current status"):
            current_status = body.strip()[:800]

    # (B) relevance: score non-status sections by prompt-keyword overlap.
    kw = {w for w in re.findall(r"[a-z0-9]{4,}", clean_text(prompt).lower())}
    scored = []
    for heading, body in sections:
        if heading.lstrip("#").strip().lower().startswith("current status"):
            continue
        words = {w for w in re.findall(r"[a-z0-9]{4,}", (heading + " " + body).lower())}
        score = len(kw & words)
        if score >= 2:
            scored.append((score, heading.strip(), body.strip()))
    scored.sort(key=lambda item: -item[0])

    relevant, used, budget = [], 0, 3000
    for _score, heading, body in scored[:3]:
        if used >= budget:
            break
        room = budget - used
        chunk_body = body if len(body) <= room else body[:room] + " …[truncated - read file]"
        chunk = f"\n{heading}\n{chunk_body}\n"
        relevant.append(chunk)
        used += len(chunk)

    out = [
        "PROJECT SHARED STATE (lean view) - full file: " + path,
        "- Sections in the file (read it directly for any not shown below):",
    ]
    out.extend(toc)
    if current_status:
        out.append("\n## Current Status\n" + current_status)
    if relevant:
        out.append("\nSections matching this turn:")
        out.extend(relevant)
    out.append(
        "\n- Lean excerpt to save tokens; re-read the canonical file above for anything "
        "not shown. If this turn changes durable facts, update that file before finishing."
    )
    return "\n".join(out).strip() + "\n"


def shared_state_turn_context(session, agent_key, fallback_cwd="", prompt=""):
    """Prompt-aware shared-state context for one turn.

    Replaces the old whole-file injection with smart_state_context (ToC + Current
    Status + prompt-relevant sections), so per-turn tokens stay flat no matter how
    large AGENT_STATE grows. Pointer-only when injection is disabled in settings."""
    prefs = memory_preferences()
    root = infer_project_root(session, fallback_cwd)
    if not prefs.get("inject_shared_state"):
        return project_state_pointer_context(root)
    return smart_state_context(root, prompt)


def pending_handoff_root(session, pending_context=""):
    root = clean_text((session or {}).get("pending_handoff_project_root"))
    if root:
        root = os.path.abspath(os.path.expanduser(root))
        if os.path.isdir(root):
            return root
    state_path = clean_text((session or {}).get("pending_handoff_state_path"))
    lines = clean_text(pending_context).splitlines()
    for index, line in enumerate(lines):
        if line.strip().lower().startswith("also read the shared project state before acting:"):
            for candidate in lines[index + 1 :]:
                state_path = clean_text(candidate)
                if state_path:
                    break
            break
    if state_path:
        state_path = os.path.abspath(os.path.expanduser(state_path))
        if os.path.basename(state_path) == PROJECT_STATE_FILENAME:
            candidate = os.path.dirname(state_path)
            if os.path.isdir(candidate):
                return candidate
    return ""


# Each client reads its own rules file and ignores the others'. Writing them is
# plain file output: no model is involved, so this costs nothing to run.
AGENT_RULES_FILES = {
    "claude": "CLAUDE.md",
    "codex": "AGENTS.md",
    "gemini": "GEMINI.md",
}

AGENT_RULES_TEMPLATE = """# How to work in this project

## Talking to me
- Lead with the answer. Reasoning after, and only if it changes what I do.
- Short sentences, small paragraphs, bullets over walls of text.
- Plain words. Before any technical term, say in ordinary words what it is.
- Never drop a raw name (a variable, table, flag, file) into a sentence as
  though I already know it.
- No long dashes. A comma, a colon or a full stop instead.
- One question at a time.

## Working
- Do exactly what was asked. Nothing extra, however good the idea.
- Fix the cause, not the symptom.
- Anything out of scope you notice goes in one line in
  FINDINGS_OUTSIDE_SCOPE.md. Do not act on it.
- Never say done, works or verified unless you exercised the real failure.
  Say what you checked and what you did not.
- If tests exist they must pass. Never skip or delete one to go green.

## This project
<!-- Add what an agent needs to know here: how to run it, how to test it,
     what not to touch. -->
"""


def write_agent_rules(root, agents=None, overwrite=False):
    """Create the per-client rules files a project is missing.

    Claude reads CLAUDE.md, Codex reads AGENTS.md, Gemini reads GEMINI.md, and
    each ignores the others'. AWBN used to inject the owner's preferences into
    every turn instead, which duplicated rules Claude already had and made its
    answers differ from the same model run in a terminal. A file on disk is read
    by the client itself, costs nothing per turn, and the owner can edit it.

    Existing files are never overwritten unless asked. Returns what was written
    and what was left alone.
    """
    root = os.path.abspath(os.path.expanduser(clean_text(root)))
    if not root or not os.path.isdir(root):
        raise ValueError("project folder not found")
    wanted = [clean_text(a).lower() for a in (agents or AGENT_RULES_FILES)]
    written, skipped = [], []
    for agent in wanted:
        name = AGENT_RULES_FILES.get(agent)
        if not name:
            continue
        path = os.path.join(root, name)
        if os.path.exists(path) and not overwrite:
            skipped.append(name)
            continue
        save_text_atomic(path, AGENT_RULES_TEMPLATE)
        written.append(name)
    return {"written": written, "skipped": skipped, "root": root}


def project_state_path(cwd):
    cwd = os.path.abspath(os.path.expanduser(clean_text(cwd) or os.path.expanduser("~")))
    if not cwd or not os.path.isdir(cwd):
        return ""
    if cwd == os.path.abspath(os.path.expanduser("~")):
        return ""
    return os.path.join(cwd, PROJECT_STATE_FILENAME)


def project_registry_path(cwd):
    cwd = os.path.abspath(os.path.expanduser(clean_text(cwd) or os.path.expanduser("~")))
    if not cwd or not os.path.isdir(cwd):
        return ""
    if cwd == os.path.abspath(os.path.expanduser("~")):
        return ""
    return os.path.join(cwd, PROJECT_REGISTRY_DIRNAME, PROJECT_REGISTRY_FILENAME)


def project_registry_id(root):
    root = os.path.abspath(os.path.expanduser(clean_text(root) or os.path.expanduser("~")))
    label = re.sub(r"[^a-z0-9]+", "-", project_label(root).lower()).strip("-")
    digest = hashlib.sha1(root.encode("utf-8")).hexdigest()[:10]
    return f"{label or 'project'}-{digest}"


def read_project_registry(cwd):
    path = project_registry_path(cwd)
    if not path or not os.path.isfile(path):
        return "", {}
    data = load_json(path, {})
    return path, data if isinstance(data, dict) else {}


def ensure_project_registry(
    cwd,
    session=None,
    agent_key="",
    title="",
    state_path="",
    sequence=None,
):
    root = os.path.abspath(os.path.expanduser(clean_text(cwd) or os.path.expanduser("~")))
    if not root or not os.path.isdir(root):
        return ""
    path = project_registry_path(root)
    if not path:
        return ""
    existing = load_json(path, {}) if path else {}
    if not isinstance(existing, dict):
        existing = {}
    now = now_iso()
    aliases = [
        clean_text(project_label(root)),
        clean_text(title),
        clean_text((session or {}).get("handoff_base_title")),
        clean_text((session or {}).get("title")),
        clean_text((session or {}).get("preview")),
    ]
    aliases = [
        alias
        for alias in dict.fromkeys(aliases)
        if alias
        and not alias.lower().startswith("new ")
        # Reject wandering auto-generated chat titles (long prose / questions /
        # truncated prompts) so the project keeps clean, stable aliases.
        and len(alias) <= 48
        and not alias.endswith("?")
        and "…" not in alias
        and "..." not in alias
    ]
    registry = {
        **existing,
        "schema": 1,
        "project_id": clean_text(existing.get("project_id")) or project_registry_id(root),
        "display_name": clean_text(existing.get("display_name")) or project_label(root),
        "root": root,
        "state_file": clean_text(state_path) or project_state_path(root),
        "updated_at": now,
    }
    if not registry.get("created_at"):
        registry["created_at"] = now
    merged_aliases = list(dict.fromkeys((existing.get("aliases") or []) + aliases))
    registry["aliases"] = [clean_text(alias) for alias in merged_aliases if clean_text(alias)]
    related_roots = []
    values = existing.get("related_roots") or []
    if isinstance(values, str):
        values = [values]
    elif isinstance(values, dict):
        values = list(values.values())
    if isinstance(values, list):
        for value in values:
            if isinstance(value, dict):
                value = value.get("root") or value.get("path")
            path_value = os.path.abspath(os.path.expanduser(clean_text(value)))
            if path_value and os.path.isdir(path_value) and path_value != root:
                related_roots.append(path_value)
    registry["related_roots"] = list(dict.fromkeys(related_roots))
    clients = existing.get("clients") if isinstance(existing.get("clients"), dict) else {}
    agent_key = clean_text(agent_key or (session or {}).get("agent"))
    if agent_key:
        client = clients.get(agent_key) if isinstance(clients.get(agent_key), dict) else {}
        client.update(
            {
                "last_session_id": clean_text((session or {}).get("id")),
                "last_title": clean_text(title or (session or {}).get("title")),
                "updated_at": now,
            }
        )
        if sequence is not None:
            try:
                client["last_handoff_sequence"] = int(sequence)
            except (TypeError, ValueError):
                pass
        clients[agent_key] = client
    registry["clients"] = clients
    save_json(path, registry)
    return path


def read_project_state(cwd, max_chars=PROJECT_STATE_MAX_CHARS):
    path = project_state_path(cwd)
    if not path or not os.path.isfile(path):
        return "", ""
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            return path, handle.read(max_chars)
    except OSError:
        return "", ""


def project_state_pointer_context(cwd):
    path = project_state_path(cwd)
    if not path or not os.path.isfile(path):
        return ""
    registry_path, registry = read_project_registry(cwd)
    root = clean_text(registry.get("root")) or os.path.abspath(
        os.path.expanduser(clean_text(cwd) or os.path.expanduser("~"))
    )
    registry_line = f"- Project registry: {registry_path}\n" if registry_path else ""
    return (
        "PROJECT SHARED STATE - read before acting:\n"
        f"- Canonical file: {path}\n"
        f"- Project root: {root}\n"
        f"{registry_line}"
        "- Shared state injection is disabled in Workbench memory settings. "
        "Read the canonical file directly if project memory matters for this turn.\n"
    )


def project_state_context(cwd, max_chars=PROJECT_STATE_MAX_CHARS):
    path, text = read_project_state(cwd, max_chars=max_chars)
    if not path:
        return ""
    registry_path, registry = read_project_registry(cwd)
    root = clean_text(registry.get("root")) or os.path.abspath(
        os.path.expanduser(clean_text(cwd) or os.path.expanduser("~"))
    )
    registry_line = f"- Project registry: {registry_path}\n" if registry_path else ""
    project_id_line = (
        f"- Project id: {clean_text(registry.get('project_id'))}\n"
        if registry.get("project_id")
        else ""
    )
    related = [
        os.path.abspath(os.path.expanduser(clean_text(value)))
        for value in (registry.get("related_roots") or [])
        if clean_text(value)
    ] if isinstance(registry.get("related_roots"), list) else []
    related_line = (
        "- Related roots: " + ", ".join(related) + "\n"
        if related
        else ""
    )
    truncated = ""
    try:
        file_size = os.path.getsize(path)
    except OSError:
        file_size = 0
    if file_size > len(text.encode("utf-8", errors="ignore")):
        truncated = (
            "\n\n[Excerpt truncated. Read the file directly before making "
            "decisions that depend on older project history.]"
        )
    return (
        "PROJECT SHARED STATE - read before acting:\n"
        f"- Canonical file: {path}\n"
        f"- Project root: {root}\n"
        f"{registry_line}"
        f"{project_id_line}"
        f"{related_line}"
        "- Treat this as cross-client project memory shared by Claude, Codex, Gemini, and local models.\n"
        "- If this turn changes durable project facts, update this file before finishing.\n\n"
        f"{text.strip()}{truncated}"
    )


def strip_prior_state_snapshots(text):
    text = clean_text(text)
    if not text:
        return ""
    return re.split(r"\n## Prior State Snapshot\b", text, maxsplit=1)[0].strip()


def local_project_state_summary(existing_state, handoff_packet, cwd, model=None):
    model = clean_text(model) or LOCAL_PROJECT_STATE_MODEL
    existing_state = strip_prior_state_snapshots(existing_state)
    prompt = f"""Update a cross-agent project state file.

Project directory: {cwd}

Existing AGENT_STATE.md:
{existing_state or '(none yet)'}

Latest session handoff:
{handoff_packet}

Write a concise but SPECIFIC Markdown AGENT_STATE.md that another coding model
can act on with no further context. Use these headings exactly:
# Agent State
## Project
## Current Objective
## Durable Facts
## Recent Changes
## Open Tasks
## Known Risks
## Verification Commands
## Last Updated

Hard rules:
- PRESERVE every durable fact already in the existing AGENT_STATE.md above. Carry
  it forward and merge new information in; never drop facts just because this
  session did not touch them.
- Be concrete: name actual files, functions, commands, and config keys (e.g.
  `awbench_server.py: next_handoff_title()`, `app/lib/main.dart`). A coding
  model should be able to open the right file from this alone.
- ## Current Objective must describe the REAL in-flight work for this project.
  Never write "Continue from the automatic handoff" or restate the handoff
  instruction — that is meaningless to the next session.
- Prefer stable project facts over chat-transcript chatter. Do not invent details;
  if unknown, say what to inspect (file/command) rather than guessing.
"""
    if not _OLLAMA_INFERENCE_SEM.acquire(blocking=False):
        return ""
    try:
        body = json.dumps(
            {
                "model": model,
                "messages": [
                    {
                        "role": "system",
                        "content": (
                            "You update a durable project state Markdown file. "
                            "Be concise, factual, and preserve important existing facts."
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
                "stream": False,
            }
        ).encode("utf-8")
        base_url = os.environ.get("OLLAMA_HOST", OLLAMA_BASE).rstrip("/")
        request = urllib.request.Request(
            f"{base_url}/api/chat",
            data=body,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=90) as response:
            payload = json.loads(response.read().decode("utf-8"))
        return clean_text((payload.get("message") or {}).get("content"))
    except Exception:
        return ""
    finally:
        _OLLAMA_INFERENCE_SEM.release()


# Single source of truth for the deterministic fallback's filler bullets. These
# also derive the boilerplate markers below, so the template and the markers can
# never drift apart (editing a bullet updates both).
_FALLBACK_STATE_BULLETS = {
    "objective": "Continue from the latest session handoff below.",
    "facts": "See the latest handoff and inspect the filesystem before acting.",
    "changes": "Derived from the latest session handoff.",
    "tasks": "Continue unresolved work from the latest handoff.",
    "risks": "This fallback state was generated without a local LLM summary; verify details against the repo.",
}

# A line is boilerplate (not a concrete fact) when it contains one of these. The
# fallback bullets are included automatically; the extras are circular/filler
# phrases a weak local model emits that are not part of the deterministic template.
_STATE_BOILERPLATE_MARKERS = tuple(
    {bullet.lower() for bullet in _FALLBACK_STATE_BULLETS.values()}
    | {
        "continue from the automatic handoff",
        "inspect the filesystem before acting",
    }
)


def fallback_project_state(existing_state, handoff_packet, cwd):
    handoff_excerpt = clean_text(handoff_packet)[:12_000]
    bullets = _FALLBACK_STATE_BULLETS
    return (
        "# Agent State\n\n"
        f"## Project\n- Directory: {cwd}\n\n"
        f"## Current Objective\n- {bullets['objective']}\n\n"
        f"## Durable Facts\n- {bullets['facts']}\n\n"
        f"## Recent Changes\n- {bullets['changes']}\n\n"
        f"## Open Tasks\n- {bullets['tasks']}\n\n"
        f"## Known Risks\n- {bullets['risks']}\n\n"
        "## Verification Commands\n- git status\n- git log --oneline -10\n\n"
        f"## Last Updated\n- {now_iso()}\n\n"
        "## Latest Handoff\n"
        f"{handoff_excerpt}\n"
    )


def state_substance_score(text):
    """Count concrete, non-boilerplate fact lines in an AGENT_STATE.md body."""
    concrete = 0
    for line in clean_text(text).splitlines():
        stripped = line.strip().lstrip("-*0123456789. ").strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("```"):
            continue
        low = stripped.lower()
        if any(marker in low for marker in _STATE_BOILERPLATE_MARKERS):
            continue
        if len(stripped) >= 14:
            concrete += 1
    return concrete


def save_text_atomic(path, content):
    ensure_private_parent(path)
    temporary = f"{path}.tmp-{os.getpid()}-{threading.get_ident()}-{uuid.uuid4()}"
    with open(temporary, "w", encoding="utf-8") as handle:
        handle.write(content.rstrip() + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    ensure_private_file(temporary)
    os.replace(temporary, path)
    ensure_private_file(path)


def append_debug_event(event, **fields):
    payload = {"time": now_iso(), "event": clean_text(event)}
    for key, value in fields.items():
        payload[key] = value
    try:
        ensure_private_parent(DEBUG_LOG_FILE)
        # Serialize the whole check-rotate-append: this runs from many concurrent
        # turn threads, and an unlocked rotate lets thread B rotate + append a
        # tiny line before thread A's stale os.replace overwrites the just-saved
        # .1 generation, discarding the prior log. One generation kept as .1.
        with DEBUG_LOG_LOCK:
            try:
                if os.path.getsize(DEBUG_LOG_FILE) > DEBUG_LOG_MAX_BYTES:
                    os.replace(DEBUG_LOG_FILE, DEBUG_LOG_FILE + ".1")
            except OSError:
                pass
            with open(DEBUG_LOG_FILE, "a", encoding="utf-8") as handle:
                handle.write(json.dumps(payload, sort_keys=True) + "\n")
        ensure_private_file(DEBUG_LOG_FILE)
    except OSError:
        return


def compose_project_state(existing, packet, cwd, model="", note_taker="ollama"):
    """Produce the next AGENT_STATE.md content and protect a substantive existing
    state from being clobbered by a materially thinner result.

    Generates via the local note-taker (when enabled) or the deterministic
    fallback, then applies the anti-boilerplate guard here — in the one place all
    callers share — instead of in each caller. Returns ``(content, info)`` where
    info carries source/scoring details for the caller to log.
    """
    content = ""
    source = "fallback"
    if clean_text(note_taker).lower() == "ollama":
        chosen = clean_text(model) or LOCAL_PROJECT_STATE_MODEL
        content = local_project_state_summary(existing, packet, cwd, model=chosen)
        if content:
            source = f"ollama:{chosen}"
    if not content:
        content = fallback_project_state(existing, packet, cwd)
    # Don't let a thin, off-topic session clobber a substantive existing state with
    # boilerplate — keep the richer existing state when the new summary is thinner.
    existing_score = state_substance_score(existing)
    new_score = state_substance_score(content)
    preserved = existing_score >= 6 and new_score < max(6, existing_score // 2)
    if preserved:
        content = existing
        source = f"{source}->preserved"
    return content, {
        "source": source,
        "existing_score": existing_score,
        "new_score": new_score,
        "preserved": preserved,
    }


def latest_turn_notes(session, max_chars=3500):
    """Compact notes of what just happened in the session's most recent turn — the
    raw material the local model distills into durable AGENT_STATE entries."""
    turns = (session or {}).get("turns") or []
    if not turns:
        return ""
    turn = turns[-1]
    parts = []
    prompt = clean_text(turn.get("prompt"))
    if prompt:
        parts.append("User request:\n" + prompt)
    chunks = []
    for item in turn.get("items") or []:
        if not isinstance(item, dict):
            continue
        if item.get("type") not in {"agentMessage", "agent_message", "note", "system"}:
            continue
        text = clean_text(item.get("text"))
        if not text and isinstance(item.get("content"), str):
            text = clean_text(item.get("content"))
        if text:
            chunks.append(text)
    if chunks:
        parts.append("What the agent did/said:\n" + "\n".join(chunks))
    return "\n\n".join(parts).strip()[:max_chars]


def parse_state_delta(raw):
    """Parse the writer model's output into (status, entries). Tolerant of extra
    text: only STATUS: and ENTRY: lines are read."""
    status = ""
    entries = []
    for line in clean_text(raw).splitlines():
        line = line.strip()
        if line.upper().startswith("STATUS:"):
            status = line.split(":", 1)[1].strip()
        elif line.upper().startswith("ENTRY:"):
            body = line.split(":", 1)[1].strip()
            if "|" not in body:
                continue
            tag, text = body.split("|", 1)
            tag = tag.strip().upper()
            text = text.strip().lstrip("-").strip()
            if tag in STATE_TAG_TO_SECTION and text:
                entries.append((tag, text))
    return status, entries


def generate_state_delta(project_label, current_status, turn_notes, date_str, model=None):
    """Ask the fast local model for a Status line + 0..3 categorized log entries for
    the latest turn. Non-blocking on the inference slot — returns ('', []) if the
    model is busy or unreachable (we simply skip this update rather than block a turn
    or rewrite the file)."""
    model = clean_text(model) or STATE_WRITER_MODEL
    turn_notes = clean_text(turn_notes)
    if not turn_notes:
        return "", []
    system = (
        "You maintain a durable project-knowledge file by APPENDING short entries. "
        "You never rewrite existing content. From the latest work, output ONLY lines "
        "in this format and nothing else:\n"
        "STATUS: <one line: the current objective right now>\n"
        "ENTRY: <TAG> | <one or two sentences; name real files/functions/commands>\n"
        "Allowed TAGs: RULE (a reusable do/don't), SETBACK (what broke + the real "
        "fix), PROGRESS (what got done). Emit an ENTRY only when there is something "
        "durable worth keeping (0 to 3). Add a RULE whenever a reusable do/don't "
        "emerged. Be concise and factual. No headings, no commentary, no chat chatter."
    )
    user = (
        f"Project: {project_label}\nDate: {date_str}\n"
        f"Current objective (context): {current_status or '(unknown)'}\n\n"
        f"Latest work:\n{turn_notes}"
    )
    if not _OLLAMA_INFERENCE_SEM.acquire(blocking=False):
        return "", []
    try:
        body = json.dumps({
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
            "options": {"temperature": 0.2},
        }).encode("utf-8")
        base_url = os.environ.get("OLLAMA_HOST", OLLAMA_BASE).rstrip("/")
        request = urllib.request.Request(
            f"{base_url}/api/chat",
            data=body,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=120) as response:
            payload = json.loads(response.read().decode("utf-8"))
        raw = clean_text((payload.get("message") or {}).get("content"))
        raw = re.sub(r"<think>.*?</think>", "", raw, flags=re.S).strip()
        return parse_state_delta(raw)
    except Exception:
        return "", []
    finally:
        _OLLAMA_INFERENCE_SEM.release()


def split_state_sections(content):
    """Split markdown into (preamble, [(heading_line, body), ...]) on '## ' headings.
    Preamble is everything before the first '## ' (title + intro)."""
    preamble = []
    sections = []
    heading = None
    buf = []
    for line in (content or "").splitlines():
        if line.startswith("## "):
            if heading is None:
                preamble = buf
            else:
                sections.append((heading, "\n".join(buf).strip("\n")))
            heading = line.strip()
            buf = []
        else:
            buf.append(line)
    if heading is None:
        preamble = buf
    else:
        sections.append((heading, "\n".join(buf).strip("\n")))
    return "\n".join(preamble).strip("\n"), sections


def apply_state_delta(existing_content, project_label, status, entries, date_str):
    """Non-destructively fold a (status, entries) delta into the AGENT_STATE markdown:
    refresh Current Status, prepend each entry (newest-first) to its section, creating
    core sections near the top if missing. Existing content is never rewritten."""
    if not (existing_content or "").strip():
        existing_content = (
            f"# Agent State - {project_label}\n\n"
            "> Source of truth, kept next to the code. Newest entries on top of each "
            "section; older entries are never rewritten. Split into AGENT_STATE_2.md "
            "if this gets large - never truncate.\n"
        )
    preamble, sections = split_state_sections(existing_content)
    order = [h for h, _ in sections]
    body = {h: b for h, b in sections}

    def ensure_section(heading):
        if heading in body:
            return
        body[heading] = ""
        if heading in STATE_CORE_SECTIONS:
            insert_at = 0
            for core in STATE_CORE_SECTIONS:
                if core == heading:
                    break
                if core in order:
                    insert_at = order.index(core) + 1
            order.insert(insert_at, heading)
        else:
            order.append(heading)

    if status:
        ensure_section("## Current Status")
        body["## Current Status"] = f"- Objective: {status}\n- Updated: {date_str}"
    from difflib import SequenceMatcher

    def _norm_entry(line):
        line = re.sub(r"^\s*-\s*", "", line)
        line = re.sub(r"^\[\d{4}-\d{2}-\d{2}\]\s*", "", line)
        return re.sub(r"\s+", " ", line).strip().lower().rstrip(".")

    for tag, text in entries:
        heading = STATE_TAG_TO_SECTION[tag]
        ensure_section(heading)
        prior = body[heading].strip("\n")
        # Dedupe-on-write: the note-taker tends to re-phrase the same rule, which
        # bloated AGENT_STATE and re-triggered full-state injection. Skip an entry
        # that's an exact or near-duplicate (>0.72 ratio) of one already present.
        new_norm = _norm_entry(text)
        existing = [
            _norm_entry(ln) for ln in prior.splitlines() if ln.strip().startswith("- ")
        ]
        if new_norm and any(
            SequenceMatcher(None, new_norm, ex).ratio() > 0.72 for ex in existing
        ):
            continue
        body[heading] = (f"- [{date_str}] {text}" + ("\n" + prior if prior else "")).strip("\n")

    out = [preamble] if preamble else []
    for heading in order:
        out.append(f"{heading}\n{body[heading]}".rstrip())
    return "\n\n".join(out).strip() + "\n"


def roll_state_file_if_large(state_path, content):
    """Split-don't-truncate: once the file passes STATE_SPLIT_BYTES, archive it to
    AGENT_STATE_<n>.md and keep only the durable top sections (Current Status + Rules)
    in a fresh main file that points at the archive. Returns the MAIN-file content."""
    if len(content.encode("utf-8", errors="ignore")) <= STATE_SPLIT_BYTES:
        return content
    base, ext = os.path.splitext(state_path)
    n = 2
    while os.path.exists(f"{base}_{n}{ext}"):
        n += 1
    archive = f"{base}_{n}{ext}"
    try:
        save_text_atomic(archive, content)
    except Exception:
        return content
    preamble, sections = split_state_sections(content)
    keep = {h: b for h, b in sections}
    out = [preamble] if preamble else []
    for heading in ("## Current Status", "## Rules (do / don't)"):
        if heading in keep:
            out.append(f"{heading}\n{keep[heading]}".rstrip())
    out.append(
        "## Archived Log\n"
        f"- Older Setbacks/Progress moved to `{os.path.basename(archive)}` on "
        f"{now_iso()[:10]} (Rules + Status kept here)."
    )
    return "\n\n".join(out).strip() + "\n"


def refresh_project_state_file(session, force=False, model=None, reason="manual"):
    prefs = memory_preferences()
    mode = clean_text(prefs.get("auto_update")).lower()
    reason = clean_text(reason) or "manual"
    if mode == "off":
        append_debug_event(
            "project_state_skip",
            reason=reason,
            detail="memory updates disabled",
            session=clean_text((session or {}).get("id")),
        )
        return "", ""
    if reason.startswith("handoff") and not prefs.get("update_on_handoff"):
        append_debug_event(
            "project_state_skip",
            reason=reason,
            detail="handoff updates disabled",
            session=clean_text((session or {}).get("id")),
        )
        return "", ""
    root = infer_project_root(session, clean_text((session or {}).get("cwd")))
    if not root or not os.path.isdir(root):
        return "", ""
    session["project_root"] = root
    state_path = project_state_path(root)
    if not state_path:
        # root resolved to the bare home dir (project_state_path returns "" for
        # ~), so there is no project AGENT_STATE to maintain here. Skip cleanly
        # instead of falling through to open("")/save_text_atomic("") — which
        # raised "[Errno 2] ... '.tmp-...' -> ''" and silently aborted the
        # post-turn state refresh for every home-dir session.
        return "", ""
    signature = handoff_signature(session)
    if (
        not force
        and clean_text(session.get("project_state_signature")) == signature
        and os.path.isfile(state_path)
    ):
        registry_path = ensure_project_registry(
            root,
            session=session,
            agent_key=clean_text(session.get("agent")),
            title=clean_text(session.get("title")),
            state_path=state_path,
            sequence=session.get("handoff_sequence"),
        )
        return state_path, registry_path
    # Read the FULL existing file (no truncation — this is a source of truth) and
    # ask the local model for an incremental delta from the latest turn. We APPEND
    # the delta; we never re-summarize/rewrite the existing content.
    try:
        with open(state_path, encoding="utf-8", errors="replace") as handle:
            existing = handle.read()
    except OSError:
        existing = ""
    _registry_path0, registry = read_project_registry(root)
    project_label = (
        clean_text((registry or {}).get("display_name"))
        or os.path.basename(root.rstrip("/"))
        or "project"
    )
    _pre, _secs = split_state_sections(existing)
    current_status = dict(_secs).get("## Current Status", "")
    chosen_model = clean_text(model) or STATE_WRITER_MODEL
    date_str = now_iso()[:10]
    status, entries = generate_state_delta(
        project_label, current_status, latest_turn_notes(session), date_str, chosen_model
    )
    wrote = False
    if status or entries:
        new_content = apply_state_delta(existing, project_label, status, entries, date_str)
        new_content = roll_state_file_if_large(state_path, new_content)
        if new_content != existing:
            save_text_atomic(state_path, new_content)
            wrote = True
    else:
        append_debug_event(
            "project_state_skip",
            reason=reason,
            detail="no durable delta from latest turn",
            session=clean_text(session.get("id")),
        )
    session["project_state_signature"] = signature
    session["project_state_updated_at"] = now_iso()
    sequence = session.get("handoff_sequence")
    registry_path = ensure_project_registry(
        root,
        session=session,
        agent_key=clean_text(session.get("agent")),
        title=clean_text(session.get("title")),
        state_path=state_path,
        sequence=sequence,
    )
    if wrote:
        append_debug_event(
            "project_state_update",
            reason=reason,
            note_taker="append",
            session=clean_text(session.get("id")),
            project_root=root,
            state_path=state_path,
            entries=len(entries),
        )
    return state_path, registry_path


def _background_refresh_project_state(session):
    """Fire-and-forget wrapper for the post-turn call site: keeps the same
    on-failure debug event the inline call used to log, without letting an
    exception escape into the daemon thread silently."""
    try:
        refresh_project_state_file(session, force=False, reason="turn_complete")
    except Exception as error:
        append_debug_event(
            "project_state_skip",
            reason="turn_complete",
            detail=f"error: {clean_text(error)}",
            session=clean_text((session or {}).get("id")),
        )


def open_project_state_file(session_id="", cwd=""):
    session = {}
    if clean_text(session_id):
        try:
            session = load_session(clean_text(session_id))
        except Exception:
            session = {}
    if not session:
        session = {
            "id": clean_text(session_id),
            "title": project_label(cwd),
            "agent": "",
            "cwd": clean_text(cwd),
            "turns": [],
        }
    root = infer_project_root(session, clean_text(session.get("cwd")) or cwd)
    if not root:
        return ""
    state_path = project_state_path(root)
    if not state_path:
        return ""
    if not os.path.isfile(state_path):
        packet = structured_handoff_packet(session)
        _existing_path, existing = read_project_state(root, max_chars=60_000)
        content, _info = compose_project_state(existing, packet, root, note_taker="fallback")
        save_text_atomic(state_path, content)
    ensure_project_registry(
        root,
        session=session,
        agent_key=clean_text(session.get("agent")),
        title=clean_text(session.get("title")),
        state_path=state_path,
        sequence=session.get("handoff_sequence"),
    )
    subprocess.Popen(["xdg-open", state_path])
    return state_path


def read_jsonl_lines(path, limit=None):
    try:
        with open(path, encoding="utf-8") as handle:
            for index, line in enumerate(handle):
                if limit is not None and index >= limit:
                    break
                try:
                    yield json.loads(line)
                except ValueError:
                    continue
    except OSError:
        return


def native_session_id(session):
    source_id = clean_text(session.get("source_session_id"))
    if source_id:
        return source_id
    backend = session.get("backend") or {}
    return clean_text(backend.get("session_id") or backend.get("thread_id"))


def session_clean_title(session):
    """A clean, terminal-safe title — never the injected <session_context> blob.
    Prefers AWBN's own title, then the user's first prompt, then the project name.
    Always non-empty."""
    raw = clean_text(session.get("title"))
    title = SESSION_CONTEXT_BLOCK.sub("", raw).strip() if raw else ""
    if title:
        return title[:80]
    for turn in (session.get("turns") or []):
        if not isinstance(turn, dict):
            continue
        text = clean_text(turn.get("prompt"))
        if not text:
            for item in (turn.get("items") or []):
                if not isinstance(item, dict):
                    continue
                if item.get("type") not in {"userMessage", "user_message"}:
                    continue
                content = item.get("content")
                if isinstance(content, list):
                    text = clean_text(
                        " ".join(
                            clean_text(p.get("text"))
                            for p in content
                            if isinstance(p, dict) and p.get("text")
                        )
                    )
                elif isinstance(content, str):
                    text = clean_text(content)
                if not text:
                    text = clean_text(item.get("text"))
                if text:
                    break
        text = SESSION_CONTEXT_BLOCK.sub("", text).strip()
        if text:
            return text[:60].strip()
    return clean_text(project_label(session.get("cwd"))) or "Codex session"


def sync_native_title_from_session(session):
    title = session_clean_title(session)
    native_id = native_session_id(session)
    agent = clean_text(session.get("agent")).lower()
    if not native_id or agent not in {"claude", "codex", "gemini"}:
        return False
    if agent == "claude":
        claude_root = Path(os.path.expanduser("~/.claude/projects"))
        if not claude_root.is_dir():
            return False
        paths = list(claude_root.glob(f"*/*{native_id}.jsonl"))
        if not paths:
            paths = list(claude_root.glob(f"*/{native_id}.jsonl"))
        if not paths:
            return False
        records = [
            {"type": "custom-title", "customTitle": title, "sessionId": native_id},
            {"type": "agent-name", "agentName": title, "sessionId": native_id},
            {"type": "ai-title", "aiTitle": title, "sessionId": native_id},
        ]
        with open(paths[0], "a", encoding="utf-8") as handle:
            for record in records:
                handle.write(json.dumps(record, separators=(",", ":")) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        return True
    if agent == "codex":
        database = os.path.expanduser("~/.codex/state_5.sqlite")
        if not os.path.isfile(database):
            return False
        try:
            import sqlite3

            # 30s busy-wait: the Codex CLI may hold this DB during an active turn;
            # without a timeout the write throws "database is locked" and the
            # session never gets a terminal-visible title.
            connection = sqlite3.connect(database, timeout=30)
            try:
                # AWBN drives Codex through `codex exec --json` so the UI can stream
                # structured events, but those native threads are still user-facing
                # conversations. Normalize owned threads back to terminal-visible
                # metadata so plain `codex resume` treats them like CLI sessions.
                # The resume picker reads title / preview / first_user_message; set all
                # three to the clean title so the row never shows the <session_context>
                # blob, whichever column it displays. Flip exec→cli so `codex resume`
                # lists it as a normal interactive session.
                cursor = connection.execute(
                    "update threads set title = ?, preview = ?, first_user_message = ?, "
                    "source = case when source = 'exec' then 'cli' else source end, "
                    "thread_source = case when coalesce(thread_source, '') = '' "
                    "then 'user' else thread_source end "
                    "where id = ?",
                    (title, title, title, native_id),
                )
                connection.commit()
                return cursor.rowcount > 0
            finally:
                connection.close()
        except Exception as error:
            append_debug_event(
                "native_title_sync_failed",
                agent=agent,
                session=clean_text(session.get("id")),
                native_id=native_id,
                error=clean_text(error),
            )
            return False
    if agent == "gemini":
        titles = load_json(GEMINI_TITLE_CACHE_FILE, {}) or {}
        titles[native_id] = title
        save_json(GEMINI_TITLE_CACHE_FILE, titles)
    return True


def sync_owned_codex_threads_for_terminal():
    """Backfill terminal-compatible metadata for AWBN-owned Codex threads.

    This is intentionally scoped to sessions that AWBN owns through a native
    Codex thread id. Imported native history and unrelated Codex sessions are
    left alone.
    """
    fixed = 0
    for session in all_sessions():
        if clean_text(session.get("agent")).lower() != "codex":
            continue
        if not native_thread_owned(session):
            continue
        if sync_native_title_from_session(session):
            fixed += 1
    return fixed


def native_thread_owned(session):
    return bool(session.get("native_thread_owned"))


def session_uses_external_native_history(session):
    agent = clean_text(session.get("agent")).lower()
    if agent not in {"claude", "codex", "gemini"}:
        return False
    if native_thread_owned(session):
        return False
    if native_session_id(session):
        return True
    return bool(clean_text(session.get("source_path")))


def raw_artifact_session_dir(session_id):
    return os.path.join(CONFIG_DIR, "artifacts", safe_artifact_session_key(session_id))


def refresh_session_from_native_transcript(session, persist=True):
    source_path = clean_text(session.get("source_path"))
    if not source_path or not os.path.isfile(source_path):
        return session
    agent = clean_text(session.get("agent"))
    if agent not in {"claude", "codex", "gemini"}:
        return session
    source_mtime_ns = os.stat(source_path).st_mtime_ns
    if (
        session.get("transcript_loaded")
        and int(session.get("source_mtime_ns") or 0) == source_mtime_ns
    ):
        return session
    if agent == "claude":
        metadata = claude_session_metadata(source_path)
        session["turns"] = claude_jsonl_turns(source_path)
        session["context"] = metadata["context"]
        if metadata["title"]:
            session["title"] = metadata["title"]
    elif agent == "codex":
        session["turns"] = codex_rollout_turns(source_path)
        session["context"] = codex_context_from_rollout(source_path)
    elif agent == "gemini":
        session["turns"] = gemini_jsonl_turns(source_path)
        title = gemini_title_from_jsonl(source_path)
        if title:
            session["title"] = title
    session["source_mtime_ns"] = source_mtime_ns
    session["transcript_loaded"] = True
    if persist:
        save_session(session)
    return session


def session_event_payload(session):
    external_native = bool(
        clean_text(session.get("origin")).endswith("-terminal")
        or clean_text(session.get("source_path"))
    )
    project_root = (
        filesystem_project_root_for_session(session, session.get("cwd"))
        if external_native
        else infer_project_root(session, session.get("cwd"))
    )
    # v4.0.5: emit the REAL path — a root inferred through a symlink alias
    # (e.g. an old ~/shortcut pointing at the real folder) never
    # string-matches the registered project root in the UI, which left a
    # freshly created project chat showing "No project chat selected"
    # string-match the registered project root.
    if project_root:
        try:
            project_root = os.path.realpath(project_root)
        except OSError:
            pass
    return {
        "id": clean_text(session.get("id")),
        "title": clean_text(session.get("title")) or "Untitled",
        "agent": clean_text(session.get("agent")),
        "backend": deepcopy(session.get("backend") or {}),
        "cwd": clean_text(session.get("cwd")),
        "project_root": project_root,
        "project_id": clean_text(session.get("project_id")),
        "project_chat": session.get("project_chat") is True,
        "origin": clean_text(session.get("origin")) or "local",
        "source_session_id": clean_text(session.get("source_session_id")),
        "updated_at": clean_text(session.get("updated_at")),
        "created_at": clean_text(session.get("created_at")),
        "worker_job_id": clean_text(session.get("worker_job_id")),
        "worker_parent_session_id": clean_text(session.get("worker_parent_session_id")),
        "worktree_branch": clean_text(session.get("worktree_branch")),
        "kanban_phase": clean_text(session.get("kanban_phase")),
        "context": deepcopy(session.get("context") or {}),
    }


def ui_extract_user_text(content):
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for part in content:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, dict):
                parts.append(str(part.get("text") or ""))
        return "".join(parts)
    if isinstance(content, dict):
        return str(content.get("text") or "")
    return ""


def ui_first_text(item, keys):
    if not isinstance(item, dict):
        return ""
    for key in keys:
        value = clean_text(item.get(key))
        if value:
            return value
    return ""


def ui_is_image_path(path):
    return os.path.splitext(clean_text(path))[1].lower() in {
        ".avif",
        ".bmp",
        ".gif",
        ".jpeg",
        ".jpg",
        ".png",
        ".svg",
        ".webp",
    }


def ui_is_video_path(path):
    return os.path.splitext(clean_text(path))[1].lower() in {
        ".3g2",
        ".3gp",
        ".avi",
        ".m4v",
        ".mkv",
        ".mov",
        ".mp4",
        ".mpeg",
        ".mpg",
        ".ogv",
        ".ts",
        ".webm",
        ".wmv",
    }


def ui_message_attachments(item):
    attachments = []
    if not isinstance(item, dict):
        return attachments
    for attachment in item.get("attachments") or []:
        if not isinstance(attachment, dict):
            continue
        path = clean_text(attachment.get("path"))
        name = clean_text(attachment.get("name")) or os.path.basename(path)
        if not path and not name:
            continue
        attachments.append(
            {
                "name": name,
                "path": path,
                "is_image": bool(attachment.get("is_image")) or ui_is_image_path(path),
                "is_video": bool(attachment.get("is_video")) or ui_is_video_path(path),
            }
        )
    return attachments


# Work-log entry types that are an actual tool invocation, as opposed to the
# agent narrating (reasoning), summarizing (report), or the app annotating
# (note/system). Only these are counted as "tools" (v4.3.3).
TOOL_CALL_DETAIL_TYPES = frozenset({"command", "file", "tool"})


def count_tool_calls(details):
    """How many of these work-log entries are real tool calls.

    Reported: a card read "Tools 59" for a Codex turn that made 64 tool calls.
    Neither number was the other's — `tool_count` was `len(tool_parts)`, i.e.
    every work-log entry including reasoning, reports and notes, displayed
    under a label that says "Tools". It counted a real quantity; it just
    wasn't the one on the label."""
    return sum(
        1
        for detail in details or []
        if isinstance(detail, dict)
        and clean_text(detail.get("type")) in TOOL_CALL_DETAIL_TYPES
    )


def ui_tool_detail(item):
    if not isinstance(item, dict):
        return None
    item_type = clean_text(item.get("type"))
    tag = clean_text(item.get("tag"))
    if item_type in {"userMessage", "agentMessage"}:
        return None
    if item_type == "commandExecution":
        command = ui_first_text(item, ["command"])
        output = ui_first_text(item, ["aggregatedOutput", "output", "content", "text"])
        if command and output and command != output:
            content = f"$ {command}\n\n{output}"
        elif command:
            content = f"$ {command}"
        else:
            content = output
        label = "Command"
        detail_type = "command"
    elif item_type == "fileChange":
        label = "File"
        detail_type = "file"
        content = ui_first_text(item, ["content", "text", "path", "message"])
    elif item_type == "reasoning":
        label = "Reasoning"
        detail_type = "reasoning"
        content = ui_first_text(item, ["content", "text", "message"])
    elif item_type == "report":
        label = "Worker" if tag == "worker" else "Report"
        detail_type = "report"
        content = ui_first_text(item, ["content", "text", "message"])
    elif item_type == "note":
        label = "Note"
        detail_type = "note"
        content = ui_first_text(item, ["content", "text", "message"])
    else:
        label = {"tool": "Tool", "system": "System", "worker": "Worker"}.get(tag, "Tool")
        detail_type = tag or item_type
        content = ui_first_text(item, ["content", "text", "message", "command"])
    if not content:
        return None
    return {"type": detail_type, "label": label, "content": content}


def ui_latest_turn_summary(session):
    turns = session.get("turns") or []
    if not turns:
        return "", ""
    turn = turns[-1] if isinstance(turns[-1], dict) else {}
    status = clean_text(turn.get("status"))
    prompt = clean_text(turn.get("prompt"))
    if prompt:
        return status, prompt
    for item in turn.get("items") or []:
        if isinstance(item, dict) and item.get("type") == "userMessage":
            prompt = clean_text(ui_extract_user_text(item.get("content")))
            if prompt:
                return status, prompt
    return status, ""


def ui_default_empty_session_title(agent, title):
    normalized = clean_text(title).lower()
    if not normalized:
        return True
    if normalized in {
        "new claude session",
        "new claude code",
        "new claude code session",
        "claude session",
        "new codex session",
        "codex session",
        "new gemini session",
        "gemini session",
        "new local session",
        "local session",
        "new ollama session",
        "ollama session",
    }:
        return True
    agent = clean_text(agent).lower()
    if agent == "claude":
        return normalized in {"new session", "new claude"}
    if agent == "codex":
        return normalized in {"new session", "new codex"}
    if agent == "gemini":
        return normalized in {"new session", "new gemini"}
    if agent in {"ollama", "local"}:
        return normalized == "new session"
    return False


def session_is_worker(session):
    """A spawned worker / delegated sub-session — a process artifact of some
    parent session, reachable from that parent's Workers pane, NOT a top-level
    conversation. Kept out of the primary session list."""
    return bool(
        clean_text(session.get("worker_job_id"))
        or clean_text(session.get("worker_parent_session_id"))
    )


def session_is_native_linked(session):
    """Discovered from an external Claude/Codex/Gemini terminal transcript
    rather than created in AWBN. These are import-on-demand — hidden from the
    primary list until the user explicitly imports one (`user_imported`)."""
    origin = clean_text(session.get("origin"))
    return (
        origin.endswith("-terminal")
        or bool(clean_text(session.get("source_path")))
        or bool(clean_text(session.get("source_session_id")))
    )


def ui_session_has_real_content(session):
    if session.get("user_created"):
        return True
    turns = session.get("turns")
    if isinstance(turns, list) and turns:
        return True
    return not ui_default_empty_session_title(session.get("agent"), session.get("title"))


def ui_user_visible_session(session):
    # "All" scope: everything that isn't an empty scaffold — workers and native
    # imports included.
    if session_is_worker(session):
        return True
    return ui_session_has_real_content(session)


def ui_session_in_primary_list(session):
    """Primary (default) list = intentional AWBN work only: sessions created
    here, plus native sessions the user explicitly imported. Workers and
    not-yet-imported terminal sessions are excluded (they live in the Workers
    pane and the "All" view respectively)."""
    if session_is_worker(session):
        return False
    if session_is_native_linked(session) and not session.get("user_imported"):
        return False
    return ui_session_has_real_content(session)


def ui_session_in_terminal_list(session):
    """External Claude/Codex/Gemini terminal history only."""
    if session_is_worker(session):
        return False
    return session_is_native_linked(session) and ui_session_has_real_content(session)


def ui_session_summary(session):
    # Very long chats are cached without their transcript (see
    # local_session_records) but WITH these three fields precomputed, so the
    # list view never re-parses tens of MB to render one row.
    precomputed = session.get("_awbn_summary")
    if isinstance(precomputed, dict):
        status = clean_text(precomputed.get("last_turn_status"))
        prompt = clean_text(precomputed.get("latest_prompt"))
    else:
        status, prompt = ui_latest_turn_summary(session)
    payload = session_event_payload(session)
    turns = session.get("turns")
    payload.update(
        {
            "transcript_loaded": bool(session.get("transcript_loaded")),
            "source_path": clean_text(session.get("source_path")),
            # v4.7.1 (data loss: "fuck my queue disappeared after restarting
            # awbn"). The continuation queue used to live only in the
            # workspace TAB list, and every save replaced that list wholesale
            # — so a queue on a session whose tab was not open was silently
            # dropped. It belongs to the session, and now lives with it.
            "queued_prompts": session.get("queued_prompts")
            if isinstance(session.get("queued_prompts"), list)
            else [],
            "turn_count": int(precomputed.get("turn_count") or 0)
            if isinstance(precomputed, dict)
            else (len(turns) if isinstance(turns, list) else 0),
            "last_turn_status": status,
            "latest_prompt": prompt,
            # Frontend uses these to badge rows and gate the "Import" action.
            "user_imported": bool(session.get("user_imported")),
            "native_linked": session_is_native_linked(session),
            "is_worker": session_is_worker(session),
        }
    )
    return payload


_SESSION_LIST_CACHE = {}
_SESSION_LIST_CACHE_LOCK = threading.Lock()
# The built list, saved so a bridge restart doesn't rebuild it. Guarded by the
# same folder fingerprint the in-memory cache uses, so a session added, removed
# or edited while the bridge was down still rebuilds.
SESSION_LIST_CACHE_FILE = os.path.join(CONFIG_DIR, "session-list.json")


def _session_dir_signature():
    """A cheap fingerprint of the sessions folder: how many files there are and
    the newest modification time. Building the list costs ~145ms of summarising
    342 records; between edits none of it changes, so this decides whether any
    of that work is needed at all."""
    newest = 0.0
    count = 0
    try:
        with os.scandir(SESS_DIR) as entries:
            for entry in entries:
                if not entry.name.endswith(".json"):
                    continue
                count += 1
                try:
                    newest = max(newest, entry.stat().st_mtime_ns)
                except OSError:
                    continue
    except OSError:
        return (0, 0.0)
    return (count, newest)


def ui_list_sessions_payload(scope="primary"):
    """Cached against the sessions folder's own fingerprint (v4.3.3).

    The list is rebuilt only when a session file has actually been added,
    removed or written. Everything else — reopening the app, switching tabs,
    a background refresh — reuses the built list."""
    signature = _session_dir_signature()
    with _SESSION_LIST_CACHE_LOCK:
        cached = _SESSION_LIST_CACHE.get(scope)
        if cached is not None and cached[0] == signature:
            return cached[1]
    stored = _load_persisted_session_list(scope, signature)
    if stored is not None:
        with _SESSION_LIST_CACHE_LOCK:
            _SESSION_LIST_CACHE[scope] = (signature, stored)
        return stored
    payload, per_file = _build_session_list_payload(
        scope, reuse=_saved_session_rows_by_file(scope)
    )
    with _SESSION_LIST_CACHE_LOCK:
        _SESSION_LIST_CACHE[scope] = (signature, payload)
    _persist_session_list(scope, signature, payload, per_file)
    return payload


def _load_persisted_session_list(scope, signature):
    """The list saved by an earlier run, if the folder hasn't changed since."""
    raw = load_json(SESSION_LIST_CACHE_FILE, {}) or {}
    entry = raw.get(scope) if isinstance(raw, dict) else None
    if not isinstance(entry, dict):
        return None
    saved = entry.get("signature")
    if not isinstance(saved, list) or len(saved) != 2:
        return None
    if (int(saved[0]), int(saved[1])) != signature:
        return None
    rows = entry.get("rows")
    return rows if isinstance(rows, list) else None


def _persist_session_list(scope, signature, payload, per_file=None):
    """Save the built list, plus what each file contributed to it.

    The per-file map is what lets a restart after activity reuse the work:
    without it, one changed session file meant re-reading and re-summarising
    all 360 records (0.26s) to draw the list."""
    try:
        raw = load_json(SESSION_LIST_CACHE_FILE, {}) or {}
        if not isinstance(raw, dict):
            raw = {}
        entry = {"signature": [signature[0], signature[1]], "rows": payload}
        if per_file is not None:
            entry["files"] = per_file
        raw[scope] = entry
        save_json(SESSION_LIST_CACHE_FILE, raw)
    except OSError:
        pass


def _saved_session_rows_by_file(scope):
    """What each session file contributed to the saved list, by file stamp.

    A row means "this file is in the list and looks like this"; None means
    "this file was filtered out". Both are answers worth keeping — skipping a
    filtered-out file saves reading it just to discard it again."""
    raw = load_json(SESSION_LIST_CACHE_FILE, {}) or {}
    entry = raw.get(scope) if isinstance(raw, dict) else None
    files = entry.get("files") if isinstance(entry, dict) else None
    return files if isinstance(files, dict) else {}


def _session_file_stamps():
    """Every session file with its (modification time, size), cheaply."""
    stamps = {}
    try:
        with os.scandir(SESS_DIR) as entries:
            for entry in entries:
                if not entry.name.endswith(".json"):
                    continue
                try:
                    stat = entry.stat()
                except OSError:
                    continue
                stamps[entry.path] = f"{stat.st_mtime_ns}:{stat.st_size}"
    except OSError:
        return {}
    return stamps


def _build_session_list_payload(scope="primary", reuse=None):
    """scope="primary" (default) → only AWBN-created + explicitly-imported
    sessions (the clean list). scope="terminal" → external terminal history.
    scope="all" → everything visible, including workers.

    `reuse` is the per-file map an earlier run saved. Any file whose stamp
    still matches is taken from it — not read, not summarised, not even
    opened. Returns (rows, per_file)."""
    deleted_ids, deleted_paths = deleted_native_refs()
    if scope == "all":
        keep = ui_user_visible_session
    elif scope == "terminal":
        keep = ui_session_in_terminal_list
    else:
        keep = ui_session_in_primary_list
    stamps = _session_file_stamps()
    reuse = reuse or {}
    sessions = []
    per_file = {}
    fresh = []
    for path, stamp in stamps.items():
        saved = reuse.get(path)
        if isinstance(saved, dict) and saved.get("stamp") == stamp:
            per_file[path] = saved
            row = saved.get("row")
            if isinstance(row, dict):
                sessions.append(row)
        else:
            fresh.append(path)
    for path in fresh:
        session = load_session_record(path)
        if session is None:
            continue
        row = None
        if not source_is_deleted(session, deleted_ids, deleted_paths) and keep(session):
            row = ui_session_summary_cached(path, session)
            sessions.append(row)
        per_file[path] = {"stamp": stamps[path], "row": row}
    sessions.sort(
        key=lambda value: clean_text(value.get("updated_at")) or clean_text(value.get("created_at")),
        reverse=True,
    )
    return sessions, per_file


def ui_session_messages_payload(session_id):
    session = load_session(session_id)
    agent = clean_text(session.get("agent"))
    messages = []
    for turn in session.get("turns") or []:
        if not isinstance(turn, dict):
            continue
        turn_id = clean_text(turn.get("id"))
        created_at = clean_text(turn.get("created_at"))
        completed_at = clean_text(turn.get("completed_at")) or created_at
        usage = turn.get("usage") if isinstance(turn.get("usage"), dict) else {}
        model = clean_text(turn.get("model"))
        effort = clean_text(turn.get("effort"))
        status = clean_text(turn.get("status"))
        assistant_parts = []
        tool_parts = []
        for index, item in enumerate(turn.get("items") or []):
            if not isinstance(item, dict):
                continue
            item_type = clean_text(item.get("type"))
            if item_type == "userMessage":
                text = ui_extract_user_text(item.get("content")).strip()
                attachments = ui_message_attachments(item)
                if text or attachments:
                    messages.append(
                        {
                            "id": f"{turn_id}-user-{index}",
                            "role": "user",
                            "content": text,
                            "attachments": attachments,
                            "time": created_at,
                        }
                    )
            elif item_type == "agentMessage":
                text = ui_first_text(item, ["text", "content"])
                if text:
                    assistant_parts.append(text)
            else:
                detail = ui_tool_detail(item)
                if detail:
                    tool_parts.append(detail)
        if assistant_parts or tool_parts:
            messages.append(
                {
                    "id": f"{turn_id}-agent",
                    "role": "assistant",
                    "agent": agent,
                    "content": "\n\n".join(assistant_parts),
                    "tools": tool_parts,
                    "time": completed_at,
                    "model": model,
                    "effort": effort,
                    "status": status,
                    "duration_ms": int(turn.get("duration_ms") or 0),
                    "input_tokens": safe_int(usage.get("input_tokens")),
                    "output_tokens": safe_int(usage.get("output_tokens")),
                    "total_tokens": safe_int(usage.get("total_tokens")),
                    "cache_creation_input_tokens": safe_int(
                        usage.get("cache_creation_input_tokens") or 0
                    ),
                    "cache_read_input_tokens": safe_int(
                        usage.get("cache_read_input_tokens") or 0
                    ),
                    # Tool calls only — not every work-log entry. The Work
                    # Log pane still shows all of `tool_parts`; this figure
                    # is what the strip labels "Tools", so it counts tool
                    # invocations and leaves out the agent's own narration.
                    "tool_count": count_tool_calls(tool_parts),
                    # Plan consumption for plan-billed clients (Codex), so a
                    # reloaded turn shows the same figure as a live one.
                    "plan_used_percent": usage.get("plan_used_percent"),
                    "cost_usd": usage.get("cost_usd"),
                }
            )
    return messages


def ui_session_work_log_payload(session_id):
    session = load_session(session_id)
    entries = []
    for turn in session.get("turns") or []:
        if not isinstance(turn, dict):
            continue
        turn_id = clean_text(turn.get("id"))
        created_at = clean_text(turn.get("created_at"))
        for index, item in enumerate(turn.get("items") or []):
            if not isinstance(item, dict):
                continue
            item_type = clean_text(item.get("type"))
            if item_type in {"userMessage", "agentMessage"}:
                continue
            if item_type == "commandExecution":
                content = ui_first_text(item, ["command", "aggregatedOutput", "text"])
            elif item_type == "fileChange":
                content = ui_first_text(item, ["content", "text", "path"])
            else:
                content = ui_first_text(item, ["content", "text", "message", "command"])
            if content:
                entries.append(
                    {
                        "id": f"{turn_id}-work-{index}",
                        "type": item_type,
                        # What KIND of row this is — "tool", "command",
                        # "note" (the agent talking), "system" (this client's
                        # own chatter). `type` cannot tell them apart: a tool
                        # call and a rate-limit blob are both "system". The
                        # app needs this to show steps without the plumbing
                        # (reported v4.3.5: "it shouldn't be showing me all
                        # this work log crap").
                        "tag": clean_text(item.get("tag")),
                        # What was actually run, for command steps.
                        "command": clean_text(item.get("command")),
                        # The file a tool touched, so a step can read "Read
                        # ship-concept1.jpeg" instead of a bare "Read". The
                        # tool name alone told you nothing about what it was
                        # working on.
                        "file_path": clean_text(item.get("file_path")),
                        "content": content,
                        "time": created_at,
                    }
                )
    return entries


def ui_is_text_path(path):
    return os.path.splitext(clean_text(path))[1].lower() in {
        ".cfg",
        ".gd",
        ".gdextension",
        ".gdnlib",
        ".gdns",
        ".gdshader",
        ".gdshaderinc",
        ".godot",
        ".import",
        ".tscn",
        ".tres",
        ".uid",
        ".txt",
        ".md",
        ".json",
        ".jsonl",
        ".log",
        ".py",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".css",
        ".html",
        ".yaml",
        ".yml",
        ".toml",
        ".ini",
        ".rs",
        ".sh",
    }


def ui_artifact_value(path):
    try:
        stat = os.stat(path)
        size = stat.st_size
        modified = int(stat.st_mtime)
    except OSError:
        size = 0
        modified = 0
    return {
        "name": os.path.basename(path),
        "path": path,
        "size": size,
        "modified": modified,
        "is_image": ui_is_image_path(path),
        "is_text": ui_is_text_path(path),
    }


def ui_session_artifacts_payload(session_id):
    session_id = clean_text(session_id)
    if not session_id:
        raise RuntimeError("missing session id")
    directory = raw_artifact_session_dir(session_id)
    if not os.path.isdir(directory):
        return []
    artifacts = []
    for entry in os.scandir(directory):
        try:
            if entry.is_file(follow_symlinks=False):
                artifacts.append(ui_artifact_value(entry.path))
        except OSError:
            continue
    artifacts.sort(key=lambda value: int(value.get("modified") or 0), reverse=True)
    return artifacts


def ui_unique_artifact_destination(directory, name):
    basename = os.path.basename(clean_text(name)) or "artifact"
    stem, ext = os.path.splitext(basename)
    stem = stem or "artifact"
    candidate = os.path.join(directory, basename)
    index = 1
    while os.path.exists(candidate):
        candidate = os.path.join(directory, f"{stem}-{index}{ext}")
        index += 1
    return candidate


def ui_artifact_directory_bytes(directory):
    total = 0
    try:
        entries = os.scandir(directory)
    except OSError:
        return 0
    with entries:
        for entry in entries:
            try:
                if entry.is_file(follow_symlinks=False):
                    total += entry.stat(follow_symlinks=False).st_size
            except OSError:
                continue
    return total


def ui_assert_artifact_capacity(directory, additional_bytes, request_bytes=0):
    if additional_bytes < 0 or additional_bytes > ARTIFACT_MAX_FILE_BYTES:
        raise RuntimeError(
            f"attachment exceeds the {ARTIFACT_MAX_FILE_BYTES // (1024 * 1024)} MB per-file limit"
        )
    if request_bytes + additional_bytes > ARTIFACT_MAX_REQUEST_BYTES:
        raise RuntimeError(
            f"attachments exceed the {ARTIFACT_MAX_REQUEST_BYTES // (1024 * 1024)} MB request limit"
        )
    if ui_artifact_directory_bytes(directory) + additional_bytes > ARTIFACT_MAX_SESSION_BYTES:
        raise RuntimeError("this chat has reached its 2 GB artifact limit")
    free = shutil.disk_usage(directory).free
    if free - additional_bytes < ARTIFACT_MIN_FREE_BYTES:
        raise RuntimeError("not enough free disk space to store this attachment safely")


def ui_atomic_copy_artifact(source, destination, expected_size):
    temporary = os.path.join(
        os.path.dirname(destination),
        f".{os.path.basename(destination)}.tmp-{os.getpid()}-{uuid.uuid4().hex}",
    )
    copied = 0
    try:
        with open(source, "rb") as input_handle, open(temporary, "xb") as output_handle:
            chmod_best_effort(temporary, PRIVATE_FILE_MODE)
            while True:
                chunk = input_handle.read(1024 * 1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > ARTIFACT_MAX_FILE_BYTES or copied > expected_size:
                    raise RuntimeError("attachment changed or exceeded its size limit while copying")
                output_handle.write(chunk)
            output_handle.flush()
            os.fsync(output_handle.fileno())
        if copied != expected_size:
            raise RuntimeError("attachment changed while it was being copied; try again")
        os.replace(temporary, destination)
        chmod_best_effort(destination, PRIVATE_FILE_MODE)
    finally:
        try:
            if os.path.exists(temporary):
                os.unlink(temporary)
        except OSError:
            pass


def ui_store_artifacts_payload(session_id, paths):
    session_id = clean_text(session_id)
    if not session_id:
        raise RuntimeError("missing session id")
    directory = artifact_session_dir(session_id)
    stored = []
    raw_paths = list(paths or [])
    if len(raw_paths) > ARTIFACT_MAX_FILES_PER_REQUEST:
        raise RuntimeError(
            f"select at most {ARTIFACT_MAX_FILES_PER_REQUEST} attachments at a time"
        )
    request_bytes = 0
    for raw_path in raw_paths:
        source = os.path.abspath(os.path.expanduser(clean_text(raw_path)))
        if not source or not os.path.isfile(source):
            continue
        try:
            source_size = os.stat(source, follow_symlinks=True).st_size
        except OSError:
            continue
        ui_assert_artifact_capacity(directory, source_size, request_bytes)
        destination = ui_unique_artifact_destination(directory, os.path.basename(source))
        ui_atomic_copy_artifact(source, destination, source_size)
        request_bytes += source_size
        stored.append(ui_artifact_value(destination))
    return stored


def ui_session_artifact_path(session_id, path):
    session_id = clean_text(session_id)
    if not session_id:
        raise RuntimeError("missing session id")
    directory = os.path.abspath(raw_artifact_session_dir(session_id))
    artifact_path = os.path.abspath(os.path.expanduser(clean_text(path)))
    if not artifact_path:
        raise RuntimeError("missing artifact path")
    if os.path.dirname(artifact_path) != directory:
        raise RuntimeError("artifact path is outside this session")
    if os.path.islink(artifact_path) or not os.path.isfile(artifact_path):
        raise RuntimeError("artifact not found")
    return artifact_path


def ui_open_artifact_payload(session_id, path):
    artifact_path = ui_session_artifact_path(session_id, path)
    opener = shutil.which("xdg-open") or shutil.which("gio")
    if not opener:
        raise RuntimeError("no desktop opener is available")
    command = [opener, artifact_path]
    if os.path.basename(opener) == "gio":
        command = [opener, "open", artifact_path]
    subprocess.Popen(
        command,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    return ui_artifact_value(artifact_path)


def ui_rename_artifact_payload(session_id, path, name):
    artifact_path = ui_session_artifact_path(session_id, path)
    new_name = clean_text(name)
    if not new_name:
        raise RuntimeError("artifact name cannot be empty")
    if new_name != os.path.basename(new_name) or "/" in new_name or "\\" in new_name:
        raise RuntimeError("artifact name must not contain folders")
    if len(new_name) > 180:
        raise RuntimeError("artifact name is too long")
    directory = os.path.dirname(artifact_path)
    target = os.path.join(directory, new_name)
    if os.path.abspath(target) == artifact_path:
        return ui_artifact_value(artifact_path)
    if os.path.exists(target):
        raise RuntimeError("artifact name already exists")
    os.rename(artifact_path, target)
    return ui_artifact_value(target)


def ui_delete_artifact_payload(session_id, path):
    artifact_path = ui_session_artifact_path(session_id, path)
    os.remove(artifact_path)
    return ui_session_artifacts_payload(session_id)


def ui_normalized_clipboard_type(value):
    return clean_text(value).split(";", 1)[0].strip().lower()


def ui_image_extension_for_clipboard_type(value):
    mime = ui_normalized_clipboard_type(value)
    return {
        "image/png": "png",
        "image/jpeg": "jpg",
        "image/jpg": "jpg",
        "image/pjpeg": "jpg",
        "image/webp": "webp",
        "image/gif": "gif",
        "image/bmp": "bmp",
        "image/x-bmp": "bmp",
        "image/x-ms-bmp": "bmp",
        "image/svg+xml": "svg",
        "image/tiff": "tiff",
        "image/tif": "tiff",
        "image/avif": "avif",
        "image/heic": "heic",
        "image/heif": "heif",
        "image/vnd.microsoft.icon": "ico",
        "image/x-icon": "ico",
    }.get(mime)


def ui_preferred_clipboard_image_type(available):
    preferred = [
        "image/png",
        "image/jpeg",
        "image/webp",
        "image/gif",
        "image/bmp",
        "image/svg+xml",
        "image/tiff",
        "image/avif",
        "image/heic",
        "image/heif",
        "image/vnd.microsoft.icon",
        "image/x-icon",
    ]
    for mime in preferred:
        for candidate in available:
            if ui_normalized_clipboard_type(candidate) == mime:
                extension = ui_image_extension_for_clipboard_type(candidate)
                if extension:
                    return candidate, extension
    for candidate in available:
        extension = ui_image_extension_for_clipboard_type(candidate)
        if extension:
            return candidate, extension
    return None, None


def ui_store_clipboard_image_bytes(session_id, extension, data, source):
    if not data:
        raise RuntimeError(f"{source} clipboard image was empty")
    if len(data) > CLIPBOARD_MAX_BYTES:
        raise RuntimeError(
            f"{source} clipboard image exceeds the {CLIPBOARD_MAX_BYTES // (1024 * 1024)} MB limit"
        )
    directory = artifact_session_dir(session_id)
    ui_assert_artifact_capacity(directory, len(data), 0)
    destination = ui_unique_artifact_destination(
        directory,
        f"clipboard-{time.time_ns()}.{extension}",
    )
    temporary = f"{destination}.tmp-{os.getpid()}-{uuid.uuid4().hex}"
    try:
        with open(temporary, "xb") as handle:
            chmod_best_effort(temporary, PRIVATE_FILE_MODE)
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
        chmod_best_effort(destination, PRIVATE_FILE_MODE)
    finally:
        try:
            if os.path.exists(temporary):
                os.unlink(temporary)
        except OSError:
            pass
    return ui_artifact_value(destination)


def ui_clipboard_line_to_path(line):
    trimmed = clean_text(line)
    if (
        not trimmed
        or trimmed.startswith("#")
        or trimmed.lower() in {"copy", "cut"}
    ):
        return ""
    if trimmed.startswith("file://"):
        raw_uri = trimmed[len("file://") :]
        if raw_uri.startswith("localhost"):
            raw_uri = raw_uri[len("localhost") :]
        decoded = urllib.parse.unquote(raw_uri)
        if os.path.isabs(decoded):
            return decoded
    expanded = os.path.abspath(os.path.expanduser(trimmed))
    if os.path.isabs(expanded):
        return expanded
    return ""


def ui_clipboard_reference_paths(text):
    paths = []
    seen = set()
    for line in str(text or "").splitlines():
        path = ui_clipboard_line_to_path(line)
        if not path or path in seen or not os.path.isfile(path):
            continue
        seen.add(path)
        paths.append(path)
        if len(paths) >= 100:
            break
    return paths


def ui_run_clipboard_command(command, timeout=3, max_output=CLIPBOARD_MAX_BYTES):
    """Capture clipboard helpers through disk-backed files with a hard cap."""
    with tempfile.TemporaryFile() as stdout_handle, tempfile.TemporaryFile() as stderr_handle:
        process = subprocess.Popen(
            command,
            stdout=stdout_handle,
            stderr=stderr_handle,
        )
        deadline = time.monotonic() + timeout
        exceeded = False
        while process.poll() is None:
            output_size = os.fstat(stdout_handle.fileno()).st_size
            error_size = os.fstat(stderr_handle.fileno()).st_size
            if output_size > max_output or error_size > 1024 * 1024:
                exceeded = True
                process.kill()
                break
            if time.monotonic() >= deadline:
                process.kill()
                process.wait()
                raise subprocess.TimeoutExpired(command, timeout)
            time.sleep(0.02)
        process.wait()
        output_size = os.fstat(stdout_handle.fileno()).st_size
        if exceeded or output_size > max_output:
            return subprocess.CompletedProcess(
                command,
                1,
                b"",
                f"clipboard data exceeds the {max_output // (1024 * 1024)} MB limit".encode(),
            )
        stdout_handle.seek(0)
        stderr_handle.seek(0)
        return subprocess.CompletedProcess(
            command,
            process.returncode,
            stdout_handle.read(max_output + 1),
            stderr_handle.read(1024 * 1024 + 1),
        )


def ui_paste_clipboard_artifacts_wayland(session_id):
    if not shutil.which("wl-paste"):
        raise RuntimeError("wl-paste is not available")
    types = ui_run_clipboard_command(["wl-paste", "--list-types"])
    if types.returncode != 0:
        detail = clean_text(types.stderr.decode("utf-8", errors="replace"))
        raise RuntimeError(
            f"could not inspect the Wayland clipboard: {detail}"
            if detail
            else "could not inspect the Wayland clipboard"
        )
    available = [
        clean_text(line)
        for line in types.stdout.decode("utf-8", errors="replace").splitlines()
        if clean_text(line)
    ]
    mime, extension = ui_preferred_clipboard_image_type(available)
    if mime and extension:
        image = ui_run_clipboard_command(["wl-paste", "--type", mime])
        if image.returncode == 0 and image.stdout:
            return [
                ui_store_clipboard_image_bytes(
                    session_id,
                    extension,
                    image.stdout,
                    "Wayland",
                )
            ]

    for mime in ["x-special/gnome-copied-files", "text/uri-list", "text/plain"]:
        if not any(ui_normalized_clipboard_type(candidate) == mime for candidate in available):
            continue
        references = ui_run_clipboard_command(["wl-paste", "--type", mime])
        if references.returncode != 0:
            continue
        paths = ui_clipboard_reference_paths(
            references.stdout.decode("utf-8", errors="replace")
        )
        if paths:
            return ui_store_artifacts_payload(session_id, paths)
    raise RuntimeError("the Wayland clipboard does not contain supported files")


def ui_paste_clipboard_artifacts_xclip(session_id):
    if not shutil.which("xclip"):
        raise RuntimeError("xclip is not available")
    types = ui_run_clipboard_command(
        ["xclip", "-selection", "clipboard", "-t", "TARGETS", "-o"]
    )
    if types.returncode != 0:
        detail = clean_text(types.stderr.decode("utf-8", errors="replace"))
        raise RuntimeError(
            f"could not inspect the X11 clipboard with xclip: {detail}"
            if detail
            else "could not inspect the X11 clipboard with xclip"
        )
    available = [
        clean_text(line)
        for line in types.stdout.decode("utf-8", errors="replace").splitlines()
        if clean_text(line)
    ]
    mime, extension = ui_preferred_clipboard_image_type(available)
    if mime and extension:
        image = ui_run_clipboard_command(
            ["xclip", "-selection", "clipboard", "-t", mime, "-o"]
        )
        if image.returncode == 0 and image.stdout:
            return [
                ui_store_clipboard_image_bytes(
                    session_id,
                    extension,
                    image.stdout,
                    "X11",
                )
            ]

    for mime in ["x-special/gnome-copied-files", "text/uri-list", "text/plain"]:
        if not any(ui_normalized_clipboard_type(candidate) == mime for candidate in available):
            continue
        references = ui_run_clipboard_command(
            ["xclip", "-selection", "clipboard", "-t", mime, "-o"]
        )
        if references.returncode != 0:
            continue
        paths = ui_clipboard_reference_paths(
            references.stdout.decode("utf-8", errors="replace")
        )
        if paths:
            return ui_store_artifacts_payload(session_id, paths)
    raise RuntimeError("the X11 clipboard does not contain supported files")


def ui_paste_clipboard_artifacts_payload(session_id):
    session_id = clean_text(session_id)
    if not session_id:
        raise RuntimeError("missing session id")
    errors = []
    for reader in (ui_paste_clipboard_artifacts_wayland, ui_paste_clipboard_artifacts_xclip):
        try:
            artifacts = reader(session_id)
            if artifacts:
                return artifacts
        except Exception as error:
            errors.append(clean_text(error))
    raise RuntimeError(
        "the clipboard does not contain supported files"
        + (f" ({'; '.join(errors)})" if errors else "")
    )


DEFAULT_PROJECTS_HOME = os.path.expanduser("~/Projects")


def projects_home_path(config=None):
    """Where this user's own projects live.

    AWBN has always built its OWN folders on first run, but never suggested a
    home for the user's work, so a fresh install opened with an empty Projects
    list and nowhere obvious to put anything (reported: "shouldn't it ask if it
    wants to create a project folder for their projects?"). This is only a
    suggestion: nothing is created until the owner says yes, and an existing
    choice is always honoured.
    """
    if config is None:
        config = load_json(CONFIG_FILE, {}) or {}
    chosen = clean_text((config or {}).get("projects_home"))
    return os.path.abspath(os.path.expanduser(chosen)) if chosen else DEFAULT_PROJECTS_HOME


def create_projects_home(path=""):
    """Make the folder and remember it. Returns (path, created)."""
    target = os.path.abspath(os.path.expanduser(clean_text(path))) if clean_text(path) else DEFAULT_PROJECTS_HOME
    if os.path.exists(target) and not os.path.isdir(target):
        raise RuntimeError(f"{target} exists and is not a folder.")
    created = not os.path.isdir(target)
    os.makedirs(target, exist_ok=True)
    with locked_config():
        config = load_json(CONFIG_FILE, {}) or {}
        if not isinstance(config, dict):
            config = {}
        config["projects_home"] = target
        save_json(CONFIG_FILE, config)
    return target, created


def ui_app_state_payload():
    config = load_json(CONFIG_FILE, {}) or {}
    return {
        "active_agent": config.get("active_agent"),
        "active_workspace_index": config.get("active_workspace_index", 0),
        "agent_settings": config.get("agent_settings") or {},
        "agent_options": ui_agent_options_payload(config),
        # Direct by DEFAULT. Smart mode injected a policy telling the agent to
        # hand work to Haiku and Sonnet at low effort, and shipped worker
        # profiles pinned to them. Measured by the community: subagent-heavy
        # runs burn around 7x the tokens of a single thread, and they are not
        # automatically cheaper, because each one rebuilds context, re-explores
        # and reports back before the main model even reads it. Nothing on
        # screen said which model answered, so the cost was paid in both money
        # and quality, invisibly. Smart stays available; it is no longer the
        # thing that happens to you by default.
        "claude_orchestration": config.get("claude_orchestration") or {"mode": "direct"},
        "codex_sandbox": config.get("codex_sandbox") or "workspace-write",
        "custom_clients": config.get("custom_clients") or [],
        "cwd": config.get("cwd") or os.path.expanduser("~"),
        "display_preferences": config.get("display_preferences") or {},
        "projects_home": projects_home_path(config),
        "projects_home_exists": os.path.isdir(projects_home_path(config)),
        "handoff_preferences": config.get("handoff_preferences") or {},
        "memory_preferences": config.get("memory_preferences") or {},
        "onboarding_version": clamp_int(
            config.get("onboarding_version"), 0, 0, CURRENT_ONBOARDING_VERSION
        ),
        # How many times setup has been put off with "Remind me later"
        # (v4.7.1). Setup returns on the next fresh open until this reaches
        # ONBOARDING_MAX_DEFERRALS, so someone who dismissed it by accident
        # gets it back, and someone who means it is left alone.
        "onboarding_deferrals": clamp_int(
            config.get("onboarding_deferrals"), 0, 0, ONBOARDING_MAX_DEFERRALS
        ),
        "recent_projects": config.get("recent_projects") or [os.path.expanduser("~")],
        "session_order": config.get("session_order") or {},
        "split_view_enabled": config.get("split_view_enabled") is True,
        "split_left_session_id": clean_text(config.get("split_left_session_id")),
        "split_right_session_id": clean_text(config.get("split_right_session_id")),
        "workspace_tabs": config.get("workspace_tabs") or [],
    }


def ui_complete_onboarding_payload():
    with locked_config():
        config = load_json(CONFIG_FILE, {}) or {}
        if not isinstance(config, dict):
            config = {}
        config["onboarding_version"] = CURRENT_ONBOARDING_VERSION
        save_json(CONFIG_FILE, config)
    return ui_app_state_payload()


def ui_defer_onboarding_payload():
    """Put setup off without marking it done."""
    with locked_config():
        config = load_json(CONFIG_FILE, {}) or {}
        if not isinstance(config, dict):
            config = {}
        current = clamp_int(config.get("onboarding_deferrals"), 0, 0, ONBOARDING_MAX_DEFERRALS)
        config["onboarding_deferrals"] = min(current + 1, ONBOARDING_MAX_DEFERRALS)
        save_json(CONFIG_FILE, config)
    return ui_app_state_payload()


def ui_save_app_preferences_payload(request):
    with locked_config():
        config = load_json(CONFIG_FILE, {}) or {}
        if not isinstance(config, dict):
            config = {}
        for key in (
            "claude_orchestration",
            "display_preferences",
            "handoff_preferences",
            "memory_preferences",
        ):
            value = request.get(key)
            if isinstance(value, dict):
                config[key] = value
        if "custom_clients" in request:
            config["custom_clients"] = ui_normalize_custom_clients(
                request.get("custom_clients")
            )
        if "codex_sandbox" in request:
            mode = clean_text(request.get("codex_sandbox")).lower()
            if mode in CODEX_SANDBOX_MODES:
                config["codex_sandbox"] = mode
        save_json(CONFIG_FILE, config)
    return ui_app_state_payload()


def ui_save_workspace_state_payload(request):
    with locked_config():
        config = load_json(CONFIG_FILE, {}) or {}
        if not isinstance(config, dict):
            config = {}
        tabs = ui_normalize_workspace_tabs(request.get("tabs"))
        previous_tabs = (
            config.get("workspace_tabs")
            if isinstance(config.get("workspace_tabs"), list)
            else []
        )
        preserving_previous_tabs = False
        if not tabs and previous_tabs and request.get("clear_tabs") is not True:
            tabs = previous_tabs
            preserving_previous_tabs = True
        active_index = safe_int(
            config.get("active_workspace_index")
            if preserving_previous_tabs
            else request.get("active_index"),
            0,
        )
        if tabs:
            active_index = max(0, min(active_index, len(tabs) - 1))
        else:
            active_index = 0
        config["workspace_tabs"] = tabs
        config["active_workspace_index"] = active_index
        tab_ids = {
            clean_text(tab.get("session_id"))
            for tab in tabs
            if isinstance(tab, dict) and clean_text(tab.get("session_id"))
        }
        split_left = clean_text(request.get("split_left_session_id"))
        split_right = clean_text(request.get("split_right_session_id"))
        split_enabled = (
            request.get("split_view_enabled") is True
            and split_left
            and split_right
            and split_left != split_right
            and split_left in tab_ids
            and split_right in tab_ids
        )
        config["split_view_enabled"] = split_enabled
        config["split_left_session_id"] = split_left if split_enabled else ""
        config["split_right_session_id"] = split_right if split_enabled else ""
        session_order = request.get("session_order")
        if isinstance(session_order, dict):
            config["session_order"] = {
                clean_text(key): [
                    clean_text(value)
                    for value in values
                    if clean_text(value)
                ][:500]
                for key, values in session_order.items()
                if clean_text(key) and isinstance(values, list)
            }
        save_json(CONFIG_FILE, config)
    return ui_app_state_payload()


def safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def safe_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def ui_normalize_workspace_tabs(raw_tabs):
    tabs = raw_tabs if isinstance(raw_tabs, list) else []
    normalized = []
    for raw in tabs[:24]:
        if not isinstance(raw, dict):
            continue
        session_id = clean_text(raw.get("session_id"))
        title = clean_text(raw.get("title"))[:120]
        agent = clean_text(raw.get("agent"))[:64]
        cwd = clean_text(raw.get("cwd"))[:2000]
        model = clean_text(raw.get("model"))[:160]
        effort = clean_text(raw.get("effort"))[:80]
        if not (session_id or title or cwd):
            continue
        tab = {
            "title": title,
            "agent": agent,
            "cwd": cwd,
            "model": model,
            "effort": effort,
            "session_id": session_id,
            "input_text": clean_text(raw.get("input_text"))[:20000],
            "attachment_paths": [
                clean_text(path)
                for path in (raw.get("attachment_paths") if isinstance(raw.get("attachment_paths"), list) else [])
                if clean_text(path)
            ][:50],
            "queued_prompts": ui_normalize_queued_prompts(raw.get("queued_prompts")),
        }
        normalized.append(tab)
    return normalized


def ui_normalize_queued_prompts(raw_prompts):
    prompts = raw_prompts if isinstance(raw_prompts, list) else []
    normalized = []
    for raw in prompts[:25]:
        if not isinstance(raw, dict):
            continue
        prompt = clean_text(raw.get("prompt"))[:20000]
        attachments = [
            clean_text(path)
            for path in (raw.get("attachments") if isinstance(raw.get("attachments"), list) else [])
            if clean_text(path)
        ][:50]
        if prompt or attachments:
            normalized.append({"prompt": prompt, "attachments": attachments})
    return normalized


def ui_slug(value):
    text = clean_text(value).lower()
    text = re.sub(r"[^a-z0-9_-]+", "-", text).strip("-_")
    return re.sub(r"-{2,}", "-", text)


def ui_normalize_custom_clients(raw_clients):
    clients = raw_clients if isinstance(raw_clients, list) else []
    normalized = []
    seen = set()
    reserved = {"claude", "codex", "gemini", "ollama", "local", "all"}
    for index, raw in enumerate(clients[:24]):
        if not isinstance(raw, dict):
            continue
        label = re.sub(r"\s+", " ", clean_text(raw.get("label")) or "Custom CLI")
        if len(label) > 64:
            raise RuntimeError("Custom client labels must be 64 characters or fewer")
        key = ui_slug(raw.get("key")) or ui_slug(label) or f"custom-{index + 1}"
        if not key.startswith("custom-"):
            key = f"custom-{key}"
        if key in reserved:
            raise RuntimeError(f"Custom client key is reserved: {key}")
        if key in seen:
            raise RuntimeError(f"Duplicate custom client key: {key}")
        command = clean_text(raw.get("command"))
        if not command:
            raise RuntimeError(f"Custom client '{label}' needs a command")
        if len(command) > 2000:
            raise RuntimeError(f"Custom client '{label}' command is too long")
        try:
            tokens = shlex.split(command)
        except ValueError as error:
            raise RuntimeError(f"Custom client '{label}' command is invalid: {error}") from error
        if not tokens:
            raise RuntimeError(f"Custom client '{label}' command is empty")
        if Path(tokens[0]).name in {"sudo", "su", "pkexec"}:
            raise RuntimeError(f"Custom client '{label}' cannot start with {tokens[0]}")

        client = dict(raw)
        client["key"] = key
        client["label"] = label
        client["command"] = command
        model = clean_text(raw.get("model"))
        if model:
            if len(model) > 120:
                raise RuntimeError(f"Custom client '{label}' model is too long")
            client["model"] = model
        else:
            client.pop("model", None)
        client["persistent"] = bool(raw.get("persistent"))
        for field, default, minimum, maximum in (
            ("idle_timeout_seconds", 4.0, 0.5, 120.0),
            ("first_byte_timeout_seconds", 90.0, 5.0, 600.0),
            ("response_timeout_seconds", 300.0, 30.0, 3600.0),
        ):
            raw_value = raw.get(field)
            if field not in raw or raw_value is None or raw_value == "":
                client.pop(field, None)
                continue
            try:
                value = float(raw_value)
            except (TypeError, ValueError):
                value = default
            client[field] = max(minimum, min(maximum, value))
        seen.add(key)
        normalized.append(client)
    return normalized


def ui_sanitize_key_label(value, fallback=""):
    text = re.sub(r"\s+", " ", clean_text(value))
    if len(text) > 80:
        raise RuntimeError("Key labels must be 80 characters or fewer")
    return text or fallback


def ui_sanitize_key_value(value):
    raw = value if isinstance(value, str) else str(value or "")
    if "\n" in raw or "\r" in raw:
        raise RuntimeError("Key values must be single-line values")
    text = raw.replace("\x00", "").strip()
    if not text:
        raise RuntimeError("Key value is required")
    if len(text) > 20_000:
        raise RuntimeError("Key value is too large")
    return text


def ui_parse_keys_markdown(text):
    entries = []
    service = "Other"
    for line in str(text or "").splitlines():
        stripped = line.strip()
        if stripped.startswith("## "):
            service = ui_sanitize_key_label(stripped[3:], "Other")
            continue
        if not stripped.startswith("- ") or ":" not in stripped:
            continue
        name, value = stripped[2:].split(":", 1)
        name = ui_sanitize_key_label(name, "")
        value = value.strip()
        if name and value:
            entries.append({"service": service, "name": name, "value": value})
    return entries


def ui_normalize_key_entries(raw):
    entries = []
    source = raw if isinstance(raw, list) else []
    for item in source:
        if not isinstance(item, dict):
            continue
        service = ui_sanitize_key_label(item.get("service"), "Other")
        name = ui_sanitize_key_label(item.get("name"), "")
        value = clean_text(item.get("value"))
        if name and value:
            entries.append({"service": service, "name": name, "value": value})
    entries.sort(key=lambda item: (item["service"].lower(), item["name"].lower()))
    return entries


def ui_read_keys_entries():
    payload = load_json(KEYS_STORE_FILE, None)
    if isinstance(payload, dict):
        return ui_normalize_key_entries(payload.get("keys"))
    if isinstance(payload, list):
        return ui_normalize_key_entries(payload)
    entries = []
    # One-way compatibility import for older installs.  New writes stay in
    # the private 0700 app directory instead of duplicating secrets at ~/.
    imported_path = ""
    for legacy_path in (KEYS_EXPORT_FILE, LEGACY_KEYS_EXPORT_FILE):
        try:
            with open(legacy_path, encoding="utf-8") as handle:
                entries = ui_parse_keys_markdown(handle.read())
        except OSError:
            continue
        if entries:
            imported_path = legacy_path
            break
    if entries:
        ui_write_keys_entries(entries)
        # Older builds left a plaintext duplicate at ~/keys_list.md. Move it
        # into the private app directory after a verified import instead of
        # silently deleting the user's only recoverable copy.
        if imported_path == LEGACY_KEYS_EXPORT_FILE:
            migrated = os.path.join(CONFIG_DIR, "legacy-keys_list.migrated.md")
            try:
                if not os.path.exists(migrated):
                    os.replace(LEGACY_KEYS_EXPORT_FILE, migrated)
                    chmod_best_effort(migrated, PRIVATE_FILE_MODE)
            except OSError:
                pass
    return entries


def ui_serialize_keys_markdown(entries):
    groups = {}
    for entry in entries:
        groups.setdefault(entry["service"], []).append(entry)
    lines = [
        "# Keys List",
        "",
        "<!-- Exported by Agent Workbench Native from ~/.config/agent-workbench-native/keys.json.",
        "     Local only. File permissions are set to user-read/write. -->",
    ]
    for service in sorted(groups, key=lambda value: value.lower()):
        lines.extend(["", f"## {service}"])
        for entry in sorted(groups[service], key=lambda item: item["name"].lower()):
            lines.append(f"- {entry['name']}: {entry['value']}")
    return "\n".join(lines) + "\n"


def ui_write_keys_entries(entries):
    entries = ui_normalize_key_entries(entries)
    save_json(KEYS_STORE_FILE, {"schema": 1, "keys": entries})
    ensure_private_parent(KEYS_EXPORT_FILE)
    temporary = f"{KEYS_EXPORT_FILE}.tmp-{os.getpid()}-{threading.get_ident()}-{uuid.uuid4()}"
    with open(temporary, "w", encoding="utf-8") as handle:
        handle.write(ui_serialize_keys_markdown(entries))
        handle.flush()
        os.fsync(handle.fileno())
    chmod_best_effort(temporary, PRIVATE_FILE_MODE)
    os.replace(temporary, KEYS_EXPORT_FILE)
    chmod_best_effort(KEYS_EXPORT_FILE, PRIVATE_FILE_MODE)


def ui_keys_payload():
    return {
        "path": KEYS_EXPORT_FILE,
        "store_path": KEYS_STORE_FILE,
        "keys": ui_read_keys_entries(),
    }


def ui_add_key_payload(request):
    service = ui_sanitize_key_label(request.get("service"), "Other")
    name = ui_sanitize_key_label(request.get("name"), "")
    value = ui_sanitize_key_value(request.get("value"))
    entries = ui_read_keys_entries()
    if not name:
        base = f"{service.upper().replace(' ', '_')}_KEY"
        name = base
        index = 2
        while any(
            entry["service"].lower() == service.lower() and entry["name"] == name
            for entry in entries
        ):
            name = f"{base}_{index}"
            index += 1
    replaced = False
    for entry in entries:
        if entry["service"].lower() == service.lower() and entry["name"] == name:
            entry["value"] = value
            replaced = True
            break
    if not replaced:
        entries.append({"service": service, "name": name, "value": value})
    ui_write_keys_entries(entries)
    return ui_keys_payload()


def ui_delete_key_payload(request):
    service = ui_sanitize_key_label(request.get("service"), "Other")
    name = ui_sanitize_key_label(request.get("name"), "")
    entries = ui_read_keys_entries()
    filtered = [
        entry
        for entry in entries
        if not (entry["service"].lower() == service.lower() and entry["name"] == name)
    ]
    if len(filtered) == len(entries):
        raise RuntimeError("Key not found")
    ui_write_keys_entries(filtered)
    return ui_keys_payload()


def ui_sanitize_env_key_name(value):
    name = clean_text(value).strip()
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", name):
        raise RuntimeError("Environment variable names must look like OPENAI_API_KEY")
    if len(name) > 120:
        raise RuntimeError("Environment variable name is too long")
    return name


def ui_env_quote_value(value):
    text = ui_sanitize_key_value(value)
    if re.match(r"^[A-Za-z0-9_@%+=:,./-]+$", text):
        return text
    # POSIX shells cannot escape a quote with a backslash while already
    # inside single quotes. Close, emit a quoted literal quote, and reopen.
    return "'" + text.replace("'", "'\"'\"'") + "'"


def ui_find_key_entry(service, name):
    service = ui_sanitize_key_label(service, "Other")
    name = ui_sanitize_key_label(name, "")
    for entry in ui_read_keys_entries():
        if entry["service"].lower() == service.lower() and entry["name"] == name:
            return entry
    raise RuntimeError("Saved key not found")


def ui_resolve_env_target(path):
    raw = clean_text(path).strip()
    if not raw:
        raise RuntimeError("Target .env path is required")
    target = normalized_filesystem_path(raw)
    if os.path.isdir(target):
        target = os.path.join(target, ".env")
    basename = os.path.basename(target)
    if basename != ".env" and not basename.startswith(".env."):
        raise RuntimeError("Target must be a .env file")
    parent = os.path.dirname(target)
    if not os.path.isdir(parent):
        raise RuntimeError("Target .env directory does not exist")
    return target


def ui_write_env_value(target_path, env_name, value):
    target_path = ui_resolve_env_target(target_path)
    env_name = ui_sanitize_env_key_name(env_name)
    new_line = f"{env_name}={ui_env_quote_value(value)}"
    try:
        with open(target_path, encoding="utf-8") as handle:
            lines = handle.read().splitlines()
    except FileNotFoundError:
        lines = []
    except OSError as error:
        raise RuntimeError(f"Could not read target .env: {error}") from error

    action = "created"
    pattern = re.compile(rf"^\s*(?:export\s+)?{re.escape(env_name)}\s*=")
    next_lines = []
    replaced = False
    for line in lines:
        if not replaced and pattern.match(line) and not line.lstrip().startswith("#"):
            next_lines.append(new_line)
            replaced = True
            action = "updated"
        else:
            next_lines.append(line)
    if not replaced:
        if next_lines and next_lines[-1].strip():
            next_lines.append("")
        next_lines.append("# Added by Agent Workbench Native from a saved local key.")
        next_lines.append(new_line)

    text = "\n".join(next_lines) + "\n"
    temporary = f"{target_path}.tmp-{os.getpid()}-{threading.get_ident()}-{uuid.uuid4()}"
    try:
        with open(temporary, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        chmod_best_effort(temporary, PRIVATE_FILE_MODE)
        os.replace(temporary, target_path)
        chmod_best_effort(target_path, PRIVATE_FILE_MODE)
    except OSError as error:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise RuntimeError(f"Could not write target .env: {error}") from error
    return {"target_path": target_path, "env_name": env_name, "action": action}


def ui_write_key_to_env_payload(request):
    entry = ui_find_key_entry(request.get("service"), request.get("name"))
    env_name = ui_sanitize_env_key_name(request.get("env_name") or entry["name"])
    result = ui_write_env_value(request.get("target_path"), env_name, entry["value"])
    return {
        "service": entry["service"],
        "name": entry["name"],
        **result,
    }


def ui_project_state_payload(session_id="", cwd=""):
    session = {}
    session_id = clean_text(session_id)
    if session_id:
        try:
            session = load_session(session_id)
        except Exception:
            session = {"id": session_id, "cwd": clean_text(cwd)}
    fallback_cwd = clean_text(cwd) or clean_text(session.get("cwd"))
    root = infer_project_root(session, fallback_cwd)
    path = project_state_path(root)
    registry_path, registry = read_project_registry(root)
    prefs = memory_preferences()
    content = ""
    truncated = False
    if path and os.path.isfile(path):
        try:
            size = os.path.getsize(path)
            with open(path, encoding="utf-8", errors="replace") as handle:
                content = handle.read(120_000)
            truncated = size > len(content.encode("utf-8", errors="ignore"))
        except OSError:
            content = ""
    return {
        "root": root,
        "path": path,
        "registry_path": registry_path,
        "project_id": clean_text(registry.get("project_id")) if isinstance(registry, dict) else "",
        "display_name": clean_text(registry.get("display_name")) if isinstance(registry, dict) else "",
        "exists": bool(path and os.path.isfile(path)),
        "content": content,
        "truncated": truncated,
        "preferences": prefs,
    }


def ui_dedupe(values):
    result = []
    seen = set()
    for value in values:
        cleaned = clean_text(value)
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        result.append(cleaned)
    return result


def awbn_visible_ollama_model(model):
    name = clean_text(model).lower()
    return bool(name) and not any(
        name.startswith(prefix) for prefix in HIDDEN_AWBN_OLLAMA_MODEL_PREFIXES
    )


def visible_ollama_models():
    return [model for model in ollama_models() if awbn_visible_ollama_model(model)]


def ui_agent_settings(config, key):
    key = clean_text(key)
    defaults = dict(UI_DEFAULT_AGENT_SETTINGS.get(key) or {"model": "Default", "effort": "Default"})
    configured = (config.get("agent_settings") or {}).get(key) or {}
    if isinstance(configured, dict):
        defaults.update(
            {
                "model": clean_text(configured.get("model")) or defaults.get("model"),
                "effort": clean_text(configured.get("effort")) or defaults.get("effort"),
            }
        )
    # Empty/"Default" resolves to opus; "fable" is now a real selectable option
    # (Claude Fable 5) so it's no longer coerced away here.
    if key == "claude" and defaults.get("model") in {"", "Default"}:
        defaults["model"] = "opus"
    return defaults


def ui_agent_options_payload(config=None):
    """The agent/model options carried in /state.

    v4.3.3: this used to build its own list straight out of the hardcoded
    UI_MODEL_OPTIONS table, and left Gemini out entirely. That made two lists
    in one app — the Conversation screen showed the discovered models while
    the Projects screen and every fresh start showed the hand-typed ones, so
    gpt-5.6 was present in one place and missing in another. There is now one
    source: the discovery cache. Only the user's own saved default model and
    effort are layered on top, plus their custom clients."""
    config = config if isinstance(config, dict) else (load_json(CONFIG_FILE, {}) or {})
    # Read the cache, never build it. This payload backs /app-state, which is
    # the first call the app makes and blocks its launch on — building the
    # catalogs here cost 4.3 seconds on a cold bridge (measured 2026-07-30).
    # Until the startup warm-up lands, the hardcoded baseline stands in; the
    # app fetches /client/models moments later and merges the live list over
    # the top, and a baseline list is labelled as one on screen either way.
    try:
        cached = peek_model_discovery_agents() or []
        discovered = {clean_text(agent.get("key")): agent for agent in cached}
    except Exception:  # noqa: BLE001 - /state must render even if a CLI can't be read
        discovered = {}
    options = []
    for key in SELECTABLE_FIXED_AGENTS:
        settings = ui_agent_settings(config, key)
        agent = discovered.get(key) or {}
        models = list(agent.get("models") or UI_MODEL_OPTIONS.get(key) or ["Default"])
        efforts = ui_dedupe(
            [
                *(agent.get("efforts") or UI_EFFORT_OPTIONS.get(key) or ["Default"]),
                settings.get("effort"),
            ]
        )
        default_model = clean_text(settings.get("model"))
        if default_model not in models:
            default_model = clean_text(agent.get("default_model")) or models[0]
        options.append(
            {
                "key": key,
                "label": UI_AGENT_LABELS.get(key, key.title()),
                "agent": key,
                "models": models,
                "all_models": list(agent.get("all_models") or models),
                "model_labels": dict(agent.get("model_labels") or {}),
                "efforts": efforts,
                "efforts_by_model": dict(agent.get("efforts_by_model") or {}),
                "connected": bool(installed_cli_path(key)),
                "local": False,
                "default_model": default_model,
                "default_effort": settings.get("effort") or "Default",
                "model_source": agent.get("model_source") or "static",
                "effort_source": agent.get("effort_source") or "static",
                "static": agent.get("static", True),
            }
        )
    installed_ollama = visible_ollama_models()
    ollama_models = installed_ollama or ["Default"]
    options.append(
        {
            "key": "ollama",
            "label": "Ollama",
            "agent": "local",
            "models": ollama_models,
            "all_models": ollama_models,
            "model_labels": {},
            "efforts": ["Default"],
            "efforts_by_model": {},
            "connected": bool(installed_cli_path("ollama") or installed_ollama),
            "local": True,
            "default_model": ollama_models[0],
            "default_effort": "Default",
            "model_source": "dynamic" if installed_ollama else "static",
            "effort_source": "static",
            "static": not bool(installed_ollama),
        }
    )
    for client in config.get("custom_clients") or []:
        if not isinstance(client, dict):
            continue
        label = clean_text(client.get("label")) or "Custom CLI"
        if label in installed_ollama:
            continue
        key = clean_text(client.get("key")) or f"custom-{label}"
        models = ui_dedupe([client.get("model"), label])
        options.append(
            {
                "key": key,
                "label": label,
                "agent": "local",
                "models": models or [label],
                "all_models": models or [label],
                "model_labels": {},
                "efforts": ["Default"],
                "efforts_by_model": {},
                "connected": custom_client_command_available(client.get("command")),
                "local": True,
                "default_model": (models or [label])[0],
                "default_effort": "Default",
                "model_source": "dynamic",
                "effort_source": "static",
                "static": False,
            }
        )
    return options


def normalize_ui_agent_key(agent):
    value = clean_text(agent).lower()
    if value in {"local", "ollama"}:
        return "ollama"
    if value in {"claude", "codex", "gemini", "hermes"}:
        return value
    config = load_json(CONFIG_FILE, {}) or {}
    for client in config.get("custom_clients") or []:
        if not isinstance(client, dict):
            continue
        if value and value == clean_text(client.get("key")).lower():
            return clean_text(client.get("key"))
    return value or "claude"


def ui_agent_launchability_error(agent):
    agent = normalize_ui_agent_key(agent)
    if agent in SELECTABLE_FIXED_AGENTS:
        return "" if installed_cli_path(agent) else f"{UI_AGENT_LABELS.get(agent, agent)} is not installed"
    if agent == "ollama":
        return "" if installed_cli_path("ollama") or visible_ollama_models() else "Ollama is not installed or running"
    config = load_json(CONFIG_FILE, {}) or {}
    for client in config.get("custom_clients") or []:
        if not isinstance(client, dict):
            continue
        if clean_text(client.get("key")).lower() != agent:
            continue
        return "" if custom_client_command_available(client.get("command")) else (
            f"Custom client {clean_text(client.get('label')) or agent} is not installed"
        )
    return f"Unknown client: {agent}"


def ui_create_session(
    agent,
    model,
    effort,
    cwd,
    title,
    *,
    free_chat=False,
    validate_client=False,
):
    agent = normalize_ui_agent_key(agent)
    if validate_client:
        launch_error = ui_agent_launchability_error(agent)
        if launch_error:
            raise RuntimeError(launch_error)
    if free_chat:
        ensure_private_dir(FREE_CHAT_WORKSPACE_DIR)
        cwd_path = os.path.abspath(FREE_CHAT_WORKSPACE_DIR)
    else:
        cwd_path = os.path.abspath(os.path.expanduser(clean_text(cwd) or os.path.expanduser("~")))
    if not os.path.isdir(cwd_path):
        raise RuntimeError(f"project directory does not exist: {cwd_path}")
    project_root = find_project_root(cwd_path)
    timestamp = now_iso()
    fallback_title = {
        "claude": "New claude session",
        "codex": "New codex session",
        "gemini": "New gemini session",
        "hermes": "New hermes session",
        "ollama": "New local session",
    }.get(agent, "New local session")
    settings = ui_agent_settings(load_json(CONFIG_FILE, {}) or {}, agent)
    model = clean_text(model) or clean_text(settings.get("model")) or "Default"
    effort = clean_text(effort) or clean_text(settings.get("effort")) or "Default"
    backend = {"model": model}
    if effort and effort != "Default" and agent != "gemini":
        backend["effort"] = effort
    session = {
        "id": str(uuid.uuid4()),
        "title": clean_text(title) or fallback_title,
        "agent": agent,
        "backend": backend,
        "cwd": cwd_path,
        "project_root": project_root,
        "origin": "local",
        "created_at": timestamp,
        "updated_at": timestamp,
        "user_created": True,
        "turns": [],
    }
    save_session(session)
    return session


def ui_update_session(session_id, title=None, model=None, effort=None):
    session_id = clean_text(session_id)
    if not session_id:
        raise RuntimeError("missing session id")
    with locked_sessions(session_id):
        session = load_session(session_id)
        native_updated = False
        new_title = clean_text(title)
        if new_title:
            session["title"] = new_title
            session["user_renamed"] = True
            native_updated = sync_native_title_from_session(session)
        backend = session.setdefault("backend", {})
        if model is not None:
            cleaned_model = clean_text(model)
            if cleaned_model:
                backend["model"] = cleaned_model
        if effort is not None:
            cleaned_effort = clean_text(effort) or "Default"
            if clean_text(session.get("agent")) == "gemini" or cleaned_effort == "Default":
                backend.pop("effort", None)
            else:
                backend["effort"] = cleaned_effort
        session["updated_at"] = now_iso()
        save_session(session)
    return session, native_updated


def record_deleted_session(session):
    agent = clean_text(session.get("agent")) or "local"
    native_id = native_session_id(session)
    source_path = clean_text(session.get("source_path"))
    session_id = clean_text(session.get("id"))
    with locked_config():
        config = load_json(CONFIG_FILE, {}) or {}
        if not isinstance(config, dict):
            config = {}
        tombstones = config.get("deleted_session_tombstones")
        if not isinstance(tombstones, dict):
            tombstones = {}
        bucket = tombstones.get(agent)
        if not isinstance(bucket, dict):
            bucket = {"ids": [], "paths": []}
        ids = bucket.get("ids") if isinstance(bucket.get("ids"), list) else []
        paths = bucket.get("paths") if isinstance(bucket.get("paths"), list) else []
        for value in (native_id, session_id):
            if value and value not in ids:
                ids.append(value)
        if source_path and source_path not in paths:
            paths.append(source_path)
        bucket["ids"] = ids
        bucket["paths"] = paths
        tombstones[agent] = bucket
        config["deleted_session_tombstones"] = tombstones
        save_json(CONFIG_FILE, config)


def ui_delete_session(session_id):
    session_id = clean_text(session_id)
    if not session_id:
        raise RuntimeError("missing session id")
    with locked_sessions(session_id):
        session = load_session(session_id)
        worker_blocker = worker_session_delete_blocker(session)
        if worker_blocker:
            raise RuntimeError(worker_blocker)
        # Refuse rather than interrupt: deleting a conversation while its turn
        # is finalizing can erase output and race a late durable save.
        with ACTIVE_LOCK:
            if session_id in ACTIVE_TURNS:
                raise RuntimeError(
                    "cannot delete a conversation while its turn is active; "
                    "stop the turn and wait for it to finish first"
                )
            # Block a new turn claim for the remainder of this transaction.
            with DELETED_SESSION_IDS_LOCK:
                DELETED_SESSION_IDS.add(session_id)
        session_file_removed = False
        try:
            close_claude_stream_session(session_id)
            forget_persistent_custom_cli_session(session_id)
            close_ui_terminal_session(session_id)
            worktree_error = remove_session_worktree(session)
            if worktree_error:
                append_debug_event(
                    "worktree_remove_failed",
                    session=session_id,
                    error=worktree_error,
                )
                raise RuntimeError(worktree_error)
            record_deleted_session(session)
            try:
                remove_project_session_records(session)
            except Exception as error:
                append_debug_event(
                    "project_record_remove_failed",
                    session=session_id,
                    error=clean_text(error)[:500],
                )
            path = session_path(session_id)
            if os.path.exists(path):
                os.remove(path)
            session_file_removed = not os.path.exists(path)
            try:
                remove_worker_metadata_for_deleted_session(session)
            except Exception as error:
                # The conversation is already gone at this point. Keep the
                # deletion tombstone authoritative and reconcile stale worker
                # metadata later rather than allowing a late save to recreate it.
                append_debug_event(
                    "worker_metadata_remove_failed",
                    session=session_id,
                    error=clean_text(error)[:500],
                )
            # Attachments and generated artifacts are AWBN-owned copies.
            artifact_dir = raw_artifact_session_dir(session_id)
            if os.path.islink(artifact_dir):
                os.remove(artifact_dir)
            elif os.path.isdir(artifact_dir):
                shutil.rmtree(artifact_dir)
            # Removing the sidecar while holding its flock is safe: the lock
            # remains on the inode until locked_sessions exits.
            try:
                os.remove(session_lock_path(session_id))
            except OSError:
                pass
        except Exception:
            # Before the session record is removed, a refused/failed delete
            # leaves it usable. Afterwards the marker must remain so a stale
            # in-memory copy can never recreate a partially deleted session.
            if not session_file_removed:
                with DELETED_SESSION_IDS_LOCK:
                    DELETED_SESSION_IDS.discard(session_id)
            raise
    return {
        "native_deleted": False,
        "native_error": "",
        "tombstone_error": "",
    }


def detach_session_for_turn(session):
    if not session_uses_external_native_history(session):
        return session, None
    session = refresh_session_from_native_transcript(session)
    native_id = native_session_id(session)
    detached_at = now_iso()
    if clean_text(session.get("origin")).endswith("-terminal"):
        detached = deepcopy(session)
        previous_session_id = clean_text(session.get("id"))
        detached["id"] = str(uuid.uuid4())
        detached["origin"] = "local"
        detached["created_at"] = detached_at
        detached["updated_at"] = detached_at
        detached["native_thread_owned"] = False
        detached["detached_from_session_id"] = previous_session_id
        detached["detached_from_native_id"] = native_id
        detached["detached_from_source_path"] = clean_text(session.get("source_path"))
        detached["detached_at"] = detached_at
        detached.pop("source_session_id", None)
        detached.pop("source_path", None)
        detached.pop("source_mtime_ns", None)
        detached["transcript_loaded"] = True
        backend = detached.setdefault("backend", {})
        backend.pop("session_id", None)
        backend.pop("thread_id", None)
        source_artifacts = raw_artifact_session_dir(previous_session_id)
        if os.path.isdir(source_artifacts):
            copy_missing_tree(source_artifacts, artifact_session_dir(detached["id"]))
        save_session(detached)
        return detached, {
            "action": "detached",
            "previous_session_id": previous_session_id,
            "message": "Detached imported native history into a local Agent Workbench continuation.",
        }
    session["native_thread_owned"] = False
    session["detached_from_native_id"] = native_id
    session["detached_from_source_path"] = clean_text(session.get("source_path"))
    session["detached_at"] = detached_at
    session.pop("source_session_id", None)
    session.pop("source_path", None)
    session.pop("source_mtime_ns", None)
    session["transcript_loaded"] = True
    backend = session.setdefault("backend", {})
    backend.pop("session_id", None)
    backend.pop("thread_id", None)
    session["updated_at"] = detached_at
    save_session(session)
    return session, {
        "action": "relinked",
        "previous_session_id": clean_text(session.get("id")),
        "message": "Detached this legacy-linked session from shared native history before continuing.",
    }


def deleted_native_refs():
    config = load_json(CONFIG_FILE, {}) or {}
    ids = set()
    paths = set()
    for bucket in (config.get("deleted_session_tombstones") or {}).values():
        if not isinstance(bucket, dict):
            continue
        ids.update(clean_text(value) for value in bucket.get("ids") or [] if clean_text(value))
        paths.update(
            os.path.abspath(os.path.expanduser(clean_text(value)))
            for value in bucket.get("paths") or []
            if clean_text(value)
        )
    return ids, paths


# v4.3.0 (beta prep): every /sessions and /projects call used to re-read and
# re-parse EVERY session file — 333 files here, ~0.6s a call, and the UI polls
# these. Cache per file, keyed on (mtime, size), so only genuinely changed
# sessions are re-read. Correctness is unchanged: a session that changes on
# disk always has a new mtime/size, and the cache self-prunes deleted files.
_SESSION_RECORD_CACHE = {}
# Only cache modest files. `turns` (the whole transcript) is read by the list
# payload, so entries can't be trimmed — but holding every huge chat in RAM
# would cost hundreds of MB.
_SESSION_CACHE_MAX_BYTES = 1_500_000
_SESSION_RECORD_CACHE_LOCK = threading.Lock()
# Summarising one session record is ~1ms; the list summarises 107 of them, so
# a rebuild cost 0.117s — and a rebuild happened every time ANY session file
# was written, which is once per message sent. Keyed on the same
# (modification time, size) stamp as the record itself, so writing one session
# re-summarises one session instead of all of them (v4.3.3).
#
# Deliberately memory-only. Saving these to disk was tried so a restarted
# bridge could skip the work; measured, it made the restart WORSE — 0.26s to
# 0.65s — because writing the 237KB file cost more than re-summarising. The
# restart path keeps its own saved list (SESSION_LIST_CACHE_FILE); this one
# earns its keep on the common path, which is every message sent.
_SESSION_SUMMARY_CACHE = {}
_SESSION_SUMMARY_CACHE_LOCK = threading.Lock()


def ui_session_summary_cached(path, session):
    """ui_session_summary(), but computed once per version of the file."""
    key = str(path)
    try:
        stat = os.stat(key)
        stamp = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        # No file to key on (a record held only in memory) — summarise it.
        return ui_session_summary(session)
    with _SESSION_SUMMARY_CACHE_LOCK:
        cached = _SESSION_SUMMARY_CACHE.get(key)
        if cached is not None and cached[0] == stamp:
            return cached[1]
    summary = ui_session_summary(session)
    with _SESSION_SUMMARY_CACHE_LOCK:
        _SESSION_SUMMARY_CACHE[key] = (stamp, summary)
    return summary


SESSION_TRIM_CACHE_FILE = os.path.join(CONFIG_DIR, "session-summaries.json")
_SESSION_TRIM_DISK = None
_SESSION_TRIM_DISK_LOCK = threading.Lock()


def _session_trim_disk_cache():
    """Trimmed records saved from a previous run, keyed by file fingerprint.

    The in-memory cache is empty after every bridge restart, so the first
    listing paid the full cost again — 0.63s, which is exactly when the app is
    starting and asking for it. Measured 2026-07-30: of 360 stored sessions,
    the 15 oversized ones account for 0.35s of the 0.42s cold build, and their
    trimmed records serialise to 0.03MB. So only those are persisted: nearly
    all of the saving, for a file small enough to rewrite without churn."""
    global _SESSION_TRIM_DISK
    with _SESSION_TRIM_DISK_LOCK:
        if _SESSION_TRIM_DISK is None:
            raw = load_json(SESSION_TRIM_CACHE_FILE, {}) or {}
            _SESSION_TRIM_DISK = raw if isinstance(raw, dict) else {}
        return _SESSION_TRIM_DISK


def _session_trim_key(path, stamp):
    return f"{path}|{stamp[0]}|{stamp[1]}"


def _remember_trimmed_session(path, stamp, record):
    """Persist one trimmed record, pruning any older fingerprint for that file."""
    key = _session_trim_key(path, stamp)
    with _SESSION_TRIM_DISK_LOCK:
        if _SESSION_TRIM_DISK is None:
            return
        prefix = f"{path}|"
        for stale in [k for k in _SESSION_TRIM_DISK if k.startswith(prefix) and k != key]:
            _SESSION_TRIM_DISK.pop(stale, None)
        _SESSION_TRIM_DISK[key] = record
        snapshot = dict(_SESSION_TRIM_DISK)
    try:
        save_json(SESSION_TRIM_CACHE_FILE, snapshot)
    except OSError:
        pass


def _session_record_without_transcript(session):
    """A session record small enough to keep, for chats too big to cache whole.

    ui_session_summary() has always known how to read a precomputed
    `_awbn_summary` "so the list view never re-parses tens of MB to render one
    row" — but nothing ever wrote one, so the saving never happened. Measured
    2026-07-30: of 359 stored sessions totalling 247MB, the 20 over the cache
    limit hold 221MB of it, and every listing re-read and re-parsed all of
    them. That is why the session list and the project list each took about
    half a second, every time.

    Everything except the transcript is kept, plus the three fields the
    summary would otherwise derive from it. Callers that genuinely need turns
    ask for full=True, which bypasses the cache entirely."""
    status, prompt = ui_latest_turn_summary(session)
    turns = session.get("turns")
    trimmed = {key: value for key, value in session.items() if key != "turns"}
    trimmed["_awbn_summary"] = {
        "last_turn_status": status,
        "latest_prompt": prompt,
        "turn_count": len(turns) if isinstance(turns, list) else 0,
    }
    return trimmed


def load_session_record(path):
    """One stored session, cached against its own (modification time, size).

    Split out of local_session_records so the session list can read just the
    files that actually changed instead of all of them."""
    key = str(path)
    try:
        stat = os.stat(key)
        stamp = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        return None
    with _SESSION_RECORD_CACHE_LOCK:
        cached = _SESSION_RECORD_CACHE.get(key)
    if cached is not None and cached[0] == stamp:
        session = cached[1]
    elif (
        stat.st_size > _SESSION_CACHE_MAX_BYTES
        and _session_trim_disk_cache().get(_session_trim_key(key, stamp)) is not None
    ):
        # Saved by an earlier run and the file has not changed since — no need
        # to re-read and re-parse tens of MB to list one row.
        session = _session_trim_disk_cache()[_session_trim_key(key, stamp)]
        with _SESSION_RECORD_CACHE_LOCK:
            _SESSION_RECORD_CACHE[key] = (stamp, session)
    else:
        session = load_json(key, None)
        if isinstance(session, dict) and session.get("id"):
            if stat.st_size > _SESSION_CACHE_MAX_BYTES:
                # Trim BEFORE returning, not just before caching: callers must
                # not get a full record on the first pass and a trimmed one
                # afterwards, or a bug hides until the cache happens to be warm.
                session = _session_record_without_transcript(session)
                _remember_trimmed_session(key, stamp, session)
            with _SESSION_RECORD_CACHE_LOCK:
                _SESSION_RECORD_CACHE[key] = (stamp, session)
    if isinstance(session, dict) and session.get("id"):
        return session
    return None


def local_session_records(full=False):
    """Every stored session. `full=True` bypasses the cache and returns
    complete records — only the startup repair pass needs the transcripts."""
    records = []
    try:
        paths = list(Path(SESS_DIR).glob("*.json"))
    except OSError:
        return records
    if full:
        for path in paths:
            session = load_json(str(path), None)
            if isinstance(session, dict) and session.get("id"):
                records.append((path, session))
        return records
    seen = set()
    for path in paths:
        key = str(path)
        seen.add(key)
        session = load_session_record(key)
        if session is not None:
            records.append((path, session))
    if len(_SESSION_RECORD_CACHE) > len(seen):
        with _SESSION_RECORD_CACHE_LOCK:
            for stale in [k for k in _SESSION_RECORD_CACHE if k not in seen]:
                _SESSION_RECORD_CACHE.pop(stale, None)
    return records


def source_is_deleted(session, deleted_ids, deleted_paths):
    source_path = clean_text(session.get("source_path"))
    return (
        clean_text(session.get("id")) in deleted_ids
        or native_session_id(session) in deleted_ids
        or (
            source_path
            and os.path.abspath(os.path.expanduser(source_path)) in deleted_paths
        )
    )


def claude_context_limit(model):
    value = clean_text(model).lower()
    if value in {"opus", "sonnet", "fable"}:
        return 1_000_000
    # The 1M-context family. This list was written when 4.6/4.7/4.8 were the
    # newest and never grew: claude-opus-5 and claude-sonnet-5 fell through to
    # 200k, so a session five times inside its window reported 88% full
    # (reported: "how the fuck can awbn already be at 88 context limit when
    # we'd be nowhere near that here"). Matching the FAMILY rather than each
    # dated build, so the next release does not repeat this.
    if re.search(r"(?:opus|sonnet|fable|mythos)-(?:[5-9]|4-[678])\b", value):
        return 1_000_000
    # Haiku is the one small-context family, and stays 200k.
    return 200_000


def gemini_context_limit(model):
    value = clean_text(model).lower()
    if not value or value in {"auto", "default"}:
        return 1_000_000
    if "image" in value:
        if "flash" in value:
            return 128_000
        return 65_000
    if "gemini" in value:
        return 1_000_000
    return 0


def context_from_claude_usage(usage, model="", compact_count=0):
    if not isinstance(usage, dict):
        return {}
    used = sum(
        safe_int(usage.get(key))
        for key in (
            "input_tokens",
            "cache_creation_input_tokens",
            "cache_read_input_tokens",
        )
    )
    if used <= 0:
        return {}
    limit = claude_context_limit(model)
    return {
        "used": used,
        "limit": limit,
        "percent": min(100.0, used * 100.0 / limit),
        "model": clean_text(model),
        "compact_count": int(compact_count or 0),
        "input_tokens": safe_int(usage.get("input_tokens")),
        "cache_creation_input_tokens": safe_int(usage.get("cache_creation_input_tokens")),
        "cache_read_input_tokens": safe_int(usage.get("cache_read_input_tokens")),
        "cache_total_tokens": safe_int(usage.get("cache_creation_input_tokens"))
        + safe_int(usage.get("cache_read_input_tokens")),
    }


def claude_model_alias(model):
    value = clean_text(model).lower()
    for alias in ("fable", "opus", "sonnet", "haiku"):
        if alias in value:
            return alias
    return "Default"


def claude_session_metadata(path):
    title = ""
    preview = ""
    cwd = ""
    context = {}
    compact_count = 0
    resumable = False
    for record in read_jsonl_lines(path):
        if not isinstance(record, dict) or record.get("isSidechain"):
            continue
        cwd = cwd or clean_text(record.get("cwd"))
        record_type = record.get("type")
        if record_type in {"ai-title", "custom-title"}:
            candidate = clean_text(record.get("customTitle") or record.get("aiTitle"))
            if candidate:
                title = candidate
            continue
        if record_type == "system" and record.get("subtype") == "compact_boundary":
            compact_count += 1
            continue
        message = record.get("message") or {}
        if record_type == "user" and not record.get("isMeta"):
            content = message.get("content")
            text_parts = []
            if isinstance(content, str):
                command = re.search(
                    r"<command-name>(.*?)</command-name>",
                    content,
                    flags=re.DOTALL,
                )
                text_parts.append(command.group(1) if command else content)
            elif isinstance(content, list):
                text_parts.extend(
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                )
            candidate = clean_text("\n".join(text_parts))
            if candidate:
                resumable = True
                preview = preview or shorten(candidate)
        elif record_type == "assistant":
            model = clean_text(message.get("model"))
            if model and model != "<synthetic>":
                candidate = context_from_claude_usage(
                    message.get("usage") or {},
                    model,
                    compact_count,
                )
                if candidate:
                    context = candidate
    return {
        "title": title,
        "preview": preview,
        "cwd": cwd,
        "context": context,
        "resumable": resumable,
    }


def claude_transcript_path_for_session(session, claude_root=None):
    source_path = clean_text((session or {}).get("source_path"))
    if source_path and os.path.isfile(source_path):
        return source_path
    native_id = native_session_id(session or {})
    if not native_id:
        return ""
    root = Path(claude_root or os.path.expanduser("~/.claude/projects"))
    if not root.is_dir():
        return ""
    for path in root.glob("*/*.jsonl"):
        if path.stem == native_id:
            return str(path)
    return ""


def repair_inflated_claude_context(session, transcript_path):
    """Replace cumulative turn billing with the latest API call's context."""
    if clean_text((session or {}).get("agent")).lower() != "claude":
        return False
    current = (
        session.get("context") if isinstance(session.get("context"), dict) else {}
    )
    used = int(current.get("used") or 0)
    limit = int(current.get("limit") or 0)
    percent = float(current.get("percent") or 0)
    if used <= 0 or limit <= 0:
        return False
    if used <= limit and percent < HANDOFF_WARNING_PERCENT:
        return False
    if not transcript_path or not os.path.isfile(transcript_path):
        return False
    replacement = claude_session_metadata(transcript_path).get("context") or {}
    replacement_used = int(replacement.get("used") or 0)
    replacement_limit = int(replacement.get("limit") or 0)
    if replacement_used <= 0 or replacement_limit <= 0:
        return False
    if replacement_used >= used and used <= limit:
        return False
    # Nothing to do if the transcript says exactly what the record already
    # says. Without this the pass "repaired" the same 12 sessions on every
    # single start, forever: it rewrote each one with an identical context and
    # reported success, because a transcript that genuinely exceeds the limit
    # still trips the guards above on the next pass. That cost 3.8s of startup
    # work that changed nothing, and rewriting the files churned their
    # modification times, which invalidated the session-list cache every
    # restart (v4.3.3).
    if replacement == current:
        return False
    session["context"] = replacement
    if float(replacement.get("percent") or 0) < HANDOFF_WARNING_PERCENT:
        for key in (
            "handoff_stage_ready",
            "handoff_stage_signature",
            "handoff_stage_artifact",
            "handoff_stage_updated_at",
        ):
            session.pop(key, None)
    return True


def repair_concatenated_claude_chat(session, transcript_path):
    """Move old Claude progress narration out of the final chat message."""
    if clean_text((session or {}).get("agent")).lower() != "claude":
        return False
    if not transcript_path or not os.path.isfile(transcript_path):
        return False
    native_turns = claude_jsonl_turns(transcript_path)
    if not native_turns:
        return False
    native_items = native_turns[-1].get("items") or []
    final_text = ""
    progress = []
    for item in native_items:
        if not isinstance(item, dict):
            continue
        if item.get("type") == "agentMessage":
            final_text = clean_text(item.get("text") or item.get("content"))
        elif item.get("tag") == "progress":
            value = clean_text(item.get("text") or item.get("content"))
            if value:
                progress.append(value)
    if not final_text:
        return False
    turns = session.get("turns") if isinstance(session.get("turns"), list) else []
    if not turns or not isinstance(turns[-1], dict):
        return False
    items = turns[-1].get("items")
    if not isinstance(items, list):
        return False
    answer_index = -1
    for index in range(len(items) - 1, -1, -1):
        if isinstance(items[index], dict) and items[index].get("type") == "agentMessage":
            answer_index = index
            break
    if answer_index < 0:
        return False
    current_text = clean_text(
        items[answer_index].get("text") or items[answer_index].get("content")
    )
    if current_text == final_text or not current_text.endswith(final_text):
        return False
    existing_progress = {
        clean_text(item.get("content") or item.get("text"))
        for item in items
        if isinstance(item, dict) and item.get("tag") == "progress"
    }
    additions = [
        {"type": "system", "tag": "progress", "content": value}
        for value in progress
        if value not in existing_progress
    ]
    if additions:
        items[answer_index:answer_index] = additions
        answer_index += len(additions)
    items[answer_index]["text"] = final_text
    items[answer_index].pop("content", None)
    return True


def repair_inflated_claude_contexts(claude_root=None, pace_every=0, pace_seconds=0.0):
    """Repair display/accounting records across every stored session.

    `pace_every`/`pace_seconds` let the caller breathe between sessions. This
    reads and re-parses every session file (359 of them, 237MB, on the machine
    this was measured on), and Python threads share one interpreter — run flat
    out in the background it tripled the app's request times while it worked:
    the same three launch calls took 3.62s during the pass against 1.16s on a
    settled bridge. Pausing briefly hands the interpreter back to whoever is
    actually waiting on a response."""
    fixed = 0
    for index, (_path, session) in enumerate(local_session_records(full=True)):
        if pace_every and pace_seconds and index and index % pace_every == 0:
            time.sleep(pace_seconds)
        transcript = claude_transcript_path_for_session(session, claude_root)
        context_fixed = repair_inflated_claude_context(session, transcript)
        chat_fixed = repair_concatenated_claude_chat(session, transcript)
        if not context_fixed and not chat_fixed:
            continue
        save_session(session)
        fixed += 1
    return fixed


def claude_jsonl_turns(path):
    turns = []
    current = None
    pending_text = []
    seen = set()

    def ensure_turn(timestamp=""):
        nonlocal current
        if current is None:
            current = {
                "id": str(uuid.uuid4()),
                "created_at": clean_text(timestamp) or now_iso(),
                "status": "completed",
                "items": [],
            }
            turns.append(current)
        return current

    def flush_assistant_text(final=False):
        nonlocal pending_text
        if not pending_text:
            return
        turn = ensure_turn()
        progress = pending_text[:-1] if final else pending_text
        turn["items"].extend(
            {"type": "system", "text": text, "tag": "progress"}
            for text in progress
        )
        if final:
            turn["items"].append({"type": "agentMessage", "text": pending_text[-1]})
        pending_text = []

    for record in read_jsonl_lines(path):
        if not isinstance(record, dict) or record.get("isSidechain"):
            continue
        record_id = clean_text(record.get("uuid"))
        if record_id and record_id in seen:
            continue
        if record_id:
            seen.add(record_id)
        record_type = record.get("type")
        if record_type not in {"user", "assistant"}:
            continue
        message = record.get("message") or {}
        content = message.get("content")
        blocks = content if isinstance(content, list) else [{"type": "text", "text": content}]
        timestamp = clean_text(record.get("timestamp"))
        if record_type == "user":
            prompt = clean_text(
                "\n".join(
                    clean_text(block.get("text"))
                    for block in blocks
                    if isinstance(block, dict) and block.get("type") == "text"
                )
            )
            if prompt:
                prompt = strip_harness_injections(prompt)
                flush_assistant_text(final=True)
                if prompt:
                    current = {
                        "id": record_id or str(uuid.uuid4()),
                        "created_at": timestamp or now_iso(),
                        "status": "completed",
                        "items": [
                            {
                                "type": "userMessage",
                                "content": [{"type": "text", "text": prompt}],
                            }
                        ],
                    }
                    turns.append(current)
                else:
                    current = None
            for block in blocks:
                if not isinstance(block, dict) or block.get("type") != "tool_result":
                    continue
                output = block.get("content")
                if isinstance(output, list):
                    output = "\n".join(
                        clean_text(part.get("text"))
                        for part in output
                        if isinstance(part, dict) and part.get("type") == "text"
                    )
                if clean_text(output):
                    ensure_turn(timestamp)["items"].append(
                        {"type": "system", "text": clean_text(output), "tag": "tool"}
                    )
            continue
        for block in blocks:
            if not isinstance(block, dict):
                continue
            block_type = block.get("type")
            if block_type == "text" and clean_text(block.get("text")):
                pending_text.append(clean_text(block.get("text")))
            elif block_type == "thinking" and clean_text(block.get("thinking")):
                ensure_turn(timestamp)["items"].append(
                    {
                        "type": "reasoning",
                        "summary": [clean_text(block.get("thinking"))],
                    }
                )
            elif block_type == "tool_use":
                flush_assistant_text(final=False)
                name = clean_text(block.get("name"))
                tool_input = block.get("input") or {}
                if name == "Bash":
                    command = clean_text(tool_input.get("command"))
                    if command:
                        ensure_turn(timestamp)["items"].append(
                            {"type": "commandExecution", "command": command}
                        )
                elif name in {"Edit", "Write", "NotebookEdit"}:
                    target = clean_text(
                        tool_input.get("file_path")
                        or tool_input.get("notebook_path")
                        or tool_input.get("path")
                    )
                    ensure_turn(timestamp)["items"].append(
                        {
                            "type": "fileChange",
                            "content": target or name,
                            "changes": [{"path": target}] if target else [],
                        }
                    )
                elif name:
                    detail = clean_text(
                        tool_input.get("description")
                        or tool_input.get("query")
                        or tool_input.get("file_path")
                    )
                    ensure_turn(timestamp)["items"].append(
                        {
                            "type": "system",
                            "text": f"Tool: {name}" + (f" - {detail}" if detail else ""),
                            "tag": "tool",
                        }
                    )
    flush_assistant_text(final=True)
    return [turn for turn in turns if turn.get("items")]


# A base64 data URL that is plainly an encoded file rather than a short inline
# icon. 256 chars of payload is far past anything worth keeping as message text.
# No \s in the payload class: base64 in a data URL is one unbroken run, and
# allowing whitespace let the match run past the blob and swallow the words
# after it.
CODEX_IMAGE_DATA_URL = re.compile(
    r"data:image/[A-Za-z0-9.+-]+;base64,[A-Za-z0-9+/=]{256,}"
)

CODEX_IMAGE_PART_TYPES = {"input_image", "image", "image_url", "output_image"}


def codex_message_text(value):
    """Flatten a Codex message payload to plain text, minus any encoded image.

    Codex writes a message with an attachment as a LIST of content parts, and a
    pasted screenshot lands in one of them as a base64 data URL. This used to be
    handed straight to clean_text(), whose str() rendered the whole list — so
    several MB of encoded image became the message text, inside a session file
    that is rewritten in full on every single save. One chat reached 26.9 MB
    across 25 turns that way, and the store as a whole reached 195 MB.

    Dropping the bytes loses nothing: the picture stays in Codex's own rollout
    under ~/.codex/sessions, which is the source this transcript is rebuilt
    from, and AWBN re-derives turns from it whenever it changes.
    """
    if value is None:
        return ""
    if isinstance(value, str):
        return CODEX_IMAGE_DATA_URL.sub("[image]", value)
    if isinstance(value, dict):
        part_type = clean_text(value.get("type")).lower()
        if part_type in CODEX_IMAGE_PART_TYPES or value.get("image_url"):
            return "[image]"
        for key in ("text", "content", "message", "output", "summary"):
            if key in value:
                return codex_message_text(value[key])
        return ""
    if isinstance(value, (list, tuple)):
        pieces = [codex_message_text(item) for item in value]
        return "\n".join(piece for piece in pieces if piece)
    return CODEX_IMAGE_DATA_URL.sub("[image]", clean_text(value))


def codex_rollout_turns(path):
    if not path or not os.path.isfile(path):
        return []
    turns = []
    current = None
    for record in read_jsonl_lines(path):
        if not isinstance(record, dict) or record.get("type") not in {
            "event_msg",
            "response_item",
        }:
            continue
        payload = record.get("payload") or {}
        event_type = payload.get("type")
        item = None
        timestamp = clean_text(record.get("timestamp"))
        if record.get("type") == "event_msg" and event_type == "user_message":
            text = strip_harness_injections(codex_message_text(payload.get("message")))
            if not text:
                continue
            current = {
                "id": str(uuid.uuid4()),
                "created_at": timestamp or now_iso(),
                "status": "completed",
                "items": [],
            }
            turns.append(current)
            item = {
                "type": "userMessage",
                "content": [{"type": "text", "text": text}],
            }
        elif record.get("type") == "event_msg" and event_type == "agent_message":
            text = clean_text(codex_message_text(payload.get("message")))
            if not text:
                continue
            if current is None:
                current = {
                    "id": str(uuid.uuid4()),
                    "created_at": timestamp or now_iso(),
                    "status": "completed",
                    "items": [],
                }
                turns.append(current)
            item = (
                {"type": "system", "text": text, "tag": "progress"}
                if payload.get("phase") == "commentary"
                else {"type": "agentMessage", "text": text}
            )
        elif record.get("type") == "response_item" and current is not None:
            if event_type == "function_call":
                name = clean_text(payload.get("name"))
                arguments = payload.get("arguments")
                command = ""
                if name == "exec_command" and isinstance(arguments, str):
                    try:
                        command = clean_text((json.loads(arguments) or {}).get("cmd"))
                    except (ValueError, AttributeError):
                        command = clean_text(arguments)
                item = (
                    {"type": "commandExecution", "command": command}
                    if command
                    else {"type": "system", "text": f"Tool: {name}", "tag": "tool"}
                    if name
                    else None
                )
            elif event_type in {"function_call_output", "custom_tool_call_output"}:
                output = payload.get("output")
                if isinstance(output, dict):
                    output = output.get("content") or output.get("output")
                # A tool can hand back an image too (a screenshot step), so this
                # goes through the same flattening as a message.
                output_text = clean_text(codex_message_text(output))
                if output_text:
                    item = {
                        "type": "system",
                        "text": output_text,
                        "tag": "system",
                    }
            elif event_type == "reasoning":
                summary = payload.get("summary") or []
                text = clean_text(
                    " ".join(
                        value.get("text", "") if isinstance(value, dict) else str(value)
                        for value in summary
                    )
                )
                if text:
                    item = {"type": "reasoning", "summary": [text], "text": text}
        if item is not None and current is not None:
            current["items"].append(item)
    return [turn for turn in turns if turn.get("items")]


def codex_context_from_rollout(path):
    context = {}
    for record in read_jsonl_lines(path):
        if not isinstance(record, dict) or record.get("type") != "event_msg":
            continue
        payload = record.get("payload") or {}
        if payload.get("type") != "token_count":
            continue
        info = payload.get("info") or {}
        usage = info.get("last_token_usage") or {}
        used = safe_int(usage.get("input_tokens") or usage.get("total_tokens"))
        limit = safe_int(info.get("model_context_window"))
        if used > 0 and limit > 0:
            context = {
                "used": used,
                "limit": limit,
                "percent": min(100.0, used * 100.0 / limit),
                "model": "Codex",
                "compact_count": 0,
            }
    return context


def gemini_session_index():
    index = {}
    root = Path(os.path.expanduser("~/.gemini"))
    if not root.is_dir():
        return index
    for candidate in root.rglob("session-*.jsonl"):
        try:
            header = next(read_jsonl_lines(str(candidate), limit=1), {})
            session_id = clean_text(header.get("sessionId"))
            if not session_id:
                continue
            mtime = candidate.stat().st_mtime_ns
        except OSError:
            continue
        existing = index.get(session_id)
        if existing and int(existing.get("mtime_ns") or 0) >= mtime:
            continue
        index[session_id] = {
            "path": str(candidate),
            "project_hash": clean_text(header.get("projectHash")),
            "start_time": clean_text(header.get("startTime")),
            "updated_at": iso_from_unix(candidate.stat().st_mtime),
            "mtime_ns": mtime,
        }
    return index


def known_project_paths():
    values = {os.path.abspath(os.path.expanduser("~"))}
    config = load_json(CONFIG_FILE, {}) or {}
    for value in [config.get("cwd"), *(config.get("recent_projects") or [])]:
        if clean_text(value):
            values.add(os.path.abspath(os.path.expanduser(clean_text(value))))
    for workspace in config.get("workspace_tabs") or []:
        if isinstance(workspace, dict) and clean_text(workspace.get("cwd")):
            values.add(os.path.abspath(os.path.expanduser(clean_text(workspace.get("cwd")))))
    for _path, session in local_session_records():
        if clean_text(session.get("cwd")):
            values.add(os.path.abspath(os.path.expanduser(clean_text(session.get("cwd")))))
    return values


def gemini_title_from_jsonl(path):
    for record in read_jsonl_lines(path, limit=500):
        messages = []
        if isinstance(record, dict) and isinstance(record.get("$set"), dict):
            payload = record["$set"].get("messages")
            if isinstance(payload, list):
                messages = payload
        elif isinstance(record, dict):
            messages = [record]
        for message in messages:
            if not isinstance(message, dict) or message.get("type") != "user":
                continue
            prompt = clean_text(
                "\n".join(
                    clean_text(block.get("text"))
                    for block in message.get("content") or []
                    if isinstance(block, dict) and block.get("text")
                )
            )
            _, visible = strip_session_context(prompt)
            if visible:
                return shorten(visible)
    return ""


def gemini_native_titles():
    cached = load_json(GEMINI_TITLE_CACHE_FILE, {}) or {}
    if not isinstance(cached, dict):
        cached = {}
    try:
        if time.time() - os.path.getmtime(GEMINI_TITLE_CACHE_FILE) < 300:
            return cached
    except OSError:
        pass
    try:
        # Session-title discovery is read-only metadata.  Never weaken Gemini's
        # trust or approval policy just to make this optional convenience work.
        # Older Gemini builds may not support a non-interactive listing here;
        # in that case the cached titles below are the safe fallback.
        result = subprocess.run(
            ["gemini", "--list-sessions"],
            cwd=os.path.expanduser("~"),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return cached
    titles = dict(cached)
    ansi = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
    for raw_line in (result.stdout or "").splitlines():
        line = ansi.sub("", raw_line)
        match = re.match(
            r"^\s*\d+\.\s+(.*?)\s+\([^()]*(?:ago)?\)\s+"
            r"\[([0-9a-fA-F-]{36})\]\s*$",
            line,
        )
        if not match:
            continue
        title, session_id = (clean_text(value) for value in match.groups())
        if title and not title.lower().startswith("<session_context>"):
            titles[session_id] = title
    save_json(GEMINI_TITLE_CACHE_FILE, titles)
    return titles


def gemini_jsonl_turns(path):
    messages = []
    seen_ids = set()
    for record in read_jsonl_lines(path):
        if isinstance(record, dict) and isinstance(record.get("$set"), dict):
            payload = record["$set"].get("messages")
            if isinstance(payload, list):
                messages = payload
                seen_ids = {
                    clean_text(message.get("id"))
                    for message in messages
                    if isinstance(message, dict) and clean_text(message.get("id"))
                }
            continue
        if not isinstance(record, dict) or record.get("type") not in {"user", "gemini"}:
            continue
        message_id = clean_text(record.get("id"))
        if message_id and message_id in seen_ids:
            continue
        messages.append(record)
        if message_id:
            seen_ids.add(message_id)
    turns = []
    current = None

    def ensure_turn(timestamp=""):
        nonlocal current
        if current is None:
            current = {
                "id": str(uuid.uuid4()),
                "created_at": clean_text(timestamp) or now_iso(),
                "status": "completed",
                "items": [],
            }
            turns.append(current)
        return current

    def append_work(text, tag="system"):
        if clean_text(text):
            ensure_turn()["items"].append(
                {"type": "system", "text": clean_text(text), "tag": tag}
            )

    for message in messages:
        if not isinstance(message, dict):
            continue
        message_type = message.get("type")
        timestamp = clean_text(message.get("timestamp"))
        content = message.get("content") or []
        if not isinstance(content, list):
            content = []
        if message_type == "user":
            prompt = clean_text(
                "\n".join(
                    clean_text(block.get("text"))
                    for block in content
                    if isinstance(block, dict) and block.get("text")
                )
            )
            hidden, _visible = strip_session_context(prompt)
            visible = strip_harness_injections(prompt)
            if hidden and visible:
                append_work(hidden, "system")
            if visible:
                current = {
                    "id": clean_text(message.get("id")) or str(uuid.uuid4()),
                    "created_at": timestamp or now_iso(),
                    "status": "completed",
                    "items": [
                        {
                            "type": "userMessage",
                            "content": [{"type": "text", "text": visible}],
                        }
                    ],
                }
                turns.append(current)
            continue
        if message_type != "gemini":
            continue
        ensure_turn(timestamp)
        for thought in message.get("thoughts") or []:
            if isinstance(thought, dict):
                text = clean_text(
                    thought.get("description")
                    or thought.get("thinking")
                    or thought.get("summary")
                    or thought.get("subject")
                )
                if text:
                    current["items"].append(
                        {"type": "reasoning", "summary": [text], "text": text}
                    )
        assistant_text = []
        for block in content:
            if not isinstance(block, dict):
                continue
            if clean_text(block.get("text")):
                assistant_text.append(clean_text(block.get("text")))
            elif isinstance(block.get("functionCall"), dict):
                call = block["functionCall"]
                name = clean_text(call.get("name"))
                arguments = call.get("args") or {}
                detail = clean_text(
                    arguments.get("command")
                    or arguments.get("file_path")
                    or arguments.get("path")
                    or arguments.get("url")
                    or arguments.get("query")
                )
                current["items"].append(
                    {
                        "type": "commandExecution"
                        if name == "run_shell_command"
                        else "system",
                        "command": detail if name == "run_shell_command" else "",
                        "text": (
                            f"Tool: {name}" + (f" - {detail}" if detail else "")
                            if name != "run_shell_command"
                            else ""
                        ),
                        "tag": "tool",
                    }
                )
        text = clean_text("\n".join(assistant_text))
        thought_text, visible_text = split_gemini_visible_text(text)
        if thought_text:
            current["items"].append(
                {"type": "reasoning", "summary": [thought_text], "text": thought_text}
            )
        if visible_text:
            current["items"].append({"type": "agentMessage", "text": visible_text})
    return [turn for turn in turns if turn.get("items")]


def native_session_summaries():
    summaries = []
    deleted_ids, deleted_paths = deleted_native_refs()
    home = os.path.abspath(os.path.expanduser("~"))

    claude_root = Path(os.path.expanduser("~/.claude/projects"))
    if claude_root.is_dir():
        for path in claude_root.glob("*/*.jsonl"):
            session_id = path.stem
            metadata = claude_session_metadata(str(path))
            if not metadata["resumable"]:
                continue
            summary = {
                "id": f"claude-terminal:{session_id}",
                "source_session_id": session_id,
                "agent": "claude",
                "origin": "claude-terminal",
                "cwd": metadata["cwd"] or home,
                "title": clean_native_title(metadata["title"], metadata["preview"]) or "Claude session",
                "preview": metadata["preview"] or "Claude session",
                "created_at": iso_from_unix(path.stat().st_ctime),
                "updated_at": iso_from_unix(path.stat().st_mtime),
                "source_path": str(path),
                "source_mtime_ns": path.stat().st_mtime_ns,
                "backend": {
                    "session_id": session_id,
                    "model": claude_model_alias(
                        (metadata.get("context") or {}).get("model")
                    ),
                },
                "context": metadata["context"],
                "turns": [],
                "transcript_loaded": False,
            }
            if not source_is_deleted(summary, deleted_ids, deleted_paths):
                summaries.append(summary)

    database = os.path.expanduser("~/.codex/state_5.sqlite")
    if os.path.isfile(database):
        try:
            import sqlite3

            # 30s busy-wait: the Codex CLI may hold this DB during an active turn;
            # without a timeout the write throws "database is locked" and the
            # session never gets a terminal-visible title.
            connection = sqlite3.connect(database, timeout=30)
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                "select id, rollout_path, cwd, title, preview, first_user_message, "
                "created_at, updated_at, model, reasoning_effort, agent_role "
                "from threads where archived = 0 order by updated_at desc limit 500"
            ).fetchall()
            connection.close()
        except Exception:
            rows = []
        for row in rows:
            if clean_text(row["agent_role"]):
                continue
            path = clean_text(row["rollout_path"])
            try:
                mtime_ns = os.stat(path).st_mtime_ns if path else 0
            except OSError:
                mtime_ns = 0
            session_id = clean_text(row["id"])
            preview = clean_text(
                row["preview"] or row["title"] or row["first_user_message"]
            )
            summary = {
                "id": f"codex-terminal:{session_id}",
                "source_session_id": session_id,
                "agent": "codex",
                "origin": "codex-terminal",
                "cwd": clean_text(row["cwd"]) or home,
                "title": clean_native_title(row["title"], preview) or "Codex session",
                "preview": preview or "Codex session",
                "created_at": iso_from_unix(row["created_at"]),
                "updated_at": iso_from_unix(row["updated_at"]),
                "source_path": path,
                "source_mtime_ns": mtime_ns,
                "backend": {
                    "thread_id": session_id,
                    "model": clean_text(row["model"]) or default_model_for("codex"),
                    "effort": clean_text(row["reasoning_effort"]) or DEFAULT_AGENT_SETTINGS["codex"]["effort"],
                },
                "context": codex_context_from_rollout(path),
                "turns": [],
                "transcript_loaded": False,
            }
            if not source_is_deleted(summary, deleted_ids, deleted_paths):
                summaries.append(summary)

    project_by_hash = {
        hashlib.sha256(path.encode("utf-8")).hexdigest(): path
        for path in known_project_paths()
    }
    gemini_titles = gemini_native_titles()
    for session_id, metadata in gemini_session_index().items():
        path = metadata["path"]
        title = (
            clean_text(gemini_titles.get(session_id))
            or gemini_title_from_jsonl(path)
            or "Gemini session"
        )
        summary = {
            "id": f"gemini-terminal:{session_id}",
            "source_session_id": session_id,
            "agent": "gemini",
            "origin": "gemini-terminal",
            "cwd": project_by_hash.get(metadata["project_hash"], home),
            "title": title,
            "preview": title,
            "created_at": metadata["start_time"] or metadata["updated_at"],
            "updated_at": metadata["updated_at"],
            "source_path": path,
            "source_mtime_ns": metadata["mtime_ns"],
            "backend": {"session_id": session_id, "model": "Auto"},
            "context": {},
            "turns": [],
            "transcript_loaded": False,
        }
        if not source_is_deleted(summary, deleted_ids, deleted_paths):
            summaries.append(summary)
    return summaries


def sync_native_history():
    existing_records = local_session_records()
    existing_by_id = {session["id"]: (path, session) for path, session in existing_records}
    linked_native_ids = {
        native_session_id(session): session["id"]
        for _path, session in existing_records
        if native_session_id(session)
    }
    discovered_ids = set()
    created = 0
    updated = 0
    for summary in native_session_summaries():
        imported_id = summary["id"]
        source_id = native_session_id(summary)
        linked_id = linked_native_ids.get(source_id)
        if linked_id and linked_id != imported_id:
            continue
        discovered_ids.add(imported_id)
        existing_entry = existing_by_id.get(imported_id)
        if existing_entry:
            _path, existing = existing_entry
            previous_mtime = int(existing.get("source_mtime_ns") or 0)
            current_mtime = int(summary.get("source_mtime_ns") or 0)
            turns = existing.get("turns") or []
            transcript_loaded = bool(existing.get("transcript_loaded"))
            user_title = clean_text(existing.get("title")) if existing.get("user_renamed") else ""
            candidate = dict(existing)
            candidate.update(summary)
            if user_title:
                candidate["title"] = user_title
                candidate["preview"] = user_title
                candidate["user_renamed"] = True
            candidate["turns"] = turns
            candidate["transcript_loaded"] = (
                transcript_loaded and previous_mtime == current_mtime
            )
            if candidate != existing:
                save_session(candidate)
                updated += 1
        else:
            save_session(summary)
            created += 1

    removed = 0
    for path, session in existing_records:
        if session.get("origin") not in {
            "claude-terminal",
            "codex-terminal",
            "gemini-terminal",
        }:
            continue
        if session.get("id") in discovered_ids:
            continue
        try:
            path.unlink()
            removed += 1
        except OSError:
            pass
    return {"created": created, "updated": updated, "removed": removed}


def load_native_transcript(session_id):
    with locked_sessions(session_id):
        session = load_session(session_id)
        return refresh_session_from_native_transcript(session)


def ollama_models():
    try:
        with urllib.request.urlopen(f"{OLLAMA_BASE}/api/tags", timeout=3) as response:
            data = json.load(response)
        return [model["name"] for model in data.get("models", []) if model.get("name")]
    except Exception:
        return []


def _refresh_ollama_ctx_cache():
    global _OLLAMA_CTX_CACHE, _OLLAMA_CTX_TS
    try:
        with urllib.request.urlopen(f"{OLLAMA_BASE}/api/tags", timeout=3) as response:
            data = json.load(response)
        _OLLAMA_CTX_CACHE = {
            m["name"]: int((m.get("details") or {}).get("context_length") or 0)
            for m in data.get("models", [])
            if m.get("name")
        }
        _OLLAMA_CTX_TS = time.monotonic()
    except Exception:
        pass


def ollama_model_context(model):
    """Return the declared context-length for a local Ollama model, or 262144 as fallback."""
    if time.monotonic() - _OLLAMA_CTX_TS > _OLLAMA_CTX_TTL:
        _refresh_ollama_ctx_cache()
    ctx = _OLLAMA_CTX_CACHE.get(clean_text(model), 0)
    return ctx if ctx > 0 else 262_144


def orchestration_mode():
    config = load_json(CONFIG_FILE, {}) or {}
    # See ui_app_state_payload: routing is opt-IN now, never the default.
    return clean_text((config.get("claude_orchestration") or {}).get("mode") or "direct")


# Codex has no headless approval protocol (see docs/CODEX_GEMINI_PERMISSION_SPIKE.md),
# but `codex exec` DOES support OS-level sandbox modes — real containment with no
# prompts. This is the robust safety knob for codex: default to workspace-write
# (edit the project, but not the wider system), opt down to read-only or up to
# danger-full-access (the old bypass behavior).
CODEX_SANDBOX_MODES = ("workspace-write", "read-only", "danger-full-access")


def codex_sandbox_mode():
    config = load_json(CONFIG_FILE, {}) or {}
    mode = clean_text(config.get("codex_sandbox")).lower()
    return mode if mode in CODEX_SANDBOX_MODES else "workspace-write"


RESPONSE_STYLE_TEMPLATES = {
    "plain": (
        "Response style - Plain & Direct:\n"
        "- Lead with the direct answer to what the user asked, in the first sentence.\n"
        "- Write for a smart person who is NOT a programmer. Assume they do not know "
        "technical terms, tool names, protocols, or services. This is the most "
        "important rule.\n"
        "- Before you use ANY technical term or product name (a protocol, a tool, a "
        "service, a file format), first say in everyday words what it does and why it "
        "matters here. Lead with the plain-English meaning; the technical name is "
        "optional and goes in parentheses, second.\n"
        "  Example - DON'T: 'I'll use Tailscale Funnel to expose the local server "
        "over HTTPS.'  DO: 'I'll make your app reachable from the open internet "
        "through a secure web link, so anyone you share it with can open it - nothing "
        "for them to install (this uses a tool called Tailscale Funnel).'\n"
        "- Explain what each thing MEANS FOR THE USER, not how it works under the "
        "hood. If they couldn't act on a sentence, it's too technical - rewrite it.\n"
        "- Do NOT narrate your plan or running commentary step by step ('I'm going "
        "to…', 'I'm adding…', 'I'm about to…', 'The change will…'). Just do the work "
        "and report the result in a few tight sentences.\n"
        "- Do not explain background tooling, internal notifications, search "
        "commands, or your own process unless the user asks - the user cares about "
        "the result, not the plumbing.\n"
        "- Keep it short. No preamble and no self-justification.\n"
        "- Your reply is a brief summary for a person, NOT a log of what you did. The "
        "steps, commands, and file edits you make are recorded separately, so don't "
        "recount them - give the outcome and anything the user needs to decide.\n"
        "- NEVER write one long block of text. Break the answer into short paragraphs "
        "of at most 2-3 sentences, separated by a blank line. Use a bulleted list when "
        "you have more than two parallel points.\n"
        "- Format in Markdown: a blank line between paragraphs, `- ` bullets for lists, "
        "and **bold** for the few words that matter most."
    ),
    "concise": (
        "Response style - Concise:\n"
        "- Answer in as few words as possible; prefer short bullets over paragraphs.\n"
        "- State the result first. Omit background, caveats, and process unless asked.\n"
        "- No filler and no restating the question.\n"
        # Short was the only rule here, and short with no plain-language rule just
        # produces dense engineer-speak: raw identifiers dropped in as if they were
        # ordinary words, sentences packed past the point of reading.
        "- Write for a smart person who is NOT a programmer. Brief must never mean "
        "technical. This matters more than saving a word.\n"
        "- Before any technical term, tool, service, or file format, say in everyday "
        "words what it is. Plain meaning first; the name second in brackets, or left "
        "out entirely.\n"
        "- NEVER drop a raw identifier - a variable, table, setting, flag, or file "
        "name - into a sentence as though the reader knows it. Say what the thing IS, "
        "then name it.\n"
        "- Short sentences, one idea each. Being brief means fewer ideas, not the "
        "same ideas crushed together.\n"
        "- Format in Markdown: `- ` bullets, blank lines between points, **bold** keywords. "
        "Never one long run-on paragraph."
    ),
    "structured": (
        "Response style - Structured & Skimmable:\n"
        "- Make the answer easy to scan in seconds. NEVER write a wall of text.\n"
        "- Lead with a one-sentence direct answer, then the supporting detail.\n"
        "- Use Markdown structure aggressively:\n"
        "  - Short paragraphs (2-3 sentences max), separated by a blank line.\n"
        "  - `- ` bulleted lists for any set of parallel items, steps, or options.\n"
        "  - **Bold** the key terms, names, files, and decisions.\n"
        "  - A Markdown table when comparing things across the same dimensions.\n"
        "  - Short `## ` or `### ` headings when the answer has more than one section.\n"
        "- Prefer short sentences. Cut filler words. One idea per line where it helps.\n"
        "- Do not narrate your process; show the organized result."
    ),
    "detailed": "",
}

CHAT_RESULT_DISCIPLINE = (
    "Visible chat discipline - IMPORTANT:\n"
    "- The Conversation/chat pane is for the user-facing result, not a work log. "
    "Do not put chronological process narration, tool-by-tool progress, build logs, "
    "or internal bookkeeping in chat unless the user explicitly asks for those "
    "details.\n"
    "- Never mention internal agent ownership, lanes, routing rules, handoff files, "
    "or suggested future chunks in the final answer unless the user explicitly asks "
    "about them or must make a decision before work can continue.\n"
    "- If the user asks for status, if the work is incomplete, or if you need to "
    "report process state, use exactly these short Markdown sections: **Needed**, "
    "**Done**, **Left**. Put 1-3 short bullets under each section. If nothing "
    "remains, write `- Nothing.` under **Left**.\n"
    "- Never mix stale and current state in the same paragraph. Do not say a fix "
    "is still pending and also that all fixes are applied. Reconcile the current "
    "state before answering.\n"
    "- Avoid long progress paragraphs. If a paragraph lists multiple actions or "
    "timeline steps, convert it to the **Needed** / **Done** / **Left** format.\n"
    # The owner reads the long dash as a tell that a machine wrote the text, and
    # does not want it in anything AWBN produces. Lives here rather than in one
    # style preset so it holds for every preset and every client.
    # Written by name, not by character, because this file gets swept for long
    # dashes and a literal one here would be replaced and turn the rule into
    # nonsense.
    "- NEVER use a long dash. That means the em dash (unicode U+2014) and the en "
    "dash (U+2013). The owner reads them as a tell that a machine wrote the text. "
    "Use a comma, a colon, a full stop, or brackets instead, and rewrite the "
    "sentence if none of those fit. The ordinary keyboard hyphen is fine, in "
    "compound words (well-tested, follow-up) and in commands and file names, and "
    "is NOT what this rule is about. This applies to every reply, every heading "
    "and every bullet, including any file you write for the user to read."
)

# Injected on every Codex turn. Codex keeps the FULL output of every command it runs
# in its own context window, so verbose builds/logs and whole-file reads fill it
# fast (the user repeatedly hit this). These rules cut the fill rate at the source.
# The forced "Understood: <task in one short sentence>" opener is GONE.
#
# It demanded a restatement on every single reply, including ones with nothing to
# restate, so the model manufactured a plausible-sounding line instead. Observed:
# a reply opening "Understood: confirm the rule before I build it" when that was
# not what had been asked at all. It also compressed multi-part requests to one
# sentence BEFORE answering, and the reply then followed the compression rather
# than the original words.
#
# The genuinely useful half is kept: stop and ask when the answer would change
# what gets built.
ACK_BEFORE_WORK = (
    "If the request is unclear in a way that would change WHAT you build, ask one "
    "short question and stop there rather than guessing. Otherwise answer directly "
    "and do not open with a restatement of what was asked."
)

# Every client, not just Claude: the policy block above is delivered to Claude
# through --append-system-prompt, and Codex/Gemini never saw it. An agent
# testing an auto-clicker took over the pointer with no warning and the owner
# could not stop it, so this rule has to reach whoever is driving.
LIVE_MACHINE_WARNING = (
    "Before you touch the live machine:\n"
    "Some actions take over the computer the user is sitting at - moving or "
    "clicking the mouse, sending keystrokes, grabbing input devices, covering "
    "the screen, running an auto-clicker or macro recorder, restarting the "
    "display, or anything else the user would SEE happen to their own desktop. "
    "Before the first such action in a turn, say in plain words, in chat, what "
    "you are about to do, what it will look like, and how they stop it. Then "
    "do it. Never let the first sign of it be their pointer moving on its own.\n"
    "Testing counts. Test on the live desktop only when there is no other way, "
    "say so first, and prefer a method the user can interrupt. If a run of such "
    "actions will last more than a few seconds, say how long, and stop at the "
    "first sign the user is trying to take back control.\n"
    "When the user asks to open, show, or let them see a local file, folder, "
    "image, video, or app, they mean make the requested item visibly appear on "
    "their desktop. After the warning, use the operating system's normal opener "
    "for the requested item. Resolve words such as it, this, that, and them from "
    "the recent conversation and the current AWBN view. Do not substitute opening "
    "AWBN itself. An opener returning success only proves the request was sent. It "
    "does not prove a window appeared. Before saying the item is open, verify the "
    "target is visible with a window listing, screenshot, or another desktop "
    "read-back. If visibility cannot be verified, say only that the open request "
    "was sent and could not be confirmed. If more than one target is plausible, "
    "ask which one before acting."
)


CODEX_CONTEXT_DISCIPLINE = (
    "Context discipline - IMPORTANT. Your context window is limited and every "
    "command's FULL output is kept in it, so verbose output fills it fast:\n"
    "- Run builds, tests, and linters QUIETLY. Prefer minimal-output flags "
    "(e.g. `cargo check -q`, `make -s`, run `pnpm build` and check the exit code) and "
    "rely on the exit status. Only re-run with verbose output when diagnosing a "
    "specific failure.\n"
    "- NEVER read or print an entire large or binary file. Read only the lines you "
    "need (ranged reads, or `rg`/`grep`/`sed -n`/`head` for the relevant part). Do "
    "not `cat` whole files or paste full build logs back.\n"
    "- On success, keep just the result (pass/fail + the one key line); don't echo "
    "the full log.\n"
    "- Prefer fewer, targeted commands over many broad ones."
)


def _decode_partial_json_string(fragment):
    """Decode the CONTENTS of a JSON string that may be cut mid-escape —
    used by the live-typing view, which reads a Write tool call's input
    while the model is still generating it (v4.1.2)."""
    out = []
    i = 0
    length = len(fragment)
    while i < length:
        ch = fragment[i]
        if ch != "\\":
            out.append(ch)
            i += 1
            continue
        if i + 1 >= length:
            break  # dangling backslash — fragment ends mid-escape
        nxt = fragment[i + 1]
        if nxt == "n":
            out.append("\n")
            i += 2
        elif nxt == "t":
            out.append("\t")
            i += 2
        elif nxt == "r":
            i += 2
        elif nxt == "u":
            if i + 6 <= length:
                try:
                    out.append(chr(int(fragment[i + 2 : i + 6], 16)))
                except ValueError:
                    pass
                i += 6
            else:
                break
        else:
            out.append(nxt)
            i += 2
    return "".join(out)


def claude_write_typing_snapshot(buf):
    """(path, content_so_far) from a partially streamed Write tool input.

    The tool input arrives as raw JSON text fragments; file_path completes
    early, content keeps growing until the block closes. Both extracted
    tolerantly from the incomplete JSON. Pure + unit-tested."""
    path_match = re.search(r'"file_path"\s*:\s*"((?:[^"\\]|\\.)*)"', buf)
    path = _decode_partial_json_string(path_match.group(1)) if path_match else ""
    content = ""
    content_match = re.search(r'"content"\s*:\s*"', buf)
    if content_match:
        rest = buf[content_match.end():]
        value_match = re.match(r'(?:[^"\\]|\\.)*', rest)
        if value_match:
            content = _decode_partial_json_string(value_match.group(0))
    return path, content


def project_sibling_chat_count(session):
    """How many OTHER chats this project already has.

    A project keeps many chats and each is its own client session, so a new one
    starts with no history at all. An agent that opens a project, reads its
    state file and recognises none of it can reasonably conclude the state was
    wiped — reported exactly that: "it's acting like it doesn't know them and
    telling me agent state was wiped". Knowing that earlier chats exist, and
    that their history is simply not visible here, is the difference between a
    calm start and a false alarm."""
    if not isinstance(session, dict) or not session.get("project_chat"):
        return 0
    root = clean_text(session.get("project_root")) or clean_text(session.get("cwd"))
    if not root:
        return 0
    mine = clean_text(session.get("id"))
    target = os.path.realpath(os.path.abspath(os.path.expanduser(root)))
    count = 0
    for _path, other in local_session_records():
        if other.get("project_chat") is not True:
            continue
        if clean_text(other.get("id")) == mine:
            continue
        theirs = clean_text(other.get("project_root")) or clean_text(other.get("cwd"))
        if not theirs:
            continue
        try:
            if os.path.realpath(os.path.abspath(os.path.expanduser(theirs))) == target:
                count += 1
        except OSError:
            continue
    return count


def project_awareness_prompt(session):
    """System-prompt block making a PROJECT chat self-aware (v3.9.7).

    Tells the model it runs inside the AWBN desktop app, which project this
    chat belongs to, and that the file viewer beside the chat follows its
    file access — so "open/show/find X" means locate-and-Read the file
    under the project root, which visibly navigates the user's viewer.
    Empty string for non-project sessions (loose chats keep vanilla
    behavior).
    """
    if not isinstance(session, dict) or not session.get("project_chat"):
        return ""
    root = clean_text(session.get("project_root")) or clean_text(session.get("cwd"))
    if not root:
        return ""
    name = project_label(root) or "this project"
    siblings = project_sibling_chat_count(session)
    history_note = (
        ""
        if not siblings
        else (
            f"\n- This project already has {siblings} other chat"
            f"{'' if siblings == 1 else 's'}, each with its own history that "
            "you CANNOT see from here. Work recorded in state files, handoff "
            "notes or the code was done in those. If you meet notes, progress "
            "or decisions you do not recognise, that is expected - it is NOT "
            "evidence that anything was wiped, reset or lost. Read what is "
            "there and carry on from it; never announce that state was lost, "
            "and never re-do or overwrite work on that assumption.\n"
        )
    )
    return (
        "## Where you are\n"
        f"You are a PROJECT CHAT inside Agent Workbench (AWBN), a desktop "
        f"app. This chat belongs to the project \"{name}\" rooted at "
        f"{root} (your working directory). A file viewer pane sits beside "
        "this chat showing the project's file tree, and it automatically "
        "highlights and opens every file you Read or Write.\n"
        f"{history_note}"
        "- When the user asks to open, show, or find a file, they mean: "
        "locate it under THIS project root and Read it - that displays it "
        "in their viewer. Then confirm with its project-relative path.\n"
        "- Stay inside the project root; do not go hunting in unrelated "
        "directories unless the user explicitly asks.\n"
        "- SAY SO WHEN A REQUEST IS NOT ABOUT THIS PROJECT. The owner keeps "
        "one chat per project and types into whichever is open, so a message "
        "meant for another project lands here regularly. Judge it by meaning, "
        "not by keywords: a question about stock profits does not belong in a "
        "mouse-clicker project, whatever words it uses. When a request plainly "
        "belongs elsewhere, answer with one short line naming which project it "
        "sounds like and asking whether to continue here - and change nothing "
        "and run nothing until they say yes. If it is merely ambiguous, ask "
        "before acting. Answering an off-project question as though it "
        "belonged here is the failure mode: he was able to ask this chat about "
        "another project's numbers and get an answer, which is how work ends "
        "up in the wrong place.\n"
        "- If several files match, Read the most likely one first, then "
        "mention the other candidates by relative path.\n"
        "- When creating or changing project files, use the Write/Edit "
        "tools rather than shell redirection (`>`/`tee`) - the user's "
        "viewer follows Write/Edit live, so they can watch the work happen."
    )


def claude_reads_its_own_rules():
    """True when Claude Code will pick up the owner's rules without help.

    It reads ~/.claude/CLAUDE.md and a CLAUDE.md beside the project. If either
    exists there is no reason for AWBN to inject a second copy of the same
    preferences, and every reason not to: a duplicated instruction is one more
    thing competing with the actual message.
    """
    home = os.path.expanduser("~/.claude/CLAUDE.md")
    return os.path.isfile(home) or os.path.isfile(os.path.expanduser("~/CLAUDE.md"))


def response_style_prompt():
    """Build the user's configured response-style instruction for --append-system-prompt.

    Stored under config['claude_orchestration']['response_style'] = {preset, custom}.
    A preset template and an optional free-text custom block are combined; an empty
    result means 'use the model's default behavior'.
    """
    config = load_json(CONFIG_FILE, {}) or {}
    style = (config.get("claude_orchestration") or {}).get("response_style") or {}
    if not isinstance(style, dict):
        style = {}
    # Default to Plain & Direct (not "detailed") so responses stay tight out of the
    # box — verbose default output bloats sessions and can drop Codex streams.
    preset = clean_text(style.get("preset")).lower() or "plain"
    parts = [ACK_BEFORE_WORK, CHAT_RESULT_DISCIPLINE]
    if preset != "custom":
        template = RESPONSE_STYLE_TEMPLATES.get(preset, "")
        if template:
            parts.append(template)
    custom = clean_text(style.get("custom"))
    if custom:
        parts.append("Additional user response rules:\n" + custom)
    return "\n\n".join(parts)


def history_messages(session):
    messages = []
    for turn in session.get("turns", []):
        if turn.get("status") == "running":
            continue
        for item in turn.get("items", []):
            kind = item.get("type")
            if kind == "userMessage":
                content = item.get("content")
                if isinstance(content, list):
                    text = "".join(
                        part.get("text", "") if isinstance(part, dict) else str(part)
                        for part in content
                    )
                elif isinstance(content, dict):
                    text = content.get("text", "")
                else:
                    text = str(content or "")
                if text.strip():
                    messages.append({"role": "user", "content": text})
            elif kind == "agentMessage":
                text = clean_text(item.get("text"))
                if text:
                    messages.append({"role": "assistant", "content": text})
    return messages


def prior_history_messages(session):
    messages = history_messages(session)
    if messages and messages[-1].get("role") == "user":
        return messages[:-1]
    return messages


def pick_backend(session):
    agent = clean_text(session.get("agent")).lower()
    config = load_json(CONFIG_FILE, {}) or {}
    custom_keys = {
        clean_text(client.get("key")).lower()
        for client in (config.get("custom_clients") or [])
        if isinstance(client, dict) and clean_text(client.get("key"))
    }
    backend = session.get("backend") or {}
    custom_key = clean_text(backend.get("custom_client_key")).lower()
    if agent in custom_keys or custom_key in custom_keys:
        return "custom"
    if "claude" in agent:
        return "claude"
    if "codex" in agent or "gpt" in agent:
        return "codex"
    if "gemini" in agent:
        return "gemini"
    if "hermes" in agent:
        return "hermes"
    return "ollama"


VIDEO_EXTENSIONS = {
    "3g2",
    "3gp",
    "avi",
    "m4v",
    "mkv",
    "mov",
    "mp4",
    "mpeg",
    "mpg",
    "ogv",
    "webm",
    "wmv",
}


def prompt_with_attachments(prompt, paths, video_previews=None):
    readable = [path for path in paths if os.path.isfile(path)]
    if not readable:
        return prompt
    attachment_note = (
        f"{prompt.rstrip()}\n\n"
        "The user attached the following local files. Inspect each relevant file "
        "with the appropriate file or image-reading tool before answering:\n- "
        + "\n- ".join(readable)
    )
    preview_lines = []
    for preview in video_previews or []:
        source = preview.get("source") or ""
        frames = [frame for frame in preview.get("frames") or [] if os.path.isfile(frame)]
        if not frames:
            continue
        preview_lines.append(
            f"Video preview frames generated for {source}:\n- "
            + "\n- ".join(frames)
        )
    if preview_lines:
        attachment_note += (
            "\n\nFor attached video files, inspect these generated frame images "
            "before answering. They are sampled from the video timeline:\n\n"
            + "\n\n".join(preview_lines)
        )
    elif any(attachment_is_video(path) for path in readable):
        attachment_note += (
            "\n\nAt least one attached file is a video. The file reader cannot play "
            "video directly; use ffprobe/ffmpeg or extract frames before answering."
        )
    return attachment_note


def attachment_is_image(path):
    return os.path.splitext(path)[1].lower().lstrip(".") in {
        "avif",
        "bmp",
        "gif",
        "heic",
        "heif",
        "ico",
        "jpg",
        "jpeg",
        "png",
        "svg",
        "tif",
        "tiff",
        "webp",
    }


def attachment_is_video(path):
    return os.path.splitext(path)[1].lower().lstrip(".") in VIDEO_EXTENSIONS


def attachment_metadata(paths):
    return [
        {
            "name": os.path.basename(path),
            "path": path,
            "is_image": attachment_is_image(path),
            "is_video": attachment_is_video(path),
        }
        for path in paths or []
        if clean_text(path)
    ]


def video_duration_seconds(path):
    if not shutil.which("ffprobe"):
        return 0.0
    try:
        result = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                path,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=10,
            check=False,
        )
        return max(0.0, float((result.stdout or "0").strip() or 0))
    except Exception:
        return 0.0


def video_sample_timestamps(duration):
    if duration and duration > 1:
        fractions = [0.08, 0.25, 0.5, 0.75, 0.92]
        return sorted({max(0.1, min(duration - 0.1, duration * value)) for value in fractions})
    return [0.1, 1.0, 2.0]


def video_preview_slug(path):
    stem = re.sub(
        r"[^A-Za-z0-9._-]+",
        "-",
        Path(path).stem,
    ).strip("-")[:42] or "video"
    digest = hashlib.sha1(
        f"{os.path.abspath(path)}:{os.path.getmtime(path) if os.path.exists(path) else 0}".encode(
            "utf-8"
        )
    ).hexdigest()[:8]
    return f"{stem}-{digest}"


def generate_video_attachment_previews(session_id, paths):
    videos = [path for path in paths or [] if os.path.isfile(path) and attachment_is_video(path)]
    if not videos or not shutil.which("ffmpeg"):
        return []
    previews = []
    root = os.path.join(artifact_session_dir(session_id), "video-previews")
    ensure_private_dir(root)
    for source in videos[:3]:
        preview_dir = os.path.join(root, video_preview_slug(source))
        ensure_private_dir(preview_dir)
        frames = []
        duration = video_duration_seconds(source)
        for index, timestamp in enumerate(video_sample_timestamps(duration), start=1):
            destination = os.path.join(preview_dir, f"frame-{index:02d}.jpg")
            if os.path.isfile(destination) and os.path.getsize(destination) > 0:
                ensure_private_file(destination)
                frames.append(destination)
                continue
            try:
                result = subprocess.run(
                    [
                        "ffmpeg",
                        "-hide_banner",
                        "-loglevel",
                        "error",
                        "-y",
                        "-ss",
                        f"{timestamp:.3f}",
                        "-i",
                        source,
                        "-frames:v",
                        "1",
                        "-vf",
                        "scale=960:-2",
                        "-q:v",
                        "3",
                        destination,
                    ],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=25,
                    check=False,
                )
                if result.returncode == 0 and os.path.isfile(destination) and os.path.getsize(destination) > 0:
                    ensure_private_file(destination)
                    frames.append(destination)
            except Exception:
                continue
        if frames:
            previews.append(
                {
                    "source": source,
                    "duration_seconds": duration,
                    "frames": frames,
                }
            )
    return previews


def safe_artifact_session_key(session_id):
    label = re.sub(r"[^A-Za-z0-9._-]+", "-", session_id).strip("-")[:48] or "session"
    digest = hashlib.sha1(session_id.encode("utf-8")).hexdigest()[:8]
    return f"{label}-{digest}"


def artifact_session_dir(session_id):
    path = os.path.join(CONFIG_DIR, "artifacts", safe_artifact_session_key(session_id))
    ensure_private_dir(path)
    return path


def handoff_item_text(item):
    kind = item.get("type", "")
    if kind == "userMessage":
        content = item.get("content")
        if isinstance(content, list):
            return clean_text(
                " ".join(
                    part.get("text", "")
                    for part in content
                    if isinstance(part, dict)
                )
            )
        if isinstance(content, dict):
            return clean_text(content.get("text"))
        return clean_text(content)
    if kind == "fileChange":
        changes = item.get("changes") or []
        if changes:
            return clean_text(
                ", ".join(
                    str(change.get("path") or change.get("filePath") or "")
                    for change in changes
                    if isinstance(change, dict)
                )
            )
    if kind == "reasoning":
        summary = item.get("summary")
        if isinstance(summary, list):
            return clean_text(" ".join(map(str, summary)))
    return clean_text(
        item.get("text")
        or item.get("content")
        or item.get("command")
        or item.get("summary")
    )


def unique_handoff_values(values, limit=None, item_limit=1400):
    result = []
    seen = set()
    for value in values:
        value = clean_text(value)
        normalized = re.sub(r"\s+", " ", value)
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        if len(value) > item_limit:
            value = value[: item_limit - 1].rstrip() + "…"
        result.append(value)
        if limit and len(result) >= limit:
            break
    return result


def handoff_section(name, values, fallback="None recorded.", limit=None, item_limit=1400):
    values = unique_handoff_values(values, limit=limit, item_limit=item_limit)
    body = "\n".join(f"- {value}" for value in values) if values else f"- {fallback}"
    return f"## {name}\n{body}"


def structured_handoff_packet(session, max_chars=HANDOFF_MAX_CHARS, minimal=False):
    title = clean_text(session.get("title") or "Untitled")
    agent = clean_text(session.get("agent") or "agent").title()
    cwd = infer_project_root(session, session.get("cwd") or os.path.expanduser("~"))
    if cwd and session.get("project_root") != cwd:
        session["project_root"] = cwd
    context = session.get("context") or {}

    first_user_request = ""
    last_user_request = ""
    last_agent_conclusion = ""
    failures = []
    commands = []
    file_changes = []

    def last_line(text):
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        return lines[-1] if lines else text.strip()

    def truncate(text, limit=160):
        text = re.sub(r"\s+", " ", clean_text(text)).strip()
        return text[:limit - 1].rstrip() + "…" if len(text) > limit else text

    # A CLI launch line (claude -p …, codex exec …) is not a real "update".
    def is_launch_noise(text):
        low = text.lower()
        return any(
            marker in low
            for marker in (
                "stream-json",
                "--dangerously-skip-permissions",
                "--append-system-prompt",
                "--permission-mode",
                "--output-format",
            )
        )

    # A user-initiated Stop (or transient stream drop) is not a project blocker,
    # and a raw Python/traceback error string is not usable session state.
    def is_transient_error(text):
        low = text.strip().lower()
        return (
            "turn stopped" in low
            or "ended as cancelled" in low
            or "ended as stopped" in low
            or low.startswith("error: turn stopped")
            or "int() argument" in low
            or "traceback (most recent call last)" in low
            or "connection closed mid-response" in low
        )

    # Drop a leaked error string from being surfaced as "where it left off".
    def clean_conclusion(text):
        if not text:
            return ""
        low = text.strip().lower()
        if low.startswith("error:") or is_transient_error(low):
            return ""
        return text

    for turn_index, turn in enumerate(session.get("turns") or [], start=1):
        user_texts = []
        agent_texts = []
        for item in turn.get("items") or []:
            kind = item.get("type", "")
            text = handoff_item_text(item)
            if not text:
                continue
            if kind == "userMessage":
                user_texts.append(text)
                if not first_user_request:
                    first_user_request = truncate(text, 300)
                # The LATEST user ask is the single most important thing to carry
                # — it's what the continuing agent must actually do next.
                last_user_request = truncate(text, 400)
            elif kind == "agentMessage":
                agent_texts.append(text)
                last_agent_conclusion = text
            elif kind == "commandExecution":
                # Skip CLI launch lines — they aren't project changes.
                if not is_launch_noise(text):
                    commands.append(truncate(text))
            elif kind == "fileChange":
                file_changes.append(truncate(text))
            elif kind in {"note", "report"}:
                if text.startswith("ERROR:") and not is_transient_error(text):
                    failures.append(truncate(f"Turn {turn_index}: {text}"))
        # A turn that ended abnormally is a blocker ONLY if it wasn't a user Stop
        # or a transient stream error (those are noise, not project state).
        status = turn.get("status")
        if status not in {None, "completed"} and status not in {"cancelled", "stopped", "interrupted"}:
            reason = clean_text(turn.get("prompt")) or "no prompt"
            # If the "reason" is just the user's prompt (already in Latest request)
            # or a transient error, a bare status note is enough — no echo.
            if is_transient_error(reason) or truncate(reason, 400) == last_user_request:
                failures.append(f"Turn {turn_index} ended as {status}")
            else:
                failures.append(truncate(f"Turn {turn_index} ended as {status}: {reason}"))

    def detect_project_commands(cwd):
        """Return (bullets: list[str], is_software_project: bool) for the project at cwd."""
        result = []
        is_software = False
        if not cwd or not os.path.isdir(cwd):
            result += [
                f'cd "{cwd or os.path.expanduser("~")}"',
                "git status",
                "git log --oneline -10",
                "ls",
            ]
            return result, False

        pkg_json = os.path.join(cwd, "package.json")
        if os.path.isfile(pkg_json):
            is_software = True
            try:
                with open(pkg_json, encoding="utf-8") as fh:
                    pkg = json.load(fh)
            except Exception:
                pkg = {}
            scripts = pkg.get("scripts") or {}
            deps_all = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            script_text = json.dumps(scripts).lower()
            has_tauri = os.path.isdir(os.path.join(cwd, "src-tauri")) or "tauri" in script_text or "tauri" in " ".join(deps_all).lower()
            result.append("pnpm install - install deps")
            for name, desc in [("dev", "start dev server"), ("build", "production build"),
                                ("test", "run tests"), ("check", "type-check"),
                                ("lint", "lint code")]:
                if name in scripts:
                    result.append(f"pnpm {name} - {desc}")
            if has_tauri:
                result.append("pnpm tauri dev - launch Tauri desktop app")
                result.append("pnpm tauri build - build distributable")

        cargo = os.path.join(cwd, "Cargo.toml")
        if os.path.isfile(cargo):
            is_software = True
            result += ["cargo build - compile", "cargo test - run tests", "cargo run - run binary"]

        has_py = os.path.isfile(os.path.join(cwd, "pyproject.toml")) or \
                 os.path.isfile(os.path.join(cwd, "requirements.txt")) or \
                 any(f.endswith(".py") for f in (os.listdir(cwd) if os.path.isdir(cwd) else []))
        if has_py:
            is_software = True
            if os.path.isfile(os.path.join(cwd, "pyproject.toml")):
                result.append("python3 -m pytest - run tests")
            else:
                result.append("python3 <script>.py - run entry point")

        result += [f'cd "{cwd}"', "git status", "git log --oneline -10", "ls"]
        # Cap to 6 most relevant; dedupe
        seen, final = set(), []
        for item in result:
            k = item.lower().strip()
            if k not in seen:
                seen.add(k)
                final.append(item)
            if len(final) >= 6:
                break
        return final, is_software

    goal = first_user_request or "No user request recorded."
    latest_request = last_user_request or "(none recorded - read the shared state and git log to infer the current objective)"
    # Where it left off: the last substantive agent conclusion, with leaked error
    # strings scrubbed so we never hand off a Python traceback as "state".
    left_off = clean_conclusion(truncate(last_line(last_agent_conclusion), 300))
    if not left_off:
        left_off = "No clean conclusion recorded - check `git log --oneline -15` and the shared state for the actual current state."

    used = int(context.get("used") or 0)
    limit = int(context.get("limit") or 0)
    context_line = (
        f"{round(used * 100 / limit)}% ({used:,}/{limit:,} tokens)"
        if used > 0 and limit > 0
        else "unknown"
    )

    cmd_bullets, is_sw_project = detect_project_commands(cwd)
    state_path = project_state_path(cwd)
    registry_path = project_registry_path(cwd)
    state_instruction = (
        f"- Read `{state_path}` first; it is the shared state across Claude, Codex, Gemini, and local models."
        if state_path
        else f"- If `{PROJECT_STATE_FILENAME}` exists in the project root, read it first; it is shared state across Claude, Codex, Gemini, and local models."
    )
    if minimal:
        parts = [
            "# Session Handoff - read the source of truth, not a transcript summary",
            f"- Project: {cwd}  ·  From: {title} ({agent})  ·  {now_iso()}",
            "",
            "## Do this, in order",
            state_instruction,
            "- Use `git log --oneline -15` and `git status` for recent history; this handoff is intentionally lean and does not duplicate the full chat transcript.",
            "- Then continue the user's latest unresolved objective after a brief acknowledgment without asking them to repeat context.",
        ] + (["- Before changing code: read the relevant files first, and run the relevant build/check command so you know the current baseline."] if is_sw_project else [])
        return "\n".join(parts)[:max_chars]

    changes_section = handoff_section(
        "Recent file changes", file_changes[-10:], item_limit=160
    )
    real_updates = [c for c in commands if c][-6:]
    parts = [
        f"# Session Handoff - {title} ({agent})",
        f"- Project: {cwd}",
        f"- Shared state: {state_path or 'unavailable'}  (read this first)",
        f"- Context at handoff: {context_line}",
        f"- Generated: {now_iso()}",
        "",
        f"## Goal\n{goal}",
        "",
        f"## Latest request - continue this\n{latest_request}",
        "",
        f"## Where it left off\n{left_off}",
        "",
        changes_section,
    ]
    if real_updates:
        parts += ["", handoff_section("Commands run", real_updates, item_limit=160)]
    if failures:
        parts += [
            "",
            handoff_section("Blockers / unresolved", failures[-8:], item_limit=160),
        ]
    parts += [
        "",
        "## Useful commands\n" + "\n".join(f"- {b}" for b in cmd_bullets),
        "",
        "## Continue",
        state_instruction,
        "- Run `git status` and `git log --oneline -15` for the current baseline - this handoff is intentionally lean and is NOT a chat transcript.",
        "- Continue the latest request above after a brief acknowledgment; do not ask the user to repeat context.",
        "- Don't repeat an approach already recorded as a blocker without a reason.",
    ] + (["- Before changing code: read the relevant files and run the build/check command above so you know the current state."] if is_sw_project else [])
    packet = "\n".join(parts)
    if len(packet) > max_chars:
        packet = packet[: max_chars - 160].rstrip() + (
            "\n\n[Handoff truncated at the configured safety limit. "
            "The categorized sections above take priority.]"
        )
    return packet


def handoff_signature(session):
    turns = session.get("turns") or []
    context = session.get("context") or {}
    last_turn = turns[-1] if turns else {}
    return "|".join(
        [
            str(len(turns)),
            clean_text(session.get("updated_at")),
            clean_text(last_turn.get("id")),
            clean_text(last_turn.get("status")),
            str(context.get("used") or 0),
            str(context.get("limit") or 0),
            str(context.get("compact_count") or 0),
        ]
    )


def stage_handoff(session, force=False):
    try:
        session = refresh_session_from_native_transcript(session)
    except Exception:
        pass
    context = session.get("context") or {}
    used = int(context.get("used") or 0)
    limit = int(context.get("limit") or 0)
    percent = round(used * 100 / limit) if used > 0 and limit > 0 else 0
    compact_count = int(context.get("compact_count") or 0)
    if not force and percent < HANDOFF_WARNING_PERCENT and compact_count <= 0:
        return ""
    signature = handoff_signature(session)
    existing = clean_text(session.get("handoff_stage_artifact"))
    if (
        not force
        and session.get("handoff_stage_ready")
        and session.get("handoff_stage_signature") == signature
        and os.path.isfile(existing)
    ):
        return existing
    try:
        refresh_project_state_file(
            session,
            force=force
            and clean_text(session.get("project_state_signature")) != signature,
            reason="handoff_stage",
        )
    except Exception:
        pass
    path = os.path.join(artifact_session_dir(session["id"]), "HANDOFF.md")
    save_text_atomic(path, structured_handoff_packet(session))
    session["handoff_stage_ready"] = True
    session["handoff_stage_signature"] = signature
    session["handoff_stage_artifact"] = path
    session["handoff_stage_updated_at"] = now_iso()
    return path


def all_sessions():
    """Return every local session, including worker sessions."""
    sessions = []
    try:
        names = os.listdir(SESS_DIR)
    except OSError:
        return sessions
    for name in names:
        if not name.endswith(".json"):
            continue
        session = load_json(os.path.join(SESS_DIR, name))
        if isinstance(session, dict):
            sessions.append(session)
    return sessions


def sessions_for_handoff_title(agent_key, project_root):
    agent_key = clean_text(agent_key)
    return [
        session
        for session in all_sessions()
        if clean_text(session.get("agent")) == agent_key
        and session_matches_project_root(session, project_root)
    ]


def session_matches_project_root(session, project_root):
    if not project_root:
        return True
    root = infer_project_root(session, session.get("cwd") or project_root)
    return bool(root and roots_related(project_root, root))


def title_sequence_value(title, base):
    title = clean_text(title)
    base = clean_text(base)
    if not title or not base:
        return None
    if title.casefold() == base.casefold():
        return 1
    match = re.match(
        rf"^{re.escape(base)}\s+(\d+)$",
        title,
        flags=re.IGNORECASE,
    )
    if not match:
        return None
    return max(1, int(match.group(1)))


def source_handoff_base_title(source, project_root):
    current = clean_text(source.get("title") or "Session")
    # 1. The project registry's display_name is AUTHORITATIVE: every continuation
    #    reads "<Project> N", even when the source chat has a wandering auto-title
    #    (e.g. "could you open my ollama…") or a poisoned handoff_base_title from an
    #    earlier bad continuation. This wins over the stored base so a once-broken
    #    chain self-heals.
    _path, registry = read_project_registry(project_root)
    registry_name = clean_text(registry.get("display_name"))
    if registry_name and not registry_name.lower().startswith("new "):
        return registry_name
    # 2. With no registry name, an explicitly stored base (e.g. a worker's
    #    descriptive chain name) beats the bare directory-basename fallback.
    base = clean_text(source.get("handoff_base_title"))
    if base:
        return base
    # 3. Fall back to the directory name, then the source-title heuristic.
    if clean_text(project_root):
        dir_name = clean_text(project_label(project_root))
        if dir_name:
            return dir_name
    base = current or "Session"
    match = re.match(r"^(.*?)\s+(\d+)$", current)
    if not match or int(match.group(2)) < 2:
        return base
    candidate_base = clean_text(match.group(1))
    source_agent = clean_text(source.get("agent"))
    if clean_text(source.get("handoff_sequence")):
        return candidate_base
    for session in sessions_for_handoff_title(source_agent, project_root):
        if session.get("id") == source.get("id"):
            continue
        if title_sequence_value(clean_text(session.get("title")), candidate_base):
            return candidate_base
    return base


def next_handoff_title(source, target_agent=None):
    target_agent = clean_text(target_agent or source.get("agent"))
    project_root = infer_project_root(source, source.get("cwd") or os.path.expanduser("~"))
    base = source_handoff_base_title(source, project_root)
    highest = 0
    for session in sessions_for_handoff_title(target_agent, project_root):
        value = title_sequence_value(clean_text(session.get("title")), base)
        if value:
            highest = max(highest, value)
    # The source session occupies at least sequence 1 in this project's chain — even
    # when its own auto-generated title (e.g. "could you open my ollama…") doesn't
    # match the canonical base — so the first handoff lands on "<base> 2", not a
    # bare "<base>", and every continuation thereafter increments by one.
    source_seq = title_sequence_value(clean_text(source.get("title")), base)
    if not source_seq:
        try:
            source_seq = int(source.get("handoff_sequence") or 0)
        except (TypeError, ValueError):
            source_seq = 0
    highest = max(highest, source_seq or 1)
    sequence = highest + 1
    title = base if sequence == 1 else f"{base} {sequence}"
    return title, base, sequence


def known_agent_keys():
    keys = {"claude", "codex", "hermes", "ollama"}
    config = load_json(CONFIG_FILE, {}) or {}
    for client in config.get("custom_clients") or []:
        if isinstance(client, dict) and clean_text(client.get("key")):
            keys.add(clean_text(client.get("key")))
    return keys


def handoff_intro_text(source, artifact_path, state_path=""):
    """The first thing shown in a continuation chat, so it is never blank."""
    source_title = clean_text((source or {}).get("title")) or "the previous chat"
    lines = [
        f"**Carried on from \"{source_title}\".**",
        "",
        "This chat picks up where that one stopped. The full notes are saved "
        "and get read before anything else happens here.",
        "",
        f"- Notes: `{artifact_path}`",
    ]
    if state_path:
        lines.append(f"- Project state: `{state_path}`")
    turns = (source or {}).get("turns")
    if isinstance(turns, list) and turns:
        lines.append(f"- Came from {len(turns)} messages of history")
    lines += [
        "",
        "Send your next message and it carries straight on.",
    ]
    return "\n".join(lines)


def free_handoff_title(source, target_agent, wanted, base_title, sequence):
    """A continuation name nobody is already sitting on.

    The app suggests one by adding 1 to the current session's number, which
    knows nothing about what exists: from "<name> 2" it always proposes
    "<name> 3". When an earlier handoff already left a session on that
    name, deploy failed with "already has a project session named ..." - an
    error the owner could do nothing about, from a button whose whole job is to
    pick the name. Step past the taken ones instead of refusing.

    A name the owner typed themselves is left alone; only the suggested one is
    advanced, and the created session is returned so the real name is shown.
    """
    root = infer_project_root(
        source, (source or {}).get("cwd") or os.path.expanduser("~")
    )
    if not root or not clean_text(target_agent) or not clean_text(wanted):
        return wanted
    taken = {
        clean_text(existing.get("title")).casefold()
        for existing in sessions_for_handoff_title(target_agent, root)
    }
    if clean_text(wanted).casefold() not in taken:
        return wanted
    base = clean_text(base_title)
    match = re.match(r"^(.*?)\s*(\d+)$", clean_text(wanted))
    if match:
        base = clean_text(match.group(1)) or base
        start = safe_int(match.group(2)) or 2
    else:
        base = base or clean_text(wanted)
        start = safe_int(sequence) or 2
    if not base:
        return wanted
    for number in range(start + 1, start + 500):
        candidate = f"{base} {number}"
        if candidate.casefold() not in taken:
            return candidate
    return wanted


def validate_handoff_plan(source, target_agent, title, state_path):
    errors = []
    warnings = []
    root = infer_project_root(source, (source or {}).get("cwd") or os.path.expanduser("~"))
    if not root or not os.path.isdir(root):
        errors.append("Could not resolve an existing project root.")
    if clean_text(target_agent) not in known_agent_keys():
        errors.append(f"Unknown target agent: {target_agent or '(blank)'}")
    if not clean_text(title):
        errors.append("Continuation title is blank.")
    if not state_path or not os.path.isfile(state_path):
        warnings.append("Shared project state file is missing or could not be refreshed.")
    exact = []
    if root and clean_text(target_agent):
        for session in sessions_for_handoff_title(target_agent, root):
            if clean_text(session.get("title")).casefold() == clean_text(title).casefold():
                exact.append(session)
        if exact:
            errors.append(
                f"Target {target_agent} already has a project session named '{title}'."
            )
    registry_path = ""
    if not errors and root:
        registry_path = ensure_project_registry(
            root,
            session=source,
            agent_key=target_agent,
            title=title,
            state_path=state_path or project_state_path(root),
        )
        if not registry_path or not os.path.isfile(registry_path):
            warnings.append("Project registry could not be written.")
    return {
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "project_root": root,
        "registry_path": registry_path,
    }


def deploy_handoff(
    source_id, target_agent, model, effort, automatic=False, title_override=""
):
    with locked_sessions(source_id):
        return _deploy_handoff_locked(
            source_id, target_agent, model, effort, automatic, title_override
        )


def _deploy_handoff_locked(
    source_id, target_agent, model, effort, automatic=False, title_override=""
):
    source = load_session(source_id)
    try:
        source = refresh_session_from_native_transcript(source)
    except Exception:
        pass
    state_path, registry_path = refresh_project_state_file(
        source,
        force=True,
        reason="handoff_deploy",
    )
    stage_handoff(source, force=True)
    packet = structured_handoff_packet(source, minimal=True)
    save_session(source)
    title, base_title, sequence = next_handoff_title(source, target_agent)
    requested_title = clean_text(title_override)
    if requested_title:
        title = requested_title
        parsed_sequence = title_sequence_value(title, base_title)
        if parsed_sequence:
            sequence = parsed_sequence
        else:
            match = re.match(r"^(.*?)\s+(\d+)$", title)
            if match:
                base_title = clean_text(match.group(1)) or base_title
                try:
                    sequence = int(match.group(2))
                except ValueError:
                    pass
    title = free_handoff_title(source, target_agent, title, base_title, sequence)
    validation = validate_handoff_plan(source, target_agent, title, state_path)
    if not validation["ok"]:
        raise RuntimeError("Handoff validation failed: " + "; ".join(validation["errors"]))
    registry_path = validation.get("registry_path") or registry_path
    project_root = validation.get("project_root") or infer_project_root(
        source,
        source.get("cwd"),
    )
    launch_cwd = project_root or source.get("cwd") or os.path.expanduser("~")
    # A project chat runs in the folder the owner actually opened, which is not
    # always the inferred project root, and a handoff has to stay in it.
    if source.get("project_chat"):
        source_cwd = clean_text(source.get("cwd"))
        if source_cwd and os.path.isdir(source_cwd):
            launch_cwd = source_cwd
    timestamp = now_iso()
    session = {
        "id": str(uuid.uuid4()),
        "title": title,
        "agent": target_agent,
        "backend": {"model": model},
        "cwd": launch_cwd,
        "project_root": project_root,
        "origin": "local",
        "created_at": timestamp,
        "updated_at": timestamp,
        "turns": [],
        "handoff_from": source_id,
        "handoff_base_title": base_title,
        "handoff_sequence": sequence,
    }
    # Hand off FROM a project and you must land back IN that project. The app
    # chooses which view to open from these two fields, so without them the
    # continuation opened as a loose conversation with no file tree and no
    # viewer beside it (reported: "should be handing off to a new project
    # view").
    if source.get("project_chat"):
        session["project_chat"] = True
        source_project_id = clean_text(source.get("project_id"))
        if source_project_id:
            session["project_id"] = source_project_id
        source_native_cwd = clean_text(source.get("native_cwd"))
        if source_native_cwd:
            session["native_cwd"] = source_native_cwd
    if target_agent != "gemini" and effort and effort != "Default":
        session["backend"]["effort"] = effort
    target_artifact = os.path.join(artifact_session_dir(session["id"]), "HANDOFF.md")
    save_text_atomic(target_artifact, packet)
    session["handoff_artifact"] = target_artifact
    session["handoff_context"] = (
        "Read the authoritative continuation handoff before acting:\n"
        f"{target_artifact}"
        + (f"\n\nAlso read the shared project state before acting:\n{state_path}" if state_path else "")
        + (f"\n\nAlso read the project registry before acting:\n{registry_path}" if registry_path else "")
    )
    session["handoff_stage_ready"] = True
    session["handoff_stage_signature"] = handoff_signature(source)
    session["handoff_stage_artifact"] = target_artifact
    session["handoff_stage_updated_at"] = timestamp
    # Say so, on screen, straight away. The handoff notes are only pushed into
    # the FIRST prompt, so until the owner typed something the continuation
    # opened as an empty chat reading "No messages loaded", with nothing to say
    # a handoff had happened at all (reported: "even though it's handed off
    # it's just blank chat, no indication of hand off"). One seeded message
    # makes the link visible the moment it opens.
    session["turns"] = [
        {
            "id": str(uuid.uuid4()),
            "created_at": timestamp,
            "completed_at": timestamp,
            "status": "completed",
            "items": [
                {
                    "type": "agentMessage",
                    "text": handoff_intro_text(source, target_artifact, state_path),
                }
            ],
        }
    ]
    save_session(session)
    ensure_project_registry(
        validation.get("project_root") or session.get("cwd"),
        session=session,
        agent_key=target_agent,
        title=title,
        state_path=state_path,
        sequence=sequence,
    )
    if automatic:
        source["auto_handoff_signature"] = handoff_signature(source)
        source["auto_handoff_deployed_at"] = timestamp
        source["auto_handoff_target_session_id"] = session["id"]
        save_session(source)
    append_debug_event(
        "handoff_deploy",
        source=source_id,
        target=session["id"],
        target_agent=target_agent,
        title=title,
        cwd=launch_cwd,
        project_root=project_root,
        state_path=state_path,
        registry_path=registry_path,
    )
    return session


def deploy_handoff_to_existing(source_id, target_id):
    with locked_sessions(source_id, target_id):
        return _deploy_handoff_to_existing_locked(source_id, target_id)


def _deploy_handoff_to_existing_locked(source_id, target_id):
    source = load_session(source_id)
    target = load_session(target_id)
    if source.get("id") == target.get("id"):
        raise ValueError("Choose a different target session for the handoff.")
    if target.get("worker_parent_session_id"):
        raise ValueError("Worker sessions cannot receive handoff injections.")
    root = infer_project_root(source, source.get("cwd") or os.path.expanduser("~"))
    target_root = infer_project_root(target, target.get("cwd") or os.path.expanduser("~"))
    if not root or not target_root or not roots_related(root, target_root):
        raise ValueError(
            "Existing handoff target belongs to a different project. "
            "Create a new handoff session to prevent shared-state leaks."
        )
    try:
        source = refresh_session_from_native_transcript(source)
    except Exception:
        pass
    state_path, registry_path = refresh_project_state_file(
        source,
        force=True,
        reason="handoff_existing",
    )
    stage_handoff(source, force=True)
    packet = structured_handoff_packet(source, minimal=True)
    timestamp = now_iso()
    if root:
        registry_path = ensure_project_registry(
            root,
            session=source,
            agent_key=clean_text(target.get("agent")),
            title=clean_text(target.get("title")),
            state_path=state_path or project_state_path(root),
        ) or registry_path
    target_artifact = os.path.join(artifact_session_dir(target["id"]), "HANDOFF.md")
    save_text_atomic(target_artifact, packet)
    target["handoff_artifact"] = target_artifact
    target["cwd"] = root or target.get("cwd")
    target["project_root"] = root or target.get("project_root")
    target["pending_handoff_project_root"] = root
    target["pending_handoff_state_path"] = state_path
    target["pending_handoff_context"] = (
        "This handoff is being injected into an existing session. Read it before "
        "answering, then continue the latest unresolved objective without asking "
        "the user to repeat context.\n"
        f"{target_artifact}"
        + (f"\n\nAlso read the shared project state before acting:\n{state_path}" if state_path else "")
        + (f"\n\nAlso read the project registry before acting:\n{registry_path}" if registry_path else "")
    )
    target["pending_handoff_from"] = clean_text(source.get("id"))
    target["pending_handoff_artifact"] = target_artifact
    target["updated_at"] = timestamp
    target.setdefault("turns", []).append(
        {
            "id": str(uuid.uuid4()),
            "created_at": timestamp,
            "completed_at": timestamp,
            "status": "injected",
            "items": [
                {
                    "type": "report",
                    "tag": "report",
                    "content": (
                        "Handoff packet staged from "
                        f"{clean_text(source.get('title')) or source.get('id')}."
                    ),
                }
            ],
        }
    )
    save_session(source)
    save_session(target)
    append_debug_event(
        "handoff_existing",
        source=source_id,
        target=target_id,
        target_agent=clean_text(target.get("agent")),
        title=clean_text(target.get("title")),
        project_root=root,
        state_path=state_path,
        registry_path=registry_path,
    )
    return target


def default_handoff_target(source_agent):
    config = load_json(CONFIG_FILE, {}) or {}
    preferences = config.get("handoff_preferences") or {}
    mode = clean_text(preferences.get("mode") or "current")
    sequence = [
        clean_text(agent)
        for agent in preferences.get("sequence") or []
        if clean_text(agent)
    ]
    supported = known_agent_keys()
    if mode == "fixed":
        target = clean_text(preferences.get("fixed_agent")) or source_agent
    elif mode == "sequence" and sequence:
        target = (
            sequence[(sequence.index(source_agent) + 1) % len(sequence)]
            if source_agent in sequence
            else sequence[0]
        )
    else:
        target = source_agent
    if target not in supported:
        target = source_agent if source_agent in supported else "claude"
    settings = (config.get("agent_settings") or {}).get(target) or {}
    client = None
    for candidate in config.get("custom_clients") or []:
        if isinstance(candidate, dict) and clean_text(candidate.get("key")) == target:
            client = candidate
            break
    prefer_cheap = bool(preferences.get("prefer_cheap_models", True))
    cheap_models = {
        "claude": "sonnet",
        "codex": "gpt-5.4-mini",
        "hermes": "Default",
    }
    default_models = {
        "claude": default_model_for("claude"),
        "codex": default_model_for("codex"),
        "hermes": default_model_for("hermes"),
        "ollama": (visible_ollama_models() or ["qwen3-coder:30b"])[0],
    }
    if client is not None:
        default_models[target] = (
            clean_text(client.get("model"))
            or clean_text(client.get("label"))
            or "Default"
        )
    default_efforts = {
        "claude": DEFAULT_AGENT_SETTINGS["claude"]["effort"],
        "codex": DEFAULT_AGENT_SETTINGS["codex"]["effort"],
        "hermes": DEFAULT_AGENT_SETTINGS["hermes"]["effort"],
        "ollama": "Default",
    }
    model = (
        cheap_models.get(target)
        if prefer_cheap and target in cheap_models
        else clean_text(settings.get("model"))
    ) or default_models[target]
    effort = (
        "low"
        if prefer_cheap and target in {"claude", "codex"}
        else clean_text(settings.get("effort")) or default_efforts.get(target, "Default")
    )
    return target, model, effort


def maybe_auto_deploy_handoff(source_id):
    with locked_sessions(source_id):
        return _maybe_auto_deploy_handoff_locked(source_id)


def _maybe_auto_deploy_handoff_locked(source_id):
    config = load_json(CONFIG_FILE, {}) or {}
    preferences = config.get("handoff_preferences") or {}
    if not preferences.get("auto_deploy"):
        return None
    source = load_session(source_id)
    artifact = stage_handoff(source)
    if not artifact:
        return None
    signature = handoff_signature(source)
    if clean_text(source.get("auto_handoff_signature")) == signature:
        return None
    # Claim this state BEFORE deploying, not after. The marker used to be
    # written only at the very end of a fully successful deploy, so anything
    # that went wrong on the way left no record that we had already tried, and
    # the next trigger simply started another one. Ten empty continuation
    # sessions were created inside a single minute on 2026-08-04 that way.
    # Claiming it first makes an automatic handoff at-most-once per state: a
    # failure now stops, and the owner can retry it by hand.
    source["auto_handoff_signature"] = signature
    source["auto_handoff_attempted_at"] = now_iso()
    save_session(source)
    target, model, effort = default_handoff_target(clean_text(source.get("agent")))
    return deploy_handoff(
        source_id,
        target,
        model,
        effort,
        automatic=True,
    )


def spill_work_item_to_artifact(session_id, turn_id, kind, content):
    """Divert an oversized work-log item to the session's Artifacts pane.

    The Artifacts pane is the designed home for large verbatim output; turn
    history is not (a single live session file reached 17 MB this way, and
    save_session rewrites the whole file at least once per second while a turn
    streams). Returns the truncated stand-in text to persist and stream."""
    name = (
        f"work-output-{clean_text(turn_id)[:8] or 'turn'}-{uuid.uuid4().hex[:6]}.txt"
    )
    overflow = len(content) - WORK_ITEM_HEAD_CHARS
    try:
        save_text_atomic(
            os.path.join(artifact_session_dir(session_id), name), content
        )
        note = (
            f"… [{overflow:,} more chars - full {kind} output saved to "
            f"Artifacts: {name}]"
        )
    except OSError:
        note = f"… [{overflow:,} more chars truncated]"
    return content[:WORK_ITEM_HEAD_CHARS] + "\n" + note


# v4.7.1 (audit): _run_git has 28 call sites and a 30-second timeout, and the
# read-only ones repeat constantly — the file tree refreshes every 8 seconds
# and the project list re-derives status per row. A slow repository therefore
# blocked the HTTP thread over and over, which reads to the owner as "AWBN is
# stuck". Read-only commands are memoised for a couple of seconds; anything
# that writes is never cached.
_GIT_READ_ONLY = frozenset(
    {"status", "rev-parse", "branch", "log", "ls-files", "config", "diff", "show"}
)
_GIT_CACHE_SECONDS = 2.5
_GIT_CACHE = {}
_GIT_CACHE_LOCK = threading.Lock()


def _git_cache_key(args, cwd):
    return (tuple(args), clean_text(cwd))


def _run_git(args, cwd, timeout=30):
    """Run a git command, returning (ok, stdout, stderr). Never raises."""
    cacheable = bool(args) and args[0] in _GIT_READ_ONLY
    if cacheable:
        key = _git_cache_key(args, cwd)
        now = time.monotonic()
        with _GIT_CACHE_LOCK:
            hit = _GIT_CACHE.get(key)
            if hit and now - hit[0] < _GIT_CACHE_SECONDS:
                return hit[1]
    result_tuple = _run_git_uncached(args, cwd, timeout)
    if cacheable:
        with _GIT_CACHE_LOCK:
            _GIT_CACHE[_git_cache_key(args, cwd)] = (time.monotonic(), result_tuple)
            if len(_GIT_CACHE) > 512:
                _GIT_CACHE.clear()
    return result_tuple


def _run_git_uncached(args, cwd, timeout=30):
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=cwd or None,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, "", str(exc)
    return result.returncode == 0, result.stdout.strip(), result.stderr.strip()


def git_main_repo_root(path):
    """Absolute root of the MAIN repository for *path* (resolving through linked
    worktrees), or "" when *path* is not inside a usable non-bare repository."""
    ok, common_dir, _ = _run_git(
        ["rev-parse", "--path-format=absolute", "--git-common-dir"], path
    )
    if not ok or not common_dir:
        return ""
    common_dir = os.path.abspath(common_dir)
    if os.path.basename(common_dir) == ".git":
        return os.path.dirname(common_dir)
    return ""


def create_worker_worktree(project_root, job_id):
    """Create an isolated git worktree + branch for a spawned worker session.

    Returns (worktree_path, branch, source_root, error). Best-effort by design:
    non-git projects and git failures return an error string and the caller
    falls back to the shared cwd — isolation must never block a spawn.
    """
    project_root = os.path.abspath(os.path.expanduser(clean_text(project_root) or ""))
    if not project_root or not os.path.isdir(project_root):
        return "", "", "", "no project root"
    source_root = git_main_repo_root(project_root)
    if not source_root:
        return "", "", "", "not a git repository"
    ok, _, err = _run_git(["rev-parse", "--verify", "HEAD"], project_root)
    if not ok:
        return "", "", source_root, "repository has no commits yet"
    job_id = clean_text(job_id) or uuid.uuid4().hex
    branch = f"awbn/worker-{job_id[:8].strip('-') or uuid.uuid4().hex[:8]}"
    worktree_path = os.path.join(WORKTREES_DIR, job_id)
    if os.path.exists(worktree_path):
        return "", branch, source_root, "worktree path already exists"
    try:
        os.makedirs(WORKTREES_DIR, exist_ok=True)
    except OSError as exc:
        return "", branch, source_root, str(exc)
    # Branch from the spawning session's current HEAD — project_root may itself be
    # a worktree, and branching from ITS head keeps parent/child continuity.
    ok, _, err = _run_git(
        ["worktree", "add", "-b", branch, worktree_path, "HEAD"],
        project_root,
        timeout=120,
    )
    if not ok:
        return "", branch, source_root, (err or "git worktree add failed")[:400]
    return worktree_path, branch, source_root, ""


def worktree_uncommitted_error(worktree):
    """Return a refusal reason unless a managed worktree is provably clean."""
    ok, dirty, error = _run_git(
        ["status", "--porcelain", "--untracked-files=all"],
        worktree,
        timeout=30,
    )
    if not ok:
        detail = clean_text(error)[:200]
        return "unable to verify worker worktree is clean; refusing deletion" + (
            f": {detail}" if detail else ""
        )
    if dirty:
        return (
            "worker worktree has uncommitted changes; commit or copy them "
            "before deleting this conversation"
        )
    return ""


def remove_session_worktree(session, *, allow_dirty_after_salvage=False):
    """Remove only a provably clean worker worktree.

    Commits remain on the worker branch. Ordinary session deletion refuses
    uncommitted files because its artifact tree is deleted too. The explicit
    worktree-discard route may opt in only after it durably salvages the delta.
    """
    session = session or {}
    raw_path = clean_text(session.get("worktree_path"))
    if not raw_path:
        return ""
    worktree = os.path.abspath(os.path.expanduser(raw_path))
    raw_source_root = clean_text(session.get("worktree_source_root"))
    source_root = (
        os.path.abspath(os.path.expanduser(raw_source_root)) if raw_source_root else ""
    )
    session_id = clean_text(session.get("id"))
    # Hard safety gate: only ever destroy a directory INSIDE the managed
    # worktrees dir — never the source tree, never anything the user owns.
    if not worktree.startswith(WORKTREES_DIR + os.sep) or worktree == source_root:
        return "refusing to remove a path outside the managed worktrees dir"
    if not os.path.isdir(worktree):
        if source_root and os.path.isdir(source_root):
            _run_git(["worktree", "prune"], source_root)
        return ""
    dirty_error = worktree_uncommitted_error(worktree)
    if dirty_error:
        is_verified_dirty = dirty_error.startswith(
            "worker worktree has uncommitted changes"
        )
        if not (allow_dirty_after_salvage and is_verified_dirty):
            return dirty_error

    have_repo = bool(source_root) and os.path.isdir(source_root)
    if have_repo:
        ok, listing, _ = _run_git(["worktree", "list", "--porcelain"], source_root)
        registered = ok and any(
            line.strip() == f"worktree {worktree}" for line in listing.splitlines()
        )
        if registered:
            # Do not force removal: git is the final guard if a file changes
            # after our status check.
            last_err = ""
            for attempt in range(3):
                remove_args = ["worktree", "remove"]
                if allow_dirty_after_salvage:
                    remove_args.append("--force")
                remove_args.append(worktree)
                ok, _, err = _run_git(
                    remove_args,
                    source_root,
                    timeout=60,
                )
                if ok:
                    return ""
                last_err = err
                if attempt < 2:
                    time.sleep(0.5)
            append_debug_event(
                "worktree_remove_retry_exhausted",
                session=session_id,
                error=(last_err or "")[:200],
            )
            return (last_err or "git refused to remove worker worktree")[:400]
    # An unregistered but valid managed worktree can only be removed after the
    # clean check above. This is the narrow recovery path for stale metadata.
    try:
        shutil.rmtree(worktree)
    except OSError as error:
        return (str(error) or "worktree rmtree failed")[:400]
    if have_repo:
        _run_git(["worktree", "prune"], source_root)
    return ""


def sweep_orphaned_worker_worktrees():
    """Boot-time sweep: drop managed worktree dirs whose session no longer exists.

    Only touches direct children of WORKTREES_DIR (paths this server created,
    named by session id) and only after confirming the session file is gone."""
    if not os.path.isdir(WORKTREES_DIR):
        return 0
    removed = 0
    for name in os.listdir(WORKTREES_DIR):
        path = os.path.join(WORKTREES_DIR, name)
        if not os.path.isdir(path):
            continue
        try:
            if os.path.exists(session_path(name)):
                continue
        except ValueError:
            continue
        refusal = worktree_uncommitted_error(path)
        if refusal:
            append_debug_event(
                "worktree_sweep_preserved",
                path=path,
                error=refusal,
            )
            continue
        source_root = git_main_repo_root(path)
        ok = False
        if source_root:
            ok, _, _ = _run_git(
                ["worktree", "remove", path], source_root, timeout=60
            )
            _run_git(["worktree", "prune"], source_root)
        if not ok:
            # Only use the direct fallback for an unregistered worktree. If a
            # real repo refused removal, preserve it for manual recovery.
            if source_root:
                continue
            try:
                shutil.rmtree(path)
                ok = True
            except OSError:
                ok = False
        if ok:
            removed += 1
    if removed:
        append_debug_event("worktree_sweep", removed=removed)
    return removed


def sweep_orphaned_session_locks():
    """Boot-time sweep: remove .json.lock sidecars whose session file is gone.

    An hour-long age gate keeps this conservative — a lock whose session file
    hasn't existed for an hour is orphaned, not mid-create."""
    removed = 0
    try:
        names = os.listdir(SESS_DIR)
    except OSError:
        return 0
    for name in names:
        if not name.endswith(".json.lock"):
            continue
        if os.path.exists(os.path.join(SESS_DIR, name[: -len(".lock")])):
            continue
        lock_path = os.path.join(SESS_DIR, name)
        try:
            if time.time() - os.path.getmtime(lock_path) < 3600:
                continue
            os.remove(lock_path)
            removed += 1
        except OSError:
            continue
    if removed:
        append_debug_event("session_lock_sweep", removed=removed)
    return removed


def spawn_worker_session(source_id, prompt, agent=None, model=None, effort=None):
    with locked_sessions(source_id):
        return _spawn_worker_session_locked(source_id, prompt, agent, model, effort)


def _spawn_worker_session_locked(source_id, prompt, agent=None, model=None, effort=None):
    """Create a new bounded worker session seeded with *prompt*.

    Mirrors OG ``spawn_worker_job`` (OG ~line 9487). Returns the new session
    dict.  Raises ``ValueError`` on dedup hit or bad inputs.

    SHA-256 dedup key: ``source_id|prompt|agent|model|effort`` — if the same
    tuple was already spawned for *source_id* this server run the existing
    session is returned instead of creating a duplicate.
    """
    source = load_session(source_id)
    # Resolve defaults
    agent = clean_text(agent) or clean_text(source.get("agent")) or "claude"
    model = clean_text(model) or preferred_worker_model(agent)
    effort = clean_text(effort) or "low"
    prompt = clean_text(prompt) or ""
    if not prompt:
        raise ValueError("spawn_worker_session: prompt is required")

    # --- SHA-256 dedup ---
    sig_raw = "\0".join([source_id, prompt, agent, model, effort])
    request_signature = hashlib.sha256(sig_raw.encode("utf-8")).hexdigest()

    existing_worker_job = find_worker_job_by_signature(source_id, request_signature)
    if existing_worker_job and _is_worker_job_active(
        existing_worker_job.get("status") or "",
    ):
        existing_session_id = clean_text(existing_worker_job.get("session_id"))
        if existing_session_id:
            try:
                return load_session(existing_session_id)
            except (OSError, ValueError):
                mark_worker_job_status(
                    existing_session_id,
                    "interrupted",
                    "worker session record is missing or unreadable",
                )

    # --- Build packet (not context-gated — workers always get a packet) ---
    state_path, registry_path = refresh_project_state_file(
        source,
        force=True,
        reason="worker_spawn",
    )
    packet = structured_handoff_packet(source)

    # --- Create new session ---
    job_id = str(uuid.uuid4())
    timestamp = now_iso()
    title, base_title, sequence = next_handoff_title(source, agent)
    backend: dict = {"model": model}
    if agent != "gemini" and effort and effort != "Default":
        backend["effort"] = effort

    target_artifact = os.path.join(artifact_session_dir(job_id), "HANDOFF.md")
    save_text_atomic(target_artifact, packet)

    project_root = infer_project_root(source, source.get("cwd"))
    launch_cwd = project_root or source.get("cwd") or os.path.expanduser("~")
    # Isolate the worker in its own git worktree + branch (the category-standard
    # safety mechanism: parallel workers must not collide on the shared working
    # tree). Best-effort — non-git projects and git failures fall back to the
    # shared cwd, with the reason recorded on the session.
    worktree_path, worktree_branch, worktree_source_root, worktree_error = (
        create_worker_worktree(launch_cwd, job_id)
    )
    if worktree_path:
        launch_cwd = worktree_path
    session = {
        "id": job_id,
        "title": title,
        "agent": agent,
        "backend": backend,
        "cwd": launch_cwd,
        "project_root": worktree_path or project_root,
        "origin": "local",
        "created_at": timestamp,
        "updated_at": timestamp,
        "turns": [],
        "handoff_from": source_id,
        "handoff_base_title": base_title,
        "handoff_sequence": sequence,
        "handoff_artifact": target_artifact,
        "handoff_context": (
            f"Read the authoritative continuation handoff before acting:\n{target_artifact}"
            + (f"\n\nAlso read the shared project state before acting:\n{state_path}" if state_path else "")
            + (f"\n\nAlso read the project registry before acting:\n{registry_path}" if registry_path else "")
        ),
        "handoff_stage_ready": True,
        "handoff_stage_signature": handoff_signature(source),
        "handoff_stage_artifact": target_artifact,
        "handoff_stage_updated_at": timestamp,
        # Worker markers (excluded from main session list)
        "worker_job_id": job_id,
        "worker_parent_session_id": source_id,
        "worker_request_signature": request_signature,
    }
    if worktree_path:
        session["worktree_path"] = worktree_path
        session["worktree_branch"] = worktree_branch
        session["worktree_source_root"] = worktree_source_root
        # stream_claude pins its launch dir once from native_cwd — set it now so
        # the resident process can never fall back to the shared source tree.
        session["native_cwd"] = worktree_path
        session["handoff_context"] += (
            f"\n\nYou are working in an ISOLATED git worktree at {worktree_path} "
            f"on branch {worktree_branch} (source repository: {worktree_source_root}). "
            "Work and commit on this branch only - do not switch branches, do not "
            "push, and do not cd into the source repository. Your branch is "
            "reviewed and merged after you finish."
        )
    elif worktree_error not in ("no project root", "not a git repository"):
        session["worktree_error"] = worktree_error

    # Seed first turn so the worker is ready to auto-send
    first_turn = {
        "id": str(uuid.uuid4()),
        "created_at": timestamp,
        "status": "pending",
        "prompt": prompt,
        "items": [
            {"type": "userMessage", "content": [{"type": "text", "text": prompt}]}
        ],
    }
    session["turns"].append(first_turn)

    job_record = {
        "id": job_id,
        "source_session_id": source_id,
        "source_title": source.get("title") or source_id,
        "session_id": job_id,
        "title": title,
        "prompt": prompt,
        "agent": agent,
        "model": model,
        "effort": effort,
        "status": "queued",
        "created_at": timestamp,
        "updated_at": timestamp,
        "request_signature": request_signature,
        "worktree_path": worktree_path,
        "worktree_branch": worktree_branch,
        "error": "",
    }
    try:
        # Persist the child first, then publish its index record. If either
        # write fails, roll both back before a caller can launch the worker.
        save_session(session)
        if upsert_worker_job(job_record) is None:
            raise RuntimeError("worker metadata could not be persisted")
    except Exception:
        try:
            remove_worker_metadata_for_deleted_session(session)
        except Exception:
            pass
        try:
            with locked_sessions(job_id):
                path = session_path(job_id)
                if os.path.exists(path):
                    os.remove(path)
        except Exception:
            pass
        try:
            remove_session_worktree(session)
        except Exception:
            pass
        try:
            artifact_dir = raw_artifact_session_dir(job_id)
            if os.path.islink(artifact_dir):
                os.remove(artifact_dir)
            elif os.path.isdir(artifact_dir):
                shutil.rmtree(artifact_dir)
        except OSError:
            pass
        raise

    try:
        ensure_project_registry(
            # Register under the shared source root — the worktree is disposable and
            # must not appear in the project registry as its own project.
            worktree_source_root or project_root or session.get("cwd"),
            session=session,
            agent_key=agent,
            title=title,
            state_path=state_path,
            sequence=sequence,
        )
    except Exception as error:
        # The durable worker and its metadata already exist. Registry display
        # repair is non-critical and must not make the caller retry/spawn twice.
        append_debug_event(
            "worker_project_registry_failed",
            session=job_id,
            error=clean_text(error)[:500],
        )
    return session


def split_gemini_visible_text(text):
    thoughts = []

    def replace(match):
        thoughts.append(clean_text(match.group(1)))
        return ""

    visible = re.sub(r"\[Thought:\s*true\](.*?)(?=\[Thought:\s*true\]|\Z)", replace, text, flags=re.S)
    return "\n".join(part for part in thoughts if part), clean_text(visible)


class TurnControl:
    def __init__(self):
        self.cancel = threading.Event()
        self.process = None
        self.stop_callback = None
        self.visible_prompt = ""
        self.lock = threading.Lock()

    def set_process(self, process):
        with self.lock:
            self.process = process

    def set_stop_callback(self, callback):
        with self.lock:
            self.stop_callback = callback

    def set_visible_prompt(self, prompt):
        self.visible_prompt = clean_text(prompt)

    def stop(self):
        self.cancel.set()
        with self.lock:
            process = self.process
            callback = self.stop_callback
        if callback:
            try:
                callback()
            except Exception:
                pass
            return
        if process and process.poll() is None:
            try:
                process.terminate()
            except OSError:
                pass


def subprocess_env():
    env = os.environ.copy()
    current_paths = [
        path
        for path in env.get("PATH", "").split(os.pathsep)
        if path
    ]
    merged = []
    for path in [*GUI_CLI_PATHS, *current_paths]:
        if path and path != LEGACY_BYPASS_SHIM_DIR and path not in merged:
            merged.append(path)
    env["PATH"] = os.pathsep.join(merged)
    if safe_permissions_enabled():
        # Defense in depth: if a legacy bypass shim still wins PATH resolution
        # anywhere downstream (user shell config, nested tools), this is the
        # shim's own documented switch to pass arguments through untouched.
        env["AGENT_WORKBENCH_SAFE_PERMISSIONS"] = "1"
    return env


def resolve_command_executable(command, env):
    if not command:
        return command
    executable = command[0]
    if os.path.isabs(executable) or os.sep in executable:
        return command
    resolved = shutil.which(executable, path=env.get("PATH"))
    if not resolved:
        return command
    return [resolved, *command[1:]]


def run_process(command, cwd, control):
    env = subprocess_env()
    resolved_command = resolve_command_executable(list(command), env)
    try:
        process = subprocess.Popen(
            resolved_command,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=env,
        )
    except FileNotFoundError as error:
        raise FileNotFoundError(
            f"{command[0]} executable not found. Searched PATH: {env.get('PATH', '')}"
        ) from error
    control.set_process(process)
    # Drain stderr continuously into a bounded buffer. Callers iterate stdout and
    # only read stderr at the end; without draining, a child that writes more than
    # the ~64KB pipe to stderr blocks forever and deadlocks the parent. Read the
    # captured text via process_stderr_text().
    process._stderr_chunks = []  # type: ignore[attr-defined]

    def _drain_stderr():
        try:
            for line in process.stderr:
                process._stderr_chunks.append(line)  # type: ignore[attr-defined]
                if len(process._stderr_chunks) > 400:  # type: ignore[attr-defined]
                    del process._stderr_chunks[0]  # type: ignore[attr-defined]
        except Exception:
            pass

    drain_thread = threading.Thread(target=_drain_stderr, daemon=True)
    process._stderr_drain = drain_thread  # type: ignore[attr-defined]
    drain_thread.start()
    return process


def process_stderr_text(process):
    """Return captured stderr for a run_process() child (drained in the background
    to avoid a full-pipe deadlock). Joins the drain thread briefly so late lines
    after process exit are included."""
    thread = getattr(process, "_stderr_drain", None)
    if thread is not None:
        thread.join(timeout=1.0)
    return "".join(getattr(process, "_stderr_chunks", []))


def emit_usage(emit, usage, live=False):
    if not isinstance(usage, dict):
        return
    input_tokens = safe_int(
        usage.get("input_tokens")
        or usage.get("inputTokens")
        or usage.get("input")
    )
    output_tokens = safe_int(
        usage.get("output_tokens")
        or usage.get("outputTokens")
        or usage.get("output")
    )
    # Reasoning ("inference") tokens — reported by reasoning models (Codex/GPT-5,
    # o-series). They are a billed component distinct from input and final output;
    # field name varies by client and nesting.
    output_details = usage.get("output_tokens_details") or usage.get("completion_tokens_details") or {}
    reasoning_tokens = safe_int(
        usage.get("reasoning_tokens")
        or usage.get("reasoningTokens")
        or usage.get("reasoning_output_tokens")
        or (output_details.get("reasoning_tokens") if isinstance(output_details, dict) else 0)
    )
    # claude CLI ≥ 2.1.222: `cache_creation` became a dict of TTL buckets
    # ({"ephemeral_5m_input_tokens": N, "ephemeral_1h_input_tokens": N}).
    # When the flat field was 0, the old `or` chain handed that dict straight
    # to int() and the WHOLE TURN died with "ERROR: int() argument must be a
    # string... not 'dict'" (reported twice on 2026-08-05). A dict now means
    # "sum the buckets"; anything unreadable counts 0 instead of crashing.
    cache_creation_raw = usage.get("cache_creation")
    cache_creation_bucket_sum = (
        sum(safe_int(value) for value in cache_creation_raw.values())
        if isinstance(cache_creation_raw, dict)
        else safe_int(cache_creation_raw)
    )
    cache_creation_tokens = (
        safe_int(usage.get("cache_creation_input_tokens"))
        or safe_int(usage.get("cacheCreationInputTokens"))
        or cache_creation_bucket_sum
    )
    cache_read_tokens = safe_int(
        usage.get("cache_read_input_tokens")
        or usage.get("cacheReadInputTokens")
        or usage.get("cache_read")
        # v4.3.3: Codex calls it `cached_input_tokens`, and that name was not
        # in this list — so every Codex turn reported "cache read: 0" while
        # its own turn.completed said 30,208 of 48,165. With the cached share
        # invisible, a turn whose input is overwhelmingly the same context
        # re-sent each step reads as if all of it were newly billed. That is
        # what made "6153.6k in" look impossible; 97% of it was cache.
        or usage.get("cached_input_tokens")
        or usage.get("cachedInputTokens")
    )
    # Every token the turn actually moved, cache included.
    #
    # This used to be input + output only, because Claude sends no total and the
    # fallback added the two smallest numbers. On a real 98-minute turn that read
    # 12,329 while the same record held 2,421,180 cache-read and 427,135
    # cache-creation tokens: a total that left out 99.6% of the turn. Cache reads
    # are cheap, not free, and they are certainly not nothing, so a count that
    # omits them is not a count.
    #
    # A client that sends its own total is still trusted, but only if it is not
    # smaller than the parts we can see: Claude's `result` reports a total that
    # excludes cache too, and taking it verbatim reintroduced the same lie.
    counted = input_tokens + output_tokens + cache_creation_tokens + cache_read_tokens
    reported = safe_int(usage.get("total_tokens") or usage.get("totalTokens"))
    total_tokens = max(reported, counted)
    if input_tokens or output_tokens or total_tokens:
        payload = {
            "type": "usage",
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "reasoning_tokens": reasoning_tokens,
            "total_tokens": total_tokens,
            "cache_creation_input_tokens": cache_creation_tokens,
            "cache_read_input_tokens": cache_read_tokens,
        }
        # The whole-conversation running total, when the caller worked one
        # out. Carried alongside the turn's own figures, never instead of
        # them — printing the running total ON a message is the bug this
        # pair of fields exists to keep fixed.
        for field in ("session_input_tokens", "session_output_tokens"):
            if usage.get(field) is not None:
                payload[field] = safe_int(usage.get(field))
        # Plan consumption, for clients billed against a plan rather than
        # per token. Measured by the client itself, never estimated here.
        for field in ("plan_used_percent", "plan_delta_percent"):
            if usage.get(field) is not None:
                payload[field] = safe_float(usage.get(field))
        # The turn's cost as the CLIENT reported it, when it reports one.
        # Always preferred over AWBN's own estimate.
        if usage.get("cost_usd") is not None:
            try:
                payload["cost_usd"] = safe_float(usage.get("cost_usd"))
            except (TypeError, ValueError):
                pass
        # v4.0.6: tool-attributed tokens (estimate) when the caller tracks
        # them — absent on final result usage, so consumers keep the last
        # live value rather than zeroing it.
        if usage.get("tool_tokens") is not None:
            payload["tool_tokens"] = safe_int(usage.get("tool_tokens"))
        # Sub-agent tokens, same treatment. Also folded into the total, because
        # a helper's work is the turn's work: it happened because this turn
        # asked for it, and the owner is billed for it either way.
        if usage.get("worker_tokens") is not None:
            worker_tokens = safe_int(usage.get("worker_tokens"))
            payload["worker_tokens"] = worker_tokens
            payload["total_tokens"] = safe_int(payload.get("total_tokens")) + worker_tokens
        # Mid-turn running snapshot (Claude --include-partial-messages): the
        # UI overwrites its strip with each one, but the durable recorder must
        # not feed these summed turn totals into update_context — the context
        # meter reads per-message usage, not turn sums.
        if live:
            payload["live"] = True
        emit(payload)


def update_context(session, usage, model=""):
    if not isinstance(usage, dict):
        return False
    existing_context = (
        session.get("context") if isinstance(session.get("context"), dict) else {}
    )
    input_tokens = safe_int(usage.get("input_tokens") or usage.get("inputTokens"))
    cache_creation_tokens = safe_int(
        usage.get("cache_creation_input_tokens")
        or usage.get("cacheCreationInputTokens")
    )
    cache_read_tokens = safe_int(
        usage.get("cache_read_input_tokens")
        or usage.get("cacheReadInputTokens")
    )
    used = input_tokens + cache_creation_tokens + cache_read_tokens
    limit = safe_int(
        usage.get("model_context_window")
        or usage.get("modelContextWindow")
        or existing_context.get("limit")
    )
    agent = clean_text(session.get("agent")).lower()
    if limit <= 0 and agent == "claude":
        backend = session.get("backend") if isinstance(session.get("backend"), dict) else {}
        limit = claude_context_limit(model or backend.get("model"))
    elif limit <= 0 and agent == "gemini":
        backend = session.get("backend") if isinstance(session.get("backend"), dict) else {}
        limit = gemini_context_limit(model or backend.get("model"))
    if used <= 0 or limit <= 0:
        return False
    compact_count = int(existing_context.get("compact_count") or 0)
    session["context"] = {
        "used": used,
        "limit": limit,
        "percent": min(100.0, used * 100.0 / limit),
        "model": model,
        "compact_count": compact_count,
        "input_tokens": input_tokens,
        "cache_creation_input_tokens": cache_creation_tokens,
        "cache_read_input_tokens": cache_read_tokens,
        "cache_total_tokens": cache_creation_tokens + cache_read_tokens,
    }
    return True


def bounded_text(value, limit=LOCAL_TOOL_MAX_OUTPUT):
    text = str(value or "")
    if len(text) <= limit:
        return text
    removed = len(text) - limit
    return text[:limit] + f"\n\n[truncated {removed:,} characters]"


def resolved_local_path(value, cwd):
    raw = clean_text(value)
    if not raw:
        return os.path.abspath(cwd)
    expanded = os.path.expanduser(raw)
    if not os.path.isabs(expanded):
        expanded = os.path.join(cwd, expanded)
    return os.path.abspath(expanded)


def real_local_path(value):
    return os.path.realpath(os.path.abspath(os.path.expanduser(clean_text(value))))


def path_is_under(path, parent):
    try:
        return os.path.commonpath([path, parent]) == parent
    except ValueError:
        return False


def protected_path_roots():
    home = os.path.expanduser("~")
    return [
        (real_local_path(SESS_DIR), "Agent Workbench session history"),
        (
            real_local_path(os.path.join(CONFIG_DIR, "connector-auth")),
            "Agent Workbench connector auth logs",
        ),
        (real_local_path(os.path.join(home, ".qwen")), "Qwen credentials/config"),
        (real_local_path(os.path.join(home, ".claude")), "Claude credentials/history"),
        (real_local_path(os.path.join(home, ".codex")), "Codex credentials/history"),
        (real_local_path(os.path.join(home, ".gemini")), "Gemini credentials/config"),
        (real_local_path(os.path.join(home, ".ssh")), "SSH keys/config"),
        (real_local_path(os.path.join(home, ".gnupg")), "GPG keys/config"),
        (real_local_path(os.path.join(home, ".aws")), "AWS credentials/config"),
        (real_local_path(os.path.join(home, ".azure")), "Azure credentials/config"),
        (real_local_path(os.path.join(home, ".kube")), "Kubernetes credentials/config"),
        (real_local_path(os.path.join(home, ".docker")), "Docker credentials/config"),
        (
            real_local_path(os.path.join(home, ".config", "gcloud")),
            "Google Cloud credentials/config",
        ),
        (
            real_local_path(os.path.join(home, ".local", "share", "keyrings")),
            "desktop keyrings",
        ),
    ]


def protected_path_files():
    home = os.path.expanduser("~")
    return [
        (real_local_path(BRIDGE_TOKEN_FILE), "Agent Workbench bridge token"),
        (
            real_local_path(os.path.join(CONFIG_DIR, "keys.json")),
            "Agent Workbench key store",
        ),
        (real_local_path(CONFIG_FILE), "Agent Workbench app config"),
        (real_local_path(DEBUG_LOG_FILE), "Agent Workbench debug log"),
        (real_local_path(CLAUDE_MCP_CONFIG_FILE), "Claude MCP config"),
        (
            real_local_path(GEMINI_TITLE_CACHE_FILE),
            "Gemini title cache",
        ),
        (
            real_local_path(CONFIG_BOOTSTRAP_FILE),
            "Agent Workbench bootstrap record",
        ),
        (
            real_local_path(LOCAL_DELEGATE_SERVER),
            "Agent Workbench local delegate server",
        ),
        (
            real_local_path(WORKER_JOBS_PATH),
            "Agent Workbench worker job state",
        ),
        (real_local_path(os.path.join(home, "keys_list.md")), "local keys export"),
        (real_local_path(QWEN_SETTINGS_FILE), "Qwen settings"),
        (
            real_local_path(os.path.join(home, ".qwen", "mcp-oauth-tokens.json")),
            "Qwen OAuth tokens",
        ),
        (real_local_path(os.path.join(home, ".claude.json")), "Claude config"),
        (real_local_path(os.path.join(home, ".codex", "auth.json")), "Codex auth"),
        (
            real_local_path(os.path.join(home, ".gemini", "oauth_creds.json")),
            "Gemini OAuth credentials",
        ),
    ]


def protected_local_path_reason(path):
    normalized = real_local_path(path)
    basename = os.path.basename(normalized).lower()
    if (
        basename in PROTECTED_BASENAMES
        or basename.startswith(".env.")
        or basename.endswith(PROTECTED_SUFFIXES)
    ):
        return "common secret file"
    for protected_file, label in protected_path_files():
        if normalized == protected_file:
            return label
    for protected_root, label in protected_path_roots():
        if path_is_under(normalized, protected_root):
            return label
    return ""


def protected_local_path_error(action, path):
    reason = protected_local_path_reason(path)
    if not reason:
        return ""
    return f"ERROR: blocked {action} protected local data ({reason}): {path}"


def protected_command_reason(command, cwd):
    text = clean_text(command)
    lowered = text.lower()
    for pattern in PROTECTED_COMMAND_PATTERNS:
        if pattern.lower() in lowered:
            return "command references protected local data"
    try:
        tokens = shlex.split(text)
    except ValueError:
        tokens = text.split()
    for token in tokens:
        candidate = token.strip("'\"`;,|&()[]{}")
        if not candidate or candidate.startswith("-"):
            continue
        basename = os.path.basename(candidate).lower()
        if not (
            candidate.startswith(("/", "~", "."))
            or "/" in candidate
            or "\\" in candidate
            or basename in PROTECTED_BASENAMES
            or basename.startswith(".env.")
            or basename.endswith(PROTECTED_SUFFIXES)
        ):
            continue
        reason = protected_local_path_reason(resolved_local_path(candidate, cwd))
        if reason:
            return reason
    return ""


def unsafe_local_tools_enabled():
    value = clean_text(os.environ.get("AGENT_WORKBENCH_UNSAFE_LOCAL_TOOLS")).lower()
    return value in {"1", "true", "yes", "on"}


def experimental_local_connectors_enabled():
    value = clean_text(
        os.environ.get("AWBENCH_EXPERIMENTAL_LOCAL_CONNECTORS")
    ).lower()
    return value in {"1", "true", "yes", "on"}


def local_tool_policy_enabled():
    return not unsafe_local_tools_enabled()


def control_visible_prompt(control):
    return clean_text(getattr(control, "visible_prompt", ""))


def local_tool_confirmation_present(control):
    return LOCAL_TOOL_CONFIRMATION_PHRASE in control_visible_prompt(control)


def local_tool_policy_error(action, reason, control):
    if not local_tool_policy_enabled() or local_tool_confirmation_present(control):
        return ""
    return (
        f"ERROR: blocked high-risk local tool action ({reason}) for {action}. "
        "Ask the user to resend the request with the exact phrase "
        f"{LOCAL_TOOL_CONFIRMATION_PHRASE} if they want this action."
    )


def dangerous_command_reason(command):
    text = clean_text(command)
    if not text:
        return ""
    for pattern, reason in DANGEROUS_COMMAND_PATTERNS:
        if re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL):
            return reason
    return ""


def outside_current_workspace(path, cwd):
    try:
        normalized_path = real_local_path(path)
        normalized_cwd = real_local_path(cwd)
        return not path_is_under(normalized_path, normalized_cwd)
    except Exception:
        return False


def local_workspace_path_error(action, path, cwd):
    if outside_current_workspace(path, cwd):
        return (
            f"ERROR: blocked {action} outside the current workspace: {path}. "
            "Register that folder as a project and open its chat first."
        )
    return ""


def local_write_confirmation_reason(path, cwd, executable=False):
    if outside_current_workspace(path, cwd):
        return "write outside the current workspace"
    if real_local_path(cwd) == real_local_path(os.path.expanduser("~")):
        return "write from a home-directory session"
    if executable:
        return "create executable file"
    return ""


def connector_task_confirmation_reason(connector, prompt):
    if connector == "robinhood":
        if re.search(
            r"\b(buy|sell|trade|order|cancel|exercise|deposit|withdraw|transfer)\b",
            prompt,
            flags=re.IGNORECASE,
        ):
            return "Robinhood write action"
    if CONNECTOR_WRITE_ACTION_RE.search(clean_text(prompt)):
        return f"{connector} connector write/external action"
    return ""


def strip_ansi(value):
    return re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", str(value or ""))


def run_qwen_mcp_bridge(arguments, cwd=None, timeout=90):
    if not os.path.isfile(QWEN_MCP_BRIDGE):
        raise RuntimeError(f"Qwen MCP bridge is missing: {QWEN_MCP_BRIDGE}")
    if not shutil.which("node"):
        raise RuntimeError("Node.js is required for direct MCP connectors.")
    result = subprocess.run(
        ["node", QWEN_MCP_BRIDGE, *arguments],
        cwd=cwd or os.path.expanduser("~"),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
        check=False,
    )
    output = clean_text(result.stdout)
    if result.returncode != 0:
        error = clean_text(strip_ansi(result.stderr)) or output
        raise RuntimeError(error or f"Qwen MCP bridge exited {result.returncode}")
    try:
        return json.loads(output or "{}")
    except ValueError as error:
        raise RuntimeError(
            f"Qwen MCP bridge returned invalid JSON: {bounded_text(output, 2_000)}"
        ) from error


def _refresh_connector_statuses():
    """Fetch connector statuses and store them, one refresh at a time."""
    with CONNECTOR_REFRESH_LOCK:
        if CONNECTOR_CACHE.get("refreshing"):
            return
        CONNECTOR_CACHE["refreshing"] = True
    try:
        payload = run_qwen_mcp_bridge(["list"], timeout=60)
        CONNECTOR_CACHE.update(
            {"time": time.monotonic(), "value": payload.get("connectors") or []}
        )
    except Exception:  # noqa: BLE001 - a failed probe must not wedge the panel
        CONNECTOR_CACHE["time"] = time.monotonic()
    finally:
        with CONNECTOR_REFRESH_LOCK:
            CONNECTOR_CACHE["refreshing"] = False


def connector_statuses(force=False):
    """Connector statuses, answered immediately — never by waiting.

    Probing them runs the Qwen MCP bridge, measured at 1.7 seconds, and the
    Options panel blocked on it every 15 seconds. Answer with what is known
    and refresh behind the scenes; `force=True` (the panel's own Refresh
    button) still waits, because there the user asked for a fresh reading and
    is watching a spinner for it (v4.3.3)."""
    now = time.monotonic()
    fresh = (
        CONNECTOR_CACHE["value"]
        and now - CONNECTOR_CACHE["time"] < CONNECTOR_CACHE_SECONDS
    )
    if force:
        _refresh_connector_statuses()
        return CONNECTOR_CACHE["value"]
    if not fresh:
        threading.Thread(target=_refresh_connector_statuses, daemon=True).start()
    return CONNECTOR_CACHE["value"]


def configure_connector_oauth(connector, client_id="", client_secret=""):
    connector = clean_text(connector).lower()
    if connector not in SUPPORTED_CONNECTORS:
        raise RuntimeError(f"Unsupported connector: {connector}")
    try:
        settings = json.loads(Path(QWEN_SETTINGS_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise RuntimeError(f"Could not read Qwen settings: {error}") from error
    server = (settings.get("mcpServers") or {}).get(connector)
    if not isinstance(server, dict):
        raise RuntimeError(f"Connector is not configured in Qwen Code: {connector}")
    oauth = dict(server.get("oauth") or {})
    oauth["enabled"] = True
    if clean_text(client_id):
        oauth["clientId"] = clean_text(client_id)
    if clean_text(client_secret):
        oauth["clientSecret"] = clean_text(client_secret)
    server["oauth"] = oauth
    temporary = f"{QWEN_SETTINGS_FILE}.awbench-{uuid.uuid4().hex}.tmp"
    Path(temporary).write_text(
        json.dumps(settings, indent=2) + "\n",
        encoding="utf-8",
    )
    os.chmod(temporary, 0o600)
    os.replace(temporary, QWEN_SETTINGS_FILE)
    CONNECTOR_CACHE.update({"time": 0.0, "value": []})
    return oauth


def set_connector_token(connector, token):
    connector = clean_text(connector).lower()
    if connector not in SUPPORTED_CONNECTORS:
        raise RuntimeError(f"Unsupported connector: {connector}")
    try:
        settings = json.loads(Path(QWEN_SETTINGS_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise RuntimeError(f"Could not read Qwen settings: {error}") from error
    server = (settings.get("mcpServers") or {}).get(connector)
    if not isinstance(server, dict):
        raise RuntimeError(f"Connector is not configured in Qwen Code: {connector}")
    token = token.strip() if isinstance(token, str) else ""
    if token:
        server.setdefault("headers", {})["Authorization"] = "Bearer " + token
    else:
        headers = server.get("headers") or {}
        headers.pop("Authorization", None)
        if not headers:
            server.pop("headers", None)
        else:
            server["headers"] = headers
    temporary = f"{QWEN_SETTINGS_FILE}.awbench-{uuid.uuid4().hex}.tmp"
    Path(temporary).write_text(
        json.dumps(settings, indent=2) + "\n",
        encoding="utf-8",
    )
    os.chmod(temporary, 0o600)
    os.replace(temporary, QWEN_SETTINGS_FILE)
    CONNECTOR_CACHE.update({"time": 0.0, "value": []})
    return {"ok": True, "connector": connector}


def start_connector_auth(connector, client_id="", client_secret=""):
    oauth = configure_connector_oauth(connector, client_id, client_secret)
    if connector in {"gmail", "google-drive", "google-calendar"} and not oauth.get(
        "clientId"
    ):
        raise RuntimeError(
            "Google Workspace connectors require an OAuth client ID and secret. "
            "Create one in Google Cloud, then enter it in Workbench Options."
        )
    log_dir = os.path.join(CONFIG_DIR, "connector-auth")
    ensure_private_dir(log_dir)
    log_path = os.path.join(log_dir, f"{connector}.log")
    log = open(log_path, "a", encoding="utf-8")
    try:
        ensure_private_file(log_path)
        process = subprocess.Popen(
            ["node", QWEN_MCP_BRIDGE, "auth", connector],
            cwd=os.path.expanduser("~"),
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    finally:
        log.close()
    return {"connector": connector, "pid": process.pid, "log": log_path}


def direct_connector_task(connector, prompt, cwd, timeout, emit, control):
    tools_payload = run_qwen_mcp_bridge(
        ["tools", connector],
        cwd=cwd,
        timeout=min(timeout, 90),
    )
    discovered = tools_payload.get("tools") or []
    if not discovered:
        return f"ERROR: {connector} exposed no MCP tools."
    tools = [
        {
            "type": "function",
            "function": {
                "name": clean_text(tool.get("name")),
                "description": clean_text(tool.get("description")),
                "parameters": tool.get("inputSchema")
                or {"type": "object", "properties": {}},
            },
        }
        for tool in discovered
        if clean_text(tool.get("name"))
    ]
    messages = [
        {
            "role": "system",
            "content": (
                f"You execute tasks through the {connector} MCP connector. "
                "Use the provided MCP tools directly. Do not use shell commands, "
                "do not enter plan mode, and do not claim a tool is unavailable "
                "when it is listed. Use read-only tools unless the user's request "
                "explicitly requires a write. After tool results, return a concise "
                "factual answer."
            ),
        },
        {"role": "user", "content": prompt},
    ]
    total_input = 0
    total_output = 0
    for step in range(8):
        if control.cancel.is_set():
            raise RuntimeError("Turn stopped.")
        payload = json.dumps(
            {
                "model": "qwen3-coder:30b",
                "messages": messages,
                "tools": tools,
                "stream": False,
                "options": {"temperature": 0},
            }
        ).encode("utf-8")
        request = urllib.request.Request(
            f"{OLLAMA_BASE}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            result = json.load(response)
        total_input += int(result.get("prompt_eval_count") or 0)
        total_output += int(result.get("eval_count") or 0)
        message = result.get("message") or {}
        content = clean_text(message.get("content"))
        tool_calls = message.get("tool_calls") or []
        if not tool_calls:
            emit_usage(
                emit,
                {
                    "input_tokens": total_input,
                    "output_tokens": total_output,
                    "total_tokens": total_input + total_output,
                },
            )
            return content or f"{connector} completed without a text response."
        messages.append(
            {
                "role": "assistant",
                "content": content,
                "tool_calls": tool_calls,
            }
        )
        for call in tool_calls:
            function = call.get("function") or {}
            tool_name = clean_text(function.get("name"))
            arguments = function.get("arguments") or {}
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except ValueError:
                    arguments = {}
            emit(
                {
                    "type": "work",
                    "kind": "tool",
                    "content": f"{connector} · {tool_name}",
                }
            )
            try:
                call_payload = run_qwen_mcp_bridge(
                    [
                        "call",
                        connector,
                        json.dumps({"tool": tool_name, "arguments": arguments}),
                    ],
                    cwd=cwd,
                    timeout=timeout,
                )
                tool_result = call_payload.get("text") or json.dumps(
                    call_payload.get("content") or []
                )
                if call_payload.get("is_error"):
                    tool_result = f"ERROR: {tool_result}"
            except Exception as error:
                tool_result = f"ERROR: {type(error).__name__}: {error}"
            messages.append(
                {
                    "role": "tool",
                    "tool_name": tool_name,
                    "content": bounded_text(tool_result),
                }
            )
    return f"ERROR: {connector} exceeded 8 MCP tool steps without completing."


def local_agent_tools():
    tools = [
        {
            "type": "function",
            "function": {
                "name": "read_file",
                "description": "Read a real text file from the user's computer.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "start_line": {"type": "integer", "minimum": 1},
                        "end_line": {"type": "integer", "minimum": 1},
                    },
                    "required": ["path"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "write_file",
                "description": "Create or replace a real text file on the user's computer.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "content": {"type": "string"},
                        "executable": {"type": "boolean"},
                    },
                    "required": ["path", "content"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "edit_file",
                "description": "Replace exact text in an existing file. Fails if the old text is absent or ambiguous.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "old_text": {"type": "string"},
                        "new_text": {"type": "string"},
                    },
                    "required": ["path", "old_text", "new_text"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "list_directory",
                "description": "List files and directories on the user's computer.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "depth": {"type": "integer", "minimum": 1, "maximum": 4},
                    },
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "search_files",
                "description": "Search file contents with ripgrep.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "path": {"type": "string"},
                        "glob": {"type": "string"},
                    },
                    "required": ["query"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "run_command",
                "description": "Run a shell command with local user permissions after explicit user confirmation, excluding protected credential and app-state paths.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string"},
                        "cwd": {"type": "string"},
                        "timeout_seconds": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 900,
                        },
                    },
                    "required": ["command"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "open_path",
                "description": "Open a local file, directory, application document, or URL in the user's desktop environment.",
                "parameters": {
                    "type": "object",
                    "properties": {"target": {"type": "string"}},
                    "required": ["target"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "launch_app",
                "description": "Launch a desktop application or long-running command without blocking the agent. High-risk launches require explicit user confirmation.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string"},
                        "cwd": {"type": "string"},
                    },
                    "required": ["command"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "web_fetch",
                "description": "Fetch a public HTTP or HTTPS page for research.",
                "parameters": {
                    "type": "object",
                    "properties": {"url": {"type": "string"}},
                    "required": ["url"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "list_connectors",
                "description": "List MCP services configured directly for local Qwen Code.",
                "parameters": {"type": "object", "properties": {}},
            },
        },
        {
            "type": "function",
            "function": {
                "name": "connector_task",
                "description": "Use a directly configured MCP connector with local Qwen. Connector write/external actions require explicit user confirmation.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "connector": {
                            "type": "string",
                            "enum": [
                                "threejs",
                                "cloudflare",
                                "google-drive",
                                "supabase",
                                "vercel",
                                "gmail",
                                "google-calendar",
                                "canva",
                                "hugging-face",
                                "indeed",
                                "cocounsel-legal",
                                "robinhood",
                            ],
                        },
                        "prompt": {"type": "string"},
                        "timeout_seconds": {
                            "type": "integer",
                            "minimum": 10,
                            "maximum": 900,
                        },
                    },
                    "required": ["connector", "prompt"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "delegate_agent",
                "description": "Delegate a bounded task to an installed Claude, Codex, Hermes, or Gemini CLI. Delegation requires explicit user confirmation.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "agent": {
                            "type": "string",
                            "enum": ["claude", "codex", "hermes", "gemini"],
                        },
                        "prompt": {"type": "string"},
                        "cwd": {"type": "string"},
                        "timeout_seconds": {
                            "type": "integer",
                            "minimum": 10,
                            "maximum": 900,
                        },
                    },
                    "required": ["agent", "prompt"],
                },
            },
        },
    ]
    if not unsafe_local_tools_enabled():
        disabled = {"run_command", "launch_app", "connector_task", "delegate_agent"}
        tools = [
            tool
            for tool in tools
            if clean_text((tool.get("function") or {}).get("name")) not in disabled
        ]
    elif not experimental_local_connectors_enabled():
        tools = [
            tool
            for tool in tools
            if clean_text((tool.get("function") or {}).get("name")) != "connector_task"
        ]
    return tools


def local_agent_system_prompt(cwd, model):
    high_risk_tools = (
        "Unsafe local shell, connector-action, and delegation tools are enabled by an "
        "explicit environment override. They still require the user's confirmation."
        if unsafe_local_tools_enabled()
        else "Shell execution, detached launches, connector actions, and agent delegation are disabled in the public-beta safety mode."
    )
    return f"""You are {model}, running as a local coding agent inside Agent Workbench.

You have direct tools for the user's real filesystem, shell, applications, browser, development tools, and installed cloud-agent CLIs.
Your current working directory is:
{cwd}

Operational rules:
- When the user requests an action, perform it with tools. Do not merely explain how.
- Never claim you cannot read, save, edit, create, launch, or inspect local resources unless the relevant tool actually returns an error.
- File tools are confined to the current workspace. Ask the user to register and open another project rather than reaching outside it.
- Protected credential and app-state paths are denied by the tool executor. If a tool reports protected local data, do not work around that denial.
- {high_risk_tools}
- High-risk local tool actions require explicit user confirmation with the exact phrase {LOCAL_TOOL_CONFIRMATION_PHRASE}. If a tool reports that confirmation is required, stop and ask the user for that confirmation.
- Use open_path to open files, folders, websites, and generated applications for the user.
- Only use a tool that is actually present in your current tool list.
- Robinhood write actions require the exact phrase CONFIRM ROBINHOOD ACTION in the connector prompt. Read-only Robinhood requests do not.
- Keep destructive operations scoped and intentional. Do not broadly delete or overwrite unrelated data.
- Verify completed work with an appropriate read, command, test, or process check before reporting success.
- Report concise results, exact changed paths, launched applications, and any unresolved failure.

All tool calls and results are retained in the Work Log. Conversation replies should contain the useful outcome, not raw terminal chatter."""


def bounded_local_history(session, max_messages=24, max_characters=72_000):
    selected = []
    used = 0
    for message in reversed(prior_history_messages(session)):
        content = clean_text(message.get("content"))
        if not content:
            continue
        content = re.sub(
            r"^(?:Restored previous conversation history\.\s*)+",
            "",
            content,
            flags=re.IGNORECASE,
        )
        content = re.sub(
            r"^(?:Detected dumb terminal.*?\n+)?"
            r"(?:You should probably run aider.*?\n+)?"
            r"(?:Aider v[^\n]*\n+)?"
            r"(?:Model:[^\n]*\n+)?"
            r"(?:Git repo:[^\n]*\n+)?"
            r"(?:Repo-map:[^\n]*\n+)?",
            "",
            content,
            flags=re.IGNORECASE,
        ).strip()
        if not content:
            continue
        if used + len(content) > max_characters and selected:
            break
        selected.append({"role": message["role"], "content": content})
        used += len(content)
        if len(selected) >= max_messages:
            break
    return list(reversed(selected))


def local_tool_names(tools):
    names = set()
    for tool in tools or []:
        function = tool.get("function") or {}
        name = clean_text(function.get("name"))
        if name:
            names.add(name)
    return names


def coerce_local_tool_call(raw, valid_names):
    if not isinstance(raw, dict):
        return None
    function = raw.get("function") if isinstance(raw.get("function"), dict) else None
    if function:
        name = clean_text(function.get("name"))
        arguments = function.get("arguments") or {}
    else:
        name = clean_text(
            raw.get("name")
            or raw.get("tool")
            or raw.get("tool_name")
            or raw.get("function")
            or raw.get("function_name")
        )
        arguments = (
            raw.get("arguments")
            if "arguments" in raw
            else raw.get("args")
            if "args" in raw
            else raw.get("parameters")
            if "parameters" in raw
            else raw.get("input")
            if "input" in raw
            else {}
        )
    if name not in valid_names:
        return None
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments)
        except ValueError:
            arguments = {}
    if not isinstance(arguments, dict):
        arguments = {}
    return {"type": "function", "function": {"name": name, "arguments": arguments}}


def coerce_local_tool_calls(raw, valid_names):
    if isinstance(raw, dict) and isinstance(raw.get("tool_calls"), list):
        raw = raw["tool_calls"]
    if isinstance(raw, dict) and isinstance(raw.get("tools"), list):
        raw = raw["tools"]
    if isinstance(raw, list):
        calls = []
        for item in raw:
            call = coerce_local_tool_call(item, valid_names)
            if call:
                calls.append(call)
        return calls
    call = coerce_local_tool_call(raw, valid_names)
    return [call] if call else []


def parse_bare_local_tool_arguments(raw):
    raw = (raw or "").strip()
    if not raw:
        return {}
    if raw.startswith("{"):
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
        except ValueError:
            return {}
    try:
        tree = ast.parse(f"_tool({raw})", mode="eval")
        call = tree.body
        if not isinstance(call, ast.Call):
            return {}
        arguments = {}
        if len(call.args) == 1:
            value = ast.literal_eval(call.args[0])
            if isinstance(value, dict):
                arguments.update(value)
        for keyword in call.keywords:
            if keyword.arg:
                arguments[keyword.arg] = ast.literal_eval(keyword.value)
        return arguments
    except (SyntaxError, ValueError, TypeError):
        return {}


def strip_json_code_fence(text):
    text = (text or "").strip()
    match = re.fullmatch(
        r"```(?:json|tool_call|tool)?\s*(.*?)\s*```",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    return match.group(1).strip() if match else text


def extract_local_text_tool_calls(content, valid_names):
    content = clean_text(content)
    if not content:
        return [], content

    # v4.1.5 (reported: "is qwen 30b wired up with tools?" — routed yes, but
    # its calls silently no-opped): qwen3-coder models emit tool calls in
    # their own dialect — <function=NAME><parameter=key>value</parameter>…
    # </function> — as plain text. Parse it like the other two dialects.
    function_calls = []
    for fmatch in re.finditer(
        r"<function=([A-Za-z0-9_\-]+)>(.*?)(?:</function>|\Z)",
        content,
        flags=re.IGNORECASE | re.DOTALL,
    ):
        name = clean_text(fmatch.group(1))
        args = {}
        for pmatch in re.finditer(
            r"<parameter=([A-Za-z0-9_\-]+)>\s*(.*?)\s*(?:</parameter>|\Z)",
            fmatch.group(2),
            flags=re.IGNORECASE | re.DOTALL,
        ):
            args[clean_text(pmatch.group(1))] = pmatch.group(2)
        if name:
            function_calls.extend(
                coerce_local_tool_calls(
                    [{"function": {"name": name, "arguments": args}}],
                    valid_names,
                )
            )
    if function_calls:
        visible = re.sub(
            r"<function=.*?(?:</function>|\Z)",
            "",
            content,
            flags=re.IGNORECASE | re.DOTALL,
        )
        visible = re.sub(
            r"</?tool_call>", "", visible, flags=re.IGNORECASE
        ).strip()
        return function_calls, visible

    calls = []
    visible = content
    for match in re.finditer(
        r"<tool_call>\s*(.*?)\s*</tool_call>",
        content,
        flags=re.IGNORECASE | re.DOTALL,
    ):
        try:
            parsed = json.loads(strip_json_code_fence(match.group(1)))
        except ValueError:
            continue
        calls.extend(coerce_local_tool_calls(parsed, valid_names))
    if calls:
        visible = re.sub(
            r"<tool_call>\s*.*?\s*</tool_call>",
            "",
            content,
            flags=re.IGNORECASE | re.DOTALL,
        ).strip()
        return calls, visible

    candidate = strip_json_code_fence(content)
    if candidate.startswith(("{", "[")):
        try:
            calls = coerce_local_tool_calls(json.loads(candidate), valid_names)
        except ValueError:
            calls = []
        if calls:
            return calls, ""

    bare = re.fullmatch(
        r"\s*([A-Za-z_][\w-]*)\s*\((.*)\)\s*;?\s*",
        content,
        flags=re.DOTALL,
    )
    if bare and bare.group(1) in valid_names:
        arguments = parse_bare_local_tool_arguments(bare.group(2))
        return [
            {
                "type": "function",
                "function": {"name": bare.group(1), "arguments": arguments},
            }
        ], ""

    return [], content


def public_web_url_error(url):
    """Reject loopback, LAN, link-local, metadata, and other non-public URLs."""
    try:
        parsed = urllib.parse.urlparse(clean_text(url))
    except ValueError as error:
        return f"invalid URL: {error}"
    if parsed.scheme.lower() not in {"http", "https"}:
        return "only HTTP and HTTPS URLs are supported"
    if not parsed.hostname:
        return "URL has no hostname"
    if parsed.username or parsed.password:
        return "embedded URL credentials are not allowed"
    try:
        addresses = {
            item[4][0]
            for item in socket.getaddrinfo(
                parsed.hostname,
                parsed.port or (443 if parsed.scheme.lower() == "https" else 80),
                type=socket.SOCK_STREAM,
            )
        }
    except (OSError, ValueError) as error:
        return f"hostname could not be resolved: {error}"
    if not addresses:
        return "hostname resolved to no addresses"
    for raw_address in addresses:
        try:
            address = ipaddress.ip_address(raw_address.split("%", 1)[0])
        except ValueError:
            return "hostname resolved to an invalid address"
        if not address.is_global:
            return f"non-public address is blocked: {address}"
    return ""


class PublicWebRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        reason = public_web_url_error(newurl)
        if reason:
            raise RuntimeError(f"redirect blocked: {reason}")
        return super().redirect_request(request, fp, code, msg, headers, newurl)


def local_tool_result(name, arguments, cwd, emit, control):
    arguments = arguments if isinstance(arguments, dict) else {}
    if control.cancel.is_set():
        raise RuntimeError("Turn stopped.")

    if name == "read_file":
        path = resolved_local_path(arguments.get("path"), cwd)
        scope_error = local_workspace_path_error("read", path, cwd)
        if scope_error:
            return scope_error
        protected_error = protected_local_path_error("read", path)
        if protected_error:
            return protected_error
        if not os.path.isfile(path):
            return f"ERROR: file not found: {path}"
        if os.path.getsize(path) > LOCAL_FILE_MAX_BYTES:
            return f"ERROR: file exceeds {LOCAL_FILE_MAX_BYTES:,} byte read limit: {path}"
        start = max(1, int(arguments.get("start_line") or 1))
        end = max(start, int(arguments.get("end_line") or start + 499))
        with open(path, encoding="utf-8", errors="replace") as handle:
            lines = handle.readlines()
        excerpt = "".join(
            f"{index}: {line}"
            for index, line in enumerate(lines[start - 1 : end], start=start)
        )
        emit({"type": "work", "kind": "tool", "content": f"Read {path} lines {start}-{min(end, len(lines))}"})
        return bounded_text(excerpt)

    if name == "write_file":
        path = resolved_local_path(arguments.get("path"), cwd)
        content = str(arguments.get("content") or "")
        scope_error = local_workspace_path_error("write", path, cwd)
        if scope_error:
            return scope_error
        protected_error = protected_local_path_error("write", path)
        if protected_error:
            return protected_error
        confirmation_reason = local_write_confirmation_reason(
            path,
            cwd,
            executable=bool(arguments.get("executable")),
        )
        policy_error = local_tool_policy_error("write_file", confirmation_reason, control)
        if confirmation_reason and policy_error:
            return policy_error
        if len(content.encode("utf-8")) > LOCAL_FILE_MAX_BYTES:
            return f"ERROR: content exceeds {LOCAL_FILE_MAX_BYTES:,} byte write limit"
        os.makedirs(os.path.dirname(path), exist_ok=True)
        temporary = f"{path}.awbench-{uuid.uuid4().hex}.tmp"
        with open(temporary, "w", encoding="utf-8") as handle:
            handle.write(content)
        os.replace(temporary, path)
        if arguments.get("executable"):
            os.chmod(path, os.stat(path).st_mode | 0o111)
        emit({"type": "work", "kind": "fileChange", "content": f"Wrote {path} ({len(content.encode('utf-8')):,} bytes)"})
        return f"OK: wrote {path}"

    if name == "edit_file":
        path = resolved_local_path(arguments.get("path"), cwd)
        old_text = str(arguments.get("old_text") or "")
        new_text = str(arguments.get("new_text") or "")
        scope_error = local_workspace_path_error("edit", path, cwd)
        if scope_error:
            return scope_error
        protected_error = protected_local_path_error("edit", path)
        if protected_error:
            return protected_error
        confirmation_reason = local_write_confirmation_reason(path, cwd)
        policy_error = local_tool_policy_error("edit_file", confirmation_reason, control)
        if confirmation_reason and policy_error:
            return policy_error
        if not old_text:
            return "ERROR: old_text must not be empty"
        try:
            original = Path(path).read_text(encoding="utf-8")
        except OSError as error:
            return f"ERROR: {error}"
        count = original.count(old_text)
        if count != 1:
            return f"ERROR: old_text matched {count} times; expected exactly once"
        updated = original.replace(old_text, new_text, 1)
        temporary = f"{path}.awbench-{uuid.uuid4().hex}.tmp"
        Path(temporary).write_text(updated, encoding="utf-8")
        os.replace(temporary, path)
        emit({"type": "work", "kind": "fileChange", "content": f"Edited {path}"})
        return f"OK: edited {path}"

    if name == "list_directory":
        root = resolved_local_path(arguments.get("path"), cwd)
        depth = min(4, max(1, int(arguments.get("depth") or 2)))
        scope_error = local_workspace_path_error("list", root, cwd)
        if scope_error:
            return scope_error
        protected_error = protected_local_path_error("list", root)
        if protected_error:
            return protected_error
        if not os.path.isdir(root):
            return f"ERROR: directory not found: {root}"
        entries = []
        root_depth = Path(root).parts
        for current, directories, files in os.walk(root):
            current_depth = len(Path(current).parts) - len(root_depth)
            if current_depth >= depth:
                directories[:] = []
            directories[:] = sorted(
                directory
                for directory in directories
                if directory != ".git"
                and not protected_local_path_reason(os.path.join(current, directory))
            )
            for directory in directories:
                entries.append(os.path.relpath(os.path.join(current, directory), root) + "/")
            for filename in sorted(files):
                full_path = os.path.join(current, filename)
                if protected_local_path_reason(full_path):
                    continue
                entries.append(os.path.relpath(full_path, root))
            if len(entries) >= 400:
                entries.append("[truncated]")
                break
        emit({"type": "work", "kind": "tool", "content": f"Listed {root}"})
        return "\n".join(entries) or "[empty directory]"

    if name == "search_files":
        query = clean_text(arguments.get("query"))
        root = resolved_local_path(arguments.get("path"), cwd)
        scope_error = local_workspace_path_error("search", root, cwd)
        if scope_error:
            return scope_error
        protected_error = protected_local_path_error("search", root)
        if protected_error:
            return protected_error
        protected_globs = [
            "!**/.git/**",
            "!**/.ssh/**",
            "!**/.qwen/**",
            "!**/.claude/**",
            "!**/.codex/**",
            "!**/.gemini/**",
            "!**/.gnupg/**",
            "!**/.aws/**",
            "!**/.azure/**",
            "!**/.kube/**",
            "!**/.docker/**",
            "!**/.config/gcloud/**",
            "!**/.config/agent-workbench-native/bridge-token",
            "!**/.config/agent-workbench-native/config.json",
            "!**/.config/agent-workbench-native/debug.jsonl",
            "!**/.config/agent-workbench-native/claude_mcp.json",
            "!**/.config/agent-workbench-native/gemini-titles.json",
            "!**/.config/agent-workbench-native/worker-jobs.json",
            "!**/.config/agent-workbench-native/sessions/**",
            "!**/.config/agent-workbench-native/connector-auth/**",
            "!**/.local/share/keyrings/**",
            "!**/.env",
            "!**/.env.*",
            "!**/.npmrc",
            "!**/.pypirc",
            "!**/.netrc",
            "!**/id_rsa",
            "!**/id_dsa",
            "!**/id_ecdsa",
            "!**/id_ed25519",
            "!**/credentials",
            "!**/credentials.json",
            "!**/*.key",
            "!**/*.pem",
            "!**/*.p12",
            "!**/*.pfx",
            "!**/keys_list.md",
            "!**/bridge-token",
            "!**/keys.json",
            "!**/mcp-oauth-tokens.json",
            "!**/oauth_creds.json",
        ]
        if path_is_under(real_local_path(root), real_local_path(CONFIG_DIR)):
            protected_globs += [
                "!bridge-token",
                "!config.json",
                "!debug.jsonl",
                "!claude_mcp.json",
                "!gemini-titles.json",
                "!worker-jobs.json",
                "!sessions/**",
                "!connector-auth/**",
            ]
        command = ["rg", "-n", "--hidden"]
        glob = clean_text(arguments.get("glob"))
        if glob:
            command += ["--glob", glob]
        for protected_glob in protected_globs:
            command += ["--glob", protected_glob]
        command += [query, root]
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=45,
            check=False,
        )
        emit({"type": "work", "kind": "command", "content": shlex.join(command)})
        return bounded_text(result.stdout or f"rg exit code {result.returncode}")

    if name == "run_command":
        command = str(arguments.get("command") or "")
        command_cwd = resolved_local_path(arguments.get("cwd"), cwd)
        timeout = min(900, max(1, int(arguments.get("timeout_seconds") or 120)))
        if not command:
            return "ERROR: command must not be empty"
        protected_error = protected_local_path_error("run command in", command_cwd)
        if protected_error:
            return protected_error
        protected_reason = protected_command_reason(command, command_cwd)
        if protected_reason:
            return f"ERROR: blocked command touching protected local data ({protected_reason})"
        confirmation_reason = dangerous_command_reason(command) or "run a shell command"
        policy_error = local_tool_policy_error("run_command", confirmation_reason, control)
        if policy_error:
            return policy_error
        if not os.path.isdir(command_cwd):
            return f"ERROR: working directory not found: {command_cwd}"
        emit({"type": "work", "kind": "command", "content": f"$ cd {shlex.quote(command_cwd)} && {command}"})
        try:
            result = subprocess.run(
                ["bash", "-lc", command],
                cwd=command_cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout,
                check=False,
            )
            output = result.stdout or ""
            if output:
                emit({"type": "work", "kind": "system", "content": bounded_text(output, 12_000)})
            return bounded_text(f"exit_code={result.returncode}\n{output}")
        except subprocess.TimeoutExpired as error:
            output = clean_text(error.stdout)
            return bounded_text(f"ERROR: command timed out after {timeout}s\n{output}")

    if name == "open_path":
        target = clean_text(arguments.get("target"))
        if not re.match(r"^https?://", target, flags=re.IGNORECASE):
            target = resolved_local_path(target, cwd)
            scope_error = local_workspace_path_error("open", target, cwd)
            if scope_error:
                return scope_error
            protected_error = protected_local_path_error("open", target)
            if protected_error:
                return protected_error
            if not os.path.exists(target):
                return f"ERROR: target not found: {target}"
        subprocess.Popen(
            ["xdg-open", target],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        emit({"type": "work", "kind": "command", "content": f"Opened {target}"})
        return f"OK: opened {target}"

    if name == "launch_app":
        command = clean_text(arguments.get("command"))
        command_cwd = resolved_local_path(arguments.get("cwd"), cwd)
        if not command:
            return "ERROR: command must not be empty"
        protected_error = protected_local_path_error("launch from", command_cwd)
        if protected_error:
            return protected_error
        protected_reason = protected_command_reason(command, command_cwd)
        if protected_reason:
            return f"ERROR: blocked launch touching protected local data ({protected_reason})"
        policy_error = local_tool_policy_error("launch_app", "launch a detached local command", control)
        if policy_error:
            return policy_error
        if not os.path.isdir(command_cwd):
            return f"ERROR: working directory not found: {command_cwd}"
        subprocess.Popen(
            ["bash", "-lc", command],
            cwd=command_cwd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        emit({"type": "work", "kind": "command", "content": f"Launched from {command_cwd}: {command}"})
        return f"OK: launched {command}"

    if name == "web_fetch":
        url = clean_text(arguments.get("url"))
        url_error = public_web_url_error(url)
        if url_error:
            return f"ERROR: {url_error}"
        policy_error = local_tool_policy_error(
            "web_fetch",
            f"send a network request to {urllib.parse.urlparse(url).hostname}",
            control,
        )
        if policy_error:
            return policy_error
        request = urllib.request.Request(
            url,
            headers={"User-Agent": "AgentWorkbenchNative/1.0"},
        )
        opener = urllib.request.build_opener(PublicWebRedirectHandler())
        with opener.open(request, timeout=30) as response:
            body = response.read(LOCAL_TOOL_MAX_OUTPUT + 1)
            charset = response.headers.get_content_charset() or "utf-8"
        emit({"type": "work", "kind": "tool", "content": f"Fetched {url}"})
        return bounded_text(body.decode(charset, errors="replace"))

    if name == "list_connectors":
        emit(
            {
                "type": "work",
                "kind": "command",
                "content": "Checked direct Qwen MCP connector status",
            }
        )
        return bounded_text(json.dumps(connector_statuses(force=True), indent=2))

    if name == "connector_task":
        if not experimental_local_connectors_enabled():
            return (
                "ERROR: direct local-model connector actions are disabled in "
                "the public beta"
            )
        connector = clean_text(arguments.get("connector")).lower()
        prompt = clean_text(arguments.get("prompt"))
        timeout = min(900, max(10, int(arguments.get("timeout_seconds") or 300)))
        if connector not in SUPPORTED_CONNECTORS:
            return f"ERROR: unsupported connector: {connector}"
        if not prompt:
            return "ERROR: connector prompt must not be empty"
        confirmation_reason = connector_task_confirmation_reason(connector, prompt)
        policy_error = local_tool_policy_error("connector_task", confirmation_reason, control)
        if confirmation_reason and policy_error:
            return policy_error
        if connector == "robinhood":
            write_action = re.search(
                r"\b(buy|sell|trade|order|cancel|exercise|deposit|withdraw|transfer)\b",
                prompt,
                flags=re.IGNORECASE,
            )
            if write_action and "CONFIRM ROBINHOOD ACTION" not in prompt:
                return (
                    "ERROR: Robinhood write actions require the exact phrase "
                    "CONFIRM ROBINHOOD ACTION in the connector prompt."
                )
        emit(
            {
                "type": "work",
                "kind": "worker",
                "content": f"Local Qwen MCP · {connector}",
            }
        )
        emit(
            {
                "type": "work",
                "kind": "command",
                "content": f"Direct MCP task · {connector}",
            }
        )
        try:
            return bounded_text(
                direct_connector_task(
                    connector,
                    prompt,
                    cwd,
                    timeout,
                    emit,
                    control,
                )
            )
        except subprocess.TimeoutExpired:
            return bounded_text(
                f"ERROR: connector task timed out after {timeout}s"
            )

    if name == "delegate_agent":
        agent = clean_text(arguments.get("agent")).lower()
        prompt = clean_text(arguments.get("prompt"))
        agent_cwd = resolved_local_path(arguments.get("cwd"), cwd)
        timeout = min(900, max(10, int(arguments.get("timeout_seconds") or 300)))
        maybe_emit_unsafe_permissions_notice(emit)
        protected_error = protected_local_path_error("delegate from", agent_cwd)
        if protected_error:
            return protected_error
        protected_reason = protected_command_reason(prompt, agent_cwd)
        if protected_reason:
            return f"ERROR: blocked delegation touching protected local data ({protected_reason})"
        policy_error = local_tool_policy_error(
            "delegate_agent",
            f"delegate work to {agent or 'another'} agent CLI",
            control,
        )
        if policy_error:
            return policy_error
        if agent == "claude":
            maybe_emit_claude_trust_preflight(agent_cwd, emit)
            command = [
                "claude",
                "-p",
                prompt,
                "--output-format",
                "text",
                "--no-session-persistence",
            ]
            if not safe_permissions_enabled():
                command += [
                    "--permission-mode",
                    "bypassPermissions",
                    "--dangerously-skip-permissions",
                ]
        elif agent == "codex":
            # No headless approval protocol exists for codex (plan Part 5b), but
            # honor the same OS sandbox as a direct codex session — otherwise a
            # sandboxed codex would run with full bypass the moment claude
            # delegates to it. Full bypass only when unsafe or opted in.
            sandbox = codex_sandbox_mode()
            command = ["codex", "exec"]
            if not safe_permissions_enabled() or sandbox == "danger-full-access":
                command += [
                    "--dangerously-bypass-approvals-and-sandbox",
                    "--dangerously-bypass-hook-trust",
                ]
                delegate_safety_notice = (
                    "Delegated Codex runs with NO sandbox (full access)."
                )
            else:
                command += ["-s", sandbox]
                delegate_safety_notice = f"Delegated Codex is sandboxed ({sandbox})."
            command += ["--skip-git-repo-check", "-C", agent_cwd, prompt]
        elif agent == "gemini":
            command = ["gemini", "-p", prompt, "-o", "text"]
            if safe_permissions_enabled():
                command += gemini_permission_args()
                delegate_safety_notice = (
                    "Delegated Gemini uses its default approval policy; a tool that "
                    "cannot be approved headlessly will fail rather than run unchecked."
                )
            else:
                command += gemini_permission_args()
                delegate_safety_notice = (
                    "Delegated Gemini runs with approvals bypassed (unsafe override)."
                )
        elif agent == "hermes":
            command = [
                "hermes",
                "chat",
                "--quiet",
                "--toolsets",
                "safe",
                "--source",
                "awbn-delegate",
                "--max-turns",
                "30",
                "-q",
                prompt,
            ]
        else:
            return f"ERROR: unsupported delegated agent: {agent}"
        if not shutil.which(command[0], path=subprocess_env().get("PATH")):
            return f"ERROR: {command[0]} is not installed"
        if agent in {"codex", "gemini"} and safe_permissions_enabled():
            # Keep the delegate path's disclosed safety posture matching its
            # actual flags, same as the direct codex/gemini session paths.
            emit({"type": "work", "kind": "system", "content": delegate_safety_notice})
        emit({"type": "work", "kind": "worker", "content": f"{agent} delegated task"})
        emit({"type": "work", "kind": "command", "content": f"$ {agent} <delegated prompt>"})
        try:
            result = subprocess.run(
                command,
                cwd=agent_cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout,
                check=False,
            )
        except subprocess.TimeoutExpired as error:
            return bounded_text(f"ERROR: {agent} timed out after {timeout}s\n{clean_text(error.stdout)}")
        return bounded_text(
            f"exit_code={result.returncode}\n{result.stdout or ''}"
        )

    return f"ERROR: unknown tool: {name}"


def stream_local_tool_agent(session, user_text, model, emit, control):
    installed = ollama_models()
    if not model or model in {"Default", "Auto"} or model not in installed:
        model = installed[0] if installed else (model or "qwen3-coder:30b")
    model_ctx = ollama_model_context(model)
    cwd = os.path.abspath(
        os.path.expanduser(clean_text(session.get("cwd")) or os.path.expanduser("~"))
    )
    if not os.path.isdir(cwd):
        cwd = os.path.expanduser("~")
        session["cwd"] = cwd
    backend = session.setdefault("backend", {})
    backend["model"] = model
    backend["local_tool_agent"] = True
    emit({"type": "meta", "backend": "local-tools", "model": model})
    emit(
        {
            "type": "work",
            "kind": "report",
            "content": (
                f"Local tool agent active · protected data blocked · high-risk actions gated · cwd {cwd}"
            ),
        }
    )

    messages = [
        {"role": "system", "content": local_agent_system_prompt(cwd, model)},
        *bounded_local_history(session),
        {"role": "user", "content": user_text},
    ]
    tools = local_agent_tools()
    total_input = 0
    total_output = 0
    last_prompt_tokens = 0
    repeated_calls = {}
    valid_tool_names = local_tool_names(tools)

    for step in range(LOCAL_AGENT_MAX_STEPS):
        if control.cancel.is_set():
            raise RuntimeError("Turn stopped.")
        payload = json.dumps(
            {
                "model": model,
                "messages": messages,
                "tools": tools,
                "stream": False,
                "options": {"temperature": 0},
            }
        ).encode("utf-8")
        request = urllib.request.Request(
            f"{OLLAMA_BASE}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        emit(
            {
                "type": "work",
                "kind": "reasoning",
                "content": (
                    "Planning the next action…"
                    if step == 0
                    else f"Evaluating tool results · step {step + 1}"
                ),
            }
        )
        with urllib.request.urlopen(request, timeout=600) as response:
            result = json.load(response)
        total_input += int(result.get("prompt_eval_count") or 0)
        total_output += int(result.get("eval_count") or 0)
        last_prompt_tokens = int(result.get("prompt_eval_count") or last_prompt_tokens)
        message = result.get("message") or {}
        content = clean_text(message.get("content"))
        tool_calls = coerce_local_tool_calls(
            message.get("tool_calls") or [],
            valid_tool_names,
        )
        if not tool_calls:
            tool_calls, content = extract_local_text_tool_calls(
                content,
                valid_tool_names,
            )

        if not tool_calls:
            if not content:
                content = "The local model completed without returning a response."
            emit({"type": "delta", "text": content})
            usage = {
                "input_tokens": total_input,
                "output_tokens": total_output,
                "total_tokens": total_input + total_output,
                "model_context_window": model_ctx,
            }
            emit_usage(emit, usage)
            update_context(
                session,
                {
                    "input_tokens": last_prompt_tokens,
                    "model_context_window": model_ctx,
                },
                model,
            )
            return content, model

        if content:
            emit({"type": "work", "kind": "reasoning", "content": content})
        messages.append(
            {
                "role": "assistant",
                "content": content,
                "tool_calls": tool_calls,
            }
        )
        for call in tool_calls:
            function = call.get("function") or {}
            name = clean_text(function.get("name"))
            arguments = function.get("arguments") or {}
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except ValueError:
                    arguments = {}
            signature = json.dumps(
                {"name": name, "arguments": arguments},
                sort_keys=True,
                default=str,
            )
            repeated_calls[signature] = repeated_calls.get(signature, 0) + 1
            if repeated_calls[signature] > 2:
                tool_result = (
                    "ERROR: identical tool call repeated. Inspect the prior result "
                    "and choose a different action."
                )
            else:
                try:
                    tool_result = local_tool_result(
                        name,
                        arguments,
                        cwd,
                        emit,
                        control,
                    )
                except Exception as error:
                    tool_result = f"ERROR: {type(error).__name__}: {error}"
            messages.append(
                {
                    "role": "tool",
                    "tool_name": name,
                    "content": bounded_text(tool_result),
                }
            )

    raise RuntimeError(
        f"Local agent exceeded {LOCAL_AGENT_MAX_STEPS} tool steps without completing."
    )


# ---------------------------------------------------------------------------
# Persistent streaming Claude session (Option A).
#
# Instead of one-shot `claude -p` per turn, keep ONE `claude -p --input-format
# stream-json` process alive per Workbench session. Each turn writes a single
# stream-json user message and reads events until the model is idle. Because the
# process stays resident, a background task's completion auto-re-invokes the
# model in the same stream (the deep-research "stand by then synthesize" case),
# and MCP servers initialize once per session instead of once per turn.
# Proven end-to-end in scratchpad/claude_stream_driver.py before integration.
# ---------------------------------------------------------------------------
CLAUDE_STREAM_SESSIONS: dict = {}
CLAUDE_STREAM_LOCK = threading.Lock()

# Live permission gating (claude only): pending can_use_tool control requests
# from the resident stream-json process, keyed by request_id. Each entry keeps
# what the UI needs to render an approve/deny card and what the response needs
# to answer the CLI. Codex/gemini have no headless permission protocol — their
# gating is an explicit separate spike, NOT handled here.
PENDING_PERMISSIONS: dict = {}
PENDING_PERMISSIONS_LOCK = threading.Lock()


def register_pending_permission(workbench_id, request_id, request):
    entry = {
        "id": clean_text(request_id),
        "session_id": clean_text(workbench_id),
        "tool": clean_text(request.get("tool_name")) or "tool",
        "input": request.get("input") if isinstance(request.get("input"), dict) else {},
        "suggestions": request.get("permission_suggestions") or [],
        "created_at": now_iso(),
    }
    with PENDING_PERMISSIONS_LOCK:
        PENDING_PERMISSIONS[entry["id"]] = entry
    return entry


def pop_pending_permission(request_id):
    with PENDING_PERMISSIONS_LOCK:
        return PENDING_PERMISSIONS.pop(clean_text(request_id), None)


def pending_permissions_for(workbench_id):
    workbench_id = clean_text(workbench_id)
    with PENDING_PERMISSIONS_LOCK:
        return [
            deepcopy(entry)
            for entry in PENDING_PERMISSIONS.values()
            if entry["session_id"] == workbench_id
        ]


def clear_pending_permissions(workbench_id):
    workbench_id = clean_text(workbench_id)
    with PENDING_PERMISSIONS_LOCK:
        stale = [
            key
            for key, entry in PENDING_PERMISSIONS.items()
            if entry["session_id"] == workbench_id
        ]
        for key in stale:
            PENDING_PERMISSIONS.pop(key, None)
    return len(stale)


class ClaudeStreamSession:
    def __init__(self, base_command, cwd, session_uuid, resume):
        self.base_command = list(base_command)
        self.cwd = cwd
        self.session_uuid = clean_text(session_uuid)
        # Signature excludes the per-launch session args so model/effort/prompt/
        # cwd changes force a relaunch but routine turns reuse the live process.
        self.signature = json.dumps([self.base_command, cwd], sort_keys=True)
        self.native_id = self.session_uuid
        self.lock = threading.Lock()
        cmd = list(self.base_command)
        cmd += (["--resume", self.session_uuid] if resume else ["--session-id", self.session_uuid])
        env = subprocess_env()
        cmd = resolve_command_executable(cmd, env)
        # Ground truth for permission-mode debugging: what THIS server actually
        # passed, as distinct from what the CLI's own re-exec may show in /proc.
        append_debug_event(
            "claude_stream_launch",
            session=self.session_uuid,
            argv_head=" ".join(cmd[:12]),
        )
        self.proc = subprocess.Popen(
            cmd,
            cwd=cwd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=env,
            start_new_session=True,
        )
        # A resident process never reaches the one-shot "read stderr at exit" path,
        # so its stderr pipe would fill (~64KB) and deadlock the child. Drain it
        # continuously into a bounded tail kept only for error diagnostics.
        self._stderr_tail: list = []
        threading.Thread(target=self._drain_stderr, daemon=True).start()

    def _drain_stderr(self):
        try:
            for line in self.proc.stderr:
                self._stderr_tail.append(line)
                if len(self._stderr_tail) > 200:
                    del self._stderr_tail[0]
        except (OSError, ValueError):
            pass

    def recent_stderr(self, limit=600):
        return "".join(self._stderr_tail)[-limit:]

    def is_alive(self):
        return self.proc is not None and self.proc.poll() is None

    def write_user(self, text):
        # stdin is shared between the turn thread (user messages) and HTTP
        # threads (permission control responses) — serialize the line writes.
        with self.lock:
            self.proc.stdin.write(
                json.dumps({"type": "user", "message": {"role": "user", "content": text}}) + "\n"
            )
            self.proc.stdin.flush()

    def write_control_response(self, request_id, response=None, error=""):
        """Answer a CLI control_request (permission prompt etc.) over stdin."""
        if error:
            payload = {"subtype": "error", "request_id": request_id, "error": error}
        else:
            payload = {
                "subtype": "success",
                "request_id": request_id,
                "response": response or {},
            }
        with self.lock:
            self.proc.stdin.write(
                json.dumps({"type": "control_response", "response": payload}) + "\n"
            )
            self.proc.stdin.flush()

    def interrupt(self):
        # Prefer a graceful stream-json interrupt; fall back to SIGINT to the group.
        if not self.is_alive():
            return
        try:
            self.proc.stdin.write(
                json.dumps({
                    "type": "control_request",
                    "request": {"subtype": "interrupt"},
                    "request_id": f"int-{uuid.uuid4()}",
                }) + "\n"
            )
            self.proc.stdin.flush()
        except OSError:
            try:
                os.killpg(os.getpgid(self.proc.pid), signal.SIGINT)
            except OSError:
                try:
                    self.proc.send_signal(signal.SIGINT)
                except OSError:
                    pass

    def close(self):
        if self.proc and self.proc.poll() is None:
            try:
                os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
            except OSError:
                try:
                    self.proc.terminate()
                except OSError:
                    pass
            try:
                self.proc.wait(timeout=2)
            except Exception:
                try:
                    os.killpg(os.getpgid(self.proc.pid), signal.SIGKILL)
                except OSError:
                    pass
        for stream in (self.proc.stdin, self.proc.stdout, self.proc.stderr):
            try:
                if stream:
                    stream.close()
            except OSError:
                pass


def claude_stream_session_for(workbench_id, base_command, cwd, session_uuid, resume):
    """Return a live persistent Claude session for *workbench_id*, (re)launching
    when none exists, the process died, or launch parameters changed."""
    workbench_id = clean_text(workbench_id)
    signature = json.dumps([list(base_command), cwd], sort_keys=True)
    with CLAUDE_STREAM_LOCK:
        existing = CLAUDE_STREAM_SESSIONS.get(workbench_id)
        if existing and existing.is_alive() and existing.signature == signature:
            return existing, False
        if existing:
            try:
                existing.close()
            except Exception:
                pass
            # A session we have launched before always resumes by id.
            resume = True
        session = ClaudeStreamSession(base_command, cwd, session_uuid, resume)
        CLAUDE_STREAM_SESSIONS[workbench_id] = session
        return session, True


def close_claude_stream_session(workbench_id):
    workbench_id = clean_text(workbench_id)
    with CLAUDE_STREAM_LOCK:
        session = CLAUDE_STREAM_SESSIONS.pop(workbench_id, None)
    # Any pending approval prompt is dead once the process that asked is gone —
    # clear it here so every teardown path (delete, /session/close, watchdog
    # kill) drops stale cards, not just the in-turn cleanup in stream_claude.
    clear_pending_permissions(workbench_id)
    if session:
        try:
            session.close()
        except Exception:
            pass
        return True
    return False


def close_all_claude_stream_sessions():
    with CLAUDE_STREAM_LOCK:
        sessions = list(CLAUDE_STREAM_SESSIONS.values())
        CLAUDE_STREAM_SESSIONS.clear()
    for session in sessions:
        try:
            session.close()
        except Exception:
            pass


# Claude tools that touch a specific file — the source for per-session
# file-level traceability. Searches (Grep/Glob) and opaque Bash are excluded on
# purpose: they don't name a single file operation.
CLAUDE_FILE_READ_TOOLS = {"Read"}
CLAUDE_FILE_WRITE_TOOLS = {"Edit", "MultiEdit", "Write", "NotebookEdit"}


# Folders that are never worth watching for agent-written files: build
# output, dependencies, engine caches. Same spirit as the project tree's own
# skip list, kept here so the watcher does not depend on the tree module.
WATCH_SKIP_DIRS = frozenset({
    ".dart_tool",
    ".git",
    ".godot",
    ".gradle",
    ".idea",
    ".mypy_cache",
    ".next",
    ".pytest_cache",
    ".ruff_cache",
    ".svelte-kit",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "target",
    "venv",
})
# One command can touch thousands of files (a build, a git checkout). The
# viewer shows a handful of panels, so reporting everything would be noise
# and a flood of events; the newest few are what the user actually wants.
WATCH_MAX_REPORTED = 8


def folder_file_times(root, skip_dirs=WATCH_SKIP_DIRS):
    """{path: modification time} for everything under `root` worth watching.

    Measured at 25ms for 6,427 files, so this is affordable around every
    command rather than only on demand."""
    times = {}
    if not root or not os.path.isdir(root):
        return times
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [
            name
            for name in dirnames
            if name not in skip_dirs and not name.startswith(".")
        ]
        for name in filenames:
            path = os.path.join(dirpath, name)
            try:
                times[path] = os.stat(path).st_mtime_ns
            except OSError:
                continue
    return times


def changed_files_since(before, after, limit=WATCH_MAX_REPORTED):
    """Files that appeared or changed between two folder_file_times snapshots.

    The viewer only ever lit up a file when a tool NAMED it — a Read, a Write,
    or a Bash `>` redirect. An agent that writes files by running a script
    named nothing, so its work was invisible until something happened to read
    the files back (reported: "I've yet to ever see any live coding or
    workings"). Comparing the folder before and after catches the write however
    it was made.

    Newest first, capped, and deletions are ignored — there is nothing to show
    for a file that is gone."""
    changed = [
        (stamp, path)
        for path, stamp in after.items()
        if before.get(path) != stamp
    ]
    changed.sort(reverse=True)
    return [path for _stamp, path in changed[:limit]]


def deleted_files_since(before, after, limit=WATCH_MAX_REPORTED):
    """Files that disappeared between two folder snapshots.

    Deletions cannot be opened in the viewer, but they still need a visible
    work-log event so the owner can see that the requested removal happened.
    Newest former files are reported first and the same flood cap applies.
    """
    deleted = [
        (stamp, path)
        for path, stamp in before.items()
        if path not in after
    ]
    deleted.sort(reverse=True)
    return [path for _stamp, path in deleted[:limit]]


def claude_file_access(tool_name, tool_input, cwd=""):
    """Return (op, path) for a file-touching tool_use, else (None, None).

    v4.1.1 (user repro: the viewer didn't follow a file the model created —
    reproduced: haiku wrote it via Bash, which carried no file signal):
    Bash commands are scanned for write targets too — `> path`, `>> path`,
    and `tee path` — so shell-written files light up the viewer like Write
    does. Conservative on purpose: only clear redirection targets count.
    """
    if not isinstance(tool_input, dict):
        return None, None
    path = clean_text(tool_input.get("file_path") or tool_input.get("notebook_path"))
    if path:
        if tool_name in CLAUDE_FILE_READ_TOOLS:
            return "read", path
        if tool_name in CLAUDE_FILE_WRITE_TOOLS:
            return "write", path
        return None, None
    if tool_name == "Bash":
        command = clean_text(tool_input.get("command"))
        match = re.search(
            r"(?:>>?|\btee(?:\s+-a)?)\s+(?:\"([^\"]+)\"|'([^']+)'|([^\s;|&)]+))",
            command,
        )
        if match:
            target = next((g for g in match.groups() if g), "")
            target = os.path.expanduser(clean_text(target))
            if target and not target.startswith("/") and cwd:
                target = os.path.normpath(os.path.join(cwd, target))
            if target.startswith("/") and not target.startswith(
                ("/dev/", "/proc/")
            ):
                return "write", target
    return None, None


def stream_claude(session, user_text, model, emit, control):
    backend = session.setdefault("backend", {})
    session_id = backend.get("session_id")
    first_turn = not session_id
    if first_turn:
        session_id = str(uuid.uuid4())
    # Launch a project-linked session IN its project folder (not the shared home
    # dir) so its native transcript lands in that project's Claude history and the
    # session is resumable from a terminal sitting in that folder. Decided once, on
    # the FIRST turn, and persisted as `native_cwd` so every resume reuses the same
    # folder — changing it later would break `claude --resume` (the session id is
    # bound to the folder it was created in). Existing and non-project sessions are
    # unchanged (they keep launching from the stored cwd / home).
    home = os.path.expanduser("~")
    cwd = clean_text(session.get("native_cwd"))
    if not cwd:
        if first_turn:
            project_dir = clean_text(session.get("project_root"))
            project_dir = os.path.abspath(os.path.expanduser(project_dir)) if project_dir else ""
            if project_dir and project_dir != home and os.path.isdir(project_dir):
                cwd = project_dir
                session["native_cwd"] = project_dir
        if not cwd:
            cwd = session.get("cwd") or home
    maybe_emit_unsafe_permissions_notice(emit)
    maybe_emit_claude_trust_preflight(cwd, emit)
    command = [
        "claude",
        "-p",
        "--output-format",
        "stream-json",
        "--input-format",
        "stream-json",
        "--verbose",
        # Forward raw API stream events (message_start/content_block_delta/
        # message_delta) so token usage can be emitted live DURING the turn
        # instead of only at the final `result` (reported: "35 seconds in and not
        # a single token displayed").
        "--include-partial-messages",
    ]
    if not safe_permissions_enabled():
        command += [
            "--permission-mode",
            "bypassPermissions",
            "--dangerously-skip-permissions",
        ]
    else:
        # Real interactive gating: route permission prompts over the stream-json
        # channel as can_use_tool control_requests (answered by the UI via
        # POST /session/permission-response). The explicit default permission
        # mode matters: the user's global ~/.claude/settings.json sets
        # defaultMode=bypassPermissions, which would silently skip every prompt
        # (verified live 2026-07-03) — AWBN owns the safety posture of the
        # sessions IT launches, without touching the user's own CLI defaults.
        command += [
            "--permission-mode",
            "default",
            "--permission-prompt-tool",
            "stdio",
        ]
    smart_mode = orchestration_mode() == "smart"
    # Combine orchestration policy (smart mode only) and the user's response-style
    # preference into a single --append-system-prompt so the style applies in both
    # smart and direct modes.
    append_blocks = []
    if smart_mode:
        append_blocks.append(CLAUDE_SMART_ORCHESTRATION_PROMPT)
    # Not smart-mode-only: a safety rule that stops an agent seizing the
    # pointer must not switch off with an orchestration preference.
    append_blocks.append(LIVE_MACHINE_WARNING)
    # Style rules are NOT injected for Claude. Claude Code already reads
    # ~/.claude/CLAUDE.md and the project's CLAUDE.md on its own, and that is
    # where the owner's rules actually live. Injecting a second copy here bought
    # nothing and made AWBN's answers differ from the same model in a terminal,
    # which is the one difference the app cannot afford: the whole point of AWBN
    # is to replace the terminal, not to be a worse version of it.
    #
    # Clients that do NOT read a config file of their own still get the style
    # block; see the non-Claude path, which keeps it.
    if not claude_reads_its_own_rules():
        style_prompt = response_style_prompt()
        if style_prompt:
            append_blocks.append(style_prompt)
    # v3.9.7: project chats are SELF-AWARE — they know they run inside AWBN,
    # which project they belong to, and that a file viewer follows their file
    # access (reported: "they must know they are open in awbn and which project
    # they are in so they know what to look for").
    awareness = project_awareness_prompt(session)
    if awareness:
        append_blocks.append(awareness)
    if append_blocks:
        command += ["--append-system-prompt", "\n\n".join(append_blocks)]
    if smart_mode:
        command += ["--agents", CLAUDE_SMART_AGENTS_JSON]
    # Curated MCP set (the user's servers minus the hanging codex MCP, plus the
    # delegate in smart mode), passed with --strict-mcp-config so ONLY these load.
    # This is the root fix for the MCP-init hang: the global codex MCP can never
    # initialize, while robinhood-trading and the rest stay available in every
    # Claude session. Applied in both smart and direct modes.
    mcp_config = build_claude_mcp_config(include_delegate=smart_mode, cwd=cwd)
    command += ["--mcp-config", mcp_config, "--strict-mcp-config"]
    model = clean_text(model or backend.get("model"))
    effort = clean_text(backend.get("effort"))
    if effort.lower() == "ultracode":
        model = "opus"
        effort = "max"
    if model and model != "Default":
        command += ["--model", model]
    if effort and effort != "Default":
        command += ["--effort", effort]
    # `command` is now the base launch command; the persistent session appends
    # --session-id (fresh) or --resume (continuation). Persist the native session
    # id now so later turns resume correctly even across a server restart.
    backend["session_id"] = session_id
    emit({"type": "meta", "backend": "claude", "model": model or "default"})
    logged_command = list(command)
    if "--append-system-prompt" in logged_command:
        index = logged_command.index("--append-system-prompt") + 1
        logged_command[index] = "<smart orchestration policy>"
    if "--agents" in logged_command:
        index = logged_command.index("--agents") + 1
        logged_command[index] = "<smart agent profiles>"
    emit(
        {
            "type": "work",
            "kind": "command",
            "content": "$ " + shlex.join(logged_command + ["<prompt>"]),
        }
    )
    workbench_id = clean_text(session.get("id")) or session_id
    # A previous turn that died with an unanswered permission prompt must not
    # leave stale cards behind (they also make the stall watchdog immune).
    clear_pending_permissions(workbench_id)
    stream_session, launched_now = claude_stream_session_for(
        workbench_id, command, cwd, session_id, resume=not first_turn
    )
    # A fresh resident process mid-session (watchdog relaunch) has lost the in-process
    # context, so the trimmed "unchanged" pointer no longer reflects what the model
    # holds — force the full AGENT_STATE body back into the next turn.
    if launched_now and not first_turn:
        session.pop("last_state_inject_hash", None)
    process = stream_session.proc
    control.set_process(process)
    control.set_stop_callback(stream_session.interrupt)
    try:
        stream_session.write_user(user_text)
    except (OSError, BrokenPipeError):
        # Resident process died between the liveness check and the write — relaunch
        # once (resume) and retry the message.
        close_claude_stream_session(workbench_id)
        stream_session, launched_now = claude_stream_session_for(
            workbench_id, command, cwd, session_id, resume=True
        )
        process = stream_session.proc
        control.set_process(process)
        control.set_stop_callback(stream_session.interrupt)
        stream_session.write_user(user_text)
    full = []
    pending_chat = None
    limit_error = ""
    # Piece 2: track in-flight explicit workers so we can emit worker_done when
    # the matching tool_result arrives.  Map tool_use_id → label string.
    _inflight_workers: dict = {}
    # tool_use id → file path for writes whose result hasn't arrived yet
    # (see the tool_done emit in the tool_result branch below).
    _pending_file_writes: dict = {}
    # tool_use id → snapshot of the project's file times, taken when a command
    # started. Comparing it when the command finishes finds files the command
    # wrote WITHOUT naming them — a script, a converter, a build step — which
    # the viewer could never see before (v4.3.6).
    _command_snapshots: dict = {}
    # Claude task_* events use task_id while tool_result uses tool_use_id.
    _task_worker_ids: dict = {}
    # Piece 3: model-inferred subagent tracking.
    _primary_model: str = ""
    _inferred_worker_id: str = ""  # "model:<model>" or "" when none active

    # Stall watchdog: `claude` blocks with no output when an MCP server never
    # finishes its init handshake, and the read loop below would wait forever.
    # Detect that, surface it, and stop the turn so it can't tick "Working"
    # indefinitely.
    _watch = {
        "last": time.monotonic(),
        "start": time.monotonic(),
        # A reused resident session does not re-emit `init` (only a fresh launch
        # does), so only guard against an MCP init-hang when we just launched.
        "init_seen": not launched_now,
        "warned": False,
        "killed": "",
        "background_idle_seconds": 0,
        "turn_done": False,
    }
    # Background tasks launched but not yet completed this turn. The turn finalizes
    # only on a `result` with pending_bg == 0, so a backgrounded Workflow/Bash job
    # auto-re-invokes the model and synthesizes within the same logical turn.
    pending_bg = 0

    # Live token accounting: with --include-partial-messages the CLI forwards
    # raw API stream events, so the usage strip counts up DURING the turn.
    # `in/out/cc/cr` = totals over the turn's completed messages (folded in
    # exactly once per message, on its `message_delta`); `cur_*` = the
    # in-flight message (input/cache known from `message_start`; output is a
    # chars/4 ESTIMATE from deltas until `message_delta` reports the real
    # count). Every emit is an absolute cumulative snapshot flagged `live` —
    # the UI overwrites, and the final authoritative `result` usage (not
    # flagged) lands last and wins everywhere.
    _live = {
        "in": 0, "out": 0, "cc": 0, "cr": 0,
        "cur_in": 0, "cur_out": 0, "cur_cc": 0, "cur_cr": 0,
        "last_emit": 0.0,
        # v4.0.6: tokens attributable to TOOL traffic — every model step
        # after the turn's first one exists because tool results came back,
        # so its fresh input+cache-write tokens are the tools' bill.
        "tool": 0,
        # Tokens burned by sub-agents. Their stream events are excluded from the
        # main loop on purpose (they carry parent_tool_use_id), and the final
        # `result` usage does not include them either, so without this they were
        # counted NOWHERE: the more work AWBN handed to a helper, the more the
        # turn under-reported. Smart mode actively encourages that delegation.
        "worker": 0,
        "msgs": 0,
    }

    # v4.1.2: live-typing capture — while a Write tool call's input streams,
    # forward (path, content-so-far) so the viewer shows the file being
    # typed BEFORE it lands on disk. Same bytes the turn already pays for;
    # zero extra tokens.
    _typing = {"index": None, "buf": "", "last": 0.0}

    # v4.7.4 (reported: "slow as hell compared to this, with no true
    # indication"): the CLI already streams the answer token by token — that is
    # what --include-partial-messages is for — but the bridge kept only the
    # token COUNT off those events and dropped the text. The Conversation pane
    # therefore sat empty for the whole turn and printed the finished answer in
    # one lump, which reads as the app being slow when it is exactly as fast as
    # the terminal. Forward the text as it arrives.
    #
    # "fresh" marks the start of a new assistant message. Only the LAST
    # assistant message is the Conversation result (superseded ones are demoted
    # to the Work Log below), so the first piece of each message tells the UI to
    # replace what it is showing rather than append to it.
    _stream = {"buf": "", "fresh": True, "any": False}

    def _emit_stream_text(piece):
        if _stream["fresh"]:
            emit({"type": "delta", "text": piece, "replace": True})
            _stream["buf"] = piece
            _stream["fresh"] = False
        else:
            emit({"type": "delta", "text": piece})
            _stream["buf"] += piece
        _stream["any"] = True

    def _emit_typing(force=False, done=False):
        now = time.monotonic()
        if not force and now - _typing["last"] < 0.15:
            return
        path, content = claude_write_typing_snapshot(_typing["buf"])
        if not path:
            return
        _typing["last"] = now
        emit(
            {
                "type": "file_typing",
                "path": path,
                "content": content,
                "done": done,
            }
        )

    def _emit_live_usage(force=False):
        now = time.monotonic()
        # ~8 updates/sec: fast enough to read as a live climbing counter
        # (reported at 0.5s: "very slowly... in terminal I see it quickly
        # ascending"), still cheap on the wire — live events skip the
        # context meter and session saves entirely.
        if not force and now - _live["last_emit"] < 0.125:
            return
        _live["last_emit"] = now
        emit_usage(
            emit,
            {
                "input_tokens": _live["in"] + _live["cur_in"],
                "output_tokens": _live["out"] + _live["cur_out"],
                "cache_creation_input_tokens": _live["cc"] + _live["cur_cc"],
                "cache_read_input_tokens": _live["cr"] + _live["cur_cr"],
                "tool_tokens": _live["tool"],
                "worker_tokens": _live["worker"],
            },
            live=True,
        )

    def _stall_watchdog():
        while (
            process.poll() is None
            and not control.cancel.is_set()
            and not _watch["turn_done"]
        ):
            now = time.monotonic()
            # A turn parked on a human approval is idle BY DESIGN — a pending
            # permission prompt must never be stall-killed (it may sit for
            # hours overnight). Treat it as fresh output.
            if pending_permissions_for(workbench_id):
                _watch["last"] = now
                time.sleep(4)
                continue
            if not _watch["init_seen"] and now - _watch["start"] > CLAUDE_INIT_TIMEOUT:
                _watch["killed"] = "init"
                emit({
                    "type": "work",
                    "kind": "system",
                    "content": (
                        f"⚠ Claude produced no output in {int(now - _watch['start'])}s - "
                        "an MCP server is hanging during startup. Stopping this turn."
                    ),
                })
                try:
                    process.terminate()
                    kill_deadline = time.monotonic() + 2
                    while process.poll() is None and time.monotonic() < kill_deadline:
                        time.sleep(0.1)
                    if process.poll() is None:
                        process.kill()
                except Exception:
                    pass
                return
            idle = now - _watch["last"]
            # v4.7.1 (release blocker: "cant be having this constantly stalling
            # if im releasing this beta"). This warned ONCE and then went quiet,
            # so a turn parked on a 30-minute background task showed a single
            # line at the two-minute mark and nothing for the next 28 minutes —
            # indistinguishable from a dead app. Re-warn on a cadence with the
            # running total, and say plainly that Stop is available.
            if _watch["init_seen"] and idle > CLAUDE_STALL_WARN:
                since_warn = now - _watch.get("warned_at", 0.0)
                if since_warn >= CLAUDE_STALL_REWARN:
                    _watch["warned"] = True
                    _watch["warned_at"] = now
                    minutes = int(idle // 60)
                    span = f"{minutes} min" if minutes >= 1 else f"{int(idle)}s"
                    emit({
                        "type": "work",
                        "kind": "system",
                        "content": (
                            f"… still waiting - no output for {span}. A tool or "
                            "background task may be slow. Press Stop to end it."
                        ),
                    })
                    emit({
                        "type": "stalled",
                        "idle_seconds": int(idle),
                        "background_pending": int(pending_bg),
                    })
            # Background tasks intentionally keep the turn open after a `result` so
            # Claude can synthesize once the task notification arrives. If that
            # notification never arrives, end the turn instead of leaving the UI
            # stuck "Working" forever.
            if _watch["init_seen"] and claude_background_idle_timed_out(pending_bg, idle):
                _watch["killed"] = "background_idle"
                _watch["background_idle_seconds"] = int(idle)
                emit({
                    "type": "work",
                    "kind": "system",
                    "content": (
                        f"⚠ Claude background work produced no updates for {int(idle)}s "
                        "- stopping this stuck turn."
                    ),
                })
                try:
                    process.terminate()
                    kill_deadline = time.monotonic() + 2
                    while process.poll() is None and time.monotonic() < kill_deadline:
                        time.sleep(0.1)
                    if process.poll() is None:
                        process.kill()
                except Exception:
                    pass
                return
            # Hard ceiling: genuinely hung (no output, nothing backgrounded) → kill it
            # so the turn ends instead of spinning "Working…" forever.
            if _watch["init_seen"] and pending_bg <= 0 and idle > CLAUDE_STALL_HARD:
                _watch["killed"] = "stall"
                emit({
                    "type": "work",
                    "kind": "system",
                    "content": (
                        f"⚠ Claude produced no output for {int(idle)}s with nothing "
                        "running in the background - stopping this stuck turn."
                    ),
                })
                try:
                    process.terminate()
                    kill_deadline = time.monotonic() + 2
                    while process.poll() is None and time.monotonic() < kill_deadline:
                        time.sleep(0.1)
                    if process.poll() is None:
                        process.kill()
                except Exception:
                    pass
                return
            time.sleep(4)

    threading.Thread(target=_stall_watchdog, daemon=True).start()

    for raw in process.stdout:
        _watch["last"] = time.monotonic()
        _watch["warned"] = False  # output resumed — re-arm the stall warning
        if control.cancel.is_set():
            break
        line = raw.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except ValueError:
            emit({"type": "work", "kind": "system", "content": line})
            continue
        event_type = event.get("type")
        if event_type == "system" and event.get("subtype") == "init":
            _watch["init_seen"] = True
            new_id = event.get("session_id")
            if new_id:
                backend["session_id"] = new_id
                session["native_thread_owned"] = True
        elif event_type == "system" and event.get("subtype") == "task_started":
            pending_bg += 1
            agent_id = clean_text(event.get("tool_use_id"))
            task_id = clean_text(event.get("task_id"))
            worker_id = agent_id or task_id or str(uuid.uuid4())
            if task_id:
                _task_worker_ids[task_id] = worker_id
            worker_name = clean_text(
                event.get("subagent_type")
                or event.get("description")
                or "sub-agent"
            )
            detail = clean_text(event.get("description") or event.get("prompt"))
            _inflight_workers.setdefault(worker_id, worker_name)
            emit(
                {
                    "type": "work",
                    "kind": "worker",
                    "content": worker_name,
                    "id": worker_id,
                    "task_id": task_id,
                    "detail": detail,
                    "status": "running",
                }
            )
        elif event_type == "system" and event.get("subtype") == "task_updated":
            task_id = clean_text(event.get("task_id"))
            patch = event.get("patch") or {}
            status = clean_text(patch.get("status")) or "running"
            emit(
                {
                    "type": "work",
                    "kind": "worker_update",
                    "content": status,
                    "id": _task_worker_ids.get(task_id, task_id),
                    "task_id": task_id,
                    "status": status,
                }
            )
        elif event_type == "system" and event.get("subtype") == "task_notification":
            pending_bg = max(0, pending_bg - 1)
            agent_id = clean_text(event.get("tool_use_id"))
            task_id = clean_text(event.get("task_id"))
            worker_id = _task_worker_ids.get(task_id, agent_id or task_id) or str(uuid.uuid4())
            usage = event.get("usage") or {}
            _live["worker"] += safe_int(usage.get("total_tokens"))
            _emit_live_usage(force=True)
            status = clean_text(event.get("status")) or "completed"
            summary = clean_text(event.get("summary"))
            label = _inflight_workers.pop(worker_id, "") or summary or "sub-agent"
            emit(
                {
                    "type": "work",
                    "kind": "worker_done",
                    "content": label,
                    "id": worker_id,
                    "task_id": task_id,
                    "status": status,
                    "summary": summary,
                    "total_tokens": safe_int(usage.get("total_tokens")),
                    "duration_ms": safe_int(usage.get("duration_ms")),
                }
            )
        elif event_type == "stream_event" and not event.get("parent_tool_use_id"):
            # Raw API stream events for the MAIN loop only (subagent events
            # carry parent_tool_use_id and are excluded — their tokens are
            # reported separately via task_notification, and the final
            # `result` usage does not include them either).
            inner = event.get("event") or {}
            inner_type = inner.get("type")
            if inner_type == "message_start":
                # New assistant message — its first text piece replaces what the
                # Conversation pane is showing instead of appending to it.
                _stream["fresh"] = True
                usage = (inner.get("message") or {}).get("usage") or {}
                _live["cur_in"] = safe_int(usage.get("input_tokens"))
                _live["cur_cc"] = safe_int(usage.get("cache_creation_input_tokens"))
                _live["cur_cr"] = safe_int(usage.get("cache_read_input_tokens"))
                _live["cur_out"] = safe_int(usage.get("output_tokens"))
                _emit_live_usage(force=True)
            elif inner_type == "content_block_start":
                block = inner.get("content_block") or {}
                if (
                    block.get("type") == "tool_use"
                    and clean_text(block.get("name")) == "Write"
                ):
                    _typing["index"] = inner.get("index")
                    _typing["buf"] = ""
            elif inner_type == "content_block_stop":
                if (
                    _typing["index"] is not None
                    and inner.get("index") == _typing["index"]
                ):
                    _emit_typing(force=True, done=True)
                    _typing["index"] = None
                    _typing["buf"] = ""
            elif inner_type == "content_block_delta":
                delta = inner.get("delta") or {}
                piece = (
                    delta.get("text")
                    or delta.get("thinking")
                    or delta.get("partial_json")
                    or ""
                )
                if piece:
                    # Streaming estimate; corrected by message_delta below.
                    _live["cur_out"] += max(1, len(piece) // 4)
                    _emit_live_usage()
                # Visible prose only — thinking and tool-argument JSON have
                # their own surfaces (reasoning rows, the live file preview).
                text_piece = delta.get("text") or ""
                if text_piece:
                    _emit_stream_text(text_piece)
                if (
                    _typing["index"] is not None
                    and inner.get("index") == _typing["index"]
                    and delta.get("partial_json")
                ):
                    _typing["buf"] += delta.get("partial_json")
                    _emit_typing()
            elif inner_type == "message_delta":
                # Fires exactly once per API message — fold the finished
                # message into the turn totals using its REAL output count.
                usage = inner.get("usage") or {}
                real_out = safe_int(usage.get("output_tokens"))
                _live["msgs"] += 1
                if _live["msgs"] > 1:
                    # Steps after the first exist because of tool results —
                    # their new input + cache-writes are tool traffic.
                    _live["tool"] += _live["cur_in"] + _live["cur_cc"]
                _live["in"] += _live["cur_in"]
                _live["cc"] += _live["cur_cc"]
                _live["cr"] += _live["cur_cr"]
                _live["out"] += real_out or _live["cur_out"]
                _live["cur_in"] = _live["cur_out"] = 0
                _live["cur_cc"] = _live["cur_cr"] = 0
                _emit_live_usage(force=True)
        elif event_type == "assistant":
            message = event.get("message") or {}
            turn_model = clean_text(message.get("model") or model)
            if update_context(session, message.get("usage") or {}, turn_model):
                emit({"type": "context", "context": session["context"]})

            # Piece 3: establish primary model on the first assistant event;
            # infer a subagent when model changes and no explicit worker is active.
            if turn_model:
                if not _primary_model:
                    _primary_model = turn_model
                elif turn_model != _primary_model and not _inflight_workers:
                    # Model handoff — infer a subagent worker if not already tracked.
                    inferred_id = f"model:{turn_model}"
                    if _inferred_worker_id != inferred_id:
                        # Clear any stale inferred worker first.
                        if _inferred_worker_id:
                            emit({
                                "type": "work",
                                "kind": "worker_done",
                                "id": _inferred_worker_id,
                                "content": _inferred_worker_id.split(":", 1)[-1],
                            })
                        _inferred_worker_id = inferred_id
                        short_name = turn_model.split("-")[0] if "-" in turn_model else turn_model
                        emit({
                            "type": "work",
                            "kind": "worker",
                            "content": short_name,
                            "model_inferred": True,
                            "id": inferred_id,
                        })
                elif turn_model == _primary_model and _inferred_worker_id:
                    # Model returned to primary — clear inferred worker.
                    emit({
                        "type": "work",
                        "kind": "worker_done",
                        "id": _inferred_worker_id,
                        "content": _inferred_worker_id.split(":", 1)[-1],
                    })
                    _inferred_worker_id = ""

            message_text = []
            for block in message.get("content") or []:
                if not isinstance(block, dict):
                    continue
                if block.get("type") == "text":
                    piece = block.get("text", "")
                    if piece:
                        message_text.append(piece)
                        limit_error = limit_error or claude_usage_limit_error(piece)
                elif block.get("type") == "tool_use":
                    tool_name = clean_text(block.get("name")) or "Claude tool"
                    tool_input = block.get("input") or {}
                    file_op, file_path = claude_file_access(
                        tool_name, tool_input, cwd
                    )
                    tool_event = {
                        "type": "work",
                        "kind": "tool",
                        "content": tool_name,
                    }
                    # The command itself, so a step can read "Ran: magick
                    # icon.png -resize 44x44" instead of "Ran a command" —
                    # which after 90 seconds tells the user nothing about what
                    # is taking so long. Claude sends it; we were discarding it.
                    if tool_name == "Bash":
                        shell_command = clean_text(tool_input.get("command"))
                        if shell_command:
                            tool_event["command"] = shell_command[:400]
                    # Structured file access → per-session traceability.
                    if file_op and file_path:
                        tool_event["file_op"] = file_op
                        tool_event["file_path"] = file_path
                        # A tool_use event fires when the model REQUESTS the
                        # write — the file hasn't changed on disk yet. Remember
                        # the id so the matching tool_result (write landed) can
                        # emit a follow-up event the UI uses to re-read the file
                        # live (content stays empty on purpose: streamed, never
                        # persisted or counted as a tool call).
                        if file_op == "write":
                            write_id = clean_text(block.get("id"))
                            if write_id:
                                _pending_file_writes[write_id] = file_path
                    elif tool_name == "Bash":
                        # A command that names no file may still write plenty.
                        # Remember what the folder looked like so the matching
                        # result can report whatever actually changed.
                        command_id = clean_text(block.get("id"))
                        if command_id and cwd:
                            _command_snapshots[command_id] = folder_file_times(cwd)
                    emit(tool_event)
                    if tool_name in {"Agent", "Task"}:
                        worker_name = clean_text(
                            tool_input.get("subagent_type")
                            or tool_input.get("agent")
                            or tool_input.get("description")
                            or "Claude sub-agent"
                        )
                        worker_model = clean_text(tool_input.get("model"))
                        label = (
                            f"{worker_name} · {worker_model}"
                            if worker_model
                            else worker_name
                        )
                        tool_use_id = clean_text(block.get("id")) or str(uuid.uuid4())
                        # Piece 2: record in-flight worker so we can close it.
                        _inflight_workers[tool_use_id] = label
                        emit(
                            {
                                "type": "work",
                                "kind": "worker",
                                "content": label,
                                "id": tool_use_id,
                            }
                        )
            visible_message = "\n\n".join(message_text).strip()
            if visible_message:
                if pending_chat is not None:
                    # Match Codex and Claude's native transcript: superseded
                    # assistant messages are progress narration in Work Log;
                    # only the last assistant message is the Conversation result.
                    emit({"type": "work", "kind": "note", "content": pending_chat})
                pending_chat = visible_message
        elif event_type == "user":
            # Piece 2: a tool_result with parent_tool_use_id signals that the
            # matching subagent has finished (mirrors OG ~line 3449).
            message = event.get("message") or {}
            for block in (message.get("content") or []):
                if not isinstance(block, dict):
                    continue
                if block.get("type") != "tool_result":
                    continue
                parent_id = clean_text(block.get("tool_use_id") or "")
                # Write finished — the file is now really on disk. Tell the UI
                # so the code pane can re-read it immediately (real-time view)
                # instead of waiting for its 8s poll or a manual refresh.
                if parent_id and parent_id in _pending_file_writes:
                    emit({
                        "type": "work",
                        "kind": "tool_done",
                        "content": "",
                        "file_op": "write",
                        "file_path": _pending_file_writes.pop(parent_id),
                    })
                if parent_id and parent_id in _command_snapshots:
                    before = _command_snapshots.pop(parent_id)
                    after = folder_file_times(cwd)
                    for path in changed_files_since(before, after):
                        emit({
                            "type": "work",
                            "kind": "tool_done",
                            "content": "",
                            "file_op": "write",
                            "file_path": path,
                        })
                    for path in deleted_files_since(before, after):
                        emit({
                            "type": "work",
                            "kind": "tool_done",
                            "content": f"Deleted {os.path.basename(path)}",
                            "file_op": "delete",
                            "file_path": path,
                        })
                if parent_id and parent_id in _inflight_workers:
                    label = _inflight_workers.pop(parent_id)
                    emit({
                        "type": "work",
                        "kind": "worker_done",
                        "id": parent_id,
                        "content": label,
                    })
        elif event_type == "result":
            # Turn ended — clear any remaining inferred worker.
            if _inferred_worker_id:
                emit({
                    "type": "work",
                    "kind": "worker_done",
                    "id": _inferred_worker_id,
                    "content": _inferred_worker_id.split(":", 1)[-1],
                })
                _inferred_worker_id = ""
            result = clean_text(event.get("result"))
            limit_error = (
                limit_error
                or claude_usage_limit_error(result)
                or claude_usage_limit_error(event.get("error"))
            )
            # The Claude CLI computes the turn's real cost itself and reports
            # it as `total_cost_usd`. AWBN used to ignore it and price the
            # turn from its own rate table instead, which excludes
            # cache-CREATION tokens — measured 2026-07-28 on a haiku turn:
            # estimate $0.0021 against the CLI's actual $0.0184, understated
            # 8.8x, because 7,864 cache-creation tokens at the 1-hour rate
            # were the bulk of the cost. Use the number the client already
            # worked out (v4.3.3).
            claude_usage = dict(event.get("usage") or {})
            reported_cost = event.get("total_cost_usd")
            if reported_cost is not None:
                claude_usage["cost_usd"] = reported_cost
            emit_usage(emit, claude_usage)
            if limit_error or event.get("subtype") not in {None, "success", "completed"}:
                # Stop the stall watchdog before bailing out of the loop — these
                # in-loop raises used to skip the post-loop turn_done flag, leaving
                # the watchdog thread spinning every 4s for the life of the session.
                _watch["turn_done"] = True
            if limit_error:
                raise RuntimeError(limit_error)
            if event.get("subtype") not in {None, "success", "completed"}:
                raise RuntimeError(result or clean_text(event.get("error")) or "Claude turn failed.")
            # Finalize only when no background work is still pending. If a Workflow
            # or background Bash job is in flight, keep reading — its completion
            # auto-re-invokes the model to synthesize within this same turn.
            if pending_bg <= 0:
                final_text = pending_chat or result
                if final_text:
                    full.append(final_text)
                    # The answer normally arrived live, piece by piece, above.
                    # Re-send it only when it did not, or when what streamed
                    # does not match the authoritative final text — the saved
                    # transcript and the pane must never disagree.
                    if not _stream["any"] or _stream["buf"].strip() != final_text.strip():
                        emit({"type": "delta", "text": final_text, "replace": True})
                break
        elif event_type == "control_request":
            request_id = clean_text(event.get("request_id"))
            request = event.get("request") or {}
            subtype = clean_text(request.get("subtype"))
            if subtype == "can_use_tool" and request_id:
                entry = register_pending_permission(workbench_id, request_id, request)
                emit(
                    {
                        "type": "permission_request",
                        "request": entry,
                    }
                )
                emit(
                    {
                        "type": "work",
                        "kind": "system",
                        "content": (
                            f"⏸ Claude is asking permission to use {entry['tool']} - "
                            "approve or deny in the prompt card."
                        ),
                    }
                )
            elif request_id:
                # Never leave an unanswered control request — the CLI would block
                # on it forever.
                try:
                    stream_session.write_control_response(
                        request_id,
                        error=f"Agent Workbench does not handle control_request subtype '{subtype}'.",
                    )
                except (OSError, BrokenPipeError):
                    pass
        elif event_type == "control_response":
            # Ack frames for control requests WE sent (interrupts) — bookkeeping only.
            pass
        elif event_type == "system":
            # Unhandled system telemetry (thinking_tokens, rate_limit_event, and
            # similar internal bookkeeping) — every system subtype we surface to the
            # user is handled explicitly above, so anything reaching here is noise.
            # Don't dump its raw JSON into the work log.
            pass
        else:
            emit({"type": "work", "kind": "system", "content": line})
    # Turn finished (or aborted) — the persistent process stays alive for the next
    # turn, so stop the watchdog and DON'T wait on / kill the process here.
    _watch["turn_done"] = True
    # Any permission prompt still unanswered at turn end is dead — the process
    # that asked is finishing or being torn down. Drop the stale cards.
    clear_pending_permissions(workbench_id)
    process.poll()
    if _watch["killed"] == "init":
        close_claude_stream_session(workbench_id)
        # The native session never finished initializing, so its id maps to nothing.
        # Clear it so a retry starts a FRESH session (--session-id) instead of trying
        # to --resume a session that was never created (which would fail every time).
        backend.pop("session_id", None)
        session.pop("native_thread_owned", None)
        raise RuntimeError(
            "Claude stalled during MCP server startup and was stopped automatically. "
            "Re-send the prompt, or switch orchestration to 'Direct driver only' in "
            "Workbench options to skip the local-delegate MCP and reduce startup hangs."
        )
    if _watch["killed"] == "stall":
        # Mid-turn hard-stall: the process was killed. Tear it down so the next turn
        # relaunches and --resumes cleanly. The native session DID initialize, so keep
        # its id — context is preserved on the resume.
        close_claude_stream_session(workbench_id)
        raise RuntimeError(
            "Claude stopped producing output and was ended automatically. "
            "Re-send to continue - the session and its context are preserved."
        )
    if _watch["killed"] == "background_idle":
        for worker_id, label in list(_inflight_workers.items()):
            emit({
                "type": "work",
                "kind": "worker_done",
                "id": worker_id,
                "content": label,
                "status": "interrupted",
            })
        _inflight_workers.clear()
        append_debug_event(
            "claude_background_idle_timeout",
            session=workbench_id,
            pending_bg=pending_bg,
            idle_seconds=_watch.get("background_idle_seconds") or 0,
            timeout_seconds=CLAUDE_BACKGROUND_IDLE_TIMEOUT,
        )
        # The old stream may still contain a late tail if the task eventually wakes
        # up. Drop it now so the next user turn starts from a clean resumed process.
        close_claude_stream_session(workbench_id)
        raise RuntimeError(
            "Claude had background work pending but produced no updates before the "
            f"{int(CLAUDE_BACKGROUND_IDLE_TIMEOUT)}s safety timeout. The stuck turn "
            "was stopped; re-send to continue from the preserved Claude session."
        )
    if control.cancel.is_set():
        # Tear the resident process down on Stop — don't just break the read loop.
        # The interrupted turn keeps emitting its tail (leftover deltas + its
        # terminating `result`) into the pipe; if the process survived, the NEXT
        # turn would read that stale tail first, print old text and finalize early,
        # mis-attributing every later turn. Killing it forces a clean relaunch,
        # which `--resume`s the native session so context is preserved.
        close_claude_stream_session(workbench_id)
        raise RuntimeError("Turn stopped.")
    if process.returncode not in (0, None):
        # The resident process exited unexpectedly — drop it so the next turn
        # relaunches (and resumes) cleanly.
        error = stream_session.recent_stderr()
        close_claude_stream_session(workbench_id)
        if not full:
            limit_error = limit_error or claude_usage_limit_error(error)
            if limit_error:
                raise RuntimeError(limit_error)
            raise RuntimeError(f"Claude exited {process.returncode}: {error[:600]}")
    if limit_error:
        raise RuntimeError(limit_error)
    backend["session_id"] = backend.get("session_id") or session_id
    if backend.get("session_id"):
        session["native_thread_owned"] = True
    return "\n\n".join(full), model or "default"


def stream_gemini(session, user_text, model, emit, control):
    backend = session.setdefault("backend", {})
    session_id = backend.get("session_id")
    first_turn = not session_id
    if first_turn:
        session_id = str(uuid.uuid4())
    maybe_emit_unsafe_permissions_notice(emit)
    command = [
        "gemini",
        "-p",
        user_text,
        "--output-format",
        "stream-json",
    ]
    if safe_permissions_enabled():
        # Headless Gemini has no structured approval-response channel.  Its
        # default policy is still the safe choice: requests needing approval
        # fail instead of silently gaining full access to the user's machine.
        command += gemini_permission_args(skip_trust_on_unsafe=True)
        emit(
            {
                "type": "work",
                "kind": "system",
                "content": (
                    "Gemini uses its default approval policy. A tool that cannot "
                    "be approved in headless mode will fail safely."
                ),
            }
        )
    else:
        command += gemini_permission_args(skip_trust_on_unsafe=True)
    model = clean_text(model or backend.get("model"))
    if model and model not in {"Default", "Auto"}:
        command += ["--model", model]
    if first_turn:
        command += ["--session-id", session_id]
    else:
        command += ["--resume", session_id]
    emit({"type": "meta", "backend": "gemini", "model": model or "Auto"})
    logged_command = ["gemini", "-p", "<prompt>", "--output-format", "stream-json"]
    logged_command += gemini_permission_args(skip_trust_on_unsafe=True)
    emit({"type": "work", "kind": "command", "content": "$ " + shlex.join(logged_command)})
    process = run_process(command, session.get("cwd") or os.path.expanduser("~"), control)
    visible_chunks = []
    final_text = ""
    for raw in process.stdout:
        if control.cancel.is_set():
            break
        line = raw.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except ValueError:
            emit({"type": "work", "kind": "system", "content": line})
            continue
        event_type = event.get("type")
        if event_type == "init":
            backend["session_id"] = event.get("session_id") or session_id
            if backend.get("session_id"):
                session["native_thread_owned"] = True
        elif event_type == "message":
            if event.get("role") == "assistant":
                thought, visible = split_gemini_visible_text(clean_text(event.get("content")))
                if thought:
                    emit({"type": "work", "kind": "reasoning", "content": thought})
                if visible:
                    visible_chunks.append(visible)
        elif event_type == "result":
            thought, visible = split_gemini_visible_text(clean_text(event.get("result")))
            if thought:
                emit({"type": "work", "kind": "reasoning", "content": thought})
            final_text = visible or clean_text(" ".join(visible_chunks))
            if final_text:
                emit({"type": "delta", "text": final_text})
            emit_usage(emit, event.get("stats") or {})
            if event.get("status") not in {None, "success", "completed"}:
                raise RuntimeError(final_text or "Gemini turn failed.")
            break
        else:
            emit({"type": "work", "kind": "system", "content": line})
    process.wait()
    if control.cancel.is_set():
        raise RuntimeError("Turn stopped.")
    if process.returncode not in (0, None) and not final_text:
        error = process_stderr_text(process)
        raise RuntimeError(f"Gemini exited {process.returncode}: {error[:600]}")
    backend["session_id"] = backend.get("session_id") or session_id
    if backend.get("session_id"):
        session["native_thread_owned"] = True
    return final_text, model or "Auto"


def stream_hermes(session, user_text, model, emit, control):
    backend = session.setdefault("backend", {})
    awbn_prompt = (
        "You are Hermes running inside Agent Workbench Native.\n"
        "This AWBN integration supports text responses and the enabled safe "
        "Hermes tools only. It does not currently support image generation or "
        "image artifact attachment. If the user asks you to generate an image, "
        "say that Hermes in AWBN cannot generate images yet and offer a concise "
        "image prompt instead.\n\n"
        f"User request:\n{user_text}"
    )
    command = [
        "hermes",
        "chat",
        "--quiet",
        "--toolsets",
        "safe",
        "--source",
        "awbn",
        "--ignore-rules",
        "--max-turns",
        "30",
        "-q",
        awbn_prompt,
    ]
    model = clean_text(model or backend.get("model"))
    if model and model != "Default":
        command += ["--model", model]
    emit({"type": "meta", "backend": "hermes", "model": model or "Default"})
    emit(
        {
            "type": "work",
            "kind": "command",
            "content": "$ hermes chat --quiet --toolsets safe --ignore-rules -q <prompt>",
        }
    )
    process = run_process(command, session.get("cwd") or os.path.expanduser("~"), control)
    chunks = []
    for raw in process.stdout:
        if control.cancel.is_set():
            break
        if raw:
            chunks.append(raw)
    process.wait()
    if control.cancel.is_set():
        raise RuntimeError("Turn stopped.")
    output = clean_text("".join(chunks))
    if output:
        emit({"type": "delta", "text": output})
    if process.returncode not in (0, None) and not output:
        error = process_stderr_text(process)
        raise RuntimeError(f"Hermes exited {process.returncode}: {error[:600]}")
    backend["model"] = model or "Default"
    return output or "Hermes completed without returning text.", model or "Default"


def custom_client_config_for_session(session):
    agent_key = clean_text(session.get("agent")).lower()
    config = load_json(CONFIG_FILE, {}) or {}
    for client in config.get("custom_clients") or []:
        if not isinstance(client, dict):
            continue
        if clean_text(client.get("key")).lower() == agent_key:
            resolved = dict(client)
            model = custom_client_ollama_model(resolved)
            if custom_client_is_aider(resolved) and model:
                resolved.setdefault("backend", "ollama-tools")
                resolved.setdefault("model", model)
                resolved.setdefault("access", "full-user")
            return resolved
    return None


def looks_like_git_repo(path):
    if not path:
        return False
    root = Path(os.path.abspath(os.path.expanduser(clean_text(path))))
    if not root.is_dir():
        return False
    git_dir = root / ".git"
    return git_dir.is_dir() or git_dir.is_file()


def custom_client_is_aider(client):
    command = clean_text((client or {}).get("command"))
    try:
        return any(Path(token).name == "aider" for token in shlex.split(command))
    except ValueError:
        return False


def custom_client_ollama_model(client):
    command = clean_text((client or {}).get("command"))
    match = re.search(r"--model\s+(?:ollama_chat|ollama)/([^\s\"']+)", command)
    if match:
        return clean_text(match.group(1))
    label = clean_text((client or {}).get("model") or (client or {}).get("label"))
    return label if label in ollama_models() else ""


def truthy_config(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return clean_text(value).lower() in {"1", "true", "yes", "on", "persistent", "keep-alive", "keep_alive"}


def custom_client_persistent_enabled(client):
    command = clean_text((client or {}).get("command"))
    if not command or "{prompt}" in command or custom_client_is_aider(client):
        return False
    return (
        truthy_config((client or {}).get("persistent"))
        or truthy_config((client or {}).get("keep_alive"))
        or clean_text((client or {}).get("session_mode")).lower() == "persistent"
        or clean_text((client or {}).get("mode")).lower() == "persistent"
    )


def custom_session_slug(session):
    title = re.sub(
        r"[^a-z0-9]+",
        "-",
        clean_text(session.get("title")).lower(),
    ).strip("-")
    short_id = clean_text(session.get("id"))[:8] or uuid.uuid4().hex[:8]
    return f"{title[:48] or 'custom-project'}-{short_id}"


def ensure_aider_workspace(session):
    home = os.path.abspath(os.path.expanduser("~"))
    current = os.path.abspath(
        os.path.expanduser(clean_text(session.get("cwd")) or home)
    )
    if current != home and os.path.isdir(current):
        return current

    workspace = os.path.join(CUSTOM_PROJECTS_DIR, custom_session_slug(session))
    os.makedirs(workspace, exist_ok=True)
    if not looks_like_git_repo(workspace):
        subprocess.run(
            ["git", "init", "-q", workspace],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    session["cwd"] = workspace
    backend = session.setdefault("backend", {})
    backend["workspace_auto_created"] = True
    return workspace


def preferred_custom_cli_cwd(session):
    session_cwd = clean_text(session.get("cwd")) or os.path.expanduser("~")
    if looks_like_git_repo(session_cwd) and not os.path.abspath(os.path.expanduser(session_cwd)) == os.path.abspath(os.path.expanduser("~")):
        return os.path.abspath(os.path.expanduser(session_cwd))

    config = load_json(CONFIG_FILE, {}) or {}
    candidates = []
    for value in [
        config.get("cwd"),
        *(config.get("recent_projects") or []),
    ]:
        value = clean_text(value)
        if value:
            candidates.append(value)
    for workspace in config.get("workspace_tabs") or []:
        if isinstance(workspace, dict):
            value = clean_text(workspace.get("cwd"))
            if value:
                candidates.append(value)
    for value in candidates:
        absolute = os.path.abspath(os.path.expanduser(value))
        if looks_like_git_repo(absolute):
            return absolute

    return os.path.abspath(os.path.expanduser(session_cwd))


def add_aider_session_options(command, cwd):
    additions = []
    options = {
        "--no-pretty": None,
        "--no-fancy-input": None,
        "--restore-chat-history": None,
        "--chat-history-file": os.path.join(cwd, ".aider.chat.history.md"),
        "--input-history-file": os.path.join(cwd, ".aider.input.history"),
    }
    for option, value in options.items():
        if option in command:
            continue
        additions.append(option)
        if value:
            additions.append(value)
    for path in aider_editable_files(cwd):
        additions.extend(["--file", path])
    insert_at = command.index("--message") if "--message" in command else len(command)
    command[insert_at:insert_at] = additions


def aider_editable_files(cwd):
    command = [
        "git",
        "-C",
        cwd,
        "ls-files",
        "--cached",
        "--others",
        "--exclude-standard",
    ]
    result = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
    )
    candidates = []
    for relative in result.stdout.splitlines():
        relative = relative.strip()
        if not relative or relative.startswith("."):
            continue
        path = os.path.abspath(os.path.join(cwd, relative))
        if not path.startswith(os.path.abspath(cwd) + os.sep):
            continue
        try:
            size = os.path.getsize(path)
        except OSError:
            continue
        if os.path.isfile(path) and size <= 250_000:
            candidates.append((size, path))
    candidates.sort(key=lambda item: item[0])
    return [path for _size, path in candidates[:24]]


def aider_operational_prompt(user_text, cwd):
    return f"""You are operating through Aider with direct read/write access to the project at:
{cwd}

Files supplied by Aider are real local files. You may also create new files in this project.
Never claim that you cannot access or save project files. When the user asks you to build,
save, edit, fix, or create something, perform the file changes through Aider and then report
the exact paths changed. Do not tell the user to copy or save code manually.

User request:
{user_text}"""


def token_number(value, suffix):
    number = float(value)
    multiplier = {"k": 1_000, "m": 1_000_000}.get(suffix.lower(), 1)
    return int(number * multiplier)


def clean_aider_output(lines, emit):
    visible = []
    startup = []
    input_tokens = 0
    output_tokens = 0
    token_pattern = re.compile(
        r"Tokens:\s*([\d.]+)\s*([kKmM]?)\s+sent,\s*"
        r"([\d.]+)\s*([kKmM]?)\s+received\.\s*"
    )
    startup_patterns = (
        "Detected dumb terminal",
        "Warning: Input is not a terminal",
        "You should probably run aider",
        "Aider v",
        "Model:",
        "Git repo:",
        "Repo-map:",
    )
    for raw_line in lines:
        line = raw_line.rstrip()
        if not line:
            if visible and visible[-1] != "":
                visible.append("")
            continue
        if set(line) <= {"─", "-", " "}:
            continue
        match = token_pattern.search(line)
        if match:
            input_tokens = token_number(match.group(1), match.group(2))
            output_tokens = token_number(match.group(3), match.group(4))
            line = token_pattern.sub("", line).strip()
            if not line:
                continue
        if line.startswith(startup_patterns):
            startup.append(line)
            continue
        visible.append(line)
    if startup:
        emit(
            {
                "type": "work",
                "kind": "system",
                "content": "\n".join(startup),
            }
        )
    if input_tokens or output_tokens:
        emit_usage(
            emit,
            {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
            },
        )
    return "\n".join(visible).strip()


def interpolate_custom_command(command, prompt, model, cwd, title):
    result = []
    for token in shlex.split(command):
        token = token.replace("{prompt}", prompt)
        token = token.replace("{model}", model)
        token = token.replace("{cwd}", cwd)
        token = token.replace("{title}", title)
        result.append(token)
    return result


def run_custom_cli_pty(command, cwd, stdin_payload, emit, control):
    """Run a configured custom CLI through a PTY and stream display-safe output."""
    master_fd = None
    slave_fd = None
    process = None
    output_chunks = []
    try:
        master_fd, slave_fd = pty.openpty()
        try:
            fcntl.ioctl(
                slave_fd,
                termios.TIOCSWINSZ,
                struct.pack("HHHH", 40, 160, 0, 0),
            )
        except OSError:
            pass
        env = subprocess_env()
        env["TERM"] = env.get("TERM") or "xterm-256color"
        env["AGENT_WORKBENCH"] = "1"
        process = subprocess.Popen(
            resolve_command_executable(command, env),
            cwd=cwd,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            env=env,
            preexec_fn=os.setsid,
            close_fds=True,
        )
        control.set_process(process)
        os.close(slave_fd)
        slave_fd = None
        if stdin_payload:
            try:
                os.write(master_fd, stdin_payload.encode("utf-8", errors="replace"))
            except OSError:
                pass

        sent_interrupt = False
        cancel_started = 0.0
        while True:
            if control.cancel.is_set() and process.poll() is None:
                if not sent_interrupt:
                    sent_interrupt = True
                    cancel_started = time.monotonic()
                    try:
                        os.killpg(os.getpgid(process.pid), signal.SIGINT)
                    except OSError:
                        try:
                            process.terminate()
                        except OSError:
                            pass
                elif time.monotonic() - cancel_started > 1.5:
                    try:
                        os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                    except OSError:
                        try:
                            process.terminate()
                        except OSError:
                            pass

            readable, _, _ = select.select([master_fd], [], [], 0.1)
            if readable:
                try:
                    data = os.read(master_fd, 4096)
                except OSError:
                    break
                if not data:
                    break
                text = (
                    data.decode("utf-8", errors="replace")
                    .replace("\r\n", "\n")
                    .replace("\r", "\n")
                )
                text = strip_ansi(text).replace("\\[", "").replace("\\]", "")
                if text:
                    output_chunks.append(text)
                    emit({"type": "work", "kind": "stream", "content": text})

            if process.poll() is not None:
                # Drain any buffered PTY output after process exit.
                drained = False
                while True:
                    readable, _, _ = select.select([master_fd], [], [], 0)
                    if not readable:
                        break
                    try:
                        data = os.read(master_fd, 4096)
                    except OSError:
                        break
                    if not data:
                        break
                    drained = True
                    text = (
                        data.decode("utf-8", errors="replace")
                        .replace("\r\n", "\n")
                        .replace("\r", "\n")
                    )
                    text = strip_ansi(text).replace("\\[", "").replace("\\]", "")
                    if text:
                        output_chunks.append(text)
                        emit({"type": "work", "kind": "stream", "content": text})
                if not drained:
                    break

        if process.poll() is None:
            try:
                os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            except OSError:
                try:
                    process.kill()
                except OSError:
                    pass
        try:
            process.wait(timeout=2)
        except Exception:
            pass
        return "".join(output_chunks), process.poll()
    finally:
        if slave_fd is not None:
            try:
                os.close(slave_fd)
            except OSError:
                pass
        if master_fd is not None:
            try:
                os.close(master_fd)
            except OSError:
                pass


class PersistentCustomCliSession:
    def __init__(self, session_id, command, cwd, signature):
        self.session_id = clean_text(session_id)
        self.command = list(command)
        self.cwd = cwd
        self.signature = signature
        self.lock = threading.Lock()
        self.master_fd = None
        self.slave_fd = None
        self.process = None
        self.start()

    def start(self):
        self.master_fd, self.slave_fd = pty.openpty()
        try:
            fcntl.ioctl(
                self.slave_fd,
                termios.TIOCSWINSZ,
                struct.pack("HHHH", 40, 160, 0, 0),
            )
        except OSError:
            pass
        env = subprocess_env()
        env["TERM"] = env.get("TERM") or "xterm-256color"
        env["AGENT_WORKBENCH"] = "1"
        env["AGENT_WORKBENCH_PERSISTENT_CLI"] = "1"
        self.process = subprocess.Popen(
            resolve_command_executable(self.command, env),
            cwd=self.cwd,
            stdin=self.slave_fd,
            stdout=self.slave_fd,
            stderr=self.slave_fd,
            env=env,
            preexec_fn=os.setsid,
            close_fds=True,
        )
        try:
            os.close(self.slave_fd)
        except OSError:
            pass
        self.slave_fd = None

    def is_alive(self):
        return self.process is not None and self.process.poll() is None and self.master_fd is not None

    def interrupt(self):
        if self.process and self.process.poll() is None:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
            except OSError:
                try:
                    self.process.terminate()
                except OSError:
                    pass

    def close(self):
        if self.process and self.process.poll() is None:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
            except OSError:
                try:
                    self.process.terminate()
                except OSError:
                    pass
            try:
                self.process.wait(timeout=1.5)
            except Exception:
                try:
                    os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
                except OSError:
                    try:
                        self.process.kill()
                    except OSError:
                        pass
        if self.slave_fd is not None:
            try:
                os.close(self.slave_fd)
            except OSError:
                pass
            self.slave_fd = None
        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
            self.master_fd = None

    def _read_once(self):
        if self.master_fd is None:
            return ""
        try:
            data = os.read(self.master_fd, 4096)
        except OSError:
            return ""
        if not data:
            return ""
        text = (
            data.decode("utf-8", errors="replace")
            .replace("\r\n", "\n")
            .replace("\r", "\n")
        )
        return strip_ansi(text).replace("\\[", "").replace("\\]", "")

    def drain_available(self):
        chunks = []
        if self.master_fd is None:
            return ""
        while True:
            readable, _, _ = select.select([self.master_fd], [], [], 0)
            if not readable:
                break
            text = self._read_once()
            if not text:
                break
            chunks.append(text)
        return "".join(chunks)

    def exchange(self, stdin_payload, emit, control, idle_seconds, first_byte_timeout, max_seconds):
        if not self.is_alive():
            raise RuntimeError("Persistent custom CLI is not running.")
        output_chunks = []
        with self.lock:
            stale = self.drain_available()
            if stale:
                emit({"type": "work", "kind": "stream", "content": stale})
            control.set_process(self.process)
            control.set_stop_callback(self.interrupt)
            if stdin_payload:
                try:
                    os.write(self.master_fd, stdin_payload.encode("utf-8", errors="replace"))
                except OSError as error:
                    raise RuntimeError(f"could not write to persistent custom CLI: {error}") from error
            started_at = time.monotonic()
            last_output_at = started_at
            saw_output = False
            while True:
                if control.cancel.is_set():
                    break
                if self.process.poll() is not None:
                    trailing = self.drain_available()
                    if trailing:
                        output_chunks.append(trailing)
                        emit({"type": "work", "kind": "stream", "content": trailing})
                    break
                now = time.monotonic()
                if saw_output and now - last_output_at >= idle_seconds:
                    break
                if not saw_output and now - started_at >= first_byte_timeout:
                    emit(
                        {
                            "type": "work",
                            "kind": "system",
                            "content": (
                                "Persistent custom CLI produced no output before "
                                f"the {first_byte_timeout:.0f}s first-byte timeout."
                            ),
                        }
                    )
                    break
                if now - started_at >= max_seconds:
                    emit(
                        {
                            "type": "work",
                            "kind": "system",
                            "content": (
                                "Persistent custom CLI response window ended after "
                                f"{max_seconds:.0f}s; the process remains attached."
                            ),
                        }
                    )
                    break
                readable, _, _ = select.select([self.master_fd], [], [], 0.1)
                if not readable:
                    continue
                text = self._read_once()
                if not text:
                    continue
                saw_output = True
                last_output_at = time.monotonic()
                output_chunks.append(text)
                emit({"type": "work", "kind": "stream", "content": text})
        return "".join(output_chunks), self.process.poll()


def persistent_custom_cli_signature(command, cwd):
    return json.dumps({"command": list(command), "cwd": cwd}, sort_keys=True)


def persistent_custom_cli_for_session(session_id, command, cwd):
    session_id = clean_text(session_id)
    signature = persistent_custom_cli_signature(command, cwd)
    created = False
    with CUSTOM_CLI_SESSIONS_LOCK:
        current = CUSTOM_CLI_SESSIONS.get(session_id)
        if current and (not current.is_alive() or current.signature != signature):
            current.close()
            CUSTOM_CLI_SESSIONS.pop(session_id, None)
            current = None
        if not current:
            current = PersistentCustomCliSession(session_id, command, cwd, signature)
            CUSTOM_CLI_SESSIONS[session_id] = current
            created = True
        return current, created


def forget_persistent_custom_cli_session(session_id):
    session_id = clean_text(session_id)
    with CUSTOM_CLI_SESSIONS_LOCK:
        current = CUSTOM_CLI_SESSIONS.pop(session_id, None)
    if current:
        current.close()
        return True
    return False


def close_all_persistent_custom_cli_sessions():
    with CUSTOM_CLI_SESSIONS_LOCK:
        sessions = list(CUSTOM_CLI_SESSIONS.values())
        CUSTOM_CLI_SESSIONS.clear()
    for session in sessions:
        session.close()


UI_TERMINAL_SESSIONS = {}
UI_TERMINAL_LOCK = threading.Lock()
UI_TERMINAL_BACKLOG_LIMIT = 1_000_000
UI_TERMINAL_TRIM_TO = 750_000


class UiTerminalSession:
    def __init__(self, workspace_id, cwd, cols=120, rows=32):
        self.workspace_id = clean_text(workspace_id)
        self.cwd = cwd
        self.lock = threading.Lock()
        self.backlog = ""
        self.offset = 0
        self.master_fd = None
        self.slave_fd = None
        self.process = None
        self.exited = False
        self.start(cols, rows)

    def start(self, cols, rows):
        self.master_fd, self.slave_fd = pty.openpty()
        self._resize_fd(self.slave_fd, cols, rows)
        env = os.environ.copy()
        env["TERM"] = env.get("TERM") or "xterm-256color"
        env["AGENT_WORKBENCH"] = "1"
        env["AGENT_WORKBENCH_TERMINAL"] = "1"
        shell = env.get("SHELL") or "/bin/bash"
        self.process = subprocess.Popen(
            [shell, "-i"],
            cwd=self.cwd,
            stdin=self.slave_fd,
            stdout=self.slave_fd,
            stderr=self.slave_fd,
            env=env,
            preexec_fn=os.setsid,
            close_fds=True,
        )
        try:
            os.close(self.slave_fd)
        except OSError:
            pass
        self.slave_fd = None
        threading.Thread(target=self._reader_loop, daemon=True).start()

    def is_alive(self):
        return self.process is not None and self.process.poll() is None and self.master_fd is not None

    def _resize_fd(self, fd, cols, rows):
        try:
            safe_cols = max(1, min(500, int(cols or 120)))
            safe_rows = max(1, min(200, int(rows or 32)))
            fcntl.ioctl(
                fd,
                termios.TIOCSWINSZ,
                struct.pack("HHHH", safe_rows, safe_cols, 0, 0),
            )
        except (OSError, TypeError, ValueError):
            pass

    def resize(self, cols, rows):
        fd = self.master_fd
        if fd is not None:
            self._resize_fd(fd, cols, rows)

    def _append_output(self, text):
        text = strip_ansi(str(text or "").replace("\x00", ""))
        if not text:
            return
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        with self.lock:
            self.backlog += text
            if len(self.backlog) > UI_TERMINAL_BACKLOG_LIMIT:
                trim_at = max(0, len(self.backlog) - UI_TERMINAL_TRIM_TO)
                self.backlog = self.backlog[trim_at:]
                self.offset += trim_at

    def _reader_loop(self):
        carry = bytearray()
        try:
            while True:
                fd = self.master_fd
                if fd is None:
                    break
                try:
                    readable, _, _ = select.select([fd], [], [], 0.25)
                except (OSError, ValueError):
                    break
                if not readable:
                    if self.process and self.process.poll() is not None:
                        break
                    continue
                try:
                    data = os.read(fd, 8192)
                except (OSError, TypeError):
                    break
                if not data:
                    break
                carry.extend(data)
                valid_len = len(carry)
                try:
                    carry.decode("utf-8")
                except UnicodeDecodeError as error:
                    valid_len = error.start
                if valid_len == 0 and len(carry) >= 4:
                    valid_len = 1
                if valid_len == 0:
                    continue
                text = bytes(carry[:valid_len]).decode("utf-8", errors="replace")
                del carry[:valid_len]
                self._append_output(text)
        finally:
            if carry:
                self._append_output(bytes(carry).decode("utf-8", errors="replace"))
            self.exited = True
            self._append_output("\n[process exited]\n")
            try:
                if self.process:
                    self.process.wait(timeout=1)
            except Exception:
                pass

    def snapshot(self, cursor=0):
        try:
            cursor = int(cursor or 0)
        except (TypeError, ValueError):
            cursor = 0
        with self.lock:
            if cursor < self.offset:
                cursor = self.offset
            relative = max(0, cursor - self.offset)
            output = self.backlog[relative:]
            next_cursor = self.offset + len(self.backlog)
        return {
            "workspace_id": self.workspace_id,
            "cwd": self.cwd,
            "output": output,
            "cursor": next_cursor,
            "alive": self.is_alive(),
        }

    def write(self, data):
        if not self.is_alive():
            raise RuntimeError("terminal is not running")
        fd = self.master_fd
        if fd is None:
            raise RuntimeError("terminal file descriptor is closed")
        try:
            os.write(fd, str(data or "").encode("utf-8", errors="replace"))
        except OSError as error:
            raise RuntimeError("terminal file descriptor is closed") from error

    def close(self):
        if self.process and self.process.poll() is None:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
            except OSError:
                try:
                    self.process.terminate()
                except OSError:
                    pass
            try:
                self.process.wait(timeout=1.5)
            except Exception:
                try:
                    os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
                except OSError:
                    try:
                        self.process.kill()
                    except OSError:
                        pass
        for fd_name in ("slave_fd", "master_fd"):
            fd = getattr(self, fd_name)
            if fd is None:
                continue
            try:
                os.close(fd)
            except OSError:
                pass
            setattr(self, fd_name, None)


def ui_terminal_session(workspace_id, cwd, cols=120, rows=32):
    workspace_id = clean_text(workspace_id)
    if not workspace_id:
        raise RuntimeError("workspace id is required")
    cwd_path = os.path.abspath(os.path.expanduser(clean_text(cwd) or os.path.expanduser("~")))
    if not os.path.isdir(cwd_path):
        raise RuntimeError(f"terminal directory does not exist: {cwd_path}")
    with UI_TERMINAL_LOCK:
        current = UI_TERMINAL_SESSIONS.get(workspace_id)
        if current and (not current.is_alive() or current.cwd != cwd_path):
            current.close()
            UI_TERMINAL_SESSIONS.pop(workspace_id, None)
            current = None
        if not current:
            current = UiTerminalSession(workspace_id, cwd_path, cols, rows)
            UI_TERMINAL_SESSIONS[workspace_id] = current
        else:
            current.resize(cols, rows)
        return current


def ui_terminal_output(workspace_id, cursor=0):
    workspace_id = clean_text(workspace_id)
    with UI_TERMINAL_LOCK:
        current = UI_TERMINAL_SESSIONS.get(workspace_id)
    if not current:
        return {
            "workspace_id": workspace_id,
            "cwd": "",
            "output": "",
            "cursor": 0,
            "alive": False,
        }
    return current.snapshot(cursor)


def ui_terminal_write(workspace_id, data):
    workspace_id = clean_text(workspace_id)
    with UI_TERMINAL_LOCK:
        current = UI_TERMINAL_SESSIONS.get(workspace_id)
    if not current:
        raise RuntimeError("terminal is not running")
    current.write(data)
    return True


def ui_terminal_resize(workspace_id, cols, rows):
    workspace_id = clean_text(workspace_id)
    with UI_TERMINAL_LOCK:
        current = UI_TERMINAL_SESSIONS.get(workspace_id)
    if not current:
        return False
    current.resize(cols, rows)
    return True


def close_ui_terminal_session(workspace_id):
    workspace_id = clean_text(workspace_id)
    with UI_TERMINAL_LOCK:
        current = UI_TERMINAL_SESSIONS.pop(workspace_id, None)
    if current:
        current.close()
        return True
    return False


def close_all_ui_terminal_sessions():
    with UI_TERMINAL_LOCK:
        sessions = list(UI_TERMINAL_SESSIONS.values())
        UI_TERMINAL_SESSIONS.clear()
    for session in sessions:
        session.close()


def persistent_custom_cli_timeouts(client):
    idle = float((client or {}).get("idle_timeout_seconds") or 4.0)
    first_byte = float((client or {}).get("first_byte_timeout_seconds") or 90.0)
    maximum = float((client or {}).get("response_timeout_seconds") or 300.0)
    idle = min(30.0, max(0.5, idle))
    first_byte = min(300.0, max(1.0, first_byte))
    maximum = min(1800.0, max(first_byte, maximum))
    return idle, first_byte, maximum


def run_persistent_custom_cli(session, client, command, cwd, stdin_payload, emit, control):
    persistent, created = persistent_custom_cli_for_session(session["id"], command, cwd)
    idle, first_byte, maximum = persistent_custom_cli_timeouts(client)
    emit(
        {
            "type": "work",
            "kind": "system",
            "content": (
                "Persistent custom CLI session "
                + ("started" if created else "reused")
                + f" · idle {idle:.1f}s · cwd {cwd}"
            ),
        }
    )
    output_text, returncode = persistent.exchange(
        stdin_payload,
        emit,
        control,
        idle,
        first_byte,
        maximum,
    )
    if returncode is not None:
        forget_persistent_custom_cli_session(session["id"])
    return output_text, returncode


_SENSITIVE_COMMAND_NAME = re.compile(
    r"(?:api[_-]?key|access[_-]?token|auth(?:orization)?|bearer|credential|"
    r"password|passwd|secret|token)",
    re.IGNORECASE,
)
_KNOWN_SECRET_VALUE = re.compile(
    r"(?:sk-[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{12,}|"
    r"xox[baprs]-[A-Za-z0-9-]{12,})"
)


def redact_custom_command_for_log(command, prompt=""):
    """Render argv without leaking prompts or common credential arguments."""
    redacted = []
    hide_next = False
    prompt = str(prompt or "")
    for raw_token in command or []:
        token = str(raw_token)
        if hide_next:
            redacted.append("<redacted>")
            hide_next = False
            continue
        if prompt and prompt in token:
            token = token.replace(prompt, "<prompt>")
        assignment = re.match(r"^([^=]+)=(.*)$", token, flags=re.DOTALL)
        if assignment and _SENSITIVE_COMMAND_NAME.search(assignment.group(1)):
            redacted.append(f"{assignment.group(1)}=<redacted>")
            continue
        flag_name = token.split("=", 1)[0].lstrip("-")
        if token.startswith("-") and _SENSITIVE_COMMAND_NAME.search(flag_name):
            if "=" in token:
                redacted.append(token.split("=", 1)[0] + "=<redacted>")
            else:
                redacted.append(token)
                hide_next = True
            continue
        token = re.sub(
            r"(?i)(\bBearer\s+)[^\s]+",
            r"\1<redacted>",
            token,
        )
        token = _KNOWN_SECRET_VALUE.sub("<redacted>", token)
        redacted.append(token)
    return shlex.join(redacted)


def stream_custom_cli(session, user_text, model, emit, control):
    client = custom_client_config_for_session(session)
    if not client:
        raise RuntimeError("custom client configuration not found")
    command_template = clean_text(client.get("command"))
    configured_backend = clean_text(client.get("backend")).lower()
    is_native_local = configured_backend in {
        "local-tools",
        "ollama-tools",
        "native-ollama",
    }
    if not command_template and not is_native_local:
        raise RuntimeError("custom client command is missing")
    is_aider = custom_client_is_aider(client)
    backend = session.setdefault("backend", {})
    model = clean_text(model or backend.get("model"))
    if not model or model in {"Default", "Auto"}:
        model = clean_text(client.get("model") or client.get("label") or "Default")
    native_ollama_model = custom_client_ollama_model(client)
    if is_native_local or (is_aider and native_ollama_model):
        return stream_local_tool_agent(
            session,
            user_text,
            native_ollama_model or model,
            emit,
            control,
        )
    use_persistent = custom_client_persistent_enabled(client)
    cwd = ensure_aider_workspace(session) if is_aider else preferred_custom_cli_cwd(session)
    title = clean_text(session.get("title"))
    execution_prompt = aider_operational_prompt(user_text, cwd) if is_aider else user_text
    command = interpolate_custom_command(
        command_template,
        execution_prompt,
        model,
        cwd,
        title,
    )
    stdin_payload = ""
    if "{prompt}" not in command_template:
        stdin_payload = execution_prompt.rstrip() + "\n"
    if is_aider:
        add_aider_session_options(command, cwd)
    emit(
        {
            "type": "meta",
            "backend": "custom",
            "model": model or clean_text(client.get("label")) or "custom",
        }
    )
    emit(
        {
            "type": "work",
            "kind": "command",
            "content": "$ " + redact_custom_command_for_log(command, execution_prompt),
        }
    )
    if use_persistent:
        output_text, returncode = run_persistent_custom_cli(
            session,
            client,
            command,
            cwd,
            stdin_payload,
            emit,
            control,
        )
    else:
        output_text, returncode = run_custom_cli_pty(
            command,
            cwd,
            stdin_payload,
            emit,
            control,
        )
    if control.cancel.is_set():
        raise RuntimeError("Turn stopped.")
    full_text = (
        clean_aider_output(output_text.splitlines(), emit)
        if is_aider
        else output_text.strip()
    )
    if full_text:
        emit({"type": "delta", "text": full_text})
    if returncode not in (0, None) and not full_text:
        raise RuntimeError(f"Custom CLI exited {returncode}.")
    backend["custom_client_key"] = clean_text(session.get("agent"))
    backend["model"] = model
    backend["custom_persistent"] = bool(use_persistent)
    return full_text, model or "Default"


def codex_item_text(item):
    if not isinstance(item, dict):
        return ""
    text = clean_text(item.get("text") or item.get("content"))
    if text:
        return text
    parts = []
    for part in item.get("content") or []:
        if isinstance(part, dict) and part.get("type") in {"text", "output_text"}:
            parts.append(clean_text(part.get("text")))
    return "\n".join(part for part in parts if part)


# A Codex thread grows unbounded; once its rollout exceeds the model's context
# window every resume overflows and the backend drops the stream. Reset the thread
# before that point (proactive) and recover if it still happens (reactive).
CODEX_THREAD_MAX_BYTES = 24_000_000


def codex_thread_rollout_bytes(thread_id):
    """Total bytes of a Codex thread's rollout file(s) (the filename embeds the
    thread id). Used to detect a thread that is about to overflow the context."""
    tid = clean_text(thread_id)
    if not tid:
        return 0
    root = os.path.expanduser("~/.codex/sessions")
    total = 0
    try:
        for dirpath, _dirs, files in os.walk(root):
            for name in files:
                if name.endswith(".jsonl") and tid in name:
                    try:
                        total += os.path.getsize(os.path.join(dirpath, name))
                    except OSError:
                        pass
    except OSError:
        return 0
    return total


# Every field Codex reports cumulatively, under BOTH the names Codex sends and
# the names AWBN renames them to later.
#
# This list used to hold only AWBN's internal names. Codex sends
# `cached_input_tokens`, `cache_write_input_tokens` and
# `reasoning_output_tokens`; the rename to `cache_read_input_tokens` and friends
# happens in emit_usage, AFTER this subtraction. So three of the six never
# matched, and those three passed through as the thread's running total while
# input and output were correctly reduced to the turn.
#
# Measured on a real one-word Codex turn: it reported 20,815,744 cache-read
# tokens when the turn used 113,408, and 28,908 reasoning tokens when the turn
# used 0.
CODEX_CUMULATIVE_USAGE_FIELDS = (
    "input_tokens",
    "output_tokens",
    "total_tokens",
    # AWBN's names
    "cache_read_input_tokens",
    "cache_creation_input_tokens",
    "reasoning_tokens",
    # Codex's own names, which are what actually arrive here
    "cached_input_tokens",
    "cache_write_input_tokens",
    "reasoning_output_tokens",
)


def codex_plan_usage(rate_limits):
    """The share of the Codex plan used so far, from Codex's own report.

    Codex is billed against a plan, not per token, so there is no dollar
    figure to show for it — and none to be found: the model catalog embedded
    in the binary carries no price fields at all (checked 2026-07-28), so any
    dollar amount would have to be typed in from memory. That is the exact
    hand-typed-number failure this app has been unpicking all day.

    What Codex does report, in `rate_limits` events on every model step, is
    how much of the plan window has been consumed. That number is measured
    rather than estimated, so it is the one worth showing."""
    if not isinstance(rate_limits, dict):
        return None
    primary = rate_limits.get("primary")
    if not isinstance(primary, dict):
        return None
    used = primary.get("used_percent")
    if used is None:
        return None
    try:
        return round(float(used), 2)
    except (TypeError, ValueError):
        return None


def codex_plan_usage_from_rollout(path, max_bytes=262144):
    """(first_seen, latest) plan-usage percentages in a thread's rollout, so a
    caller can show both the current level and what this thread moved it by.
    Returns (None, None) when the thread reported none."""
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as handle:
            handle.seek(max(0, size - max_bytes))
            chunk = handle.read().decode("utf-8", errors="ignore")
    except OSError:
        return None, None
    first = latest = None
    for line in chunk.splitlines():
        if '"rate_limits"' not in line:
            continue
        try:
            event = json.loads(line)
        except ValueError:
            continue
        used = codex_plan_usage((event.get("payload") or {}).get("rate_limits"))
        if used is None:
            continue
        if first is None:
            first = used
        latest = used
    return first, latest


def codex_turn_usage_delta(previous, current):
    """This turn's own usage, from Codex's running thread totals (v4.3.3).

    Codex's `turn.completed` usage is CUMULATIVE for the whole thread, not the
    turn. Proven with two one-word turns on one thread:

        turn 1  in=16,674  out=6
        turn 2  in=34,129  out=12      <- turn 1 + turn 2, not turn 2

    So every finished message showed the running total of everything before
    it. Reported as "over 349.8k in" for a short question, and visible in the
    stored history as turn figures that only ever climb: 4.1M, 4.4M, 6.8M,
    7.1M, 8.3M... Those were never what a turn cost.

    Returns (this_turn, new_running_total). A total that goes DOWN means the
    thread was reset or replaced, so the current figures are taken as-is
    rather than producing a negative.
    """
    previous = previous if isinstance(previous, dict) else {}
    current = current if isinstance(current, dict) else {}
    turn = dict(current)
    reset = any(
        int(current.get(field) or 0) < int(previous.get(field) or 0)
        for field in ("input_tokens", "output_tokens")
    )
    if not reset:
        for field in CODEX_CUMULATIVE_USAGE_FIELDS:
            if field in current or field in previous:
                delta = int(current.get(field) or 0) - int(previous.get(field) or 0)
                turn[field] = max(0, delta)
    running = {
        field: int(current.get(field) or 0)
        for field in CODEX_CUMULATIVE_USAGE_FIELDS
        if field in current
    }
    # The running total is worth keeping — it is the honest "this whole
    # conversation so far" figure, just not the one to print on one message.
    turn["session_input_tokens"] = int(current.get("input_tokens") or 0)
    turn["session_output_tokens"] = int(current.get("output_tokens") or 0)
    return turn, running


def codex_file_change_events(item, started=False):
    """The work events for one Codex `file_change` item — pure, so the shape
    is testable without a running turn (v4.3.3).

    Reported: a 19-minute Codex turn applied 20 patches across 6 files and the
    window showed nothing. Three causes, all fixed here:

      * `file_path` was never emitted. That field is what makes the code pane
        follow the agent, and it was only ever set on the Claude path — so
        Codex edits never opened a file on screen.
      * the work-log line was `json.dumps(changes)`, i.e. raw JSON.
      * nothing fired on item.started, so even the after-the-fact line only
        arrived once the edit was already done.

    The item looks like:
      {"type":"file_change","status":"in_progress",
       "changes":[{"path":"/abs/App.tsx","kind":"update"}]}

    `started` picks the in-progress wording and the plain 'tool' kind; the
    completed pass uses 'tool_done', which is the UI's signal that the write
    has really landed and the file is safe to re-read.
    """
    changes = (item or {}).get("changes")
    if not isinstance(changes, list):
        return []
    verbs = {"add": ("Creating", "Created"), "update": ("Editing", "Edited"),
             "delete": ("Deleting", "Deleted")}
    events = []
    for change in changes:
        if not isinstance(change, dict):
            continue
        path = clean_text(change.get("path"))
        if not path:
            continue
        verb = verbs.get(clean_text(change.get("kind")).lower(), ("Changing", "Changed"))
        events.append(
            {
                "type": "work",
                "kind": "tool" if started else "tool_done",
                "content": f"{verb[0 if started else 1]} {os.path.basename(path)}",
                "file_path": path,
            }
        )
    return events


def codex_thread_rollout_path(thread_id):
    """Newest rollout file for a Codex thread (filename embeds the thread id). The
    rollout's token_count events carry the per-turn token usage AND the model context
    window, which the exec --json turn.completed event does not — so this is how we
    compute Codex's context-fill percentage."""
    tid = clean_text(thread_id)
    if not tid:
        return ""
    root = os.path.expanduser("~/.codex/sessions")
    best = ""
    best_mtime = -1.0
    try:
        for dirpath, _dirs, files in os.walk(root):
            for name in files:
                if name.endswith(".jsonl") and tid in name:
                    full = os.path.join(dirpath, name)
                    try:
                        mtime = os.path.getmtime(full)
                    except OSError:
                        continue
                    if mtime > best_mtime:
                        best_mtime, best = mtime, full
    except OSError:
        return ""
    return best


def update_codex_context_from_rollout(session, backend, emit=None):
    """Set session['context'] (used/limit/percent) from the thread's rollout, since
    the exec stream doesn't report the context window. Preserves compact_count and,
    when given an emit, pushes the context to the UI live."""
    thread_id = clean_text(backend.get("thread_id") or backend.get("session_id"))
    path = codex_thread_rollout_path(thread_id)
    if not path:
        return
    ctx = codex_context_from_rollout(path)
    if not ctx:
        return
    ctx["compact_count"] = int((session.get("context") or {}).get("compact_count") or 0)
    session["context"] = ctx
    if emit:
        emit({"type": "context", "context": ctx})


def codex_live_usage_from_rollout_tail(thread_id, max_bytes=65536):
    """Last token_count from the tail of the thread's rollout — cheap enough
    to call per item event, so Codex turns tick live token numbers like
    Claude's do (v4.0.9, reported: bubble showed 'Tools 23' but no tokens
    mid-turn on Codex). Returns {} when unavailable."""
    path = codex_thread_rollout_path(clean_text(thread_id))
    if not path:
        return {}
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as fh:
            fh.seek(max(0, size - max_bytes))
            chunk = fh.read().decode("utf-8", errors="ignore")
    except OSError:
        return {}
    usage = {}
    for line in chunk.splitlines():
        if '"token_count"' not in line:
            continue
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if not isinstance(record, dict) or record.get("type") != "event_msg":
            continue
        payload = record.get("payload") or {}
        if payload.get("type") != "token_count":
            continue
        info = payload.get("info") or {}
        # v4.3.3: `last_token_usage`, NOT `total_token_usage`.
        #
        # Reported as "136.3k in?? that's impossible", and it was — but not a
        # counting error. Codex's `total_token_usage` is the running total for
        # the whole thread, and every model step re-sends the entire
        # conversation, so it is literally the sum of all those re-sends.
        # Verified against one real session: 69 steps summed to exactly the
        # 6,153,606 "input" the bubble displayed, of which 5,969,664 (97%)
        # were cache re-reads and only 183,942 was new text. Printing that
        # total on a single message read as a catastrophe that never happened.
        #
        # The message line gets this step's own usage; the session total is
        # kept alongside it for anything that wants the running figure.
        step = info.get("last_token_usage") or info.get("total_token_usage") or {}
        totals = info.get("total_token_usage") or {}
        if isinstance(step, dict) and step:
            usage = {
                "input_tokens": int(step.get("input_tokens") or 0),
                "output_tokens": int(step.get("output_tokens") or 0),
                "cache_read_input_tokens": int(step.get("cached_input_tokens") or 0),
                "reasoning_tokens": int(step.get("reasoning_output_tokens") or 0),
                "session_input_tokens": int(totals.get("input_tokens") or 0),
                "session_output_tokens": int(totals.get("output_tokens") or 0),
                "session_cache_read_input_tokens": int(
                    totals.get("cached_input_tokens") or 0
                ),
            }
    return usage


def codex_stream_overflow(message):
    msg = clean_text(message).lower()
    return any(
        token in msg
        for token in (
            "stream disconnected before completion",
            "websocket closed",
            "closed by server before response",
            "context length",
            "maximum context",
            "too many tokens",
            "context_length_exceeded",
        )
    )


def usable_session_cwd(session):
    """A directory this session can actually run in, and why if it changed.

    A session remembers the folder it was made in. Folders get deleted, moved
    or (for a scratch folder) cleaned up — and every client then failed with a
    raw `[Errno 2] No such file or directory`, which tells the user nothing and
    leaves the chat dead (reported: "awbn conversation yielded no response").
    Thirty-seven stored sessions pointed at folders that no longer existed.

    Returns (directory, note). The note is empty when nothing changed."""
    home = os.path.expanduser("~")
    stored = clean_text((session or {}).get("cwd"))
    if stored and os.path.isdir(stored):
        return stored, ""
    for name in ("project_root", "native_cwd"):
        fallback = clean_text((session or {}).get(name))
        if fallback and os.path.isdir(fallback):
            return fallback, (
                f"The folder this chat was started in is gone ({stored or 'unset'}). "
                f"Running in {fallback} instead."
            )
    return home, (
        f"The folder this chat was started in is gone ({stored or 'unset'}). "
        f"Running in your home folder instead - say where it should run if that "
        f"is wrong."
    )


def codex_launch_cwd(session):
    """The directory a Codex turn should run in.

    The session's own cwd wins whenever it is a real directory — it is what the
    caller asked for and what ui_create_session already validated. Inference is
    only a fallback for sessions that never had one (imported history, older
    records)."""
    stored = clean_text((session or {}).get("cwd"))
    if stored:
        resolved = os.path.abspath(os.path.expanduser(stored))
        if os.path.isdir(resolved):
            return resolved
    return (
        infer_project_root(session, (session or {}).get("cwd"))
        or os.path.expanduser("~")
    )


def stream_codex(session, user_text, model, emit, control):
    backend = session.setdefault("backend", {})
    thread_id = backend.get("thread_id") or backend.get("session_id")
    # Run where the session says to run (v4.3.3). This inferred a project root
    # first and then wrote it back over session["cwd"], so a session created
    # with an explicit folder was moved to an ancestor and its real folder was
    # lost — reported after a turn asked to work in one directory edited files
    # in its parent. Claude and Hermes have always used session["cwd"]
    # directly; Codex was the odd one out.
    #
    # Isolation is unaffected: a worker's cwd IS its worktree path, so honouring
    # it keeps the worker inside its own tree.
    cwd = codex_launch_cwd(session)
    if not clean_text(session.get("cwd")):
        session["cwd"] = cwd
    model = clean_text(model or backend.get("model"))
    effort = clean_text(backend.get("effort"))

    # Keep the actual executable AWBN is about to launch current.  This is
    # intentionally here (rather than a blind timer) so no update can race an
    # active AWBN Codex turn, and a registry/npm problem never makes Codex
    # unusable — the existing installed CLI still launches after a warning.
    auto_update = auto_update_codex_before_turn(session.get("id"))
    if auto_update.get("updated"):
        emit(
            {
                "type": "work",
                "kind": "system",
                "content": (
                    f"Updated Codex automatically to {auto_update.get('installed') or 'the latest version'} "
                    "before this turn."
                ),
            }
        )
    elif auto_update.get("deferred"):
        emit(
            {
                "type": "work",
                "kind": "system",
                "content": "Codex update deferred until another AWBN Codex turn finishes.",
            }
        )
    elif auto_update.get("error"):
        emit(
            {
                "type": "work",
                "kind": "system",
                "content": (
                    "Codex automatic update could not finish; continuing with the installed "
                    f"version ({auto_update.get('installed') or 'unknown'}): {auto_update['error']}"
                ),
            }
        )

    def reset_thread(reason):
        backend.pop("thread_id", None)
        backend.pop("session_id", None)
        # A fresh thread has no prior context, so the trimmed "unchanged" pointer is
        # no longer enough — force the full AGENT_STATE body back into the next turn.
        session.pop("last_state_inject_hash", None)
        emit({"type": "work", "kind": "system", "content": reason})

    # Proactive: a clearly-oversized thread is doomed — start fresh so the user never
    # hits the dead wall. The project's AGENT_STATE (injected into the prompt) carries
    # continuity across the reset.
    if thread_id and codex_thread_rollout_bytes(thread_id) > CODEX_THREAD_MAX_BYTES:
        reset_thread(
            "↻ Codex conversation reached the model's memory limit - started a fresh "
            "thread to keep it working. Project state carries the context."
        )
        thread_id = ""

    maybe_emit_unsafe_permissions_notice(emit)
    proc_holder = {}

    def run_once(resume_thread):
        command = ["codex", "exec", "--json"]
        # Enforce the user's Tools-panel switches. Codex exposes a real
        # `enabled` flag per MCP server, and `-c mcp_servers.<name>.enabled=
        # false` genuinely disables it — verified with `codex mcp list`, whose
        # Status column flips to "disabled" (2026-07-28). Without this the
        # switch would be decoration.
        for off_server in sorted(disabled_mcp_servers().get("codex") or set()):
            command += ["-c", f"mcp_servers.{off_server}.enabled=false"]
        # Codex has no headless approval protocol, but `codex exec` DOES support
        # OS-level sandbox modes (see docs/CODEX_GEMINI_PERMISSION_SPIKE.md) —
        # real containment with no prompts. In safe mode we run inside the
        # chosen sandbox (default workspace-write) instead of the old blanket
        # bypass; full bypass is now an explicit opt-in (danger-full-access).
        sandbox = codex_sandbox_mode()
        if not safe_permissions_enabled() or sandbox == "danger-full-access":
            command += [
                "--dangerously-bypass-approvals-and-sandbox",
                "--dangerously-bypass-hook-trust",
            ]
            if safe_permissions_enabled():
                emit(
                    {
                        "type": "work",
                        "kind": "system",
                        "content": (
                            "Codex runs with NO sandbox (full access) - set a "
                            "sandbox in Options for containment."
                        ),
                    }
                )
        else:
            command += ["-s", sandbox]
            emit(
                {
                    "type": "work",
                    "kind": "system",
                    "content": (
                        f"Codex is sandboxed ({sandbox}) - OS-enforced containment. "
                        + (
                            "It can edit this project but not the wider system."
                            if sandbox == "workspace-write"
                            else "It can read but not write files."
                        )
                    ),
                }
            )
        command += ["--skip-git-repo-check", "-C", cwd]
        if model and model != "Default":
            command += ["--model", model]
        if effort and effort != "Default":
            command += ["-c", f'model_reasoning_effort="{effort}"']
        if resume_thread:
            command += ["resume", resume_thread, user_text]
        else:
            command += [user_text]
        emit({"type": "meta", "backend": "codex", "model": model or "default"})
        emit({"type": "work", "kind": "command", "content": "$ codex exec <prompt>"})
        process = run_process(command, cwd, control)
        proc_holder["p"] = process
        full = []
        # Codex narrates progress as a series of assistant messages. Only the LAST
        # one is the actual answer that belongs in the chat; the earlier ones are
        # work-in-progress narration and go to the work log instead. We hold the most
        # recent message and flush the previous one to the work log when a newer one
        # arrives, then emit the final one to the chat after the turn ends.
        pending_chat = None
        announced_commands: set = set()
        announced_file_changes = set()
        command_snapshots = {}

        def announce_command(item_obj):
            """Surface a Codex command as soon as it starts (not only when it
            finishes) so a long-running command — a build, a test run — shows as
            live activity instead of a silent, frozen-looking turn. Deduped by
            item id so it is never shown twice."""
            command_text = clean_text(item_obj.get("command"))
            if not command_text:
                return
            item_id = clean_text(item_obj.get("id"))
            if item_id and item_id in announced_commands:
                return
            if item_id:
                announced_commands.add(item_id)
            emit({"type": "work", "kind": "commandExecution", "content": "$ " + command_text})

        def announce_file_change(item_obj, started):
            """Emit a Codex file edit once per stage, deduped by item id."""
            item_id = clean_text(item_obj.get("id"))
            marker = f"{item_id}:{'start' if started else 'done'}" if item_id else ""
            if marker and marker in announced_file_changes:
                return
            events = codex_file_change_events(item_obj, started=started)
            if not events:
                return
            if marker:
                announced_file_changes.add(marker)
            for event in events:
                emit(event)

        for raw in process.stdout:
            if control.cancel.is_set():
                break
            line = raw.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except ValueError:
                emit({"type": "work", "kind": "system", "content": line})
                continue
            event_type = clean_text(event.get("type"))
            item = event.get("item") or {}
            if event_type in {"thread.started", "thread/started", "thread.created"}:
                new_id = event.get("thread_id") or (event.get("thread") or {}).get("id")
                if new_id:
                    backend["thread_id"] = new_id
                    session["native_thread_owned"] = True
            elif event_type in {"item.completed", "item/completed"}:
                # v4.0.9: live token tick for Codex — read the rollout tail's
                # running totals after each completed item.
                live_usage = codex_live_usage_from_rollout_tail(
                    backend.get("thread_id") or backend.get("session_id")
                )
                if live_usage:
                    emit_usage(emit, live_usage, live=True)
                item_type = clean_text(item.get("type"))
                if item_type in {"agent_message", "agentMessage"}:
                    text = codex_item_text(item)
                    if text:
                        if pending_chat is not None:
                            # A superseded assistant message = progress narration →
                            # work log, not the chat bubble.
                            emit({"type": "work", "kind": "note", "content": pending_chat})
                        pending_chat = text
                elif item_type in {"command_execution", "commandExecution"}:
                    announce_command(item)
                    command_id = clean_text(item.get("id"))
                    before = command_snapshots.pop(command_id, None)
                    if before is not None:
                        after = folder_file_times(cwd)
                        for path in changed_files_since(before, after):
                            emit(
                                {
                                    "type": "work",
                                    "kind": "tool_done",
                                    "content": f"Updated {os.path.basename(path)}",
                                    "file_op": "write",
                                    "file_path": path,
                                }
                            )
                        for path in deleted_files_since(before, after):
                            emit(
                                {
                                    "type": "work",
                                    "kind": "tool_done",
                                    "content": f"Deleted {os.path.basename(path)}",
                                    "file_op": "delete",
                                    "file_path": path,
                                }
                            )
                    output = clean_text(item.get("aggregated_output") or item.get("aggregatedOutput"))
                    if output:
                        emit({"type": "work", "kind": "system", "content": output})
                elif item_type in {"file_change", "fileChange"}:
                    announce_file_change(item, started=False)
                elif item_type == "reasoning":
                    text = codex_item_text(item) or clean_text(" ".join(item.get("summary") or []))
                    if text:
                        emit({"type": "work", "kind": "reasoning", "content": text})
            elif event_type in {"turn.completed", "turn/completed"}:
                usage = event.get("usage") or (event.get("turn") or {}).get("usage") or {}
                # Codex reports the thread's RUNNING TOTAL here, not this
                # turn's. Subtract what the thread had already used so the
                # message shows what it actually cost (v4.3.3).
                usage, running_total = codex_turn_usage_delta(
                    backend.get("codex_usage_running"), usage
                )
                if running_total:
                    backend["codex_usage_running"] = running_total
                # Codex bills against a plan, not per token, so the honest
                # "what did this cost" figure is the plan meter it reports
                # itself — there are no per-token prices anywhere on this
                # machine to compute dollars from.
                plan_path = codex_thread_rollout_path(
                    clean_text(backend.get("thread_id") or backend.get("session_id"))
                )
                if plan_path:
                    plan_start, plan_now = codex_plan_usage_from_rollout(plan_path)
                    if plan_now is not None:
                        usage["plan_used_percent"] = plan_now
                        if plan_start is not None:
                            usage["plan_delta_percent"] = round(
                                max(0.0, plan_now - plan_start), 2
                            )
                emit_usage(emit, usage)
                update_context(session, usage, model)
                # exec --json's usage has no context window; the thread rollout does.
                # Compute the real context-fill % from it so the UI shows a Codex
                # context bar and the 70% handoff trigger works.
                update_codex_context_from_rollout(session, backend, emit)
                turn = event.get("turn") or {}
                if clean_text(turn.get("status")) in {"failed", "error"}:
                    raise RuntimeError(clean_text((turn.get("error") or {}).get("message")) or "Codex turn failed.")
            elif event_type == "error":
                raise RuntimeError(clean_text(event.get("message") or event.get("error")) or "Codex error.")
            elif event_type in {"item.started", "item/started"}:
                # Surface a command the moment it starts so long builds/tests read as
                # live activity instead of a frozen, hung-looking turn.
                started_type = clean_text(item.get("type"))
                if started_type in {"command_execution", "commandExecution"}:
                    command_id = clean_text(item.get("id"))
                    if command_id and cwd:
                        command_snapshots[command_id] = folder_file_times(cwd)
                    announce_command(item)
                elif started_type in {"file_change", "fileChange"}:
                    announce_file_change(item, started=True)
            elif event_type != "turn.started":
                emit({"type": "work", "kind": "system", "content": line})
        process.wait()
        if control.cancel.is_set():
            raise RuntimeError("Turn stopped.")
        # The final assistant message is the chat answer; earlier ones already went
        # to the work log above.
        if pending_chat:
            full.append(pending_chat)
            emit({"type": "delta", "text": pending_chat})
        if process.returncode not in (0, None) and not full:
            error = process_stderr_text(process)
            raise RuntimeError(f"Codex exited {process.returncode}: {error[:600]}")
        if backend.get("thread_id") or backend.get("session_id"):
            session["native_thread_owned"] = True
        return "\n\n".join(full)

    try:
        return run_once(thread_id), model or "default"
    except RuntimeError as error:
        # Reactive: if resuming a thread dropped the stream (overflow), reset and
        # retry once on a fresh thread instead of leaving the session dead.
        if thread_id and not control.cancel.is_set() and codex_stream_overflow(error):
            # Reap the dropped/overflowed subprocess before retrying so we don't
            # orphan a possibly-hung codex process.
            old = proc_holder.get("p")
            if old is not None and old.poll() is None:
                try:
                    old.terminate()
                    old.wait(timeout=2)
                except Exception:
                    try:
                        old.kill()
                    except Exception:
                        pass
            reset_thread(
                "↻ Codex stream dropped (thread too large) - restarting the thread "
                "fresh and retrying. Project state carries the context."
            )
            return run_once(""), model or "default"
        raise


def run_turn(session, user_text, requested_model, emit, control):
    backend = pick_backend(session)
    model = requested_model or (session.get("backend") or {}).get("model")
    if backend == "custom":
        return stream_custom_cli(session, user_text, model, emit, control)
    if backend == "ollama":
        # Every installed local model — not just ones behind a hand-configured
        # custom client — gets real file/shell/app access here, gated by the
        # same protected-path blocklist and confirmation-phrase policy as the
        # custom-client "ollama-tools" path (reported: "wire up all possible
        # ollama agents to have control of the computer and programs").
        return stream_local_tool_agent(session, user_text, model, emit, control)
    if backend == "claude":
        return stream_claude(session, user_text, model, emit, control)
    if backend == "codex":
        return stream_codex(session, user_text, model, emit, control)
    if backend == "gemini":
        return stream_gemini(session, user_text, model, emit, control)
    if backend == "hermes":
        return stream_hermes(session, user_text, model, emit, control)
    raise RuntimeError(f"Unsupported backend: {backend}")


def format_reset_time(timestamp):
    try:
        moment = datetime.fromtimestamp(float(timestamp)).astimezone()
        return moment.strftime("%b %-d, %-I:%M%p").replace("AM", "am").replace("PM", "pm")
    except (TypeError, ValueError, OSError):
        return ""


def codex_usage_limits():
    root = Path(os.path.expanduser("~/.codex/sessions"))
    try:
        candidates = sorted(
            root.rglob("*.jsonl"),
            key=lambda path: path.stat().st_mtime_ns,
            reverse=True,
        )[:16]
    except OSError:
        candidates = []
    for path in candidates:
        latest = None
        try:
            with open(path, encoding="utf-8") as handle:
                for line in handle:
                    if '"rate_limits"' not in line:
                        continue
                    try:
                        event = json.loads(line)
                    except ValueError:
                        continue
                    rate_limits = (event.get("payload") or {}).get("rate_limits")
                    if isinstance(rate_limits, dict):
                        latest = rate_limits
        except OSError:
            continue
        if not latest:
            continue
        windows = []
        for key in ("primary", "secondary"):
            value = latest.get(key) or {}
            if not isinstance(value, dict) or value.get("used_percent") is None:
                continue
            minutes = int(value.get("window_minutes") or 0)
            windows.append(
                {
                    "label": "5h" if minutes and minutes <= 360 else "week",
                    "used_percent": round(float(value.get("used_percent") or 0)),
                    "reset": format_reset_time(value.get("resets_at")),
                    "purpose": (
                        "Current 5-hour usage window (primary)"
                        if key == "primary"
                        else "Current weekly usage window (secondary)"
                    ),
                }
            )
        if windows:
            return {"agent_key": "codex", "provider": "Codex", "windows": windows}
    return {
        "agent_key": "codex",
        "provider": "Codex",
        "windows": [],
        "error": "No rate-limit telemetry yet.",
    }


# --- Self-update -----------------------------------------------------------
# The maintainer publishes a small JSON manifest (version + download URL +
# notes, plus a checksummed AppImage asset). AWBN checks it at most hourly.
#
# The manifest is the ONLY thing users see. A version bump in a working copy
# reaches nobody: publish-release.sh is what rewrites the manifest, and only
# when the maintainer runs it deliberately.
#
# Public-beta updates are download-only. The dormant in-place installer remains
# behind APP_IN_PLACE_UPDATES_ENABLED=False until manifests carry a pinned
# offline signature; a checksum from the same host is not sufficient trust.
#
# The manifest is fetched from an address the maintainer owns, NOT from a
# code-host path — a repo or account can be renamed, and every installed copy
# would silently stop seeing updates. The code host is only a fallback for the
# day the site is down.
APP_UPDATE_MANIFEST_URLS = tuple(
    url
    for url in (
        clean_text(os.environ.get("AWBN_UPDATE_MANIFEST")),
        "https://kadaken.com/awbn-update.json",
        "https://kadaken.pages.dev/awbn-update.json",
        "https://raw.githubusercontent.com/LegendofZito/agent-workbench"
        "/awbn-native/release-manifest.json",
    )
    if url
)
# Kept as a name because tests and tooling refer to "the" manifest URL.
APP_UPDATE_MANIFEST_URL = APP_UPDATE_MANIFEST_URLS[0]
APP_UPDATE_STATE = {"checked_at": 0.0, "payload": None, "refreshing": False}
APP_UPDATE_REFRESH_LOCK = threading.Lock()
APP_UPDATE_CACHE_FILE = os.path.join(CONFIG_DIR, "app-update.json")
APP_UPDATE_INTERVAL_SECONDS = 3600
# Public beta updates are download-only until manifests have an offline
# signature whose public key is pinned in the app.  A checksum delivered by
# the same server as the binary detects corruption, not server compromise.
APP_IN_PLACE_UPDATES_ENABLED = False


def fetch_update_manifest():
    """First address that answers with usable JSON wins.

    Returns (manifest, source_url). Raises the last error if none answer."""
    last_error = None
    for url in APP_UPDATE_MANIFEST_URLS:
        try:
            request = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "awbn-update-check",
                    # Ask the CDN for the real file, not yesterday's copy.
                    "Cache-Control": "no-cache",
                },
            )
            with urllib.request.urlopen(request, timeout=10) as response:
                manifest = json.loads(response.read().decode("utf-8", "replace"))
            if isinstance(manifest, dict) and clean_text(manifest.get("version")):
                return manifest, url
            last_error = ValueError(f"{url} returned no version")
        except Exception as error:  # noqa: BLE001
            last_error = error
    raise last_error or ValueError("no update address answered")


def installed_app_version():
    """Version of the running build, read from the packaged pubspec."""
    here = os.path.dirname(os.path.abspath(__file__))
    # Installed layout: bridge/ sits beside the Flutter bundle, which ships
    # its own version.json. This is the case that matters for a real user.
    for candidate in (
        os.path.join(here, "..", "data", "flutter_assets", "version.json"),
        os.path.join(here, "data", "flutter_assets", "version.json"),
    ):
        try:
            with open(os.path.abspath(candidate), encoding="utf-8") as handle:
                version = clean_text(json.load(handle).get("version"))
            if version:
                return version
        except (OSError, ValueError):
            continue
    # Source checkout: awbench_server.py sits beside app/
    for candidate in (
        os.path.join(here, "app", "pubspec.yaml"),
        os.path.join(here, "..", "pubspec.yaml"),
    ):
        try:
            with open(os.path.abspath(candidate), encoding="utf-8") as handle:
                for line in handle:
                    if line.startswith("version:"):
                        return clean_text(line.split(":", 1)[1]).split("+")[0]
        except OSError:
            continue
    return ""


def running_appimage_path():
    """Absolute path of the AppImage we are running inside, or ''.

    The AppImage runtime sets APPIMAGE for AppRun, which starts this bridge,
    so a bridge with APPIMAGE set is one the AppImage owns. A bridge started
    by systemd (deb/tarball install) has no APPIMAGE and never self-swaps."""
    path = clean_text(os.environ.get("APPIMAGE"))
    if not path:
        return ""
    real = os.path.realpath(os.path.expanduser(path))
    if os.path.isfile(real) and os.access(os.path.dirname(real), os.W_OK):
        return real
    return ""


def _manifest_appimage_asset(manifest):
    """The AppImage entry from the manifest, if it is complete enough to
    install: a URL and a sha256 to check it against. No checksum, no swap."""
    assets = manifest.get("assets")
    asset = (assets or {}).get("appimage") if isinstance(assets, dict) else None
    if not isinstance(asset, dict):
        return None
    url = clean_text(asset.get("url"))
    checksum = clean_text(asset.get("sha256")).lower()
    if not url.startswith("https://") or len(checksum) != 64:
        return None
    return {"url": url, "sha256": checksum, "size": asset.get("size") or 0}


def safe_update_download_url(value):
    """Return only a credential-free HTTPS page suitable for xdg-open."""
    url = clean_text(value)
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return ""
    if (
        parsed.scheme.lower() != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
    ):
        return ""
    return url


def app_update_status():
    """Whether a newer build exists, answered immediately — never by waiting.

    Finding out means asking the update address over the internet: measured at
    0.27s on a good connection, unbounded on a bad one, on a request drawn
    into the window at start. So this answers with what is already known —
    this run's check, or the one the last run saved — and refreshes in the
    background when that is stale. Same rule as the usage chip: a slightly
    old answer costs nothing, a stall costs every start (v4.3.3)."""
    now = time.monotonic()
    cached = APP_UPDATE_STATE.get("payload")
    if cached is None:
        stored = load_json(APP_UPDATE_CACHE_FILE, {}) or {}
        if isinstance(stored, dict) and stored.get("installed"):
            # A saved answer is only about the build that was running then.
            # After an update it is wrong, so it is kept only while the
            # installed version still matches.
            if clean_text(stored.get("installed")) == installed_app_version():
                cached = stored
                APP_UPDATE_STATE["payload"] = stored
                APP_UPDATE_STATE["checked_at"] = 0.0
    fresh = cached is not None and (
        now - float(APP_UPDATE_STATE.get("checked_at") or 0)
        < APP_UPDATE_INTERVAL_SECONDS
    )
    if not fresh:
        threading.Thread(target=_refresh_app_update, daemon=True).start()
    if cached is not None:
        return {
            **cached,
            "download_url": safe_update_download_url(cached.get("download_url")),
        }
    return {
        "ok": True,
        "installed": installed_app_version(),
        "latest": "",
        "update_available": False,
        "download_url": "",
        "notes": "",
        "can_install": False,
        "install_kind": "appimage" if running_appimage_path() else "manual",
        "pending": True,
    }


def _fetch_app_update_status():
    now = time.monotonic()
    installed = installed_app_version()
    payload = {
        "ok": True,
        "installed": installed,
        "latest": "",
        "update_available": False,
        "download_url": "",
        "notes": "",
        "can_install": False,
        "install_kind": "appimage" if running_appimage_path() else "manual",
    }
    try:
        manifest, source = fetch_update_manifest()
        payload["source"] = source
        latest = clean_text(manifest.get("version"))
        payload["latest"] = latest
        payload["download_url"] = safe_update_download_url(
            manifest.get("download_url")
        )
        payload["notes"] = clean_text(manifest.get("notes"))
        if latest and installed:
            try:
                payload["update_available"] = _semver_tuple(latest) > _semver_tuple(
                    installed
                )
            except (TypeError, ValueError):
                payload["update_available"] = False
        APP_UPDATE_STATE["asset"] = _manifest_appimage_asset(manifest)
        payload["can_install"] = bool(
            APP_IN_PLACE_UPDATES_ENABLED
            and
            payload["update_available"]
            and running_appimage_path()
            and APP_UPDATE_STATE["asset"]
        )
    except Exception as error:  # noqa: BLE001
        # Offline, or no manifest published yet — never a hard failure.
        payload["error"] = clean_text(error)
    APP_UPDATE_STATE["payload"] = payload
    APP_UPDATE_STATE["checked_at"] = now
    try:
        save_json(APP_UPDATE_CACHE_FILE, payload)
    except OSError:
        pass
    return payload


def _refresh_app_update():
    """Check the update address once, in the background, one at a time."""
    with APP_UPDATE_REFRESH_LOCK:
        if APP_UPDATE_STATE.get("refreshing"):
            return
        APP_UPDATE_STATE["refreshing"] = True
    try:
        _fetch_app_update_status()
    except Exception:  # noqa: BLE001
        pass
    finally:
        with APP_UPDATE_REFRESH_LOCK:
            APP_UPDATE_STATE["refreshing"] = False


APP_UPDATE_MAX_BYTES = 400 * 1024 * 1024


def install_app_update():
    """Download the published AppImage, check it, and swap it in.

    Order matters: nothing touches the installed file until the download has
    finished AND its sha256 matches the manifest. The old AppImage is kept as
    a .bak alongside, so a bad build is one rename away from undone."""
    if not APP_IN_PLACE_UPDATES_ENABLED:
        return {
            "ok": False,
            "error": (
                "In-place updates are disabled for the beta until releases use "
                "a pinned cryptographic signature. Open the verified download page instead."
            ),
        }
    target = running_appimage_path()
    if not target:
        return {
            "ok": False,
            "error": "This install updates by download, not in place. Use the "
            "download button.",
        }
    if ACTIVE_TURNS:
        return {
            "ok": False,
            "error": "A chat is still working. Let it finish, then update.",
        }
    # Deliberately the blocking check, not the instant one. Installing is a
    # button the user pressed, so a fraction of a second is nothing, and it
    # must not act on a saved answer: the asset URL and checksum come from
    # the live manifest, and a restored-from-disk payload carries neither.
    status = _fetch_app_update_status()
    asset = APP_UPDATE_STATE.get("asset")
    if not status.get("update_available"):
        return {"ok": False, "error": "Already up to date."}
    if not asset:
        return {
            "ok": False,
            "error": "That release has no checksummed AppImage to install.",
        }
    folder = os.path.dirname(target)
    staged = os.path.join(folder, f".awbn-update-{uuid.uuid4().hex}.AppImage")
    digest = hashlib.sha256()
    try:
        request = urllib.request.Request(
            asset["url"], headers={"User-Agent": "awbn-update-install"}
        )
        written = 0
        with urllib.request.urlopen(request, timeout=60) as response, open(
            staged, "wb"
        ) as handle:
            while True:
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                written += len(chunk)
                if written > APP_UPDATE_MAX_BYTES:
                    raise ValueError("download is implausibly large - stopped")
                digest.update(chunk)
                handle.write(chunk)
        if digest.hexdigest() != asset["sha256"]:
            raise ValueError("the download did not match its published checksum")
        os.chmod(staged, 0o755)
        backup = f"{target}.previous"
        try:
            shutil.copy2(target, backup)
        except OSError:
            backup = ""
        os.replace(staged, target)
    except Exception as error:  # noqa: BLE001
        try:
            os.remove(staged)
        except OSError:
            pass
        return {"ok": False, "error": clean_text(error)}
    APP_UPDATE_STATE["payload"] = None
    APP_UPDATE_STATE["checked_at"] = 0.0
    return {
        "ok": True,
        "installed_version": status.get("latest"),
        "path": target,
        "previous_kept": bool(backup),
        "message": "Installed. Close Agent Workbench and open it again to "
        "finish.",
    }


def claude_usage_limits():
    try:
        result = subprocess.run(
            [
                "claude",
                "-p",
                "/usage",
                "--output-format",
                "json",
                "--permission-mode",
                "default",
                "--tools",
                "",
                "--no-session-persistence",
            ],
            cwd=os.path.expanduser("~"),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"agent_key": "claude", "provider": "Claude", "windows": [], "error": str(error)}
    try:
        payload = json.loads(result.stdout or "{}")
        text = clean_text(payload.get("result"))
    except ValueError:
        text = clean_text(result.stdout)
    windows = []
    session_match = re.search(
        r"Current session:\s*(\d+)% used\s*·\s*resets\s*(.+)", text, flags=re.IGNORECASE
    )
    if session_match:
        windows.append(
            {
                "label": "5h",
                "used_percent": int(session_match.group(1)),
                "reset": clean_text(session_match.group(2)),
                "purpose": "Current session",
            }
        )
    # v4.0.8: capture EVERY per-scope weekly window generically — the CLI
    # grew model-specific buckets ("Current week (Fable): 77%", previously
    # "(Sonnet only)"), and the user needs Fable's own meter visible since
    # it has its own rules.
    for match in re.finditer(
        r"Current week \(([^)]+)\):\s*(\d+)% used\s*·\s*resets\s*([^\n]+)",
        text,
        flags=re.IGNORECASE,
    ):
        scope = clean_text(match.group(1))
        label = (
            "week"
            if scope.lower().startswith("all")
            else scope.lower().replace("only", "").strip().split()[0]
        )
        windows.append(
            {
                "label": label,
                "used_percent": int(match.group(2)),
                "reset": clean_text(match.group(3)),
                "purpose": f"Current week ({scope})",
            }
        )
    if windows:
        return {"agent_key": "claude", "provider": "Claude", "windows": windows}
    return {
        "agent_key": "claude",
        "provider": "Claude",
        "windows": [],
        "error": text or "Claude usage unavailable.",
    }


def _read_usage_limits(key, normalized=""):
    if key == "claude":
        return claude_usage_limits()
    if key == "codex":
        return codex_usage_limits()
    return {
        "agent_key": key,
        "provider": (normalized or key).capitalize() or "Client",
        "windows": [],
        "error": "This client does not expose account-limit telemetry.",
    }


def _refresh_usage_limits(key, normalized=""):
    """Fetch one client's limits and store them, at most one refresh at a time."""
    with LIMIT_REFRESH_LOCK:
        if key in LIMIT_REFRESHING:
            return
        LIMIT_REFRESHING.add(key)
    try:
        value = _read_usage_limits(key, normalized)
        LIMIT_CACHE[key] = {"time": time.monotonic(), "value": value}
        try:
            save_json(
                USAGE_LIMIT_CACHE_FILE,
                {name: entry["value"] for name, entry in LIMIT_CACHE.items()},
            )
        except OSError:
            pass
    finally:
        with LIMIT_REFRESH_LOCK:
            LIMIT_REFRESHING.discard(key)


def usage_limits(agent):
    """A client's account limits, answered immediately — never by waiting.

    Reading Claude's limits means running `claude -p /usage`, which spawns the
    whole CLI: measured at a flat 2.0 seconds, every time, on a request the UI
    blocks on to draw one chip. Codex's is 40ms but still touches the disk.

    So this never fetches inline. It answers with whatever is known — the live
    cache, or the copy saved by an earlier run — and refreshes in the
    background when that is stale. The number is a percentage that moves over
    minutes; a slightly old one costs nothing, and a two-second pause costs
    every interaction that draws it (v4.3.3)."""
    normalized = clean_text(agent).lower()
    if normalized in {"", "all", "both", "combined"}:
        return {
            "provider": "Usage limits",
            "agents": [usage_limits("claude"), usage_limits("codex")],
        }
    key = "claude" if "claude" in normalized else "codex" if "codex" in normalized else normalized
    cached = LIMIT_CACHE.get(key)
    if cached is None:
        # Nothing this run — fall back to what the last run saved, so a
        # restart shows the real figure instead of a blank chip.
        persisted = load_json(USAGE_LIMIT_CACHE_FILE, {}) or {}
        stored = persisted.get(key) if isinstance(persisted, dict) else None
        if isinstance(stored, dict):
            cached = {"time": 0.0, "value": stored}
            LIMIT_CACHE[key] = cached
    if cached is None or time.monotonic() - cached["time"] >= LIMIT_CACHE_SECONDS:
        threading.Thread(
            target=_refresh_usage_limits, args=(key, normalized), daemon=True
        ).start()
    if cached is not None:
        return cached["value"]
    return {
        "agent_key": key,
        "provider": (normalized or key).capitalize() or "Client",
        "windows": [],
        "pending": True,
    }


def manual_file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _manual_edit_thread_lock(path):
    key = os.path.realpath(os.path.abspath(path))
    with MANUAL_EDIT_LOCKS_LOCK:
        lock = MANUAL_EDIT_LOCKS.get(key)
        if lock is None:
            lock = threading.RLock()
            MANUAL_EDIT_LOCKS[key] = lock
        return lock


def manual_edit_request_path(request):
    """Resolve a manual-edit request exactly as commands.py will resolve it."""
    root = commands._project_root_for_reference(
        sys.modules[__name__],
        project_id=clean_text(request.get("project_id")),
        root=clean_text(request.get("root")),
        session_id=clean_text(request.get("session_id")),
    )
    commands._require_registered_project(sys.modules[__name__], root)
    return commands._safe_project_child_path(
        sys.modules[__name__], root, request.get("path")
    )


def dispatch_manual_file_preview(handler, parsed):
    """Add the raw file revision used by optimistic manual-edit saves."""
    original_json = handler._json

    def respond(status, payload):
        output = dict(payload) if isinstance(payload, dict) else payload
        if status == 200 and isinstance(output, dict) and output.get("ok") is True:
            file_payload = output.get("file")
            path = clean_text(
                file_payload.get("path") if isinstance(file_payload, dict) else ""
            )
            if path and os.path.isfile(path):
                output["sha256"] = manual_file_sha256(path)
        original_json(status, output)

    handler._json = respond
    try:
        commands.GET_HANDLERS["/project/file-preview"](handler, parsed, {})
    finally:
        handler._json = original_json


def dispatch_manual_file_save(handler, parsed, request):
    """Compare-and-save a viewer edit, rejecting a stale preview revision."""
    try:
        path = manual_edit_request_path(request)
    except Exception:
        # Preserve the command handler's normal validation/error response.
        commands.POST_HANDLERS["/project/file/save"](handler, parsed, request)
        return
    expected = clean_text(request.get("expected_sha256"))
    if expected and not re.fullmatch(r"[0-9a-fA-F]{64}", expected):
        handler._json(
            400,
            {"ok": False, "error": "expected_sha256 must be a SHA-256 digest"},
        )
        return
    lock = _manual_edit_thread_lock(path)
    with lock:
        actual = manual_file_sha256(path) if os.path.isfile(path) else ""
        if expected and not secrets.compare_digest(expected.lower(), actual):
            handler._json(
                409,
                {
                    "ok": False,
                    "code": "edit_conflict",
                    "error": (
                        "file changed on disk after it was opened; reload it "
                        "before saving so newer work is not overwritten"
                    ),
                    "sha256": actual,
                },
            )
            return

        original_json = handler._json

        def respond(status, payload):
            output = dict(payload) if isinstance(payload, dict) else payload
            if status == 200 and isinstance(output, dict) and output.get("ok") is True:
                output["sha256"] = (
                    manual_file_sha256(path) if os.path.isfile(path) else ""
                )
                output["conflict_checked"] = bool(expected)
            original_json(status, output)

        handler._json = respond
        try:
            commands.POST_HANDLERS["/project/file/save"](handler, parsed, request)
        finally:
            handler._json = original_json


def public_health_payload():
    """Minimal unauthenticated identity used only by launch/smoke checks."""
    return {
        "ok": True,
        "app": "agent-workbench-native",
        "version": installed_app_version(),
    }


def request_bridge_shutdown(http_server, delay=0.05):
    """Schedule a clean bridge stop only when no model turn is live."""
    with ACTIVE_LOCK:
        active_count = len(ACTIVE_TURNS)
    if active_count:
        return {
            "ok": False,
            "error": "cannot shut down the bridge while a turn is active",
            "active_turns": active_count,
        }

    def stop_server():
        if delay:
            time.sleep(delay)
        http_server.shutdown()

    threading.Thread(target=stop_server, daemon=True).start()
    return {"ok": True}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Methods", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")

    def _origin_allowed(self):
        """Allow the local Tauri webview, the launcher's curl (no Origin), and
        localhost; reject real web origins. This is a defense-in-depth gate
        against a malicious page driving localhost — CORS alone does not stop
        the side effect of a cross-site POST."""
        origin = self.headers.get("Origin")
        if not origin:
            return True
        try:
            parsed = urllib.parse.urlparse(origin)
        except Exception:
            return True
        scheme = (parsed.scheme or "").lower()
        host = (parsed.hostname or "").lower()
        if scheme in ("tauri", "asset", "file"):
            return True
        if host in ("localhost", "127.0.0.1", "::1") or host.endswith(".localhost"):
            return True
        return False

    def _deny_foreign_origin(self):
        if self._origin_allowed():
            return False
        print(f"awbench_server: blocked cross-origin request from "
              f"{self.headers.get('Origin')!r} to {self.path}")
        self._json(403, {"ok": False, "error": "forbidden origin"})
        return True

    def _auth_exempt(self, path):
        # The launcher and systemd smoke checks use unauthenticated /health to decide
        # whether the local bridge is running. All real control-plane routes require
        # the per-user token.
        return path == "/health"

    def _deny_unauthorized(self, parsed):
        if self._auth_exempt(parsed.path):
            return False
        expected = bridge_auth_token()
        provided = clean_text(self.headers.get(BRIDGE_AUTH_HEADER))
        if provided and secrets.compare_digest(provided, expected):
            return False
        self._json(401, {"ok": False, "error": "unauthorized"})
        return True

    def _json(self, status, value):
        body = json.dumps(value).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        if self._deny_foreign_origin():
            return
        parsed = urllib.parse.urlparse(self.path)
        if self._deny_unauthorized(parsed):
            return
        if parsed.path == "/health":
            self._json(200, public_health_payload())
            return
        if parsed.path == "/app-state":
            try:
                self._json(200, {"ok": True, "state": ui_app_state_payload()})
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/keys":
            try:
                self._json(200, {"ok": True, **ui_keys_payload()})
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/project-state":
            try:
                query = urllib.parse.parse_qs(parsed.query)
                self._json(
                    200,
                    {
                        "ok": True,
                        "state": ui_project_state_payload(
                            clean_text(query.get("session_id", [""])[0]),
                            clean_text(query.get("cwd", [""])[0]),
                        ),
                    },
                )
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/sessions":
            try:
                query = urllib.parse.parse_qs(parsed.query)
                scope = clean_text((query.get("scope") or ["primary"])[0]).lower()
                self._json(
                    200,
                    {"ok": True, "sessions": ui_list_sessions_payload(scope=scope)},
                )
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/turn/active":
            # v4.6.4: lets the app tell a DETACHED turn (still running here
            # after the window closed) from a truly dead one, instead of
            # stamping every persisted "running" turn Cancelled on reopen.
            # Without ?id= it reports EVERY live turn — the close prompt asks
            # this, so work the window never knew about still gets the ask
            # (reported: "I absolutely didn't get a close prompt").
            query = urllib.parse.parse_qs(parsed.query)
            session_id = clean_text(query.get("id", [""])[0])
            with ACTIVE_LOCK:
                active_ids = [clean_text(key) for key in ACTIVE_TURNS]
            if session_id:
                self._json(
                    200, {"ok": True, "running": session_id in active_ids}
                )
            else:
                self._json(
                    200,
                    {
                        "ok": True,
                        "running": bool(active_ids),
                        "session_ids": active_ids,
                    },
                )
            return
        if parsed.path == "/session/messages":
            try:
                query = urllib.parse.parse_qs(parsed.query)
                session_id = clean_text(query.get("id", [""])[0])
                if not session_id:
                    raise RuntimeError("missing session id")
                self._json(
                    200,
                    {
                        "ok": True,
                        "messages": ui_session_messages_payload(session_id),
                    },
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/session/work-log":
            try:
                query = urllib.parse.parse_qs(parsed.query)
                session_id = clean_text(query.get("id", [""])[0])
                if not session_id:
                    raise RuntimeError("missing session id")
                self._json(
                    200,
                    {
                        "ok": True,
                        "entries": ui_session_work_log_payload(session_id),
                    },
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/session/artifacts":
            try:
                query = urllib.parse.parse_qs(parsed.query)
                session_id = clean_text(query.get("id", [""])[0])
                if not session_id:
                    raise RuntimeError("missing session id")
                self._json(
                    200,
                    {
                        "ok": True,
                        "artifacts": ui_session_artifacts_payload(session_id),
                    },
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/app/update":
            # Reads the manifest the maintainer publishes and reports whether
            # a newer build exists. Reading never installs anything; that is
            # POST /app/update/install, and only the user can ask for it.
            self._json(200, app_update_status())
            return
        if parsed.path == "/limits":
            agent = urllib.parse.parse_qs(parsed.query).get("agent", [""])[0]
            self._json(200, usage_limits(agent))
            return
        if parsed.path == "/connectors":
            try:
                force = (
                    urllib.parse.parse_qs(parsed.query).get("refresh", ["0"])[0]
                    == "1"
                )
                self._json(
                    200,
                    {"ok": True, "connectors": connector_statuses(force=force)},
                )
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/skills":
            try:
                query = urllib.parse.parse_qs(parsed.query)
                agent_key = clean_text(query.get("agent", ["claude"])[0])
                cwd = clean_text(query.get("cwd", [""])[0])
                self._json(200, skills_payload(agent_key, cwd))
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/client/models":
            # GET /client/models[?refresh=1] — discovered (or static-fallback)
            # model/effort options per installed CLI. Cached; refreshed on a
            # detected CLI version change (see /client/updates), on server
            # start, or here on demand with ?refresh=1.
            try:
                force = (
                    urllib.parse.parse_qs(parsed.query).get("refresh", ["0"])[0]
                    == "1"
                )
                agents = get_model_discovery_agents(force=force)
                self._json(
                    200,
                    {
                        "ok": True,
                        "agents": agents,
                        "generated_at": _MODEL_DISCOVERY_STATE.get("generated_at") or "",
                    },
                )
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/client/tools":
            # GET /client/tools — each client's MCP servers and whether the
            # user has them switched on. Read from the clients' own configs.
            try:
                self._json(200, client_tools_payload())
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/client/models/check":
            # GET /client/models/check?agent=codex&model=birdaloo — is this a
            # model the installed CLI actually knows about? Backs the Custom…
            # box, which used to store whatever was typed and only fail later,
            # at launch, with no hint that the name was never real.
            try:
                query = urllib.parse.parse_qs(parsed.query)
                self._json(
                    200,
                    check_model_name(
                        clean_text(query.get("agent", [""])[0]),
                        clean_text(query.get("model", [""])[0]),
                    ),
                )
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/terminal/output":
            try:
                query = urllib.parse.parse_qs(parsed.query)
                workspace_id = clean_text(query.get("workspace_id", [""])[0])
                cursor = clean_text(query.get("cursor", ["0"])[0])
                self._json(200, {"ok": True, **ui_terminal_output(workspace_id, cursor)})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/project/file-preview":
            dispatch_manual_file_preview(self, parsed)
            return
        if parsed.path in commands.GET_HANDLERS:
            commands.GET_HANDLERS[parsed.path](self, parsed, {})
            return
        self._json(404, {"error": "not found"})

    def do_POST(self):
        if self._deny_foreign_origin():
            return
        parsed = urllib.parse.urlparse(self.path)
        if self._deny_unauthorized(parsed):
            return
        # Robust against a bad/missing/negative Content-Length and non-object bodies:
        # a non-numeric value used to crash the worker, a negative value hung it on
        # read-until-EOF, and a non-dict JSON body crashed routes on request.get().
        try:
            length = max(0, int(self.headers.get("Content-Length", "0") or "0"))
        except (TypeError, ValueError):
            length = 0
        if length > MAX_POST_BYTES:
            self._json(
                413,
                {
                    "ok": False,
                    "error": f"request body exceeds {MAX_POST_BYTES:,} byte limit",
                },
            )
            return
        try:
            request = json.loads(self.rfile.read(length) or b"{}")
        except ValueError:
            request = {}
        if not isinstance(request, dict):
            request = {}

        if parsed.path == "/bridge/shutdown":
            result = request_bridge_shutdown(self.server)
            self._json(200 if result.get("ok") else 409, result)
            return

        if parsed.path == "/app/update/install":
            # Only reachable when the user clicks Update in Options, and only
            # does anything for an AppImage install with a checksummed asset.
            self._json(200, install_app_update())
            return

        if parsed.path == "/stop":
            session_id = clean_text(request.get("session_id"))
            with ACTIVE_LOCK:
                control = ACTIVE_TURNS.get(session_id)
            if control:
                control.stop()
                stopped = True
            else:
                stopped = forget_persistent_custom_cli_session(session_id)
            self._json(200, {"ok": stopped})
            return

        if parsed.path == "/session/close":
            # Reap any resident backend process for a session being deleted, so it
            # doesn't linger idle until app exit. Stop interrupts a turn but keeps the
            # resident alive; close tears it down for good.
            session_id = clean_text(request.get("session_id"))
            with ACTIVE_LOCK:
                control = ACTIVE_TURNS.get(session_id)
            if control:
                control.stop()
            close_claude_stream_session(session_id)
            forget_persistent_custom_cli_session(session_id)
            close_ui_terminal_session(session_id)
            self._json(200, {"ok": True})
            return

        if parsed.path == "/terminal/start":
            try:
                workspace_id = clean_text(request.get("workspace_id"))
                cwd = clean_text(request.get("cwd"))
                cols = int(request.get("cols") or 120)
                rows = int(request.get("rows") or 32)
                terminal = ui_terminal_session(workspace_id, cwd, cols, rows)
                self._json(200, {"ok": True, **terminal.snapshot(0)})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/terminal/write":
            try:
                ui_terminal_write(
                    clean_text(request.get("workspace_id")),
                    request.get("data") or "",
                )
                self._json(200, {"ok": True})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/terminal/resize":
            try:
                resized = ui_terminal_resize(
                    clean_text(request.get("workspace_id")),
                    int(request.get("cols") or 120),
                    int(request.get("rows") or 32),
                )
                self._json(200, {"ok": True, "resized": resized})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/terminal/stop":
            try:
                stopped = close_ui_terminal_session(clean_text(request.get("workspace_id")))
                self._json(200, {"ok": True, "stopped": stopped})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/projects-home/create":
            try:
                target, created = create_projects_home(request.get("path") or "")
                self._json(
                    200,
                    {"ok": True, "path": target, "created": created},
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/session/create":
            try:
                session = ui_create_session(
                    clean_text(request.get("agent")),
                    clean_text(request.get("model")),
                    clean_text(request.get("effort")) or "Default",
                    clean_text(request.get("cwd")),
                    clean_text(request.get("title")),
                    free_chat=request.get("free_chat") is True,
                    validate_client=True,
                )
                self._json(200, {"ok": True, "session": ui_session_summary(session)})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/session/queue":
            try:
                session_id = clean_text(request.get("session_id"))
                if not session_id:
                    raise RuntimeError("missing session id")
                queued = request.get("queued_prompts")
                if not isinstance(queued, list):
                    queued = []
                session = load_session(session_id)
                session["queued_prompts"] = queued[:200]
                session["updated_at"] = now_iso()
                save_session(session)
                self._json(200, {"ok": True, "queued": len(session["queued_prompts"])})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/session/update":
            try:
                session, native_updated = ui_update_session(
                    clean_text(request.get("session_id")),
                    title=request.get("title") if "title" in request else None,
                    model=request.get("model") if "model" in request else None,
                    effort=request.get("effort") if "effort" in request else None,
                )
                self._json(
                    200,
                    {
                        "ok": True,
                        "session": ui_session_summary(session),
                        "native_updated": native_updated,
                    },
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/session/delete":
            try:
                result = ui_delete_session(clean_text(request.get("session_id")))
                self._json(200, {"ok": True, **result})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/session/artifacts/store":
            try:
                artifacts = ui_store_artifacts_payload(
                    clean_text(request.get("session_id")),
                    request.get("paths") or [],
                )
                self._json(200, {"ok": True, "artifacts": artifacts})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/session/artifacts/paste":
            try:
                artifacts = ui_paste_clipboard_artifacts_payload(
                    clean_text(request.get("session_id")),
                )
                self._json(200, {"ok": True, "artifacts": artifacts})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/session/artifacts/open":
            try:
                artifact = ui_open_artifact_payload(
                    clean_text(request.get("session_id")),
                    clean_text(request.get("path")),
                )
                self._json(200, {"ok": True, "artifact": artifact})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/session/artifacts/rename":
            try:
                artifact = ui_rename_artifact_payload(
                    clean_text(request.get("session_id")),
                    clean_text(request.get("path")),
                    clean_text(request.get("name")),
                )
                self._json(200, {"ok": True, "artifact": artifact})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/session/artifacts/delete":
            try:
                artifacts = ui_delete_artifact_payload(
                    clean_text(request.get("session_id")),
                    clean_text(request.get("path")),
                )
                self._json(200, {"ok": True, "artifacts": artifacts})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/project-state/open":
            try:
                path = open_project_state_file(
                    clean_text(request.get("session_id")),
                    clean_text(request.get("cwd")),
                )
                if not path:
                    raise RuntimeError("Could not resolve project state for this session.")
                self._json(200, {"ok": True, "path": path})
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/skills/favorite":
            try:
                agent_key = clean_text(request.get("agent"))
                name = clean_text(request.get("name"))
                favorite = bool(request.get("favorite"))
                set_skill_favorite(agent_key, name, favorite)
                cwd = clean_text(request.get("cwd"))
                self._json(200, skills_payload(agent_key, cwd))
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/handoff/stage":
            session_id = clean_text(request.get("session_id"))
            try:
                with locked_sessions(session_id):
                    session = load_session(session_id)
                    artifact = stage_handoff(session, force=True)
                    save_session(session)
                self._json(200, {"ok": True, "artifact": artifact})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/handoff/deploy":
            try:
                session = deploy_handoff(
                    clean_text(request.get("session_id")),
                    clean_text(request.get("agent")) or "claude",
                    clean_text(request.get("model")) or "Default",
                    clean_text(request.get("effort")) or "Default",
                    title_override=clean_text(request.get("title")),
                )
                self._json(200, {"ok": True, "session": session})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/handoff/deploy-existing":
            try:
                session = deploy_handoff_to_existing(
                    clean_text(request.get("session_id")),
                    clean_text(request.get("target_session_id")),
                )
                self._json(200, {"ok": True, "session": session})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/handoff/auto":
            try:
                session = maybe_auto_deploy_handoff(
                    clean_text(request.get("session_id"))
                )
                self._json(200, {"ok": True, "session": session})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/history/sync":
            try:
                self._json(200, {"ok": True, **sync_native_history()})
            except Exception as error:
                self._json(500, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/history/load":
            try:
                session = load_native_transcript(clean_text(request.get("session_id")))
                self._json(
                    200,
                    {
                        "ok": True,
                        "session_id": session.get("id"),
                        "turn_count": len(session.get("turns") or []),
                    },
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/app-preferences":
            try:
                self._json(
                    200,
                    {
                        "ok": True,
                        "state": ui_save_app_preferences_payload(request),
                    },
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/onboarding/defer":
            try:
                self._json(
                    200,
                    {"ok": True, "state": ui_defer_onboarding_payload()},
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/onboarding/complete":
            try:
                self._json(
                    200,
                    {"ok": True, "state": ui_complete_onboarding_payload()},
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/workspace-state":
            try:
                self._json(
                    200,
                    {
                        "ok": True,
                        "state": ui_save_workspace_state_payload(request),
                    },
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/keys/add":
            try:
                self._json(200, {"ok": True, **ui_add_key_payload(request)})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/keys/delete":
            try:
                self._json(200, {"ok": True, **ui_delete_key_payload(request)})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/keys/write-env":
            try:
                self._json(200, {"ok": True, **ui_write_key_to_env_payload(request)})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/connectors/auth":
            try:
                value = start_connector_auth(
                    clean_text(request.get("connector")).lower(),
                    clean_text(request.get("client_id")),
                    clean_text(request.get("client_secret")),
                )
                self._json(202, {"ok": True, **value})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/connectors/token":
            try:
                value = set_connector_token(
                    clean_text(request.get("connector")).lower(),
                    request.get("token") or "",
                )
                self._json(200, value)
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/worker/spawn":
            # POST /worker/spawn — request: {source_id, prompt, agent?, model?, effort?}
            # response: {ok, session: {id, title, agent, model, effort,
            #            worker_parent_session_id, worker_job_id}}
            try:
                session = spawn_worker_session(
                    clean_text(request.get("source_id")),
                    clean_text(request.get("prompt")),
                    agent=clean_text(request.get("agent")),
                    model=clean_text(request.get("model")),
                    effort=clean_text(request.get("effort")),
                )
                self._json(200, {"ok": True, "session": session})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/worker/list":
            # POST /worker/list — request: {source_id, include_history?}
            # response: {ok, jobs: [...], sessions: [...]}
            try:
                parent_id = clean_text(request.get("source_id"))
                include_history = bool(request.get("include_history"))
                jobs = list_worker_jobs(parent_id, include_history=include_history)
                self._json(200, {"ok": True, "jobs": jobs, "sessions": jobs})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/worker/background/create":
            # POST /worker/background/create — request:
            # {source_id, title?, command?, note?, status?}
            try:
                job = create_background_worker_job(
                    clean_text(request.get("source_id")),
                    title=clean_text(request.get("title")),
                    command=clean_text(request.get("command")),
                    note=clean_text(request.get("note")),
                    status=clean_text(request.get("status")) or "running",
                )
                self._json(200, {"ok": True, "job": job})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/worker/background/update":
            # POST /worker/background/update — request:
            # {source_id, job_id, status?, title?, command?, note?}
            try:
                job = update_background_worker_job(
                    clean_text(request.get("source_id")),
                    clean_text(request.get("job_id")),
                    status=clean_text(request.get("status")),
                    title=clean_text(request.get("title")),
                    command=clean_text(request.get("command")),
                    note=clean_text(request.get("note")),
                )
                self._json(200, {"ok": True, "job": job})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/worker/clear":
            # POST /worker/clear — request: {source_id}
            # response: {ok, removed: <int>}
            try:
                parent_id = clean_text(request.get("source_id"))
                removed = remove_worker_jobs_for_source(parent_id)
                self._json(200, {"ok": True, "removed": len(removed)})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/client/updates":
            try:
                checks = []
                for spec in client_update_specs():
                    key = clean_text(spec.get("key"))
                    label = clean_text(spec.get("label")) or key
                    version_cmd = spec.get("version_cmd")
                    latest_cmd = spec.get("latest_cmd")
                    if not version_cmd:
                        checks.append(
                            {
                                "key": key,
                                "label": label,
                                "installed": "",
                                "latest": "",
                                "up_to_date": False,
                                "updated": False,
                                "checkable": bool(latest_cmd),
                                "error": "Missing version command",
                                "note": clean_text(spec.get("note")),
                            }
                        )
                        continue
                    installed_ok, installed_output = _run_capture(version_cmd)
                    if installed_ok:
                        installed_line = ((clean_text(installed_output).splitlines() or [""])[0])
                    else:
                        installed_line = ""

                    latest = ""
                    if latest_cmd:
                        latest_ok, latest_output = _run_capture(latest_cmd, timeout=40)
                        if latest_ok:
                            latest = ((clean_text(latest_output).splitlines() or [""])[0])

                    installed_tuple = _semver_tuple(installed_line or "")
                    latest_tuple = _semver_tuple(latest or "")

                    installed_version = installed_tuple and ".".join(
                        map(str, installed_tuple),
                    )
                    latest_version = latest_tuple and ".".join(
                        map(str, latest_tuple),
                    )
                    up_to_date = bool(
                        installed_tuple and latest_tuple
                        and installed_tuple >= latest_tuple,
                    )
                    checks.append(
                        {
                            "key": key,
                            "label": label,
                            "installed": installed_version or clean_text(installed_output),
                            "latest": latest_version or latest or clean_text(latest_output if latest_cmd else ""),
                            "up_to_date": up_to_date if installed_tuple and latest_tuple else False,
                            "updated": up_to_date and latest_tuple is not None,
                            "checkable": bool(latest_cmd),
                            "error": "" if installed_ok else clean_text(installed_output),
                            "note": clean_text(spec.get("note")),
                        }
                    )
                # This scan's own results ARE the "did a CLI's installed
                # version change" signal the model-discovery cache needs —
                # no extra CLI calls, just a version-string comparison.
                # Best-effort: a hiccup here must never break the version
                # scan the UI is waiting on.
                try:
                    note_client_versions_for_model_cache(checks)
                except Exception:
                    pass
                self._json(200, {"ok": True, "updates": checks})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/client/tools/toggle":
            try:
                self._json(
                    200,
                    set_mcp_server_enabled(
                        clean_text(request.get("agent")),
                        clean_text(request.get("name")),
                        request.get("enabled") is not False,
                    ),
                )
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return
        if parsed.path == "/client/update":
            try:
                key = clean_text(request.get("key"))
                spec = next(
                    (
                        item
                        for item in client_update_specs()
                        if clean_text(item.get("key")) == key
                    ),
                    None,
                )
                if not spec:
                    raise RuntimeError(f"Unknown client key: {key}")
                update_cmd = spec.get("update_cmd")
                if not update_cmd:
                    raise RuntimeError(f"No update command configured for {key}")
                with UPDATE_LOCK:
                    ok, output = _run_capture(update_cmd, timeout=300)
                status = {
                    "ok": ok,
                    "message": output,
                    "key": key,
                    "label": clean_text(spec.get("label")) or key,
                }
                if ok:
                    # A successful update run means the client is current NOW,
                    # by definition — whether it needed installing or was
                    # already latest. This matters most for specs with no
                    # latest_cmd (claude): the passive /client/updates scan can
                    # never determine up-to-date-ness for them, but the update
                    # action itself just proved it, so hand that back directly
                    # instead of leaving the UI stuck on "Update available".
                    status["up_to_date"] = True
                    _, installed = _run_capture(spec.get("version_cmd"))
                    status["installed"] = ((clean_text(installed).splitlines() or [""])[0])
                    # An explicit, successful "Update" click is itself proof
                    # something may have changed — rebuild the model cache
                    # now rather than waiting for the next passive scan, so
                    # the dropdowns are current by the time the dialog asks.
                    try:
                        with _MODEL_DISCOVERY_LOCK:
                            next_versions = dict(_MODEL_DISCOVERY_STATE.get("versions") or {})
                        next_versions[key] = status["installed"]
                        refresh_model_discovery_cache(versions=next_versions, reason="client-update")
                        status["models_refreshed"] = True
                    except Exception:
                        status["models_refreshed"] = False
                self._json(200, status)
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/project/rules/write":
            try:
                result = write_agent_rules(
                    request.get("root") or "",
                    request.get("agents"),
                    overwrite=request.get("overwrite") is True,
                )
                self._json(200, {"ok": True, **result})
            except Exception as error:
                self._json(400, {"ok": False, "error": clean_text(error)})
            return

        if parsed.path == "/project/file/save":
            dispatch_manual_file_save(self, parsed, request)
            return
        if parsed.path in commands.POST_HANDLERS:
            commands.POST_HANDLERS[parsed.path](self, parsed, request)
            return

        if parsed.path != "/send":
            self._json(404, {"error": "not found"})
            return

        self.send_response(200)
        self._cors()
        self.send_header("Content-Type", "application/x-ndjson")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

        control = TurnControl()

        # v4.1.0 (reported: closing AWBN mid-turn killed the turn — "we need
        # some kind of protective measure"): a dropped UI stream DETACHES
        # instead of cancelling. The turn keeps running server-side, the
        # durable recorder keeps persisting it, and reopening the app shows
        # the finished transcript. Only the explicit /stop route cancels.
        client_gone = {"value": False}

        def emit(event):
            if client_gone["value"]:
                return
            try:
                self.wfile.write((json.dumps(event) + "\n").encode("utf-8"))
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                client_gone["value"] = True

        session_id = clean_text(request.get("session_id"))
        visible_prompt = clean_text(request.get("message"))
        attachments = [
            os.path.abspath(os.path.expanduser(clean_text(path)))
            for path in request.get("attachments") or []
            if clean_text(path)
        ]
        attachments = [path for path in attachments if os.path.isfile(path)]
        requested_model = clean_text(request.get("model"))
        requested_effort = clean_text(request.get("effort")) or "Default"
        if not session_id:
            emit({"type": "error", "message": "missing session_id"})
            return
        if not visible_prompt and not attachments:
            emit({"type": "error", "message": "empty message"})
            return

        try:
            session = load_session(session_id)
        except Exception as error:
            emit({"type": "error", "message": f"session not found: {error}"})
            return

        try:
            session, detachment = detach_session_for_turn(session)
        except Exception as error:
            emit({"type": "error", "message": f"could not prepare session: {error}"})
            return
        active_session_id = clean_text(session.get("id")) or session_id

        if detachment and detachment["previous_session_id"] != active_session_id:
            emit(
                {
                    "type": "session",
                    "action": detachment["action"],
                    "previous_session_id": detachment["previous_session_id"],
                    "session": session_event_payload(session),
                }
            )

        if not visible_prompt:
            names = ", ".join(os.path.basename(path) for path in attachments)
            visible_prompt = (
                "Please inspect and respond to the attached "
                f"file{'s' if len(attachments) != 1 else ''}: {names}"
            )
        control.set_visible_prompt(visible_prompt)

        backend_settings = session.setdefault("backend", {})
        agent_key = clean_text(session.get("agent"))
        previous_model = clean_text(backend_settings.get("model"))
        previous_effort = clean_text(backend_settings.get("effort")) or "Default"
        if requested_model:
            backend_settings["model"] = requested_model
        elif not clean_text(backend_settings.get("model")):
            backend_settings["model"] = (
                default_model_for(agent_key) or "Default"
            )
        if agent_key == "gemini" or requested_effort == "Default":
            backend_settings.pop("effort", None)
        else:
            backend_settings["effort"] = requested_effort
        # A session remembers where it was made; folders get deleted. Repair it
        # here, once, before any client is launched with a path that is not
        # there — every one of them fails with a bare Errno 2 otherwise, and
        # the chat just stops (v4.5.8).
        runnable_cwd, cwd_note = usable_session_cwd(session)
        if cwd_note:
            session["cwd"] = runnable_cwd
            emit({"type": "work", "kind": "system", "content": cwd_note})
        launch_model = clean_text(backend_settings.get("model")) or "Default"
        launch_effort = clean_text(backend_settings.get("effort")) or "Default"
        coerced_model, model_was_coerced = coerce_model(agent_key, launch_model)
        if model_was_coerced:
            emit({
                "type": "work",
                "kind": "system",
                "content": (
                    f"Model '{launch_model}' isn't available for {agent_key} - "
                    f"using '{coerced_model}' instead."
                ),
            })
            launch_model = coerced_model
            backend_settings["model"] = coerced_model
        append_debug_event(
            "turn_start",
            scope="active",
            agent=agent_key,
            model=launch_model,
            effort=launch_effort,
            previous_model=previous_model,
            previous_effort=previous_effort,
            session=active_session_id,
            prompt_chars=len(visible_prompt),
            detached=bool(detachment),
        )

        inherited_context = clean_text(session.get("handoff_context"))
        pending_handoff_context = clean_text(session.pop("pending_handoff_context", ""))
        pending_project_root = pending_handoff_root(session, pending_handoff_context)
        shared_state_session = session
        if pending_project_root:
            shared_state_session = {
                **session,
                "cwd": pending_project_root,
                "project_root": pending_project_root,
                "title": project_label(pending_project_root),
                "handoff_base_title": project_label(pending_project_root),
            }
            session["cwd"] = pending_project_root
            session["project_root"] = pending_project_root
        shared_state = shared_state_turn_context(
            shared_state_session,
            agent_key,
            shared_state_session.get("cwd"),
            visible_prompt,
        )
        context_parts = [authoritative_time_context()]
        # Inject the handoff/continuation context once, on the first turn that
        # actually runs. The old "no turns yet" check broke spawned workers: a
        # worker pre-seeds a pending first turn, so turns was already non-empty
        # and the worker never received the instruction to read its handoff /
        # shared-state files. Gate on an explicit flag set at injection time
        # instead, so it works for workers, for interrupted-then-resent turns,
        # and for ordinary handoff sessions alike.
        if inherited_context and not session.get("handoff_context_injected"):
            context_parts.append(inherited_context)
            session["handoff_context_injected"] = True
        if pending_handoff_context:
            context_parts.append(pending_handoff_context)
            session.pop("pending_handoff_from", None)
            session.pop("pending_handoff_artifact", None)
            session.pop("pending_handoff_project_root", None)
            session.pop("pending_handoff_state_path", None)
        if shared_state:
            context_parts.append(shared_state)
        # v3.9.8: project self-awareness for every client. Claude gets the
        # block at launch via --append-system-prompt (see stream_claude);
        # every other client receives it through the prompt ONCE per session
        # (same pattern as handoff_context_injected) so Codex/Hermes/Ollama
        # project chats also know they run inside AWBN and which project
        # they belong to.
        if agent_key != "claude" and not session.get("project_awareness_injected"):
            awareness = project_awareness_prompt(session)
            if awareness:
                context_parts.append(awareness)
                session["project_awareness_injected"] = True
        # Claude receives the response style via --append-system-prompt; Codex and
        # Gemini have no system-prompt hook, so deliver it through the prompt here so
        # the chosen output style (e.g. Plain & Direct) applies to every agent.
        if agent_key in {"codex", "gemini"}:
            style_prompt = response_style_prompt()
            if style_prompt:
                context_parts.append(style_prompt)
        if agent_key == "codex":
            context_parts.append(CODEX_CONTEXT_DISCIPLINE)
        # Every client, every turn (requested: "I would like claude and codex
        # and every other agent to tell me it understand what i want before it
        # gets to work"). Claude gets this through --append-system-prompt
        # instead: measured, a line in the MESSAGE was obeyed on a trivial
        # question and ignored the moment there was real work to do, because
        # the system prompt telling it not to narrate outranked it. The other
        # clients have no system-prompt hook, so the message is the only way in.
        if agent_key != "claude":
            context_parts.append(ACK_BEFORE_WORK)
            context_parts.append(LIVE_MACHINE_WARNING)
        # What the user is looking at, sent by the app with the message. An
        # agent cannot see the window, so "the folder icon in the viewer"
        # meant nothing to it (requested: "I want it to be self aware... I
        # want it to know which tab is open"). One short line, and the app
        # sends nothing at all when no project view is open.
        view_context = clean_text(request.get("view_context"))
        if view_context:
            context_parts.append(view_context)
        # Codex records the first user message as the session's identity (the
        # title/preview that `codex resume` lists). Put the user's real prompt FIRST
        # for Codex so that identity is the prompt — not the injected
        # <session_context>/state preamble. Other agents keep context-first.
        if agent_key == "codex":
            # First AND last (v4.7.1). Codex names the session after its first
            # user message, so the prompt has to lead — but with ~700 words of
            # workbench instruction appended after it, the freshest thing read
            # before working was our rules, not the request. Precise asks ("hold
            # right click + tap left click") were getting rounded off. Repeat it
            # at the end so recency lands on the user's own words.
            message_parts = [visible_prompt, *context_parts]
            if context_parts and visible_prompt:
                message_parts.append(
                    "The request again, in the user's own words - this is the "
                    "task, and the wording matters:\n" + visible_prompt
                )
        else:
            message_parts = [*context_parts, visible_prompt]
        video_previews = generate_video_attachment_previews(active_session_id, attachments)
        preview_frame_paths = [
            frame
            for preview in video_previews
            for frame in preview.get("frames") or []
            if os.path.isfile(frame)
        ]
        backend_prompt = prompt_with_attachments(
            "\n\n".join(message_parts),
            [*attachments, *preview_frame_paths],
            video_previews,
        )
        created_at = now_iso()
        turn = {
            "id": str(uuid.uuid4()),
            "created_at": created_at,
            "status": "running",
            "prompt": visible_prompt,
            "model": launch_model,
            "effort": launch_effort,
            "items": [
                {
                    "type": "userMessage",
                    "content": [{"type": "text", "text": visible_prompt}],
                    "attachments": attachment_metadata(attachments),
                }
            ],
        }
        if attachments:
            turn["items"].append(
                {
                    "type": "fileChange",
                    "content": "Attached files:\n" + "\n".join(attachments),
                }
            )
        if video_previews:
            turn["items"].append(
                {
                    "type": "fileChange",
                    "tag": "video_preview",
                    "content": "Generated video preview frames:\n"
                    + "\n".join(
                        frame
                        for preview in video_previews
                        for frame in preview.get("frames") or []
                    ),
                }
            )
        if detachment:
            turn["items"].append(
                {
                    "type": "report",
                    "tag": "report",
                    "content": detachment["message"],
                }
            )
            emit({"type": "work", "kind": "report", "content": detachment["message"]})
        # Claim the turn slot BEFORE any persist (SESSION_TURN_CONTRACT.md §4):
        # a sender that loses the claim must not write anything — persisting
        # first left an orphan "running" turn on disk for the losing client.
        # The wedge risk that motivated the old late claim (a setup failure
        # leaving the slot held forever) is covered by the except below and by
        # the main finally, which both release the slot.
        with ACTIVE_LOCK:
            if active_session_id in ACTIVE_TURNS:
                emit({"type": "error", "message": "this session already has an active turn"})
                return
            with DELETED_SESSION_IDS_LOCK:
                if active_session_id in DELETED_SESSION_IDS:
                    emit({"type": "error", "message": "this session is being deleted"})
                    return
            ACTIVE_TURNS[active_session_id] = control

        assistant_item = {"type": "agentMessage", "text": ""}
        turn_started_at = time.monotonic()
        last_checkpoint = 0.0
        worker_job_id = clean_text(session.get("worker_job_id"))
        worker_job_error = ""
        try:
            session.setdefault("turns", []).append(turn)
            session["updated_at"] = created_at
            if worker_job_id:
                mark_worker_job_status(worker_job_id, "running")
            # Persist LAST: save_json is atomic (tmp + os.replace), so any
            # failure in this block leaves the on-disk session without the
            # new turn — no orphan "running" turn can be written.
            save_session(session)
        except Exception as error:
            with ACTIVE_LOCK:
                ACTIVE_TURNS.pop(active_session_id, None)
            emit({"type": "error", "message": f"could not start turn: {clean_text(error)}"})
            return

        def durable_emit(event):
            nonlocal last_checkpoint
            event_type = event.get("type")
            if event_type == "delta":
                if assistant_item not in turn["items"]:
                    turn["items"].append(assistant_item)
                # `replace` marks the first piece of a NEW assistant message,
                # and the authoritative final text. Appending it instead of
                # replacing glued consecutive replies together with no break at
                # all ("...touches them first.**Done so far:**"), because this
                # recorder was written when a turn emitted exactly one delta.
                # Live streaming made that assumption false.
                if event.get("replace"):
                    assistant_item["text"] = str(event.get("text") or "")
                else:
                    assistant_item["text"] += str(event.get("text") or "")
                if time.monotonic() - last_checkpoint >= 1.0:
                    session["updated_at"] = now_iso()
                    save_session(session)
                    last_checkpoint = time.monotonic()
            elif event_type == "work":
                content = clean_text(event.get("content"))
                if content:
                    kind = clean_text(event.get("kind")) or "system"
                    if len(content) > WORK_ITEM_PERSIST_MAX_CHARS:
                        content = spill_work_item_to_artifact(
                            active_session_id, turn.get("id"), kind, content
                        )
                        event = {**event, "content": content}
                    item_type = {
                        "command": "commandExecution",
                        "reasoning": "reasoning",
                        "fileChange": "fileChange",
                        "report": "report",
                        "worker": "report",
                        "worker_update": "report",
                        "worker_done": "report",
                    }.get(kind, "system")
                    item = {
                        "type": item_type,
                        "tag": kind,
                        "content": content,
                    }
                    # Persist structured file access (from claude_file_access)
                    # so per-session file-level traceability can aggregate it.
                    file_op = clean_text(event.get("file_op"))
                    file_path = clean_text(event.get("file_path"))
                    if file_op and file_path:
                        item["file_op"] = file_op
                        item["file_path"] = file_path
                    # Keep the command too, so a finished turn's steps still
                    # say what was run rather than "Ran a command".
                    shell_command = clean_text(event.get("command"))
                    if shell_command:
                        item["command"] = shell_command
                    turn["items"].append(item)
                    session["updated_at"] = now_iso()
                    # Throttled like `delta`: the item is already in memory and
                    # the turn's final save persists it. Saving per work event
                    # rewrote the whole session file (tens of MB on a long
                    # chat) for every single tool call.
                    if time.monotonic() - last_checkpoint >= 1.0:
                        save_session(session)
                        last_checkpoint = time.monotonic()
            elif event_type == "usage":
                turn["usage"] = {
                    "input_tokens": safe_int(event.get("input_tokens")),
                    "output_tokens": safe_int(event.get("output_tokens")),
                    "total_tokens": safe_int(event.get("total_tokens")),
                    "cache_creation_input_tokens": safe_int(
                        event.get("cache_creation_input_tokens") or 0,
                    ),
                    "cache_read_input_tokens": safe_int(
                        event.get("cache_read_input_tokens") or 0,
                    ),
                }
                # Carry the non-token figures through too, or a reloaded turn
                # loses them: the client-reported cost and the plan meter are
                # only ever reported once, on this event (v4.3.3).
                for extra in (
                    "reasoning_tokens",
                    "cost_usd",
                    "plan_used_percent",
                    "plan_delta_percent",
                ):
                    if event.get(extra) is not None:
                        turn["usage"][extra] = event.get(extra)
                if event.get("live"):
                    # Mid-turn running snapshot (Claude partial messages):
                    # keep it in turn["usage"] so a killed turn still shows
                    # its spend, but don't feed summed turn totals into the
                    # context meter or save the session twice a second.
                    emit(event)
                    return
                context_model = clean_text(
                    event.get("model")
                    or turn.get("model")
                    or launch_model
                    or (
                        session.get("backend", {}).get("model")
                        if isinstance(session.get("backend"), dict)
                        else ""
                    )
                )
                # Claude's result usage is cumulative billing across every API
                # message in this tool-heavy turn. `stream_claude` already updates
                # context from each per-message assistant event; using this total
                # here made one long turn falsely read 100% (for example, 9M cache
                # reads across a 1M window whose actual last call was only 172k).
                if agent_key != "claude" and update_context(
                    session, turn["usage"], context_model
                ):
                    emit({"type": "context", "context": session["context"]})
                session["updated_at"] = now_iso()
                if time.monotonic() - last_checkpoint >= 1.0:
                    save_session(session)
                    last_checkpoint = time.monotonic()
            emit(event)

        try:
            full_text, _model = run_turn(
                session,
                backend_prompt,
                launch_model,
                durable_emit,
                control,
            )
            if full_text and not assistant_item["text"]:
                assistant_item["text"] = full_text
                turn["items"].append(assistant_item)
            turn["status"] = "completed"
        except Exception as error:
            # The full traceback goes to the journal — "ERROR: int() argument
            # must be a string..." with no location cost a morning once.
            import traceback

            print(
                f"turn crashed for session {active_session_id}:\n"
                f"{traceback.format_exc()}",
                file=sys.stderr,
                flush=True,
            )
            message = clean_text(error) or "Backend error"
            turn["status"] = "cancelled" if control.cancel.is_set() else "error"
            worker_job_error = message
            error_text = "ERROR: " + message
            if assistant_item not in turn["items"]:
                turn["items"].append(assistant_item)
            if clean_text(assistant_item.get("text")):
                if error_text not in assistant_item["text"]:
                    assistant_item["text"] += "\n\n" + error_text
            else:
                assistant_item["text"] = error_text
            turn["items"].append({"type": "note", "text": error_text})
            emit({"type": "error", "message": message})
        finally:
            turn["duration_ms"] = int((time.monotonic() - turn_started_at) * 1000)
            turn["completed_at"] = now_iso()
            session["updated_at"] = turn["completed_at"]
            if worker_job_id:
                mark_worker_job_status(
                    worker_job_id,
                    "completed" if turn["status"] == "completed" else turn["status"],
                    worker_job_error,
                )
            try:
                prefs = memory_preferences()
                should_refresh, refresh_detail = should_refresh_project_state_after_turn(
                    session,
                    turn,
                    prefs,
                )
                if should_refresh:
                    # The note-taker's local-model call can block for up to
                    # 120s when Ollama is busy/slow (e.g. mid-inference on an
                    # unrelated chat — see stream_local_tool_agent, which
                    # doesn't hold _OLLAMA_INFERENCE_SEM). That used to sit
                    # inline here, so EVERY backend's turn — Claude, Codex,
                    # Ollama, anything — wouldn't emit "done" until this
                    # unrelated background task finished or timed out.
                    # Off the response path: AGENT_STATE.md still gets its
                    # update, just without holding up the turn the user is
                    # actually waiting on.
                    threading.Thread(
                        target=_background_refresh_project_state,
                        args=(session,),
                        daemon=True,
                    ).start()
                else:
                    append_debug_event(
                        "project_state_skip",
                        reason="turn_complete",
                        detail=refresh_detail,
                        session=clean_text(session.get("id")),
                    )
            except Exception as error:
                append_debug_event(
                    "project_state_skip",
                    reason="turn_complete",
                    detail=f"error: {clean_text(error)}",
                    session=clean_text(session.get("id")),
                )
            try:
                stage_handoff(session)
            except Exception:
                pass
            try:
                if native_thread_owned(session):
                    sync_native_title_from_session(session)
            except Exception as error:
                append_debug_event(
                    "native_title_sync_failed",
                    agent=agent_key,
                    session=active_session_id,
                    error=clean_text(error),
                )
            try:
                save_session(session)
                append_debug_event(
                    "turn_done",
                    scope="active",
                    status=turn["status"],
                    session=active_session_id,
                    elapsed_ms=turn["duration_ms"],
                )
            except Exception as error:
                # Disk full, permissions, anything: the turn slot MUST still
                # be released or this chat is wedged until a server restart.
                append_debug_event(
                    "turn_final_save_failed",
                    session=active_session_id,
                    error=clean_text(error),
                )
            finally:
                with ACTIVE_LOCK:
                    ACTIVE_TURNS.pop(active_session_id, None)
        emit({"type": "done", "turn_id": turn["id"], "status": turn["status"]})


NONTERMINAL_TURN_STATUSES = {"queued", "starting", "running", "in_progress"}


def reconcile_orphaned_turns():
    """Mark turns that were left mid-flight by a previous server process.

    Every backend CLI (Claude/Codex/Gemini/Ollama) runs as a child of this
    server, so when the server is restarted or crashes, those children die with
    it. Any turn still in a non-terminal state on disk can therefore never
    finish — but the UI keeps showing a 'Thinking…/Working…' spinner forever.
    This runs once at startup (when nothing is active yet, so a non-terminal
    status is provably stale) and resolves each such turn to 'interrupted' with a
    clear note, so the session shows a stopped state the user can re-send from.
    Returns the number of turns reconciled."""
    fixed = 0
    try:
        names = os.listdir(SESS_DIR)
    except OSError:
        return 0
    for name in names:
        if not name.endswith(".json"):
            continue
        session_id = name[:-5]
        path = os.path.join(SESS_DIR, name)
        try:
            with locked_sessions(session_id):
                session = load_json(path)
                if not isinstance(session, dict):
                    continue
                turns = session.get("turns")
                if not isinstance(turns, list) or not turns:
                    continue
                # EVERY unfinished turn, not just the newest. A turn only ends
                # up buried when the user sent again after one was orphaned, and
                # checking turns[-1] alone left those spinning forever — eight of
                # them on this machine, the oldest from June (v4.5.2).
                stale = [
                    turn
                    for turn in turns
                    if isinstance(turn, dict)
                    and clean_text(turn.get("status")) in NONTERMINAL_TURN_STATUSES
                ]
                if not stale:
                    continue
                for turn in stale[:-1]:
                    turn["status"] = "interrupted"
                    turn.setdefault("completed_at", now_iso())
                last = stale[-1]
                last["status"] = "interrupted"
                last.setdefault("completed_at", now_iso())
                items = last.get("items")
                if isinstance(items, list):
                    items.append({
                        "type": "system",
                        "tag": "interrupted",
                        "content": (
                            "Turn interrupted - the backend process ended before this turn "
                            "finished (server restart or crash). Re-send to continue."
                        ),
                    })
                session["updated_at"] = now_iso()
                save_session(session)
                worker_job_id = clean_text(session.get("worker_job_id"))
                if worker_job_id:
                    mark_worker_job_status(
                        worker_job_id,
                        "interrupted",
                        "backend restarted before the worker turn finished",
                    )
                fixed += len(stale)
        except (OSError, ValueError):
            pass
    return fixed


# How long to leave the server undisturbed after it starts listening, so the
# app's opening requests are answered before heavy background work begins.
#
# The app's whole launch burst — app-state, the session index, the project
# list, the file tree — measured 1.09s on this machine. Five seconds clears
# that with room for the first few clicks afterwards. Housekeeping has no
# deadline, so waiting costs nothing; running it too early costs a lot,
# because Python threads share one interpreter (the same burst took 2.96s
# with the passes running against it).
_STARTUP_QUIET_SECONDS = 5.0


def _start_background_work_after(delay, target):
    """Run `target` on a daemon thread once `delay` has passed."""

    def _runner():
        time.sleep(delay)
        target()

    threading.Thread(target=_runner, daemon=True).start()


def _run_startup_maintenance():
    """Housekeeping over stored sessions, run in the background (v4.3.3).

    These three passes read every session file on disk. Measured on a machine
    with 359 sessions (237MB): 5.3 seconds of work before the socket opened,
    of which repair_inflated_claude_contexts alone was 3.8s because it reads
    all of them in full, every start. The app cannot reach the bridge at all
    while that runs, so it was the single biggest thing standing between
    launching AWBN and using it.

    None of it is needed to answer a request — it repairs display records,
    reconciles turns left running by a crash, and refreshes Codex thread files
    for terminal resume. Backgrounding it is the same treatment model discovery
    already gets a few lines below, for the same reason.

    Safe to run alongside live requests: every write goes through
    save_session(), which takes a per-session lock and merges concurrent field
    updates, so a repair and an in-flight turn cannot clobber each other."""
    try:
        reconciled = reconcile_orphaned_turns()
        if reconciled:
            print(f"  reconciled {reconciled} orphaned turn(s) from a prior restart/crash")
        repaired_contexts = repair_inflated_claude_contexts(
            pace_every=20, pace_seconds=0.05
        )
        if repaired_contexts:
            print(f"  repaired {repaired_contexts} Claude session display/accounting record(s)")
        synced = sync_owned_codex_threads_for_terminal()
        if synced:
            print(f"  synced {synced} AWBN-owned Codex thread(s) for terminal resume")
    except Exception as error:  # noqa: BLE001 - housekeeping must never take the server down
        print(f"  startup maintenance skipped: {clean_text(error)}")


def main():
    bootstrap_next_config_dir()
    # Create the per-user token before the socket begins answering.  A clean
    # install's UI reads this file before its first protected request.
    bridge_auth_token()
    # Lock and worktree sweeps stay in front: together they are under 2ms, and
    # they clear stale locks that a starting session would otherwise trip over.
    swept_locks = sweep_orphaned_session_locks()
    if swept_locks:
        print(f"  removed {swept_locks} orphaned session lock file(s)")
    swept_worktrees = sweep_orphaned_worker_worktrees()
    if swept_worktrees:
        print(f"  removed {swept_worktrees} orphaned worker worktree(s)")
    atexit.register(close_all_persistent_custom_cli_sessions)
    atexit.register(close_all_claude_stream_sessions)
    atexit.register(close_all_ui_terminal_sessions)

    def _warm_model_discovery_cache():
        try:
            get_model_discovery_agents()
        except Exception as error:
            print(f"  model discovery warm-up skipped: {clean_text(error)}")

    # Backgrounded: this shells out to claude/codex/gemini --help, which
    # must never delay the server actually listening for requests. The
    # first /client/models call falls back to building it inline anyway if
    # this hasn't finished yet.
    # Both of these are heavy and CPU-bound — scanning ~275MB of client
    # binaries and ~237MB of stored sessions. Started immediately they starve
    # the first requests: measured 2026-07-30, the app's opening /app-state
    # took 4.70s with them running against 0.22s without. Python threads share
    # one interpreter, so "in the background" is not free.
    #
    # Letting the launch burst finish first costs nothing — the app fetches
    # models fire-and-forget and merges them when they arrive, and the
    # housekeeping is repair work with no deadline.
    _start_background_work_after(_STARTUP_QUIET_SECONDS, _warm_model_discovery_cache)
    _start_background_work_after(_STARTUP_QUIET_SECONDS, _run_startup_maintenance)
    print(f"awbench_server → http://{HOST}:{PORT}  (ollama={OLLAMA_BASE})")
    print(f"  sessions: {SESS_DIR}")
    try:
        ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
    except OSError as error:
        # v4.3.0 (beta): a taken port used to end in a raw traceback. Say what
        # happened in plain words, and tell an already-running copy apart from
        # a genuine port clash so a packaged launcher exits quietly.
        if getattr(error, "errno", None) != errno.EADDRINUSE:
            raise
        already_ours = False
        try:
            with urllib.request.urlopen(
                f"http://{HOST}:{PORT}/health", timeout=3
            ) as response:
                payload = json.loads(response.read().decode("utf-8", "replace"))
                already_ours = payload.get("app") == "agent-workbench-native"
        except Exception:  # noqa: BLE001
            already_ours = False
        if already_ours:
            print(
                "Agent Workbench Native is already running - using the copy "
                f"already listening on {HOST}:{PORT}."
            )
            return
        print(
            f"Port {PORT} on {HOST} is already in use by something else.\n"
            f"  Close whatever is using it, or start AWBN on another port:\n"
            f"    AWBENCH_PORT=8766 {os.path.basename(__file__)}"
        )
        raise SystemExit(1)


if __name__ == "__main__":
    main()
