"""New HTTP endpoints for AWBN's command-surface work (see AWBN_TERMINAL_REPLACEMENT_PLAN.md).

Registered into awbench_server's do_GET/do_POST dispatch via a small
fall-through dict, so the existing route ladder in awbench_server.py doesn't
keep growing for every new command. All Phase 1+ endpoints from the plan
attach here instead of being inserted into the 12k-line request handler.

Handlers import awbench_server lazily, inside the function body rather than
at module load time, because this module is imported near the top of
awbench_server.py (before awbench_server has finished defining its own
helpers) — a module-level `import awbench_server` here would be circular.
By the time a handler actually runs (a live HTTP request), the server has
long since finished starting up, so the deferred import is always safe.

Handler signature: (handler, parsed, request) -> None
  handler: the live Handler instance for this request — call
           handler._json(status, value) to respond.
  parsed:  urllib.parse.ParseResult of the request path (use
           urllib.parse.parse_qs(parsed.query) for GET query params).
  request: parsed JSON body dict for POST requests, or {} for GET.
"""

import threading

GET_HANDLERS = {}
POST_HANDLERS = {}

# Agents whose names this module is ever willing to place on a subprocess argv
# (e.g. `<agent> mcp list`). Anything else is rejected before it can reach a
# shell-less exec as argv[0].
_KNOWN_AGENTS = frozenset({"claude", "codex", "gemini"})

# Kanban board columns, in order. A session's phase is either explicit (set by
# dragging a card) or inferred client-side for display.
_KANBAN_PHASES = ("backlog", "planning", "implementing", "review", "done")

_PROJECT_TREE_MAX_ENTRIES = 1200
_PROJECT_TREE_MAX_DEPTH = 6
_PROJECT_PREVIEW_MAX_BYTES = 350_000
_AWBN_PROJECTS_DIR = "~/.local/share/agent-workbench-native/projects"
_PROJECT_DISCOVERY_BASES = (
    "~/Projects/Open Games",
    "~/Projects/Open Projects",
    # Where the one-evening builds live (auto clicker, adcap tools, widgets).
    "~/Projects/Scratch",
    "~/Projects",
    "~",
)
_PROJECT_DISCOVERY_MAX_ENTRIES = 800
_PROJECT_TREE_SKIP_DIRS = frozenset(
    {
        ".git",
        ".godot",
        ".hg",
        ".svn",
        ".dart_tool",
        ".next",
        ".nuxt",
        ".pytest_cache",
        ".ruff_cache",
        ".mypy_cache",
        ".tox",
        ".venv",
        "venv",
        "env",
        "__pycache__",
        "node_modules",
        "build",
        "dist",
        "target",
        ".gradle",
        ".idea",
        ".vscode",
        # v4.0.5: generated build caches that flooded the 1200-entry cap
        # (reported: a Svelte app's All view was "truncated 1200" — .svelte-kit
        # alone contributes thousands of generated files).
        ".svelte-kit",
        ".parcel-cache",
        ".turbo",
        ".cache",
        ".output",
        "coverage",
    }
)
_PROJECT_CODE_SKIP_DIRS = _PROJECT_TREE_SKIP_DIRS | frozenset(
    {
        ".agent-workbench",
        ".agents",
        ".cache",
        ".claude",
        ".codex",
        ".gemini",
        "coverage",
        "log",
        "logs",
        "temp",
        "tmp",
    }
)
_PROJECT_CODE_FILE_SUFFIXES = (
    ".bash",
    ".c",
    ".cc",
    ".cfg",
    ".conf",
    ".cpp",
    ".cs",
    ".css",
    ".dart",
    ".env",
    ".fish",
    ".gd",
    ".gdextension",
    ".gdnlib",
    ".gdns",
    ".gdshader",
    ".gdshaderinc",
    ".go",
    ".godot",
    ".h",
    ".hpp",
    ".html",
    ".ini",
    ".java",
    ".js",
    ".jsx",
    ".kt",
    ".kts",
    ".less",
    ".php",
    ".ps1",
    ".py",
    ".pyi",
    ".rb",
    ".rs",
    ".sass",
    ".scss",
    ".sh",
    ".sql",
    ".svelte",
    ".swift",
    ".toml",
    ".tres",
    ".ts",
    ".tscn",
    ".tsx",
    ".vue",
    ".xml",
    ".yaml",
    ".yml",
    ".zsh",
)
_PROJECT_CODE_EXACT_FILES = frozenset(
    {
        "cmakelists.txt",
        "dockerfile",
        "gemfile",
        "justfile",
        "license",
        "makefile",
        "procfile",
        "rakefile",
        # Structural JSON stays in Code even though data .json (caches,
        # facts dumps) moved out in v4.0.4 — these ARE app structure.
        "package.json",
        "tsconfig.json",
        "composer.json",
        "project.json",
    }
)
# v4.0.4 (reported: "what's ACTUAL app code... and what's actual ai words"):
# Code = real program/structure files only; Docs = the written words
# (.md plans, prompts, notes); All = everything. Data .json and .md left
# the Code bucket for their own homes.
_PROJECT_DOCS_FILE_SUFFIXES = (".md", ".markdown", ".txt", ".rst", ".adoc")


def _project_file_visible(mode, name, path=""):
    if mode == "all":
        return True
    lowered = str(name or "").lower()
    # v4.3.5 (reported: "even though it did that work....i dont see it"): an
    # agent had just written three ship PNGs and none of them appeared. Code
    # filters images out, Docs is words, and All buries them among 1200
    # entries — so pictures a project produces had nowhere to be seen. Images
    # is their own view.
    if mode == "images":
        import awbench_server as srv

        return srv.ui_is_image_path(lowered)
    if mode == "docs":
        return lowered.endswith(_PROJECT_DOCS_FILE_SUFFIXES) or lowered in {
            "license",
            "readme",
        }
    # mode == "code"
    if lowered in _PROJECT_CODE_EXACT_FILES:
        return True
    if lowered.startswith(("license.", "requirements")):
        return True
    if lowered.endswith((".gd.uid", ".import")):
        return True
    if lowered.endswith(_PROJECT_CODE_FILE_SUFFIXES):
        return True
    # v4.0.3 (reported: "is there no actual code to AWBN? why can't I see
    # it?"): an extensionless file that starts with a shebang IS code —
    # e.g. the OG workbench's whole program is a single file literally
    # named `agent-workbench`, which the suffix list can never match.
    if path and "." not in lowered:
        try:
            with open(path, "rb") as fh:
                return fh.read(2) == b"#!"
        except OSError:
            return False
    return False


def get(path):
    """Decorator: register a GET handler for `path`."""

    def register(fn):
        GET_HANDLERS[path] = fn
        return fn

    return register


def post(path):
    """Decorator: register a POST handler for `path`."""

    def register(fn):
        POST_HANDLERS[path] = fn
        return fn

    return register


# Phase 1+ endpoints register themselves here, e.g.:
#
# @get("/mcp/list")
# def _mcp_list(handler, parsed, request):
#     import awbench_server as srv
#     handler._json(200, {"ok": True, "servers": []})
#
# @post("/session/reset-context")
# def _reset_context(handler, parsed, request):
#     import awbench_server as srv
#     session_id = srv.clean_text(request.get("session_id"))
#     ...
#     handler._json(200, {"ok": True})


# ---------------------------------------------------------------------------
# Terminal-replacement plan, Phase 2 — context reset + context stats
# ---------------------------------------------------------------------------


@post("/session/reset-context")
def _reset_context(handler, parsed, request):
    """New chat without deleting the session/tab (claude `/clear`, codex
    `/new`, gemini `/clear`). Drops the agent's native thread linkage so the
    NEXT turn starts a fresh context, while keeping the AWBN session, its title,
    its transcript history, and its tab exactly where they are.
    """
    import awbench_server as srv

    session_id = srv.clean_text(request.get("session_id"))
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    # Stop any in-flight turn BEFORE mutating session state, mirroring
    # ui_delete_session — otherwise a live turn keeps writing to the stream and
    # backend fields we're about to reset, corrupting the fresh context.
    with srv.ACTIVE_LOCK:
        control = srv.ACTIVE_TURNS.get(session_id)
    if control:
        control.stop()
    try:
        with srv.locked_sessions(session_id):
            session = srv.load_session(session_id)
            agent = srv.clean_text(session.get("agent")).lower()
            backend = session.setdefault("backend", {})
            # Claude runs a resident stream-json process keyed by the session id;
            # tear it down so the next turn relaunches with a brand-new native id.
            srv.close_claude_stream_session(session_id)
            for key in ("session_id", "thread_id"):
                backend.pop(key, None)
            # Native-thread bookkeeping that would otherwise resume the old context.
            for key in (
                "native_thread_owned",
                "native_cwd",
                "last_state_inject_hash",
            ):
                session.pop(key, None)
            session["context"] = {
                "compact_count": int(
                    (session.get("context") or {}).get("compact_count") or 0
                )
            }
            session["updated_at"] = srv.now_iso()
            srv.save_session(session)
        srv.append_debug_event("session_reset_context", session=session_id, agent=agent)
        handler._json(200, {"ok": True, "session": srv.session_event_payload(session)})
    except Exception as error:  # noqa: BLE001 - surface as JSON, never 500-crash
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


@get("/session/context-stats")
def _context_stats(handler, parsed, request):
    """Context-window fill for the session (claude `/context`, codex `/status`,
    gemini `/stats`). Claude's is maintained live on session['context']; codex's
    is recomputed from the thread rollout on demand (the exec stream never
    reports the window). Gemini exposes no context telemetry — honest empty."""
    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    session_id = srv.clean_text((query.get("session_id") or [""])[0])
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    try:
        session = srv.load_session(session_id)
    except Exception as error:  # noqa: BLE001
        handler._json(404, {"ok": False, "error": srv.clean_text(error)})
        return
    agent = srv.clean_text(session.get("agent")).lower()
    backend = session.get("backend") or {}
    if agent == "codex":
        try:
            srv.update_codex_context_from_rollout(session, backend)
        except Exception:  # noqa: BLE001 - best-effort refresh
            pass
    context = session.get("context") or {}
    available = agent in {"claude", "codex"} and bool(context)
    handler._json(
        200,
        {
            "ok": True,
            "agent": agent,
            "available": available,
            "context": context,
            "turn_count": len(session.get("turns") or []),
        },
    )


# ---------------------------------------------------------------------------
# Terminal-replacement plan, Phase 3 — read-only inspection
# ---------------------------------------------------------------------------


def _run_read_only(cmd, cwd=None, timeout=12, strip=True):
    """Run a short read-only subprocess with the workbench's resolved PATH.
    Returns (ok, combined_output). Never raises, always bounded by *timeout* so
    an inspection endpoint can't hang the request the way an MCP init can.

    *strip* defaults True for display use; pass strip=False for column-sensitive
    output like `git status --porcelain`, whose first line begins with a
    significant leading space that a blob-level strip would silently eat."""
    import subprocess

    import awbench_server as srv

    env = srv.subprocess_env()
    resolved = srv.resolve_command_executable(list(cmd), env)
    try:
        result = subprocess.run(
            resolved,
            cwd=cwd or None,
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError:
        return False, f"{cmd[0]}: not installed"
    except subprocess.TimeoutExpired:
        return False, f"{cmd[0]}: timed out after {timeout}s"
    except OSError as error:
        return False, f"{cmd[0]}: {error}"
    out = (result.stdout or "") + (result.stderr or "")
    return result.returncode == 0, (out.strip() if strip else out)


def _project_root_for_session(srv, session_id):
    import os

    session_id = srv.clean_text(session_id)
    if not session_id:
        raise RuntimeError("missing session_id")
    session = srv.load_session(session_id)
    raw_root = srv.clean_text(srv.infer_project_root(session, session.get("cwd")))
    if not raw_root:
        raise RuntimeError("no project root for this session")
    root = os.path.realpath(os.path.abspath(os.path.expanduser(raw_root)))
    if not os.path.isdir(root):
        raise RuntimeError("no project root for this session")
    return session, root


def _project_root_for_reference(
    srv,
    *,
    project_id="",
    root="",
    session_id="",
):
    project_ref = srv.clean_text(project_id) or srv.clean_text(root)
    if project_ref:
        return _find_project_by_id_or_root(srv, project_ref)
    _session, session_root = _project_root_for_session(srv, session_id)
    return session_root


def _safe_project_child_path(srv, root, raw_path):
    import os

    root = os.path.realpath(os.path.abspath(os.path.expanduser(srv.clean_text(root))))
    value = srv.clean_text(raw_path)
    if not value:
        raise RuntimeError("missing path")
    if os.path.isabs(value):
        candidate = os.path.abspath(os.path.expanduser(value))
    else:
        candidate = os.path.abspath(os.path.join(root, value))
    resolved = os.path.realpath(candidate)
    try:
        if os.path.commonpath([root, resolved]) != root:
            raise RuntimeError("path is outside this project")
    except ValueError as error:
        raise RuntimeError("path is outside this project") from error
    if os.path.normcase(candidate) != os.path.normcase(resolved):
        raise RuntimeError("symlink preview is not supported")
    return resolved


def _git_status_for_project(root):
    ok, out = _run_read_only(
        ["git", "-C", root, "status", "--porcelain=v1"],
        cwd=root,
        timeout=10,
        strip=False,
    )
    if not ok:
        return {}
    statuses = {}
    for raw in out.splitlines():
        line = raw.rstrip("\r")
        if len(line) < 4:
            continue
        status = line[:2].strip()
        path = line[3:].strip()
        if " -> " in path:
            _old, _arrow, path = path.partition(" -> ")
        if len(path) >= 2 and path[0] == path[-1] == '"':
            path = path[1:-1]
        if path:
            statuses[path] = status or "M"
    return statuses


def _project_slug(value):
    import re

    slug = re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")
    return slug or "project"


# Folder names are slugs; project lists are read by a person. Humanize only a
# name derived from a folder. A display name the user typed is never rewritten.
_PROJECT_NAME_ACRONYMS = {
    "ai", "api", "cli", "css", "db", "gpu", "html", "id", "io", "js", "json",
    "jrpg", "mcp", "npc", "os", "pc", "rpg", "sdk", "svg", "ui", "ux", "url",
    "vr", "x11", "2d", "3d", "fps", "hud", "tv", "pdf", "png", "jpg", "yaml",
}


def _pretty_project_name(raw):
    text = (raw or "").strip()
    if not text:
        return text
    # Already written for humans (has a space), or a deliberate single word.
    # Only multi-word slugs get humanized.
    if " " in text or not any(sep in text for sep in ("-", "_")):
        return text
    words = [w for w in text.replace("_", "-").replace(".", "-").split("-") if w]
    if not words:
        return text
    pretty = []
    for word in words:
        lowered = word.lower()
        if lowered in _PROJECT_NAME_ACRONYMS:
            pretty.append(lowered.upper())
        elif word.isupper():
            pretty.append(word)
        elif any(c.isupper() for c in word[1:]):
            pretty.append(word)  # Preserve deliberate camelCase.
        else:
            pretty.append(lowered.capitalize())
    return " ".join(pretty)


def _looks_auto_named(name, root):
    """True when this project's name is just its folder slug, untouched."""
    import os

    base = os.path.basename(root.rstrip(os.sep))
    return bool(name) and name == base and ("-" in base or "_" in base)


def _project_registry_config(srv):
    config = srv.load_json(srv.CONFIG_FILE, {}) or {}
    if not isinstance(config, dict):
        config = {}
    projects = config.get("projects")
    if not isinstance(projects, dict):
        projects = {}
        config["projects"] = projects
    return config, projects


def _is_free_chat_root(srv, root):
    import os

    clean = os.path.realpath(
        os.path.abspath(os.path.expanduser(srv.clean_text(root) or "~"))
    )
    home = os.path.realpath(os.path.abspath(os.path.expanduser("~")))
    return clean in {"", "/", home}


def _normalize_project_root(srv, root, *, create=False):
    import os

    value = srv.clean_text(root)
    if not value:
        raise RuntimeError("missing project root")
    root = os.path.realpath(os.path.abspath(os.path.expanduser(value)))
    if create:
        os.makedirs(root, exist_ok=True)
    if not os.path.isdir(root):
        raise RuntimeError(f"project directory does not exist: {root}")
    return root


def _project_marker_paths(srv, root):
    import os

    metadata_dir = os.path.join(root, srv.PROJECT_REGISTRY_DIRNAME)
    marker = os.path.join(
        root,
        srv.PROJECT_REGISTRY_DIRNAME,
        srv.PROJECT_REGISTRY_FILENAME,
    )
    return metadata_dir, marker


def _validate_project_marker_storage(srv, root):
    import os

    metadata_dir, marker = _project_marker_paths(srv, root)
    if os.path.lexists(metadata_dir):
        if os.path.islink(metadata_dir) or not os.path.isdir(metadata_dir):
            raise RuntimeError(
                f"refusing unsafe project metadata directory: {metadata_dir}"
            )
    if os.path.lexists(marker):
        if os.path.islink(marker) or not os.path.isfile(marker):
            raise RuntimeError(f"refusing unsafe project marker: {marker}")
    return metadata_dir, marker


def _read_project_marker(srv, root, *, strict=False):
    import os

    _metadata_dir, marker = _project_marker_paths(srv, root)
    try:
        _validate_project_marker_storage(srv, root)
    except RuntimeError:
        if strict:
            raise
        return marker, {}
    data = srv.load_json(marker, {}) if os.path.isfile(marker) else {}
    return marker, data if isinstance(data, dict) else {}


def _project_id(srv, root, project=None, marker=None):
    project = project if isinstance(project, dict) else {}
    marker = marker if isinstance(marker, dict) else {}
    return (
        srv.clean_text(marker.get("project_id"))
        or srv.clean_text(project.get("project_id"))
        or srv.clean_text(project.get("id"))
        or srv.clean_text(marker.get("id"))
        or srv.project_registry_id(root)
    )


def _registered_project_matches(srv, projects, root):
    matches = []
    for key, value in projects.items():
        if not isinstance(value, dict):
            continue
        raw_root = srv.clean_text(value.get("root")) or srv.clean_text(key)
        try:
            candidate = _normalize_project_root(srv, raw_root)
        except RuntimeError:
            continue
        if candidate == root:
            matches.append((key, value))
    return matches


def _discovered_project_markers(srv):
    import os

    discovered = {}
    inspected = 0
    seen_bases = set()
    for raw_base in _PROJECT_DISCOVERY_BASES:
        base = os.path.realpath(os.path.abspath(os.path.expanduser(raw_base)))
        if base in seen_bases or not os.path.isdir(base):
            continue
        seen_bases.add(base)
        try:
            children = os.scandir(base)
        except OSError:
            continue
        with children:
            for child in children:
                if inspected >= _PROJECT_DISCOVERY_MAX_ENTRIES:
                    return discovered
                inspected += 1
                try:
                    if child.is_symlink() or not child.is_dir(follow_symlinks=False):
                        continue
                except OSError:
                    continue
                root = os.path.realpath(child.path)
                if _is_free_chat_root(srv, root):
                    continue
                _marker_path, marker = _read_project_marker(srv, root)
                if not marker:
                    continue
                discovered[root] = marker
    return discovered


def _managed_project_root_for_name(srv, name):
    import os

    base = os.path.abspath(os.path.expanduser(_AWBN_PROJECTS_DIR))
    os.makedirs(base, exist_ok=True)
    slug = _project_slug(name)
    root = os.path.join(base, slug)
    if not os.path.exists(root):
        return root
    index = 2
    while True:
        candidate = os.path.join(base, f"{slug}-{index}")
        if not os.path.exists(candidate):
            return candidate
        index += 1


def _write_project_marker(srv, root, project):
    marker, existing = _read_project_marker(srv, root, strict=True)
    project_id = _project_id(srv, root, project, existing)
    display_name = (
        srv.clean_text(project.get("name"))
        or srv.clean_text(existing.get("display_name"))
        or srv.project_label(root)
    )
    aliases = existing.get("aliases")
    if isinstance(aliases, str):
        aliases = [aliases]
    elif not isinstance(aliases, list):
        aliases = []
    aliases = [srv.clean_text(value) for value in aliases if srv.clean_text(value)]
    if display_name not in aliases:
        aliases.append(display_name)
    data = {
        **existing,
        "schema": existing.get("schema") or 1,
        "project_id": project_id,
        "display_name": display_name,
        "root": root,
        "state_file": srv.clean_text(existing.get("state_file"))
        or srv.project_state_path(root),
        "aliases": aliases,
        "related_roots": existing.get("related_roots", []),
        "clients": existing.get("clients", {}),
        "managed_by": srv.clean_text(existing.get("managed_by"))
        or "agent-workbench-native",
        "created_at": srv.clean_text(existing.get("created_at"))
        or srv.clean_text(project.get("created_at")),
        "updated_at": srv.clean_text(project.get("updated_at")),
    }
    # `id` was emitted by an early project-browser draft, while every existing
    # project-state consumer uses the schema-1 `project_id` field.
    data.pop("id", None)
    srv.save_json(marker, data)


def _remember_project(srv, root, *, name="", managed=False):
    import os

    root = _normalize_project_root(srv, root)
    _marker_path, marker = _read_project_marker(srv, root, strict=True)
    config, projects = _project_registry_config(srv)
    now = srv.now_iso()
    matches = _registered_project_matches(srv, projects, root)
    existing = max(
        (value for _key, value in matches),
        key=lambda value: srv.clean_text(value.get("updated_at")),
        default={},
    )
    project_id = _project_id(srv, root, existing, marker)
    project = {
        **existing,
        "id": project_id,
        "project_id": project_id,
        "name": srv.clean_text(name)
        or srv.clean_text(existing.get("name"))
        or srv.clean_text(marker.get("display_name"))
        or srv.project_label(root),
        "root": root,
        "managed": any(bool(value.get("managed")) for _key, value in matches)
        or marker.get("managed") is True
        or bool(managed),
        "created_at": srv.clean_text(existing.get("created_at"))
        or srv.clean_text(marker.get("created_at"))
        or now,
        "updated_at": now,
    }
    for key, _value in matches:
        projects.pop(key, None)
    projects[root] = project
    recent = config.get("recent_projects")
    if not isinstance(recent, list):
        recent = []
    normalized_recent = []
    for item in recent:
        try:
            candidate = _normalize_project_root(srv, item)
        except RuntimeError:
            continue
        if candidate != root and candidate not in normalized_recent:
            normalized_recent.append(candidate)
    recent = [root, *normalized_recent]
    config["recent_projects"] = recent[:25]
    srv.save_json(srv.CONFIG_FILE, config)
    try:
        if os.access(root, os.W_OK):
            _write_project_marker(srv, root, project)
    except OSError:
        pass
    return project


_PROJECT_COUNT_CACHE = {"signature": None, "value": None}
_PROJECT_COUNT_LOCK = threading.Lock()


def _project_session_counts(srv):
    """How many chats each project has, and its newest one.

    Cached against the sessions folder's own fingerprint — the same one the
    session list uses (v4.3.3). This walks every session record and summarises
    it: 0.147s cold, and it was the entire cost of drawing the project list.
    Between edits none of it changes, so it is computed once per change to
    the folder rather than once per request."""
    signature = srv._session_dir_signature()
    with _PROJECT_COUNT_LOCK:
        cached = _PROJECT_COUNT_CACHE
        if cached["signature"] == signature and cached["value"] is not None:
            return cached["value"]
    contributions = _project_contributions(srv)
    value = _fold_project_contributions(contributions)
    with _PROJECT_COUNT_LOCK:
        _PROJECT_COUNT_CACHE["signature"] = signature
        _PROJECT_COUNT_CACHE["value"] = value
    _persist_project_contributions(srv, contributions)
    return value


def _project_count_cache_file(srv):
    import os

    return os.path.join(srv.CONFIG_DIR, "project-counts.json")


def _project_contributions(srv):
    """What each session file contributes to the project counts, by file.

    Same shape as the session list's per-file map, and for the same reason:
    without it, a restart after any activity re-read and re-summarised all 360
    stored records just to count chats per project — 0.16s before the project
    list could be drawn. `None` means "this file counts toward nothing", which
    is an answer worth keeping too."""
    saved = _load_persisted_project_contributions(srv)
    stamps = srv._session_file_stamps()
    out = {}
    for path, stamp in stamps.items():
        known = saved.get(path)
        if isinstance(known, dict) and known.get("stamp") == stamp:
            out[path] = known
            continue
        session = srv.load_session_record(path)
        out[path] = {"stamp": stamp, "entry": _project_contribution(srv, path, session)}
    return out


def _project_contribution(srv, path, session):
    if session is None or session.get("project_chat") is not True:
        return None
    try:
        summary = srv.ui_session_summary_cached(path, session)
    except Exception:  # noqa: BLE001
        return None
    if summary.get("is_worker"):
        return None
    try:
        root = _normalize_project_root(srv, srv.clean_text(summary.get("project_root")))
    except RuntimeError:
        return None
    if _is_free_chat_root(srv, root):
        return None
    return {
        "root": root,
        "session_id": srv.clean_text(summary.get("id")),
        "title": srv.clean_text(summary.get("title")),
        "updated_at": srv.clean_text(summary.get("updated_at"))
        or srv.clean_text(summary.get("created_at")),
    }


def _fold_project_contributions(contributions):
    counts = {}
    latest = {}
    for record in contributions.values():
        entry = record.get("entry") if isinstance(record, dict) else None
        if not isinstance(entry, dict):
            continue
        root = entry["root"]
        counts[root] = counts.get(root, 0) + 1
        current = latest.get(root)
        if not current or entry["updated_at"] > current.get("updated_at", ""):
            latest[root] = {
                "session_id": entry["session_id"],
                "title": entry["title"],
                "updated_at": entry["updated_at"],
            }
    return counts, latest


def _load_persisted_project_contributions(srv):
    raw = srv.load_json(_project_count_cache_file(srv), {}) or {}
    files = raw.get("files") if isinstance(raw, dict) else None
    return files if isinstance(files, dict) else {}


def _persist_project_contributions(srv, contributions):
    try:
        srv.save_json(_project_count_cache_file(srv), {"files": contributions})
    except OSError:
        pass


# --- Which project does a message belong to? ------------------------------
# A project chat is scoped to one folder, but a message meant for another
# project reads perfectly normally: "the number meter is too long, truncate
# the dollar amount" names no project at all. A flat keyword list cannot
# solve this — "meter" belongs to one project and appears in ten. So each
# project earns a vocabulary from its OWN files, every term is weighted by
# how RARE it is across all projects, and the app compares the score of the
# chat you are in against every other project. Only a clearly better match
# elsewhere is worth interrupting for.

_VOCAB_STOPWORDS = frozenset("""
about after all also and any are but can code com data dev did doc docs does
each else feat file files for from get gets git had has have here how http
https index init into is it its just lib like main make makes max may min
more most new nil not now null off old one only org our out own py app apps
run runs same set sets should since some src still such test tests than that
the their them then there these they this those through to too true try type
types use used user uses using was way we were what when where which while
who why will with work works would you your
""".split())

_VOCAB_MAX_TERMS = 60
_VOCAB_MIN_LEN = 3


def _vocab_split(text):
    """Words from a path or heading: splits separators AND camelCase."""
    import re

    pieces = re.split(r"[^A-Za-z0-9]+", text or "")
    words = []
    for piece in pieces:
        if not piece:
            continue
        # fooBarBaz / HTTPServer -> foo Bar Baz / HTTP Server
        for word in re.findall(r"[A-Z]+(?![a-z])|[A-Z][a-z0-9]*|[a-z0-9]+", piece):
            lowered = word.lower()
            if len(lowered) < _VOCAB_MIN_LEN or lowered.isdigit():
                continue
            if lowered in _VOCAB_STOPWORDS:
                continue
            words.append(lowered)
    return words


def _project_term_counts(srv, root, max_entries=1200):
    """How often each term appears in this project's names and headings.

    Reads names, not file bodies — cheap, and names are where a project's
    distinctive words live. The README's headings and opening lines are the
    one body text worth reading, because that is where a project describes
    itself in the owner's own words.
    """
    import os

    counts = {}

    def add(text, weight=1):
        for word in _vocab_split(text):
            counts[word] = counts.get(word, 0) + weight

    add(os.path.basename(root.rstrip(os.sep)), weight=6)
    seen = 0
    for current, dirs, files in os.walk(root):
        dirs[:] = [
            d for d in dirs
            if d not in _PROJECT_CODE_SKIP_DIRS and not d.startswith(".")
        ]
        rel = os.path.relpath(current, root)
        if rel != ".":
            add(rel, weight=2)
        for name in files:
            if name.startswith("."):
                continue
            seen += 1
            if seen > max_entries:
                break
            add(os.path.splitext(name)[0])
            # v4.7.1: names alone were not enough. A project's subject often
            # never appears in a filename — The Pig Farm is about SpaceX, and
            # "spacex" is in four of its documents but no file is called that,
            # so asking about it inside another project's chat sailed through.
            # Markdown is where a project describes itself in the owner's own
            # words, so every .md is read (capped), not just the README.
            if name.lower().endswith((".md", ".txt")) or name.lower() in {
                "readme", "current_state.md"
            }:
                try:
                    with open(
                        os.path.join(current, name), "r", encoding="utf-8", errors="ignore"
                    ) as handle:
                        add(handle.read(6000), weight=1)
                except OSError:
                    pass
        if seen > max_entries:
            break
    return counts


def project_vocabularies(srv, roots):
    """{root: {term: weight}} — each term weighted by how rare it is.

    A word in most projects ("window", "test", "config") carries almost no
    weight; a word in one ("adcap", "chord", "godot") carries a lot. That
    single rule is what keeps ordinary English from setting the guard off.
    """
    import math

    per_root = {root: _project_term_counts(srv, root) for root in roots}
    total = len(per_root) or 1
    doc_freq = {}
    for counts in per_root.values():
        for term in counts:
            doc_freq[term] = doc_freq.get(term, 0) + 1
    vocab = {}
    for root, counts in per_root.items():
        scored = {}
        for term, count in counts.items():
            rarity = math.log((total + 1) / (doc_freq.get(term, 1) + 0.5))
            if rarity <= 0:
                continue
            scored[term] = round(math.log(1 + count) * rarity, 4)
        top = sorted(scored.items(), key=lambda kv: kv[1], reverse=True)
        vocab[root] = dict(top[:_VOCAB_MAX_TERMS])
    return vocab


_VOCAB_CACHE = {"signature": None, "vocab": {}}


def cached_project_vocabularies(srv, roots):
    """Vocabularies for these roots, rebuilt only when the set changes.

    Walking every project costs real time; the answer only shifts when a
    project is added or removed, so it is cached against the root list.
    """
    signature = tuple(sorted(roots))
    if _VOCAB_CACHE["signature"] != signature:
        _VOCAB_CACHE["vocab"] = project_vocabularies(srv, list(signature))
        _VOCAB_CACHE["signature"] = signature
    return _VOCAB_CACHE["vocab"]


def _project_payloads(srv):
    config, projects = _project_registry_config(srv)
    counts, latest = _project_session_counts(srv)
    registered = {}
    for key, value in projects.items():
        if not isinstance(value, dict):
            continue
        raw_root = srv.clean_text(value.get("root")) or srv.clean_text(key)
        try:
            root = _normalize_project_root(srv, raw_root)
        except RuntimeError:
            continue
        current = registered.get(root)
        if not current or srv.clean_text(value.get("updated_at")) > srv.clean_text(
            current.get("updated_at")
        ):
            registered[root] = value

    # One-time repair: older auto-named projects can carry a raw folder slug.
    # Rewrite only those; an explicit display name is never touched.
    repaired = False
    for root, value in registered.items():
        stored_name = srv.clean_text(value.get("name"))
        if not _looks_auto_named(stored_name, root):
            continue
        pretty = _pretty_project_name(stored_name)
        if pretty and pretty != stored_name:
            value["name"] = pretty
            repaired = True
    if repaired:
        srv.save_json(srv.CONFIG_FILE, config)

    discovered = _discovered_project_markers(srv)
    roots = set(registered)
    roots.update(discovered)

    recent_rank = {}
    recent = config.get("recent_projects")
    if isinstance(recent, list):
        for index, value in enumerate(recent):
            try:
                root = _normalize_project_root(srv, value)
            except RuntimeError:
                continue
            recent_rank.setdefault(root, len(recent) - index)

    vocab = cached_project_vocabularies(srv, sorted(roots))
    payloads = []
    for root in roots:
        project = registered.get(root) or {}
        marker = discovered.get(root)
        if marker is None:
            _marker_path, marker = _read_project_marker(srv, root)
        project_id = _project_id(srv, root, project, marker)
        project_updated = max(
            srv.clean_text(project.get("updated_at")),
            srv.clean_text(marker.get("updated_at")),
        )
        payloads.append(
            {
                "id": project_id,
                "project_id": project_id,
                "name": srv.clean_text(project.get("name"))
                or srv.clean_text(marker.get("display_name"))
                or srv.project_label(root),
                "root": root,
                "managed": project.get("managed") is True
                or marker.get("managed") is True,
                "created_at": srv.clean_text(project.get("created_at"))
                or srv.clean_text(marker.get("created_at")),
                "updated_at": project_updated,
                "chat_count": counts.get(root, 0),
                "latest_session": latest.get(root) or {},
                # This project's distinctive words, weighted by rarity. The
                # app scores an outgoing message against every project's
                # vocabulary and warns when another one clearly fits better.
                "vocabulary": vocab.get(root, {}),
            }
        )
    payloads.sort(
        key=lambda value: (
            srv.clean_text((value.get("latest_session") or {}).get("updated_at"))
            or srv.clean_text(value.get("updated_at")),
            recent_rank.get(value.get("root"), 0),
            srv.clean_text(value.get("name")).casefold(),
        ),
        reverse=True,
    )
    return payloads


def _find_project_by_id_or_root(srv, value):
    import os

    lookup = srv.clean_text(value)
    if not lookup:
        raise RuntimeError("missing project")
    expanded = os.path.abspath(os.path.expanduser(lookup))
    if os.path.isabs(lookup) or lookup.startswith("~") or os.path.isdir(expanded):
        return _normalize_project_root(srv, lookup)
    for project in _project_payloads(srv):
        if lookup in {
            srv.clean_text(project.get("id")),
            srv.clean_text(project.get("project_id")),
        }:
            return _normalize_project_root(srv, project.get("root"))
    return _normalize_project_root(srv, lookup)


def _next_project_chat_title(srv, root, name):
    """The next free "<project> N" for this project.

    Only used when the user does not type a name. A name they chose wins.
    """
    import os
    import re

    target = os.path.realpath(os.path.abspath(os.path.expanduser(root)))
    pattern = re.compile(rf"^{re.escape(name)}\s+(\d+)$")
    used = set()
    for _path, session in srv.local_session_records():
        if session.get("project_chat") is not True:
            continue
        theirs = srv.clean_text(session.get("project_root")) or srv.clean_text(
            session.get("cwd")
        )
        if not theirs:
            continue
        try:
            if os.path.realpath(os.path.abspath(os.path.expanduser(theirs))) != target:
                continue
        except OSError:
            continue
        match = pattern.match(srv.clean_text(session.get("title")))
        if match:
            used.add(int(match.group(1)))
    number = 1
    while number in used:
        number += 1
    return f"{name} {number}"


def _create_project_session(srv, root, project, request):
    agent = srv.clean_text(request.get("agent")) or "claude"
    model = srv.clean_text(request.get("model"))
    effort = srv.clean_text(request.get("effort")) or "Default"
    title = srv.clean_text(request.get("title")) or _next_project_chat_title(
        srv, root, srv.clean_text(project.get("name")) or srv.project_label(root)
    )
    session = srv.ui_create_session(
        agent,
        model,
        effort,
        root,
        title,
        validate_client=True,
    )
    with srv.locked_sessions(session["id"]):
        session = srv.load_session(session["id"])
        session["project_root"] = root
        session["project_id"] = srv.clean_text(project.get("id"))
        session["project_chat"] = True
        session["updated_at"] = srv.now_iso()
        srv.save_session(session)
    return session


def _project_file_payload(srv, root, path, is_dir, git_statuses=None):
    import os

    try:
        stat = os.stat(path)
        size = 0 if is_dir else int(stat.st_size)
        modified = int(stat.st_mtime)
    except OSError:
        size = 0
        modified = 0
    rel_path = os.path.relpath(path, root).replace(os.sep, "/")
    if rel_path == ".":
        rel_path = ""
    return {
        "name": os.path.basename(path) or srv.project_label(root),
        "path": path,
        "rel_path": rel_path,
        "depth": 0 if not rel_path else rel_path.count("/"),
        "is_dir": bool(is_dir),
        "size": size,
        "modified": modified,
        "is_image": False if is_dir else srv.ui_is_image_path(path),
        "is_text": False if is_dir else srv.ui_is_text_path(path),
        "git_status": (git_statuses or {}).get(rel_path, ""),
    }


def _project_files_payload(
    session_id="",
    max_depth=_PROJECT_TREE_MAX_DEPTH,
    *,
    project_id="",
    root="",
    mode="all",
):
    import os

    import awbench_server as srv

    root = _project_root_for_reference(
        srv,
        project_id=project_id,
        root=root,
        session_id=session_id,
    )
    try:
        max_depth = int(max_depth)
    except (TypeError, ValueError):
        max_depth = _PROJECT_TREE_MAX_DEPTH
    max_depth = max(1, min(max_depth, _PROJECT_TREE_MAX_DEPTH))
    mode = str(mode or "").strip().lower()
    if mode not in {"code", "docs", "all", "images"}:
        mode = "all"
    skip_dirs = (
        _PROJECT_CODE_SKIP_DIRS
        if mode in {"code", "docs", "images"}
        else _PROJECT_TREE_SKIP_DIRS
    )
    git_statuses = _git_status_for_project(root)
    entries = []
    truncated = False
    # Whether this project contains ANY picture at all — noted while walking,
    # BEFORE the mode filter, so it is true even in Code view where images are
    # hidden. The app shows its Art button only when this is true, so a project
    # with no pictures never offers a view of nothing (v4.4.0, requested: "can
    # we make the app smart enough to know if there are images within a
    # project or not? and it ONLY appears if there are").
    has_images = False

    def add_dir(path, depth):
        nonlocal truncated, has_images
        if len(entries) >= _PROJECT_TREE_MAX_ENTRIES:
            truncated = True
            return
        try:
            children = list(os.scandir(path))
        except OSError:
            return
        dirs = []
        files = []
        for child in children:
            try:
                if child.is_symlink():
                    continue
                if child.is_dir(follow_symlinks=False):
                    if child.name in skip_dirs:
                        continue
                    dirs.append(child)
                elif child.is_file(follow_symlinks=False):
                    if not has_images and srv.ui_is_image_path(child.name):
                        has_images = True
                    if not _project_file_visible(mode, child.name, child.path):
                        continue
                    files.append(child)
            except OSError:
                continue
        dirs.sort(key=lambda item: item.name.lower())
        files.sort(key=lambda item: item.name.lower())
        for child in [*dirs, *files]:
            if len(entries) >= _PROJECT_TREE_MAX_ENTRIES:
                truncated = True
                return
            is_dir = child.is_dir(follow_symlinks=False)
            entries.append(
                _project_file_payload(srv, root, child.path, is_dir, git_statuses)
            )
            if is_dir and depth + 1 < max_depth:
                add_dir(child.path, depth + 1)

    add_dir(root, 0)
    return {
        "ok": True,
        "root": root,
        "display_name": srv.project_label(root),
        "entries": entries,
        "truncated": truncated,
        "max_entries": _PROJECT_TREE_MAX_ENTRIES,
        "max_depth": max_depth,
        "mode": mode,
        # Fail open when the walk was cut short: the images may simply be past
        # the cap. Offering a view that turns out empty is a smaller wrong
        # than hiding pictures the project really has.
        "has_images": has_images or truncated,
    }


@get("/projects")
def _projects(handler, parsed, request):
    import awbench_server as srv

    try:
        handler._json(200, {"ok": True, "projects": _project_payloads(srv)})
    except Exception as error:  # noqa: BLE001
        handler._json(500, {"ok": False, "error": srv.clean_text(error)})


# What a folder must contain to be offered as a probable project, and the
# plain-words label the button shows for it. First hit wins.
_PROJECT_CANDIDATE_MARKERS = (
    ("project.godot", "Godot game"),
    ("pubspec.yaml", "Flutter app"),
    ("wrangler.toml", "Cloudflare worker"),
    ("Cargo.toml", "Rust project"),
    ("go.mod", "Go project"),
    ("pyproject.toml", "Python project"),
    ("requirements.txt", "Python project"),
    ("package.json", "Node / web app"),
    ("CMakeLists.txt", "C/C++ project"),
    (".git", "Git project"),
)


def _discover_project_candidates(srv):
    """Folders that look like projects but aren't registered yet.

    v4.6.5 (reported: "the create or register new project button isn't
    useful... couldn't it auto scan for what it thinks could be new projects
    and list them in clickable buttons?"). Same one-level scan over the same
    bases as marker discovery, but instead of requiring an AWBN marker it
    looks for the files real projects carry (a git folder, a Godot project
    file, a pubspec...). Anything already registered or already discovered
    is left out — this is only the NEW stuff.
    """
    import os

    known = set()
    _config, projects = _project_registry_config(srv)
    for key, value in projects.items():
        if not isinstance(value, dict):
            continue
        raw_root = srv.clean_text(value.get("root")) or srv.clean_text(key)
        try:
            known.add(_normalize_project_root(srv, raw_root))
        except RuntimeError:
            continue
    known.update(_discovered_project_markers(srv))

    candidates = []
    inspected = 0
    seen_bases = set()
    seen_roots = set()
    all_bases = {
        os.path.realpath(os.path.abspath(os.path.expanduser(raw)))
        for raw in _PROJECT_DISCOVERY_BASES
    }
    # Only ~/Projects gets the relaxed "loose scripts/README" rule. Applying
    # it to the whole home directory would sweep in unrelated user folders.
    # Only the curated project homes accept the loose "README / some scripts"
    # evidence. ~/Projects and ~ are containers, not project homes: relaxing
    # them offered "py", "ai_session_memory" and the Scratch folder itself as
    # if they were projects.
    relaxed_bases = {
        os.path.realpath(os.path.abspath(os.path.expanduser(raw)))
        for raw in (
            "~/Projects/Open Games",
            "~/Projects/Open Projects",
            "~/Projects/Scratch",
        )
    }
    skip_names = {
        "downloads", "documents", "desktop", "desktops", "pictures",
        "music", "videos", "public", "templates", "recent", "bin",
        "node_modules", "agent-docs",
    }
    for raw_base in _PROJECT_DISCOVERY_BASES:
        base = os.path.realpath(os.path.abspath(os.path.expanduser(raw_base)))
        if base in seen_bases or not os.path.isdir(base):
            continue
        seen_bases.add(base)
        relaxed = base in relaxed_bases
        try:
            children = os.scandir(base)
        except OSError:
            continue
        with children:
            for child in children:
                if inspected >= _PROJECT_DISCOVERY_MAX_ENTRIES:
                    break
                inspected += 1
                try:
                    if child.is_symlink() or not child.is_dir(
                        follow_symlinks=False
                    ):
                        continue
                except OSError:
                    continue
                if child.name.startswith(".") or child.name.startswith("_"):
                    continue
                if child.name.lower() in skip_names:
                    continue
                # Backup copies are not new projects.
                lowered = child.name.lower()
                if any(
                    word in lowered
                    for word in ("snapshot", "backup", ".bak", "quarantine")
                ):
                    continue
                root = os.path.realpath(child.path)
                if (
                    root in known
                    or root in seen_roots
                    or root in all_bases
                    or _is_free_chat_root(srv, root)
                ):
                    continue
                seen_roots.add(root)
                evidence = ""
                for marker_name, label in _PROJECT_CANDIDATE_MARKERS:
                    if os.path.exists(os.path.join(root, marker_name)):
                        evidence = label
                        break
                if not evidence and relaxed:
                    # No classic marker — a folder of loose scripts or one
                    # with its own README still counts.
                    if os.path.exists(os.path.join(root, "README.md")):
                        evidence = "Project folder"
                    else:
                        try:
                            entries = os.listdir(root)
                        except OSError:
                            entries = []
                        if any(
                            entry.endswith((".py", ".sh", ".html", ".js"))
                            for entry in entries[:200]
                        ):
                            evidence = "Scripts"
                if not evidence:
                    continue
                try:
                    modified = child.stat(follow_symlinks=False).st_mtime
                except OSError:
                    modified = 0.0
                candidates.append(
                    {
                        "name": _pretty_project_name(os.path.basename(root)),
                        "root": root,
                        "evidence": evidence,
                        "modified": modified,
                    }
                )
    candidates.sort(key=lambda item: item["modified"], reverse=True)
    return candidates[:30]


@get("/projects/discover")
def _projects_discover(handler, parsed, request):
    import awbench_server as srv

    try:
        handler._json(
            200,
            {"ok": True, "candidates": _discover_project_candidates(srv)},
        )
    except Exception as error:  # noqa: BLE001
        handler._json(500, {"ok": False, "error": srv.clean_text(error)})


@post("/projects/create")
def _projects_create(handler, parsed, request):
    import awbench_server as srv

    try:
        name = srv.clean_text(request.get("name")) or "Untitled Project"
        raw_root = srv.clean_text(request.get("root"))
        managed = not bool(raw_root)
        root = (
            _managed_project_root_for_name(srv, name)
            if managed
            else _normalize_project_root(srv, raw_root, create=request.get("create_dir") is True)
        )
        if managed:
            root = _normalize_project_root(srv, root, create=True)
        project = _remember_project(srv, root, name=name, managed=managed)
        projects = _project_payloads(srv)
        project_payload = next(
            (
                item
                for item in projects
                if srv.clean_text(item.get("id")) == srv.clean_text(project.get("id"))
            ),
            {**project, "chat_count": 0, "latest_session": {}},
        )
        handler._json(
            200,
            {
                "ok": True,
                "project": project_payload,
                "session": None,
                "projects": projects,
            },
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


@post("/projects/open")
def _projects_open(handler, parsed, request):
    import awbench_server as srv

    try:
        root = _find_project_by_id_or_root(
            srv,
            request.get("project_id") or request.get("root"),
        )
        project = _remember_project(
            srv,
            root,
            name=srv.clean_text(request.get("name")),
            managed=False,
        )
        session = None
        if request.get("new_chat") is True:
            session = _create_project_session(srv, root, project, request)
        handler._json(
            200,
            {
                "ok": True,
                "project": project,
                "session": srv.ui_session_summary(session) if session else None,
                "projects": _project_payloads(srv),
            },
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


@get("/project/files")
def _project_files(handler, parsed, request):
    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    session_id = srv.clean_text((query.get("session_id") or [""])[0])
    project_id = srv.clean_text((query.get("project_id") or [""])[0])
    root = srv.clean_text((query.get("root") or [""])[0])
    max_depth = srv.clean_text((query.get("max_depth") or [""])[0])
    mode = srv.clean_text((query.get("mode") or [""])[0])
    try:
        handler._json(
            200,
            _project_files_payload(
                session_id,
                max_depth=max_depth,
                project_id=project_id,
                root=root,
                mode=mode,
            ),
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


# --- Manual file edits from the viewer (worksheet #4 + restore points) ------
# The viewer is LOCKED by default. Unlocking lets the user type directly into
# a project file. Every manual save first snapshots the file's CURRENT bytes
# into the project's own .agent-workbench/manual-edit-backups/<digest>/, so
# the user can land on any earlier point instead of an all-or-nothing revert.
# `original.snap` is written once and NEVER pruned — "before I ever hand-edited
# this" is always reachable. Newer snapshots rotate at 20.
_MANUAL_EDIT_MAX_BYTES = 2_000_000
_MANUAL_EDIT_BACKUP_DIRNAME = "manual-edit-backups"
_MANUAL_EDIT_MAX_SNAPSHOTS = 20
_MANUAL_EDIT_ORIGINAL_ID = "original"


def _manual_edit_backup_dir(srv, root, path):
    import hashlib
    import os

    rel = os.path.relpath(path, root)
    digest = hashlib.sha256(rel.encode("utf-8")).hexdigest()[:16]
    return os.path.join(
        root, srv.PROJECT_REGISTRY_DIRNAME, _MANUAL_EDIT_BACKUP_DIRNAME, digest
    )


def _manual_edit_snapshot_path(backup_dir, snapshot_id):
    import os

    safe = "".join(ch for ch in str(snapshot_id) if ch.isalnum() or ch in "-_")
    if not safe:
        raise RuntimeError("bad restore point")
    return os.path.join(backup_dir, f"{safe}.snap")


def _manual_edit_snapshot_ids(backup_dir):
    """Newest first; the untouched original always last."""
    import os

    try:
        names = os.listdir(backup_dir)
    except OSError:
        return []
    ids = [name[:-5] for name in names if name.endswith(".snap")]
    rolling = sorted(
        (i for i in ids if i != _MANUAL_EDIT_ORIGINAL_ID), reverse=True
    )
    if _MANUAL_EDIT_ORIGINAL_ID in ids:
        rolling.append(_MANUAL_EDIT_ORIGINAL_ID)
    return rolling


def _manual_edit_capture(srv, root, path):
    """Snapshot the file's current bytes before it is overwritten."""
    import os
    import time

    if not os.path.isfile(path):
        return
    backup_dir = _manual_edit_backup_dir(srv, root, path)
    os.makedirs(backup_dir, exist_ok=True)
    with open(path, "rb") as source:
        current = source.read()
    original_path = _manual_edit_snapshot_path(backup_dir, _MANUAL_EDIT_ORIGINAL_ID)
    if not os.path.exists(original_path):
        with open(original_path, "wb") as target:
            target.write(current)
        return
    stamp = time.strftime("%Y%m%d-%H%M%S")
    snapshot_path = _manual_edit_snapshot_path(backup_dir, stamp)
    if os.path.exists(snapshot_path):
        return  # same second — the existing snapshot is equivalent
    with open(snapshot_path, "wb") as target:
        target.write(current)
    rolling = [
        i for i in _manual_edit_snapshot_ids(backup_dir)
        if i != _MANUAL_EDIT_ORIGINAL_ID
    ]
    for stale in rolling[_MANUAL_EDIT_MAX_SNAPSHOTS:]:
        try:
            os.unlink(_manual_edit_snapshot_path(backup_dir, stale))
        except OSError:
            pass


def _require_registered_project(srv, root):
    """Only folders AWBN actually knows as projects may be written through
    the viewer. Without this, any absolute path passed as `root` became a
    legal write target (audit finding, 2026-07-24)."""
    import os

    marker = os.path.join(root, srv.PROJECT_REGISTRY_DIRNAME, "project.json")
    if os.path.isfile(marker):
        return
    config = srv.load_json(srv.CONFIG_FILE, {}) or {}
    known = config.get("projects") if isinstance(config, dict) else {}
    if isinstance(known, dict):
        for candidate in known:
            if os.path.realpath(os.path.expanduser(candidate)) == root:
                return
    raise RuntimeError("that folder is not a registered project")


def _manual_edit_write(path, data):
    """Atomic replace that keeps the file's permissions — editing a 0755
    script in the viewer used to silently drop its executable bit."""
    import os
    import uuid

    mode = None
    try:
        mode = os.stat(path).st_mode
    except OSError:
        mode = None
    tmp_path = f"{path}.awbn-{uuid.uuid4().hex}.tmp"
    try:
        with open(tmp_path, "wb") as handle_out:
            handle_out.write(data)
            handle_out.flush()
            os.fsync(handle_out.fileno())
        if mode is not None:
            os.chmod(tmp_path, mode & 0o7777)
        os.replace(tmp_path, path)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass


def manual_edit_diff_summary(before_text, after_text):
    """(added, removed) line counts — drives the '+3 −1' restore-point label."""
    import difflib

    before = before_text.splitlines()
    after = after_text.splitlines()
    added = removed = 0
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(
        None, before, after
    ).get_opcodes():
        if tag in {"replace", "delete"}:
            removed += i2 - i1
        if tag in {"replace", "insert"}:
            added += j2 - j1
    return added, removed


def manual_edit_diff_lines(before_text, after_text, context=3):
    """Compact unified diff for the 'show what changed' preview."""
    import difflib

    rows = []
    for line in difflib.unified_diff(
        before_text.splitlines(),
        after_text.splitlines(),
        lineterm="",
        n=context,
    ):
        if line.startswith("+++") or line.startswith("---"):
            continue
        if line.startswith("@@"):
            rows.append({"type": "hunk", "text": line})
        elif line.startswith("+"):
            rows.append({"type": "add", "text": line[1:]})
        elif line.startswith("-"):
            rows.append({"type": "del", "text": line[1:]})
        else:
            rows.append({"type": "ctx", "text": line[1:] if line else ""})
    return rows[:600]


def _manual_edit_read_text(path):
    import os

    if not os.path.isfile(path):
        return ""
    with open(path, "rb") as handle_in:
        return handle_in.read().decode("utf-8", "replace")


def _manual_edit_snapshot_payload(srv, backup_dir, snapshot_id, current_text):
    import os
    import time

    snapshot_path = _manual_edit_snapshot_path(backup_dir, snapshot_id)
    text = _manual_edit_read_text(snapshot_path)
    added, removed = manual_edit_diff_summary(text, current_text)
    try:
        saved_at = time.strftime(
            "%Y-%m-%d %H:%M:%S", time.localtime(os.path.getmtime(snapshot_path))
        )
    except OSError:
        saved_at = ""
    return {
        "id": snapshot_id,
        "is_original": snapshot_id == _MANUAL_EDIT_ORIGINAL_ID,
        "saved_at": saved_at,
        "bytes": len(text.encode("utf-8")),
        "added": added,
        "removed": removed,
    }


@post("/project/file/save")
def _project_file_save(handler, parsed, request):
    import os

    import awbench_server as srv

    try:
        root = _project_root_for_reference(
            srv,
            project_id=srv.clean_text(request.get("project_id")),
            root=srv.clean_text(request.get("root")),
            session_id=srv.clean_text(request.get("session_id")),
        )
        _require_registered_project(srv, root)
        path = _safe_project_child_path(srv, root, request.get("path"))
        reason = srv.protected_local_path_reason(path)
        if reason:
            raise RuntimeError(reason)
        content = request.get("content")
        if not isinstance(content, str):
            raise RuntimeError("content must be text")
        encoded = content.encode("utf-8")
        if len(encoded) > _MANUAL_EDIT_MAX_BYTES:
            raise RuntimeError("file is too large to edit in the viewer")
        if os.path.isdir(path):
            raise RuntimeError("that is a folder")

        _manual_edit_capture(srv, root, path)
        _manual_edit_write(path, encoded)
        backup_dir = _manual_edit_backup_dir(srv, root, path)
        handler._json(
            200,
            {
                "ok": True,
                "path": path,
                "bytes": len(encoded),
                "revertable": bool(_manual_edit_snapshot_ids(backup_dir)),
            },
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


@get("/project/file/snapshots")
def _project_file_snapshots(handler, parsed, request):
    import urllib.parse

    import awbench_server as srv

    try:
        query = urllib.parse.parse_qs(parsed.query)
        root = _project_root_for_reference(
            srv,
            project_id=srv.clean_text((query.get("project_id") or [""])[0]),
            root=srv.clean_text((query.get("root") or [""])[0]),
            session_id=srv.clean_text((query.get("session_id") or [""])[0]),
        )
        path = _safe_project_child_path(srv, root, (query.get("path") or [""])[0])
        backup_dir = _manual_edit_backup_dir(srv, root, path)
        current_text = _manual_edit_read_text(path)
        snapshots = [
            _manual_edit_snapshot_payload(srv, backup_dir, snapshot_id, current_text)
            for snapshot_id in _manual_edit_snapshot_ids(backup_dir)
        ]
        handler._json(200, {"ok": True, "snapshots": snapshots})
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


@get("/project/file/diff")
def _project_file_diff(handler, parsed, request):
    """What changes if this restore point is applied: snapshot → current."""
    import urllib.parse

    import awbench_server as srv

    try:
        query = urllib.parse.parse_qs(parsed.query)
        root = _project_root_for_reference(
            srv,
            project_id=srv.clean_text((query.get("project_id") or [""])[0]),
            root=srv.clean_text((query.get("root") or [""])[0]),
            session_id=srv.clean_text((query.get("session_id") or [""])[0]),
        )
        path = _safe_project_child_path(srv, root, (query.get("path") or [""])[0])
        snapshot_id = srv.clean_text((query.get("id") or [""])[0])
        backup_dir = _manual_edit_backup_dir(srv, root, path)
        snapshot_text = _manual_edit_read_text(
            _manual_edit_snapshot_path(backup_dir, snapshot_id)
        )
        current_text = _manual_edit_read_text(path)
        added, removed = manual_edit_diff_summary(current_text, snapshot_text)
        handler._json(
            200,
            {
                "ok": True,
                "added": added,
                "removed": removed,
                "rows": manual_edit_diff_lines(current_text, snapshot_text),
            },
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


@post("/project/file/revert")
def _project_file_revert(handler, parsed, request):
    """Land on a restore point. Defaults to the untouched original. The
    pre-restore state is itself snapshotted first, so a restore is undoable."""
    import os

    import awbench_server as srv

    try:
        root = _project_root_for_reference(
            srv,
            project_id=srv.clean_text(request.get("project_id")),
            root=srv.clean_text(request.get("root")),
            session_id=srv.clean_text(request.get("session_id")),
        )
        _require_registered_project(srv, root)
        path = _safe_project_child_path(srv, root, request.get("path"))
        reason = srv.protected_local_path_reason(path)
        if reason:
            raise RuntimeError(reason)
        backup_dir = _manual_edit_backup_dir(srv, root, path)
        snapshot_id = srv.clean_text(request.get("id")) or _MANUAL_EDIT_ORIGINAL_ID
        snapshot_path = _manual_edit_snapshot_path(backup_dir, snapshot_id)
        if not os.path.isfile(snapshot_path):
            raise RuntimeError("that restore point no longer exists")
        with open(snapshot_path, "rb") as source:
            data = source.read()
        _manual_edit_capture(srv, root, path)
        _manual_edit_write(path, data)
        handler._json(
            200,
            {
                "ok": True,
                "path": path,
                "content": data.decode("utf-8", "replace"),
                "revertable": bool(_manual_edit_snapshot_ids(backup_dir)),
            },
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


@get("/project/file/revertable")
def _project_file_revertable(handler, parsed, request):
    import urllib.parse

    import awbench_server as srv

    try:
        query = urllib.parse.parse_qs(parsed.query)
        root = _project_root_for_reference(
            srv,
            project_id=srv.clean_text((query.get("project_id") or [""])[0]),
            root=srv.clean_text((query.get("root") or [""])[0]),
            session_id=srv.clean_text((query.get("session_id") or [""])[0]),
        )
        path = _safe_project_child_path(srv, root, (query.get("path") or [""])[0])
        backup_dir = _manual_edit_backup_dir(srv, root, path)
        handler._json(
            200,
            {"ok": True, "revertable": bool(_manual_edit_snapshot_ids(backup_dir))},
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


def _move_project_file(srv, root, from_path, to_dir):
    """Move one file into another folder inside the same project.

    Both ends go through the project-child guard, so a move can never reach
    outside the project however the paths are written. Refuses to overwrite:
    a silent replace of an existing file is not something a drag should be
    able to do by accident.

    A Godot `.import` sidecar travels with its file. Leaving one behind points
    the engine at a file that is no longer there, which is an import error the
    next time the project opens (v4.3.7).
    """
    import os
    import shutil

    source = _safe_project_child_path(srv, root, from_path)
    if not os.path.isfile(source):
        raise RuntimeError("that file is not there")
    folder = _safe_project_child_path(srv, root, to_dir)
    if not os.path.isdir(folder):
        raise RuntimeError("that is not a folder")
    name = os.path.basename(source)
    target = os.path.join(folder, name)
    if os.path.normcase(target) == os.path.normcase(source):
        return {"ok": True, "path": source, "moved": False}
    if os.path.exists(target):
        raise RuntimeError(f"{name} is already in that folder")
    shutil.move(source, target)
    moved = [target]
    sidecar = f"{source}.import"
    if os.path.isfile(sidecar):
        sidecar_target = f"{target}.import"
        if not os.path.exists(sidecar_target):
            shutil.move(sidecar, sidecar_target)
            moved.append(sidecar_target)
    return {"ok": True, "path": target, "moved": True, "files": moved}


@post("/project/move")
def _project_move(handler, parsed, request):
    """Drag a file onto a folder and it lands there (v4.3.7, requested: "I
    need to be able to drag them to a folder from awbn")."""
    import awbench_server as srv

    try:
        root = _project_root_for_reference(
            srv,
            project_id=srv.clean_text(request.get("project_id")),
            root=srv.clean_text(request.get("root")),
            session_id=srv.clean_text(request.get("session_id")),
        )
        result = _move_project_file(
            srv,
            root,
            srv.clean_text(request.get("from")),
            srv.clean_text(request.get("to_dir")),
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})
        return
    handler._json(200, result)


def _batch_tools_module(srv):
    """The batch tool server, imported as a library.

    The endpoint below runs exactly what an agent runs — same detection, same
    summarising — rather than a second copy that can drift from it."""
    import importlib.util

    path = srv.BATCH_TOOLS_SERVER
    spec = importlib.util.spec_from_file_location("awbn_batch_server", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("batch tools are not installed")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@post("/project/task")
def _project_task(handler, parsed, request):
    """Run a project's own tests, build or checks and return a short result.

    Requested as a button in the project pane: the work already existed as a
    tool an agent could call, but the owner should not have to ask an agent to
    run his own tests (v4.5.6).
    """
    import awbench_server as srv

    try:
        root = _project_root_for_reference(
            srv,
            project_id=srv.clean_text(request.get("project_id")),
            root=srv.clean_text(request.get("root")),
            session_id=srv.clean_text(request.get("session_id")),
        )
        task = srv.clean_text(request.get("task")) or "test"
        result = _batch_tools_module(srv).tool_run_task(root, task=task)
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})
        return
    handler._json(200, {"ok": True, **result})


@get("/project/file-preview")
def _project_file_preview(handler, parsed, request):
    import os

    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    session_id = srv.clean_text((query.get("session_id") or [""])[0])
    project_id = srv.clean_text((query.get("project_id") or [""])[0])
    requested_root = srv.clean_text((query.get("root") or [""])[0])
    raw_path = srv.clean_text((query.get("path") or [""])[0])
    try:
        root = _project_root_for_reference(
            srv,
            project_id=project_id,
            root=requested_root,
            session_id=session_id,
        )
        path = _safe_project_child_path(srv, root, raw_path)
        if not os.path.isfile(path):
            raise RuntimeError("file not found")
        file_info = _project_file_payload(srv, root, path, False, _git_status_for_project(root))
        content = ""
        truncated = False
        if file_info.get("is_text"):
            size = os.path.getsize(path)
            with open(path, "rb") as handle:
                data = handle.read(_PROJECT_PREVIEW_MAX_BYTES + 1)
            truncated = len(data) > _PROJECT_PREVIEW_MAX_BYTES or size > _PROJECT_PREVIEW_MAX_BYTES
            content = data[:_PROJECT_PREVIEW_MAX_BYTES].decode("utf-8", errors="replace")
        handler._json(
            200,
            {
                "ok": True,
                "root": root,
                "file": file_info,
                "content": content,
                "truncated": truncated,
                "max_bytes": _PROJECT_PREVIEW_MAX_BYTES,
            },
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


@get("/mcp/list")
def _mcp_list(handler, parsed, request):
    """Inspect configured MCP servers per agent (claude/codex/gemini `/mcp`).
    Claude's set is the curated --strict-mcp-config that every launch uses;
    codex/gemini come from their own `mcp list` subcommands."""
    import json as _json

    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    agent = srv.clean_text((query.get("agent") or ["claude"])[0]).lower()
    if agent not in _KNOWN_AGENTS:
        # `agent` becomes argv[0] of a subprocess below — never let an arbitrary
        # client string reach exec, even shell-less.
        handler._json(400, {"ok": False, "error": "unknown agent"})
        return
    if agent == "claude":
        servers = []
        try:
            config_path = srv.build_claude_mcp_config(include_delegate=False)
            data = srv.load_json(config_path, {}) or {}
            for name, spec in (data.get("mcpServers") or {}).items():
                command = ""
                if isinstance(spec, dict):
                    command = srv.clean_text(spec.get("command"))
                    args = spec.get("args")
                    if isinstance(args, list) and args:
                        command = (command + " " + " ".join(str(a) for a in args)).strip()
                servers.append({"name": name, "detail": command})
        except Exception as error:  # noqa: BLE001
            handler._json(200, {"ok": False, "agent": agent, "error": srv.clean_text(error)})
            return
        handler._json(200, {"ok": True, "agent": agent, "servers": servers, "raw": ""})
        return
    # codex / gemini: their own read-only list subcommands.
    cmd = [agent, "mcp", "list"]
    ok, out = _run_read_only(cmd, timeout=15)
    servers = []
    # Best-effort structured parse for codex's `key: command` lines; fall back to raw.
    for line in out.splitlines():
        line = line.strip()
        if not line or line.lower().startswith(("no mcp", "error", "usage")):
            continue
        if ":" in line:
            name, _, detail = line.partition(":")
            servers.append({"name": name.strip(), "detail": detail.strip()})
    handler._json(
        200,
        {"ok": ok, "agent": agent, "servers": servers, "raw": out[:4000]},
    )


@get("/project/git-diff")
def _git_diff(handler, parsed, request):
    """Git diff of the agent's changes, scoped to the session's project root.
    With worker worktree isolation (Priority 1) this shows ONLY that worker's
    isolated changes on its branch — the interactive review surface competitors
    ship (Vibe Kanban/Conductor) becomes genuinely useful here."""
    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    session_id = srv.clean_text((query.get("session_id") or [""])[0])
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    try:
        session = srv.load_session(session_id)
    except Exception as error:  # noqa: BLE001
        handler._json(404, {"ok": False, "error": srv.clean_text(error)})
        return
    # Always scope to the SESSION's own project root — never a raw client-
    # supplied path — so this can't be turned into "diff any directory".
    cwd = srv.infer_project_root(session, session.get("cwd"))
    if not cwd or not srv.looks_like_git_repo(cwd):
        handler._json(
            200,
            {"ok": False, "error": "not a git repository", "cwd": cwd, "diff": "", "files": []},
        )
        return
    # strip=False: git porcelain's status column is fixed-width and the first
    # line's leading space is significant — a blob strip would corrupt it.
    ok_status, status_out = _run_read_only(
        ["git", "-C", cwd, "status", "--porcelain"], timeout=15, strip=False
    )
    files = []
    for line in status_out.split("\n"):
        line = line.rstrip("\r")
        if len(line) >= 4:
            files.append({"status": line[:2].strip(), "path": line[3:].strip()})
    # `git diff HEAD` shows staged + unstaged tracked changes against the last
    # commit — the whole of what the agent has done since it started here.
    ok_diff, diff = _run_read_only(
        ["git", "-C", cwd, "diff", "HEAD"], timeout=20
    )
    branch = ""
    _ok, branch_out = _run_read_only(
        ["git", "-C", cwd, "rev-parse", "--abbrev-ref", "HEAD"], timeout=10
    )
    if _ok:
        branch = branch_out.strip()
    # Cap the diff so a huge change set can't recreate the giant-payload problem.
    truncated = len(diff) > 200_000
    handler._json(
        200,
        {
            "ok": True,
            "cwd": cwd,
            "branch": branch,
            "files": files,
            "diff": diff[:200_000],
            "truncated": truncated,
        },
    )


@get("/agent/doctor")
def _agent_doctor(handler, parsed, request):
    """Read-only health snapshot per agent (claude `/doctor`, codex `doctor`,
    gemini `/status`). Deliberately assembled from fast, non-interactive probes
    (version + auth/config presence) so it can never hang like the real TUI
    doctor might — bounded diagnostics, not a live session."""
    import os

    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    agent = srv.clean_text((query.get("agent") or ["claude"])[0]).lower()
    checks = []

    def probe(label, cmd, timeout=10):
        ok, out = _run_read_only(cmd, timeout=timeout)
        checks.append({"label": label, "ok": ok, "detail": out[:400]})

    if agent == "claude":
        probe("claude version", ["claude", "--version"])
        checks.append(
            {
                "label": "auth config (~/.claude.json)",
                "ok": os.path.isfile(os.path.expanduser("~/.claude.json")),
                "detail": os.path.expanduser("~/.claude.json"),
            }
        )
        try:
            config_path = srv.build_claude_mcp_config(include_delegate=False)
            data = srv.load_json(config_path, {}) or {}
            n = len(data.get("mcpServers") or {})
            checks.append(
                {"label": "curated MCP servers", "ok": True, "detail": f"{n} server(s) loaded"}
            )
        except Exception as error:  # noqa: BLE001
            checks.append({"label": "curated MCP servers", "ok": False, "detail": srv.clean_text(error)})
    elif agent == "codex":
        probe("codex version", ["codex", "--version"])
        checks.append(
            {
                "label": "auth (~/.codex/auth.json)",
                "ok": os.path.isfile(os.path.expanduser("~/.codex/auth.json")),
                "detail": os.path.expanduser("~/.codex/auth.json"),
            }
        )
    elif agent == "gemini":
        probe("gemini version", ["gemini", "--version"])
        checks.append(
            {
                "label": "auth (~/.gemini)",
                "ok": os.path.isdir(os.path.expanduser("~/.gemini")),
                "detail": os.path.expanduser("~/.gemini"),
            }
        )
    else:
        handler._json(200, {"ok": False, "agent": agent, "error": "unsupported agent", "checks": []})
        return
    handler._json(
        200,
        {"ok": all(c["ok"] for c in checks), "agent": agent, "checks": checks},
    )


@get("/hooks/list")
def _hooks_list(handler, parsed, request):
    """Read-only view of configured hooks (claude/codex/gemini `/hooks`).
    Claude's live in settings.json; codex/gemini surface via their config or a
    read-only subcommand where one exists. No editing — inspection only."""
    import os

    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    agent = srv.clean_text((query.get("agent") or ["claude"])[0]).lower()
    hooks = []
    if agent == "claude":
        for path in (
            os.path.expanduser("~/.claude/settings.json"),
            os.path.expanduser("~/.claude/settings.local.json"),
        ):
            data = srv.load_json(path, {}) or {}
            hook_cfg = data.get("hooks")
            if isinstance(hook_cfg, dict):
                for event, entries in hook_cfg.items():
                    count = len(entries) if isinstance(entries, list) else 0
                    hooks.append(
                        {
                            "event": event,
                            "detail": f"{count} hook(s)",
                            "source": os.path.basename(path),
                        }
                    )
        handler._json(200, {"ok": True, "agent": agent, "hooks": hooks})
        return
    if agent == "gemini":
        ok, out = _run_read_only(["gemini", "hooks"], timeout=12)
        handler._json(200, {"ok": ok, "agent": agent, "hooks": [], "raw": out[:3000]})
        return
    # codex: hooks live in ~/.codex/config.toml — surface presence, don't parse TOML.
    config_path = os.path.expanduser("~/.codex/config.toml")
    present = os.path.isfile(config_path)
    handler._json(
        200,
        {
            "ok": True,
            "agent": agent,
            "hooks": [],
            "raw": f"See {config_path}" if present else "No codex config found.",
        },
    )


# ---------------------------------------------------------------------------
# Terminal-replacement plan, Phase 4 — on-demand actions
# ---------------------------------------------------------------------------


@post("/session/compact")
def _session_compact(handler, parsed, request):
    """Compact context (claude `/compact`, codex `/compact`, gemini
    `/compress`). Claude interprets `/compact` in headless -p mode, so this
    returns a directive the client sends through the normal /send flow. Codex/
    gemini treat a slash line as a prompt, not a command (verified in the
    plan's Part 0), so for them this reports that in-turn compaction isn't
    available and points at reset-context instead — honest, not a fake button.
    """
    import awbench_server as srv

    session_id = srv.clean_text(request.get("session_id"))
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    try:
        session = srv.load_session(session_id)
    except Exception as error:  # noqa: BLE001
        handler._json(404, {"ok": False, "error": srv.clean_text(error)})
        return
    agent = srv.clean_text(session.get("agent")).lower()
    if agent == "claude":
        handler._json(
            200,
            {
                "ok": True,
                "agent": agent,
                "mode": "send",
                "message": "/compact",
                "note": "Claude compacts in-place when sent /compact.",
            },
        )
        return
    handler._json(
        200,
        {
            "ok": False,
            "agent": agent,
            "mode": "unsupported",
            "note": (
                f"{agent} has no headless in-turn compaction. Use New chat "
                "(reset context) — project AGENT_STATE carries continuity."
            ),
        },
    )


@post("/review")
def _review(handler, parsed, request):
    """On-demand review (claude `/review`, codex `codex review`). Returns a
    directive the client runs through /send for claude; codex has a real
    `review` subcommand but running it as a full turn belongs on the streaming
    path, so this likewise hands back a send directive rather than blocking the
    HTTP request on a long model turn."""
    import awbench_server as srv

    session_id = srv.clean_text(request.get("session_id"))
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    try:
        session = srv.load_session(session_id)
    except Exception as error:  # noqa: BLE001
        handler._json(404, {"ok": False, "error": srv.clean_text(error)})
        return
    agent = srv.clean_text(session.get("agent")).lower()
    if agent == "gemini":
        handler._json(
            200,
            {"ok": False, "agent": agent, "note": "Gemini has no review command."},
        )
        return
    message = (
        "/review"
        if agent == "claude"
        else "Review the current changes for correctness, security, and "
        "regressions. Report findings grouped by severity."
    )
    handler._json(
        200,
        {"ok": True, "agent": agent, "mode": "send", "message": message},
    )


@post("/project/init")
def _project_init(handler, parsed, request):
    """Create/refresh the project memory file (claude `/init` → CLAUDE.md,
    codex → AGENTS.md, gemini → GEMINI.md). Returns a send directive so the
    agent authors it from the real repository, matching each CLI's own /init."""
    import awbench_server as srv

    session_id = srv.clean_text(request.get("session_id"))
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    try:
        session = srv.load_session(session_id)
    except Exception as error:  # noqa: BLE001
        handler._json(404, {"ok": False, "error": srv.clean_text(error)})
        return
    agent = srv.clean_text(session.get("agent")).lower()
    filename = {"claude": "CLAUDE.md", "codex": "AGENTS.md", "gemini": "GEMINI.md"}.get(
        agent, "CLAUDE.md"
    )
    message = (
        "/init"
        if agent == "claude"
        else f"Analyze this codebase and write a concise {filename} describing "
        "its structure, build/test commands, and conventions."
    )
    handler._json(
        200,
        {"ok": True, "agent": agent, "mode": "send", "message": message, "file": filename},
    )


@post("/project/memory")
def _project_memory_write(handler, parsed, request):
    """Write the shared project memory file (AGENT_STATE.md) for a session's
    project root. Read is already served by /project-state; this is the editor
    save path (reuses the artifact-editor pattern in the UI). Bounded, atomic,
    and scoped to the session's inferred project root."""
    import os

    import awbench_server as srv

    session_id = srv.clean_text(request.get("session_id"))
    content = request.get("content")
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    if not isinstance(content, str):
        handler._json(400, {"ok": False, "error": "content must be a string"})
        return
    try:
        session = srv.load_session(session_id)
    except Exception as error:  # noqa: BLE001
        handler._json(404, {"ok": False, "error": srv.clean_text(error)})
        return
    root = srv.infer_project_root(session, session.get("cwd"))
    if not root or not os.path.isdir(root):
        handler._json(400, {"ok": False, "error": "no writable project root for this session"})
        return
    path = srv.project_state_path(root)
    try:
        srv.save_text_atomic(path, content)
    except (OSError, ValueError, UnicodeError) as error:
        # UnicodeError: client JSON can carry unpaired surrogates (e.g. \ud800)
        # that only fail at UTF-8 encode time inside save_text_atomic — return
        # JSON, don't let it bubble to a 500.
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})
        return
    srv.append_debug_event("project_memory_write", session=session_id, path=path, bytes=len(content))
    handler._json(200, {"ok": True, "path": path})


# ---------------------------------------------------------------------------
# Interactive diff review — commit + merge a worker's isolated worktree branch
# back into its source repo. Only meaningful for worker sessions (Priority 1
# worktree isolation); makes that isolation actually pay off.
# ---------------------------------------------------------------------------


def _resolve_worktree_session(srv, request):
    """Return (session, worktree, branch, source_root, error).

    error is a (status, message) tuple when the session is not a reviewable
    worker (no worktree / worktree gone); None when everything checks out."""
    import os
    import re

    session_id = srv.clean_text(request.get("session_id"))
    if not session_id:
        return None, "", "", "", (400, "missing session_id")
    try:
        session = srv.load_session(session_id)
    except Exception as error:  # noqa: BLE001
        return None, "", "", "", (404, srv.clean_text(error))
    branch = srv.clean_text(session.get("worktree_branch"))
    raw_wt = srv.clean_text(session.get("worktree_path"))
    if not raw_wt or not branch:
        return session, "", "", "", (400, "this session has no isolated worktree to review")
    worktree = os.path.abspath(os.path.expanduser(raw_wt))
    raw_source_root = srv.clean_text(session.get("worktree_source_root"))
    source_root = (
        os.path.abspath(os.path.expanduser(raw_source_root)) if raw_source_root else ""
    )
    # Never operate on a path outside the managed worktrees dir.
    if not worktree.startswith(srv.WORKTREES_DIR + os.sep) or not os.path.isdir(worktree):
        return session, "", "", "", (409, "the worktree for this session is missing")
    if not re.fullmatch(r"awbn/worker-[A-Za-z0-9_-]+", branch):
        return session, "", "", "", (409, "the worker branch metadata is invalid")
    actual_source_root = srv.git_main_repo_root(worktree)
    if not source_root or not actual_source_root or os.path.realpath(
        source_root
    ) != os.path.realpath(actual_source_root):
        return session, "", "", "", (
            409,
            "the worker source-repository metadata does not match its worktree",
        )
    return session, worktree, branch, source_root, None


def _stop_active_turn(srv, session_id):
    """Stop any in-flight turn before we git-operate on the worker's worktree,
    so the resident agent process can't be writing files mid-commit. Mirrors
    ui_delete_session / reset-context, plus a short bounded wait for the turn to
    actually clear (a stopped turn finalizes asynchronously)."""
    import time

    with srv.ACTIVE_LOCK:
        control = srv.ACTIVE_TURNS.get(session_id)
    if not control:
        return
    control.stop()
    deadline = time.monotonic() + 4.0
    while time.monotonic() < deadline:
        with srv.ACTIVE_LOCK:
            if session_id not in srv.ACTIVE_TURNS:
                return
        time.sleep(0.1)


def _commit_worktree(srv, worktree, message):
    """Stage + commit everything in *worktree*. Returns (status, sha, note)
    where status is 'committed' | 'clean' | 'failed' — the three cases must be
    distinguishable so a caller (merge) can refuse to proceed on a real
    failure rather than silently merging a stale branch."""
    srv._run_git(["add", "-A"], worktree, timeout=60)
    # `diff --cached --quiet` exits 0 when nothing is staged.
    nothing_staged, _, _ = srv._run_git(["diff", "--cached", "--quiet"], worktree)
    if nothing_staged:
        return "clean", "", "nothing to commit"
    ok, _, err = srv._run_git(
        [
            "-c",
            "user.email=agent-workbench@local",
            "-c",
            "user.name=Agent Workbench",
            "commit",
            "-m",
            message,
        ],
        worktree,
        timeout=60,
    )
    if not ok:
        return "failed", "", (err or "commit failed")[:300]
    _, sha, _ = srv._run_git(["rev-parse", "--short", "HEAD"], worktree)
    return "committed", sha, "committed"


@post("/worktree/commit")
def _worktree_commit(handler, parsed, request):
    """Commit the worker's current worktree state onto its branch, so the work
    is preserved as real commits (agents edit files but don't always commit)."""
    import os

    import awbench_server as srv

    session, worktree, branch, _source, error = _resolve_worktree_session(srv, request)
    if error:
        handler._json(error[0], {"ok": False, "error": error[1]})
        return
    session_id = srv.clean_text(session.get("id"))
    message = srv.clean_text(request.get("message")) or f"Agent Workbench worker: {branch}"
    _stop_active_turn(srv, session_id)
    # Hold the session lock across the git ops so a concurrent delete (which
    # force-removes the worktree under the same lock) can't rip it out mid-commit.
    with srv.locked_sessions(session_id):
        if not os.path.isdir(worktree):
            handler._json(409, {"ok": False, "error": "the worktree was removed"})
            return
        status, sha, note = _commit_worktree(srv, worktree, message)
    if status == "failed":
        handler._json(
            409, {"ok": False, "error": f"could not commit worker changes: {note}"}
        )
        return
    srv.append_debug_event(
        "worktree_commit", session=session_id, branch=branch, status=status
    )
    handler._json(
        200,
        {
            "ok": True,
            "committed": status == "committed",
            "commit": sha,
            "branch": branch,
            "note": note,
        },
    )


@post("/worktree/merge")
def _worktree_merge(handler, parsed, request):
    """Review-then-merge: commit any pending worker changes, then merge the
    worker's branch into the source repo's current branch. Refuses if the
    source's tracked files are dirty or it's on a detached HEAD; aborts cleanly
    on conflict (never leaves the source half-merged), reporting conflicted
    files; and never proceeds if committing the worker's own changes failed."""
    import os

    import awbench_server as srv

    session, worktree, branch, source_root, error = _resolve_worktree_session(srv, request)
    if error:
        handler._json(error[0], {"ok": False, "error": error[1]})
        return
    if (
        not source_root
        or not os.path.isdir(source_root)
        or not srv.git_main_repo_root(source_root)
    ):
        handler._json(409, {"ok": False, "error": "source repository is unavailable"})
        return
    session_id = srv.clean_text(session.get("id"))
    message = srv.clean_text(request.get("message")) or f"Agent Workbench worker: {branch}"
    _stop_active_turn(srv, session_id)
    with srv.locked_sessions(session_id):
        if not os.path.isdir(worktree):
            handler._json(409, {"ok": False, "error": "the worktree was removed"})
            return
        # The source's TRACKED files must be clean (untracked files — e.g.
        # AWBN's own .agent-workbench/ registry — don't block a merge).
        unstaged_clean, _, _ = srv._run_git(["diff", "--quiet"], source_root)
        staged_clean, _, _ = srv._run_git(["diff", "--cached", "--quiet"], source_root)
        if not (unstaged_clean and staged_clean):
            handler._json(
                409,
                {
                    "ok": False,
                    "error": "the source repo has uncommitted changes to tracked files — commit or stash them first",
                },
            )
            return
        ok_branch, target_branch, _ = srv._run_git(
            ["rev-parse", "--abbrev-ref", "HEAD"], source_root
        )
        target_branch = target_branch.strip() if ok_branch else ""
        # A detached HEAD has no branch to hold the merge commit — the result
        # would be an unreferenced orphan. Refuse rather than lose the merge.
        if not target_branch or target_branch == "HEAD":
            handler._json(
                409,
                {
                    "ok": False,
                    "error": "the source repo is on a detached HEAD — check out a branch before merging",
                },
            )
            return
        # Commit the worker's own changes first; a genuine commit failure must
        # stop us (merging now would silently exclude the uncommitted work).
        status, _sha, note = _commit_worktree(srv, worktree, message)
        if status == "failed":
            handler._json(
                409,
                {
                    "ok": False,
                    "error": f"could not commit worker changes before merge: {note}",
                },
            )
            return
        ok_merge, out_merge, err_merge = srv._run_git(
            ["merge", "--no-ff", "-m", f"Merge worker branch {branch}", branch],
            source_root,
            timeout=120,
        )
        if not ok_merge:
            detail = (err_merge or out_merge or "merge failed").strip()
            # A merge only leaves state to clean up once it has actually started
            # (MERGE_HEAD exists). Pre-merge refusals (e.g. untracked files that
            # would be overwritten) never create it, so don't --abort blindly.
            merge_started = os.path.exists(
                os.path.join(source_root, ".git", "MERGE_HEAD")
            )
            _, conflicts_out, _ = srv._run_git(
                ["diff", "--name-only", "--diff-filter=U"], source_root
            )
            conflicts = [c.strip() for c in conflicts_out.splitlines() if c.strip()]
            abort_warning = ""
            if merge_started:
                ok_abort, _, _ = srv._run_git(
                    ["merge", "--abort"], source_root, timeout=60
                )
                if not ok_abort:
                    abort_warning = (
                        " WARNING: could not auto-abort the merge — the source "
                        "repo may be left half-merged; run `git merge --abort` "
                        "there manually."
                    )
            handler._json(
                200,
                {
                    "ok": False,
                    "merged": False,
                    "target_branch": target_branch,
                    "conflicts": conflicts,
                    "blocked_untracked": "would be overwritten by merge" in detail,
                    "note": (detail[:400] + abort_warning),
                },
            )
            return
        _, merge_sha, _ = srv._run_git(["rev-parse", "--short", "HEAD"], source_root)
    srv.append_debug_event(
        "worktree_merge", session=session_id, branch=branch, target=target_branch
    )
    handler._json(
        200,
        {
            "ok": True,
            "merged": True,
            "target_branch": target_branch,
            "commit": merge_sha,
            "committed_worker_changes": status == "committed",
            "note": f"Merged {branch} into {target_branch}",
        },
    )


def _salvage_full_delta(srv, session_id, worktree, source_root, have_repo):
    """Save the worker's COMPLETE delta (committed + uncommitted) to the
    session's artifacts before its branch/worktree are destroyed. Discard
    deletes the branch, so committed work would be lost without this — the
    uncommitted-only salvage in remove_session_worktree isn't enough here.

    Returns one of:
      "saved"  — the worker's work was written to Artifacts.
      "empty"  — the worktree had no work beyond its fork point (nothing to lose).
      "failed" — there WAS (or might be) work but it could not be salvaged; the
                 caller must NOT destroy the worktree/branch in this case.
    """
    import os

    if not session_id:
        return "failed"
    try:
        artifact_dir = srv.artifact_session_dir(session_id)
    except OSError:
        return "failed"
    srv._run_git(["add", "-A"], worktree, timeout=60)
    # Diff from the branch's fork point (merge-base with the source's HEAD) so
    # the salvage includes committed commits, not just staged/uncommitted work.
    base = ""
    if have_repo:
        ok_head, src_head, _ = srv._run_git(["rev-parse", "HEAD"], source_root)
        if ok_head and src_head.strip():
            ok_mb, mb, _ = srv._run_git(
                ["merge-base", "HEAD", src_head.strip()], worktree
            )
            if ok_mb and mb.strip():
                base = mb.strip()
    ok_diff, diff = False, ""
    if base:
        ok_diff, diff, _ = srv._run_git(["diff", base], worktree, timeout=60)
    elif not have_repo:
        # Non-git worktree: no fork point exists, so a --cached diff is the best
        # obtainable delta. (When have_repo is true but merge-base FAILED, we do
        # NOT trust a partial --cached diff — it omits committed history — and
        # fall through to the full-tree copy below instead.)
        ok_diff, diff, _ = srv._run_git(["diff", "--cached"], worktree, timeout=60)
    if ok_diff and diff.strip():
        try:
            srv.save_text_atomic(
                os.path.join(artifact_dir, "worktree-discarded.diff"), diff + "\n"
            )
            return "saved"
        except OSError:
            return "failed"  # there was a diff but we couldn't write it
    if ok_diff and not diff.strip() and base:
        return "empty"  # clean worktree with a known fork point: nothing to lose
    # Diff couldn't be computed (or fork point unknown with a repo present) —
    # copy the whole tree (minus .git) so nothing is silently lost. A copy that
    # can't complete is a real failure the caller must respect.
    try:
        dest = os.path.join(artifact_dir, "worktree-discarded")
        copied = False
        for name in os.listdir(worktree):
            if name == ".git":
                continue
            srv.copy_missing_tree(
                os.path.join(worktree, name), os.path.join(dest, name)
            )
            copied = True
        return "saved" if copied else "empty"
    except (OSError, RuntimeError):
        return "failed"


@post("/worktree/discard")
def _worktree_discard(handler, parsed, request):
    """Reject a worker's work (the other half of the review loop): salvage its
    full delta to Artifacts, remove the worktree, and DELETE its branch. The
    session and its conversation are kept (with a discarded marker) so the
    rejected attempt — and the salvaged diff — remain accessible."""
    import os

    import awbench_server as srv

    session, worktree, branch, source_root, error = _resolve_worktree_session(srv, request)
    if error:
        handler._json(error[0], {"ok": False, "error": error[1]})
        return
    session_id = srv.clean_text(session.get("id"))
    _stop_active_turn(srv, session_id)
    # Hard-tear-down the resident agent process BEFORE removing the worktree:
    # it holds the worktree as its cwd, a graceful interrupt may not have landed
    # in time, and the session must be relaunchable afterward against a valid cwd.
    srv.close_claude_stream_session(session_id)
    with srv.locked_sessions(session_id):
        if not os.path.isdir(worktree):
            handler._json(409, {"ok": False, "error": "the worktree was removed"})
            return
        have_repo = (
            bool(source_root)
            and os.path.isdir(source_root)
            and bool(srv.git_main_repo_root(source_root))
        )
        # Salvage FIRST and refuse to destroy anything if it genuinely failed —
        # the branch is the durable fallback record, so keeping it (and the
        # worktree) lets the user retry or rescue rather than lose the work.
        salvage_status = _salvage_full_delta(
            srv, session_id, worktree, source_root, have_repo
        )
        if salvage_status == "failed":
            handler._json(
                500,
                {
                    "ok": False,
                    "error": (
                        "could not salvage the worker's work — the worktree and "
                        "branch were left intact so you can retry or rescue it "
                        "manually"
                    ),
                },
            )
            return
        # Reuse the hardened remover (safety gates + retry + rmtree fallback).
        # It reads the worktree_* fields, so this must run BEFORE we clear them.
        remove_error = srv.remove_session_worktree(
            session,
            allow_dirty_after_salvage=True,
        )
        if remove_error:
            handler._json(
                500,
                {
                    "ok": False,
                    "error": (
                        "the worker changes were salvaged, but its worktree could "
                        f"not be removed: {remove_error}"
                    ),
                },
            )
            return
        # Delete the branch now the worktree no longer holds it checked out.
        branch_deleted = False
        if have_repo:
            ok_del, _, _ = srv._run_git(["branch", "-D", branch], source_root, timeout=30)
            branch_deleted = ok_del
        # Clear the worktree fields so the session is no longer reviewable, and
        # repoint cwd/project_root at the source repo — they were the (now
        # deleted) worktree path, which would break the session's next turn.
        fallback_cwd = source_root if (source_root and os.path.isdir(source_root)) else ""
        for key in (
            "worktree_path",
            "worktree_branch",
            "worktree_source_root",
            "native_cwd",
        ):
            session.pop(key, None)
        if fallback_cwd:
            session["cwd"] = fallback_cwd
            session["project_root"] = fallback_cwd
        session["worktree_discarded_at"] = srv.now_iso()
        session["worktree_discarded_branch"] = branch
        session["updated_at"] = srv.now_iso()
        srv.save_session(session)
    srv.append_debug_event(
        "worktree_discard",
        session=session_id,
        branch=branch,
        branch_deleted=branch_deleted,
        salvaged=salvage_status,
    )
    handler._json(
        200,
        {
            "ok": True,
            "branch": branch,
            "branch_deleted": branch_deleted,
            "salvaged": salvage_status != "empty",
            "note": f"Discarded {branch}. Worker changes salvaged to Artifacts.",
        },
    )


@get("/session/file-activity")
def _file_activity(handler, parsed, request):
    """Per-session file-level traceability: which files the agent read/wrote,
    aggregated from the structured file_op/file_path captured on tool events.
    Distinct from the chronological Work Log — this is a clean per-file view."""
    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    session_id = srv.clean_text((query.get("session_id") or [""])[0])
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    try:
        session = srv.load_session(session_id)
    except Exception as error:  # noqa: BLE001
        handler._json(404, {"ok": False, "error": srv.clean_text(error)})
        return
    files = {}
    for turn in session.get("turns") or []:
        if not isinstance(turn, dict):
            continue
        ts = srv.clean_text(turn.get("completed_at") or turn.get("created_at"))
        for item in turn.get("items") or []:
            if not isinstance(item, dict):
                continue
            op = srv.clean_text(item.get("file_op"))
            path = srv.clean_text(item.get("file_path"))
            if op not in ("read", "write") or not path:
                continue
            record = files.setdefault(
                path,
                {"path": path, "reads": 0, "writes": 0, "last_op": "", "last_at": ""},
            )
            record["reads" if op == "read" else "writes"] += 1
            record["last_op"] = op
            if ts:
                record["last_at"] = ts
    records = list(files.values())
    # Written files first (the significant changes), then by most-recent touch.
    records.sort(key=lambda r: (r["writes"] > 0, r["last_at"]), reverse=True)
    handler._json(
        200,
        {
            "ok": True,
            "files": records[:300],
            "files_written": sum(1 for r in records if r["writes"] > 0),
            "files_read": sum(1 for r in records if r["reads"] > 0),
            "total_files": len(records),
        },
    )


@post("/session/import")
def _session_import(handler, parsed, request):
    """Pin (or un-pin) a discovered terminal/Codex/Claude session into the
    primary session list. Native sessions are import-on-demand: they stay out
    of the clean default list until the user explicitly imports one here.
    Body: {session_id, imported?: bool (default true)}.
    """
    import awbench_server as srv

    session_id = srv.clean_text(request.get("session_id"))
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    imported = request.get("imported")
    imported = True if imported is None else bool(imported)
    try:
        with srv.locked_sessions(session_id):
            session = srv.load_session(session_id)
            if imported:
                session["user_imported"] = True
            else:
                session.pop("user_imported", None)
            session["updated_at"] = srv.now_iso()
            srv.save_session(session)
        srv.append_debug_event(
            "session_import", session=session_id, imported=imported
        )
        handler._json(
            200,
            {"ok": True, "session": srv.ui_session_summary(session)},
        )
    except Exception as error:  # noqa: BLE001
        handler._json(400, {"ok": False, "error": srv.clean_text(error)})


@get("/session/permission-requests")
def _permission_requests(handler, parsed, request):
    """Pending claude can_use_tool prompts for a session — lets the UI
    repopulate approve/deny cards after a reconnect or app restart."""
    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    session_id = srv.clean_text((query.get("session_id") or [""])[0])
    handler._json(
        200, {"ok": True, "requests": srv.pending_permissions_for(session_id)}
    )


@post("/session/permission-response")
def _permission_response(handler, parsed, request):
    """Answer a pending claude permission prompt (terminal-replacement plan
    Part 5a). Writes a control_response frame onto the resident stream-json
    process's stdin; claude then runs or skips the tool and the turn resumes."""
    import awbench_server as srv

    request_id = srv.clean_text(request.get("request_id"))
    behavior = srv.clean_text(request.get("behavior")).lower()
    message = srv.clean_text(request.get("message"))
    if behavior not in ("allow", "deny"):
        handler._json(400, {"ok": False, "error": "behavior must be allow or deny"})
        return
    entry = srv.pop_pending_permission(request_id)
    if not entry:
        handler._json(404, {"ok": False, "error": "no such pending permission request"})
        return
    stream = srv.CLAUDE_STREAM_SESSIONS.get(entry["session_id"])
    if not stream or not stream.is_alive():
        handler._json(
            409,
            {"ok": False, "error": "the claude process for this request is no longer running"},
        )
        return
    if behavior == "allow":
        response = {"behavior": "allow", "updatedInput": entry.get("input") or {}}
    else:
        response = {
            "behavior": "deny",
            "message": message or "Denied by the user from Agent Workbench.",
        }
    try:
        stream.write_control_response(entry["id"], response=response)
    except (OSError, BrokenPipeError) as error:
        handler._json(500, {"ok": False, "error": f"could not reach claude: {error}"})
        return
    srv.append_debug_event(
        "permission_response",
        session=entry["session_id"],
        tool=entry["tool"],
        behavior=behavior,
    )
    handler._json(200, {"ok": True, "request_id": entry["id"], "behavior": behavior})


@post("/session/kanban-phase")
def _kanban_phase(handler, parsed, request):
    """Set a session's kanban phase (the board column it lives in). Persisted
    on the session so the board layout survives restarts."""
    import awbench_server as srv

    session_id = srv.clean_text(request.get("session_id"))
    phase = srv.clean_text(request.get("phase")).lower()
    if not session_id:
        handler._json(400, {"ok": False, "error": "missing session_id"})
        return
    if phase not in _KANBAN_PHASES:
        handler._json(400, {"ok": False, "error": f"unknown phase '{phase}'"})
        return
    try:
        with srv.locked_sessions(session_id):
            session = srv.load_session(session_id)
            session["kanban_phase"] = phase
            session["updated_at"] = srv.now_iso()
            srv.save_session(session)
    except Exception as error:  # noqa: BLE001
        handler._json(404, {"ok": False, "error": srv.clean_text(error)})
        return
    handler._json(200, {"ok": True, "session_id": session_id, "phase": phase})


@get("/limits/breakdown")
def _limits_breakdown(handler, parsed, request):
    """What actually drove usage in the current 5h/week window, per AWBN
    session — the provider APIs (claude's /usage, codex's local rollouts)
    only ever report an aggregate percentage, never a breakdown. This is
    computed from AWBN's own already-recorded per-turn token/item data, so
    it's an AWBN-activity view (only turns run through this app), not the
    provider's authoritative account-wide ledger — the dialog that renders
    this says so explicitly rather than implying more precision than it has.
    """
    import time
    from pathlib import Path

    import awbench_server as srv

    query = srv.urllib.parse.parse_qs(parsed.query)
    agent = srv.clean_text((query.get("agent") or [""])[0]).lower()
    window = srv.clean_text((query.get("window") or ["5h"])[0]).lower()
    seconds = 5 * 3600 if window in ("5h", "5hr", "5-hour") else 7 * 24 * 3600
    cutoff = time.time() - seconds

    tool_item_types = {"commandExecution", "fileChange", "reasoning"}
    entries = []
    try:
        paths = list(Path(srv.SESS_DIR).glob("*.json"))
    except OSError:
        paths = []

    for path in paths:
        try:
            # Cheap pre-filter: skip anything not touched inside the window
            # before ever opening/parsing it — several session files here
            # run into the tens of megabytes (see fable-prep/02), so paying
            # a full JSON parse for files that couldn't possibly qualify
            # would make this endpoint needlessly slow.
            if path.stat().st_mtime < cutoff:
                continue
        except OSError:
            continue
        session = srv.load_json(str(path), None)
        if not isinstance(session, dict):
            continue
        if srv.clean_text(session.get("agent")).lower() != agent:
            continue

        tokens = 0
        tool_turns = 0
        message_turns = 0
        for turn in session.get("turns") or []:
            ts = srv.parse_iso_timestamp(
                turn.get("completed_at") or turn.get("created_at")
            )
            if not ts or ts.timestamp() < cutoff:
                continue
            usage = turn.get("usage") or {}
            tokens += int(usage.get("total_tokens") or 0)
            items = turn.get("items") or []
            if any(srv.clean_text(item.get("type")) in tool_item_types for item in items):
                tool_turns += 1
            else:
                message_turns += 1

        if tokens <= 0 and tool_turns == 0 and message_turns == 0:
            continue
        entries.append(
            {
                "session_id": srv.clean_text(session.get("id")),
                "title": srv.clean_text(session.get("title")) or "Untitled",
                "tokens": tokens,
                "tool_call_turns": tool_turns,
                "message_turns": message_turns,
            }
        )

    entries.sort(key=lambda entry: entry["tokens"], reverse=True)
    handler._json(200, {"ok": True, "window": window, "sessions": entries[:12]})
